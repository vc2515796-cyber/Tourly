# Tourly3D Stage B — Production Readiness Report

## Changes made in this review

- Corrected the Gemini image-generation model ID to Google's documented stable `gemini-3.1-flash-image`. The previous `gemini-3.8-flash-image-preview` ID was not in the published model catalogue and could make all image-generation features fail.
- Added server-side MIME-type allowlisting (JPEG, PNG, WebP) and a base64 payload-size/encoding guard to the panorama generation, 3D render generation, panorama enhancement, and seam-fix endpoints. This rejects unsupported or excessively large image requests before forwarding them to the AI provider.
- Re-ran the frontend secret scan successfully.
- Checked JavaScript syntax for all `scripts/*.mjs` files successfully.
- Confirmed `package.json` and `package-lock.json` root dependency names are consistent.
- Confirmed the ZIP archive passes its integrity test.

## Verification still required before production launch

The full production build and automated test suites have **not** been verified in this environment: installing npm dependencies timed out before completion. Do not interpret the checks above as a successful TypeScript/Vite build or successful Netlify Functions test run.

Before replacing the live site:

1. Run `npm ci` in the `tourly3d/` directory and confirm it finishes successfully.
2. Run `npm run build`.
3. Run `npm run test:units` and `npm run test:smoke`.
4. Set the Firebase web configuration variables, `FIREBASE_SERVICE_ACCOUNT_KEY`, and `GEMINI_API_KEY` in Netlify. Keep service-account and Gemini keys server-side; never prefix them with `VITE_`.
5. Deploy a Preview Deploy first. Test sign-in, create/edit a floor plan, upload media, publish a tour, open the public tour on a separate browser, submit an enquiry, and test each AI feature with a small image.
6. Confirm the deployed Netlify Functions logs show no configuration, authorization, storage, or provider errors before promoting the deploy.

Optional S3/R2 storage and messaging integrations need their own credentials and provider-side setup. Without them, those optional features should remain unconfigured rather than being treated as tested.

## Deployment settings

- Base directory: `tourly3d` (when the ZIP is extracted into a repository with this folder)
- Build command: `npm run build`
- Publish directory: `dist`
- Functions directory: `netlify/functions`

This report deliberately distinguishes completed static checks from unrun build/runtime checks. Production readiness cannot be certified until the required commands and live Preview Deploy tests pass.

---

## Round 2 — full verification of this checklist (2026-10-16)

The three "verification still required" commands above have now been run on
this exact tree, plus the deployment-relevant extras. Environment: Node
v24.21.0, npm 11.19.0, fresh `node_modules` from the lockfile.

| Check | Command | Result |
|---|---|---|
| Dependency install | `npm ci` | exit 0 |
| Production build (incl. TS + functions typecheck + secret scan) | `npm run build` | exit 0 (≈5.3 s) |
| Unit suites (pHash + plan geometry) | `npm run test:units` | exit 0 — 83 passed, 0 failed |
| Function + auth + leads + analytics smoke suites | `npm run test:smoke` | exit 0 — 116 passed, 0 failed (incl. 36 new analytics checks) |
| Production-only install guard | `rm -rf node_modules && npm ci --omit=dev && npm run build` | exit 0 |

Additionally verified this round, beyond the checklist:

- Real-browser run of the production build (headless Chromium): public tour
  page, engagement event firing (tour-view once per session, refresh-safe;
  scene-view; hotspot click; source tagging for `?src=qr` / `?src=embed`),
  enquiry submission with the site-visit flag, embed banner, QR generation
  from the shipped chunk (the PNG was decoded by an independent QR decoder
  to the exact expected URL), and the honest unconfigured states of
  /analytics, /leads and /dashboard. Zero page errors.
- A real bug was found by that browser pass and fixed: panorama hotspot
  pins never rendered at any camera orientation (impossible visibility
  condition). Re-verified fixed in the browser.
- The two changes from the previous review (Gemini image model ID and the
  MIME/base64 guards on the four image endpoints) are intact and pass the
  full matrix above. The model ID `gemini-3.1-flash-image` is still NOT
  live-verified against Google's API — that needs a preview deploy with a
  real `GEMINI_API_KEY` (checklist item 5 remains a manual step).

Items 4–6 of the original checklist (env vars in Netlify, Preview Deploy
smoke test, function-log review) still require a deployment with real
credentials — unchanged and documented in DEPLOY.md / AUTH-SETUP.md.

---

## Round 3 — Gemini reliability & fallback engine (2026-10-16)

Base: the Round-2 deliverable, uploaded back byte-identical (sha256
`683797c4…22c8`). This round adds the server-side Gemini model-fallback
system requested for production hardening.

**Completed (all commands exit 0, full matrix in VERIFICATION.md):**

- New `netlify/functions/_gemini.mts`: primary + fallback models per kind
  (text/image), all four defaults verified against Google's official model
  catalogue (2026-10-06 page date); bounded retries (default 2/model, hard
  max 5) for transient failures only (429/500/503/504, timeouts, network);
  exponential backoff with jitter; `Retry-After`-aware 429 handling; per-
  attempt timeouts; a 24 s wall-clock budget across all attempts so the
  function answers inside Netlify's synchronous execution limit; 401/403
  fail fast with no retry and no fallback; 404/400 skip to the fallback
  model without same-model retries; classified, key-sanitised errors.
- All 11 AI call sites rewired through the engine — payloads unchanged
  (multimodal inline images preserved), caller AbortControllers preserved,
  upstream error bodies no longer echoed verbatim to browsers.
- New 52-check engine suite (`scripts/test-gemini-fallback.mjs`) covering
  all six mandated scenarios; +2 function-level wiring checks in the smoke
  suite. Matrix: units 135/135, smoke 118/118, build + secret scan green,
  production-only install build green, clean-room re-run from the shipped
  ZIP green.
- `NETLIFY-SETUP.md` added (exact build settings + every env-var name);
  `.env.example` documents the 8 new OPTIONAL Gemini vars (safe defaults,
  no values).

**Still requiring a live deployment (unchanged honesty list):**

- Real Gemini API behaviour of the four default model IDs (mocked-fetch
  tests only — latency, quotas, image fidelity need a preview deploy with
  a real `GEMINI_API_KEY`).
- The actual Netlify sync-timeout cutoff on this site (budget is
  env-tunable if the site's plan allows more than the default 24 s).
- Original checklist items 4–6 (env vars, Preview Deploy smoke, function
  log review) remain manual deployment steps.

---

## Round 4 — AI feature upgrade & Concept Floor Plan (2026-10-16)

Base: the Round-3 deliverable, uploaded back byte-identical (sha256
`2a0e1dd0…89b6`). This round implements the Stage D AI upgrade on top of
the existing application (no rewrite).

**Completed (full matrix in VERIFICATION.md, all exit 0):**

- Central AI usage-control layer (`_aiusage.mts`): per-user daily quotas
  (per-IP anonymous fallback), aggregate usage tracking with privacy
  guarantees (no prompts/personal data/keys in the usage store —
  test-asserted), content-hash result cache; wired into the shared engine.
- AI Concept Floor Plan end-to-end: validated panorama upload → 4
  client-rendered perspective crops (no new dependencies) → server-side
  Gemini vision analysis with strict schema validation and honest 502s →
  conversion into the EXISTING plan document (additive fields,
  schemaVersion unchanged, pre-existing plans load untouched) → full
  editing in the existing Plan Studio (drag/undo/redo/inspector) with
  uncertainty flags, "CONCEPTUAL FLOOR PLAN — NOT TO SCALE" watermark,
  reset-to-generated, regeneration confirm + preserve-on-failure, PNG/JSON
  export, and "Use in tour" public mini-map attachment.
- Copywriter +highlights/+buyerSummary (validated, facts-grounded);
  lead insights (enquiry summary, stated-only requirements, stage-aware
  next actions, owner-scoped, phone/email excluded from prompts —
  test-asserted); optional interior concepts (whitelisted styles,
  illustrative labelling, honest unconfigured state); Phase-8 scoping
  audit of tour Q&A (stateless by design, per-call isolation tested).
- Tests: +29 concept-engine unit checks, +36 concept-flow integration
  checks; total matrix 164 unit + 154 smoke, all green; build, typechecks,
  secret scan, script syntax checks, production-only install all exit 0;
  clean-room re-run from the shipped ZIP green.

**Still requiring a live deployment (unchanged honesty list):**

- Real Gemini behaviour of the default models (mocked-fetch tests only).
- Real-browser exercise of the new Plan Studio interactions (drag, PNG
  export, crop rendering) — logic-tested but not browser-tested this
  round.
- Image-model pricing itemisation (documented as a pointer, not quoted).
- Original checklist items 4–6 (env vars, preview-deploy smoke, function
  log review) remain manual deployment steps.
