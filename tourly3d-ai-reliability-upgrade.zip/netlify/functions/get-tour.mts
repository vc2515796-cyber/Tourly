import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import { jsonResponse, TOURS_STORE_NAME, TOUR_META_PREFIX, TOUR_PREVIEW_PREFIX, TOUR_OWNER_PREFIX, hashPassword, safeEqual } from "./_shared.mts";

export default async (req: Request) => {
  if (req.method !== "GET") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  const id = new URL(req.url).searchParams.get("id");
  if (!id) {
    return jsonResponse(400, { error: "id query parameter is required" });
  }
  // Metadata (password hashes) lives in the same store under a reserved
  // prefix — never let a request address it directly.
  if (id.startsWith(TOUR_META_PREFIX) || id.startsWith(TOUR_PREVIEW_PREFIX) || id.startsWith(TOUR_OWNER_PREFIX)) {
    return jsonResponse(404, { error: "Tour not found" });
  }

  try {
    const store = getStore({ name: TOURS_STORE_NAME });
    const tour = await store.get(id, { type: "json" });
    if (!tour) {
      return jsonResponse(404, { error: "Tour not found" });
    }

    const meta = (await store.get(TOUR_META_PREFIX + id, { type: "json" })) as
      | { salt: string; hash: string }
      | null;

    if (meta) {
      // Sent as a header (not a query param) so it doesn't end up in URLs/logs.
      const supplied = req.headers.get("x-tour-password");
      if (!supplied) {
        return jsonResponse(401, { error: "Password required", passwordRequired: true });
      }
      const attempt = await hashPassword(supplied, meta.salt);
      if (!safeEqual(attempt, meta.hash)) {
        return jsonResponse(401, { error: "Incorrect password", passwordRequired: true, wrong: true });
      }
    }

    return jsonResponse(200, { tour });
  } catch (err) {
    return jsonResponse(500, { error: "Could not fetch tour", detail: String(err) });
  }
};

export const config: Config = {
  path: "/api/tour",
};
