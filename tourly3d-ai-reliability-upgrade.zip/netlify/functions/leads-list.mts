import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import {
  jsonResponse,
  verifyAuthToken,
  firebaseAdminConfigured,
  AdminSetupError,
  TokenProjectMismatchError,
} from "./_shared.mts";
import { LEADS_STORE_NAME, LEAD_KEY_PREFIX, MAX_LEADS_LISTED, loadLead, type Lead } from "./_leads.mts";

/**
 * Stage B5 — lists the CALLER's leads (GET /api/leads). Auth is a verified
 * Firebase ID token; the query is scoped by the verified uid via the key
 * prefix, so one agent physically cannot enumerate another agent's leads.
 * 503 when server auth isn't configured (same honest contract as publish).
 */

export default async (req: Request) => {
  if (req.method !== "GET") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  if (!firebaseAdminConfigured()) {
    return jsonResponse(503, {
      error:
        "Lead management isn't available on this deployment yet — FIREBASE_SERVICE_ACCOUNT_KEY isn't set (see AUTH-SETUP.md §4).",
    });
  }

  let caller: Awaited<ReturnType<typeof verifyAuthToken>>;
  try {
    caller = await verifyAuthToken(req);
  } catch (err) {
    if (err instanceof AdminSetupError) {
      return jsonResponse(503, { error: err.message });
    }
    if (err instanceof TokenProjectMismatchError) {
      return jsonResponse(401, { error: err.message });
    }
    return jsonResponse(401, { error: "Your session has expired — sign in again." });
  }
  if (!caller) {
    return jsonResponse(401, { error: "Sign in to see your leads." });
  }

  try {
    const store = getStore({ name: LEADS_STORE_NAME });
    // Prefix scoping: only this verified uid's leads are even addressable.
    const list = await store.list({ prefix: `${LEAD_KEY_PREFIX}${caller.uid}:` });
    const leads: Lead[] = [];
    for (const blob of list.blobs.slice(0, MAX_LEADS_LISTED)) {
      const lead = await loadLead(store, caller.uid, blob.key.split(":")[2] ?? "");
      if (lead) leads.push(lead);
    }
    leads.sort((a, b) => b.updatedAt - a.updatedAt);
    // Summary shape — activities stay server-side until a lead is opened.
    return jsonResponse(200, {
      leads: leads.map((l) => ({
        id: l.id,
        tourId: l.tourId,
        tourName: l.tourName,
        stopTitle: l.stopTitle,
        name: l.name ?? null,
        phone: l.phone ?? null,
        email: l.email ?? null,
        message: l.message,
        stage: l.stage,
        visitRequested: l.visitRequested === true,
        createdAt: l.createdAt,
        updatedAt: l.updatedAt,
        nextActionAt: l.nextActionAt ?? null,
        activityCount: l.activities.length,
      })),
    });
  } catch (err) {
    return jsonResponse(500, { error: "Couldn't load your leads.", detail: String(err) });
  }
};

export const config: Config = {
  path: "/api/leads",
};
