import type { Store } from "@netlify/blobs";

/**
 * Stage B5 — shared lead types + helpers for the lead functions.
 *
 * Storage model (Netlify Blobs, store "waypoint-leads"):
 *   lead:{ownerUid}:{leadId}            → full Lead JSON (atomic doc)
 *   leadcontact:{ownerUid}:{contactKey} → dedupe marker {leadId, at}
 *
 * Ownership rules:
 * - The lead's ownerUid is derived SERVER-SIDE from the published tour's
 *   owner:{tourId} record. A client-supplied owner id is never trusted.
 * - List/update/draft access is scoped by the VERIFIED caller's uid, both
 *   via the key prefix and an explicit ownerUid check on the loaded lead.
 */

export const LEADS_STORE_NAME = "waypoint-leads";
export const LEAD_KEY_PREFIX = "lead:";
export const LEAD_CONTACT_KEY_PREFIX = "leadcontact:";

/** Same store the published tours + owner records live in. */
export const TOURS_STORE = "waypoint-tours";
export const TOUR_OWNER_PREFIX = "owner:";

export const LEAD_STAGES = [
  "new",
  "contacted",
  "qualified",
  "visit-requested",
  "visit-scheduled",
  "closed",
  "not-interested",
] as const;

export type LeadStage = (typeof LEAD_STAGES)[number];

export type LeadActivity =
  | { id: string; kind: "stage-change"; at: number; fromStage?: LeadStage; toStage: LeadStage }
  | { id: string; kind: "note"; at: number; text: string }
  | { id: string; kind: "contact-logged"; at: number; text: string }
  | { id: string; kind: "draft"; at: number; text: string; channel: string; language: string };

export type Lead = {
  id: string;
  tourId: string;
  /** Snapshot of the tour name at capture time (display convenience). */
  tourName: string;
  /** Scene the visitor was viewing, when known. */
  stopId?: string;
  stopTitle?: string;
  name?: string;
  phone?: string;
  email?: string;
  message: string;
  /** Must be true at capture — the visitor explicitly agreed to be contacted. */
  consent: boolean;
  /** Set when the visitor ticked "I'd like to request a site visit" in the
   *  enquiry form. Optional so every pre-existing Lead stays valid. */
  visitRequested?: boolean;
  stage: LeadStage;
  /** Set by the SERVER from the tour's owner record — never client-supplied. */
  ownerUid: string;
  createdAt: number;
  updatedAt: number;
  /** Optional follow-up date the agent set for themselves (epoch ms). */
  nextActionAt?: number;
  activities: LeadActivity[];
};

export function isLeadStage(v: unknown): v is LeadStage {
  return typeof v === "string" && (LEAD_STAGES as readonly string[]).includes(v);
}

export function leadStoreKey(ownerUid: string, leadId: string): string {
  return `${LEAD_KEY_PREFIX}${ownerUid}:${leadId}`;
}

/** Contact details are normalised before hashing so trivial formatting
 *  differences don't defeat the dedupe window. */
export function normalizeContactKey(input: { phone?: string; email?: string }): string | null {
  const phone = (input.phone ?? "").replace(/[^0-9+]/g, "");
  const email = (input.email ?? "").trim().toLowerCase();
  if (phone.length >= 6) return `p:${phone}`;
  if (/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return `e:${email}`;
  return null;
}

/** Loads and validates a stored lead document. */
export async function loadLead(store: Store, ownerUid: string, leadId: string): Promise<Lead | null> {
  const raw = await store.get(leadStoreKey(ownerUid, leadId), { type: "json" });
  if (!raw || typeof raw !== "object") return null;
  const lead = raw as Lead;
  if (!lead.id || lead.ownerUid !== ownerUid || !Array.isArray(lead.activities)) return null;
  return lead;
}

export const LEAD_CAPTURE_RATE_LIMIT = 5; // per IP per minute
export const LEAD_DEDUPE_WINDOW_MS = 10 * 60 * 1000;
export const MAX_LEADS_LISTED = 200;
