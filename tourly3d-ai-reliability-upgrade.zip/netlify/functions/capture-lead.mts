import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import { jsonResponse, rateLimit, clientIp } from "./_shared.mts";
import {
  LEADS_STORE_NAME,
  LEAD_CAPTURE_RATE_LIMIT,
  LEAD_CONTACT_KEY_PREFIX,
  LEAD_DEDUPE_WINDOW_MS,
  TOUR_OWNER_PREFIX,
  TOURS_STORE,
  normalizeContactKey,
  type Lead,
} from "./_leads.mts";
import { ANALYTICS_STORE_NAME, recordTourEvent } from "./_analytics.mts";

/**
 * Stage B5 — PUBLIC endpoint that captures an enquiry from a published
 * tour's public page (/tour/:id). Security posture:
 *  - strict payload validation + length caps
 *  - hidden honeypot field (bots fill it → silently accepted but discarded)
 *  - per-IP rate limit (fails open on infra errors like the rest of the app)
 *  - consent MUST be explicitly true
 *  - the lead's owner is resolved from the tour's SERVER-SIDE owner record —
 *    a client can never choose whose CRM the lead lands in
 *  - a short dedupe window prevents double-submits creating two leads
 * Nothing about the owner (uid/email) is returned to the visitor.
 */

type CaptureBody = {
  tourId?: string;
  name?: string;
  phone?: string;
  email?: string;
  message?: string;
  consent?: boolean;
  stopId?: string;
  stopTitle?: string;
  company?: string; // honeypot — must stay empty
  visitRequested?: boolean;
};

const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

export default async (req: Request) => {
  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  let body: CaptureBody;
  try {
    body = await req.json();
  } catch {
    return jsonResponse(400, { error: "Invalid JSON body" });
  }

  // Honeypot: real visitors never see this field. Accept-and-discard keeps
  // bots from learning they were caught.
  if (typeof body.company === "string" && body.company.trim() !== "") {
    return jsonResponse(200, { ok: true });
  }

  const tourId = typeof body.tourId === "string" ? body.tourId.trim().slice(0, 64) : "";
  const name = typeof body.name === "string" ? body.name.trim().slice(0, 80) : "";
  const phone = typeof body.phone === "string" ? body.phone.trim().slice(0, 20) : "";
  const email = typeof body.email === "string" ? body.email.trim().toLowerCase().slice(0, 120) : "";
  const message = typeof body.message === "string" ? body.message.trim().slice(0, 2000) : "";
  const stopId = typeof body.stopId === "string" ? body.stopId.slice(0, 64) : undefined;
  const stopTitle = typeof body.stopTitle === "string" ? body.stopTitle.slice(0, 80) : undefined;
  const visitRequested = body.visitRequested === true;

  // --- validation (plain, specific messages the public form can show) ---
  if (!tourId) return jsonResponse(400, { error: "Which tour is this about? Please reload the page and try again." });
  if (!message) return jsonResponse(400, { error: "Please write a short message." });
  if (message.length < 5) return jsonResponse(400, { error: "Please write a slightly longer message." });
  if (body.consent !== true) return jsonResponse(400, { error: "Please tick the consent box so the agent can reply." });
  if (!phone && !email) {
    return jsonResponse(400, { error: "Leave a phone number or an email so the agent can get back to you." });
  }
  if (phone && !/^[0-9+()\-\s]{6,20}$/.test(phone)) {
    return jsonResponse(400, { error: "That phone number doesn't look right." });
  }
  if (email && !EMAIL_RE.test(email)) {
    return jsonResponse(400, { error: "That email address doesn't look right." });
  }

  try {
    const toursStore = getStore({ name: TOURS_STORE });
    const leadsStore = getStore({ name: LEADS_STORE_NAME });

    // Abuse guard: 5 submissions per IP per minute, fails open like the rest.
    const { limited } = await rateLimit(leadsStore, `lead-capture:${clientIp(req)}`, LEAD_CAPTURE_RATE_LIMIT, 60);
    if (limited) {
      return jsonResponse(429, { error: "Too many enquiries from this connection — please wait a minute." });
    }

    // The tour must exist AND be published (ownership recorded). This is
    // what ties the lead to the right agent — server-side, exclusively.
    const tour = (await toursStore.get(tourId, { type: "json" })) as { id?: string; name?: string } | null;
    if (!tour) {
      return jsonResponse(404, { error: "This tour isn't available anymore." });
    }
    const owner = (await toursStore.get(TOUR_OWNER_PREFIX + tourId, { type: "json" })) as { uid?: string } | null;
    if (!owner?.uid) {
      return jsonResponse(404, { error: "This tour isn't accepting enquiries right now." });
    }

    // Dedupe: same contact + same tour within the window returns the
    // existing lead instead of creating a duplicate.
    const contactKey = normalizeContactKey({ phone, email });
    if (contactKey) {
      const markerKey = `${LEAD_CONTACT_KEY_PREFIX}${owner.uid}:${contactKey}:${tourId}`;
      const marker = (await leadsStore.get(markerKey, { type: "json" })) as { leadId?: string; at?: number } | null;
      if (marker?.leadId && typeof marker.at === "number" && Date.now() - marker.at < LEAD_DEDUPE_WINDOW_MS) {
        return jsonResponse(200, { ok: true, duplicate: true });
      }
      const leadId = crypto.randomUUID();
      const now = Date.now();
      const lead: Lead = {
        id: leadId,
        tourId,
        tourName: typeof tour.name === "string" ? tour.name.slice(0, 120) : "Property tour",
        stopId,
        stopTitle,
        name: name || undefined,
        phone: phone || undefined,
        email: email || undefined,
        message,
        consent: true,
        visitRequested: visitRequested || undefined,
        stage: "new",
        ownerUid: owner.uid, // from the server's owner record — never the client
        createdAt: now,
        updatedAt: now,
        activities: [],
      };
      await leadsStore.setJSON(leadStore(owner.uid, leadId), lead);
      await leadsStore.setJSON(markerKey, { leadId, at: now });

      // Engagement analytics: enquiry (+ visit-request) events are recorded
      // HERE, server-side, so the public track-event endpoint can refuse
      // those kinds — a browser can never inflate conversion numbers.
      // Best-effort: an analytics hiccup must never lose the lead itself.
      try {
        const analyticsStore = getStore({ name: ANALYTICS_STORE_NAME });
        await recordTourEvent(analyticsStore, tourId, { kind: "enquiry", source: "direct" });
        if (visitRequested) {
          await recordTourEvent(analyticsStore, tourId, { kind: "visit-request", source: "direct" });
        }
      } catch {
        // Swallowed deliberately — see comment above.
      }
      return jsonResponse(200, { ok: true });
    }

    return jsonResponse(400, { error: "Leave a valid phone number or email so the agent can reply." });
  } catch (err) {
    return jsonResponse(500, { error: "Couldn't send your enquiry — please try again.", detail: String(err) });
  }
};

function leadStore(ownerUid: string, leadId: string): string {
  return `lead:${ownerUid}:${leadId}`;
}

export const config: Config = {
  path: "/api/capture-lead",
};
