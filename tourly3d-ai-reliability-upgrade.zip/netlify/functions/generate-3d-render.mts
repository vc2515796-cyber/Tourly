import type { Config } from "@netlify/functions";
import { jsonResponse, enforceAiRateLimit } from "./_shared.mts";
import { callGemini, GeminiError, getGeminiApiKey } from "./_gemini.mts";
import { enforceAiQuota } from "./_aiusage.mts";

/**
 * Generates a stylized isometric 3D room render from a 2D floor plan
 * photo/screenshot. This is an AI image generation — NOT real 3D
 * reconstruction. There is no actual geometry, no accurate scale, and
 * nothing here is interactive or editable in 3D; it is one static
 * rendered image. Callers must keep StopMedia.synthetic = true and an
 * honest note on the stop — same rule as generate-panorama.mts.
 */
export default async (req: Request) => {
  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  const limited = await enforceAiRateLimit(req, "generate-3d-render", 5);
  if (limited) return limited;

  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    return jsonResponse(503, { error: "3D render generation not configured" });
  }
  // Expensive IMAGE-GENERATION call: a per-user daily quota
  // (AI_DAILY_QUOTA_{FEATURE}, default 10) enforced in FAIL-CLOSED mode —
  // if the usage limiter can't be reached, the request is refused rather
  // than risking uncapped image-generation usage during a store outage.
  const quotaResponse = await enforceAiQuota(req, "generate-3d-render", { failMode: "closed" });
  if (quotaResponse) return quotaResponse;


  let body: { imageBase64?: string; mimeType?: string; style?: string };
  try {
    body = await req.json();
  } catch {
    return jsonResponse(400, { error: "Invalid JSON body" });
  }

  const { imageBase64, mimeType, style = "modern" } = body;
  if (!imageBase64 || !mimeType) {
    return jsonResponse(400, { error: "imageBase64 and mimeType are required" });
  }
  // Keep JSON payloads below typical serverless request limits and reject
  // non-image MIME types before forwarding user input to the paid AI API.
  if (!/^image\/(jpeg|png|webp)$/.test(mimeType)) {
    return jsonResponse(415, { error: "Use a JPEG, PNG, or WebP image." });
  }
  if (imageBase64.length > 4_500_000 || !/^[A-Za-z0-9+/]*={0,2}$/.test(imageBase64)) {
    return jsonResponse(413, { error: "Image is too large or has an invalid encoding. Try a smaller image." });
  }

  const allowedStyles = ["modern", "minimal", "cozy", "luxury"];
  const safeStyle = allowedStyles.includes(style) ? style : "modern";

  const prompt = [
    "This image is a 2D top-down architectural floor plan (walls, room outlines, and labels).",
    "Generate a single isometric 3D cutaway render of this floor plan, viewed from above at an angle,",
    "roughly like a professional real-estate isometric room illustration: walls extruded upward,",
    `furnished in a ${safeStyle} interior design style, warm even lighting, clean lines, no people, no text overlays.`,
    "Keep the room layout, wall positions, doors, and windows consistent with the floor plan given —",
    "do not invent extra rooms or change the layout. This is a concept visualization, not an exact",
    "architectural drawing, so reasonable artistic interpretation of furniture and finishes is fine.",
    "Return only the rendered isometric image.",
  ].join(" ");

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 50_000);

  try {
    const { response } = await callGemini(
      "image",
      {
        contents: [
          {
            parts: [
              { text: prompt },
              { inline_data: { mime_type: mimeType, data: imageBase64 } },
            ],
          },
        ],
        generationConfig: { responseModalities: ["IMAGE"] },
      },
      { signal: controller.signal, functionName: "generate-3d-render" }
    );

    const data = await response.json();
    const parts = data?.candidates?.[0]?.content?.parts ?? [];
    const imagePart = parts.find((p: any) => p.inlineData || p.inline_data);
    const inline = imagePart?.inlineData ?? imagePart?.inline_data;

    if (!inline?.data) {
      return jsonResponse(502, { error: "No image returned by Gemini" });
    }

    return jsonResponse(200, {
      imageBase64: inline.data,
      mimeType: inline.mimeType ?? inline.mime_type ?? "image/jpeg",
    });
  } catch (err: any) {
    if (err instanceof GeminiError) {
      return jsonResponse(err.httpStatus, { error: err.safeMessage, retryable: err.retryable });
    }
    if (err?.name === "AbortError") {
      return jsonResponse(504, { error: "Generation timed out" });
    }
    return jsonResponse(500, { error: "Generation failed" });
  } finally {
    clearTimeout(timeout);
  }
};

export const config: Config = {
  path: "/api/generate-3d-render",
};
