import type { Config } from "@netlify/functions";
import { jsonResponse, enforceAiRateLimit } from "./_shared.mts";
import { callGemini, GeminiError, getGeminiApiKey } from "./_gemini.mts";
import { enforceAiQuota } from "./_aiusage.mts";

/**
 * Silently improves lighting/sharpness/color of a panorama photo before it's
 * stored, using Gemini's image-editing capability. This is intentionally
 * invisible to the end user — no UI mentions it, and on ANY failure the
 * CLIENT falls back to the original photo silently.
 */
export default async (req: Request) => {
  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  const limited = await enforceAiRateLimit(req, "enhance-panorama", 10);
  if (limited) return limited;

  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    return jsonResponse(503, { error: "Enhancement not configured" });
  }
  // Expensive IMAGE-GENERATION call: a per-user daily quota
  // (AI_DAILY_QUOTA_{FEATURE}, default 10) enforced in FAIL-CLOSED mode —
  // if the usage limiter can't be reached, the request is refused rather
  // than risking uncapped image-generation usage during a store outage.
  const quotaResponse = await enforceAiQuota(req, "enhance-panorama", { failMode: "closed" });
  if (quotaResponse) return quotaResponse;


  let body: { imageBase64?: string; mimeType?: string; kind?: "sphere" | "cylinder" };
  try {
    body = await req.json();
  } catch {
    return jsonResponse(400, { error: "Invalid JSON body" });
  }

  const { imageBase64, mimeType, kind } = body;
  if (!imageBase64 || !mimeType) {
    return jsonResponse(400, { error: "imageBase64 and mimeType are required" });
  }
  // Keep JSON payloads below typical serverless request limits and reject
  // non-image MIME types before forwarding user input to the paid AI API.
  if (!/^image\/(jpeg|png|webp)$/.test(mimeType)) {
    return jsonResponse(415, { error: "Use a JPEG, PNG, or WebP image." });
  }
  if (imageBase64.length > 4_500_000 || !/^[A-Za-z0-9+/]*={0,2}$/.test(imageBase64)) {
    return jsonResponse(413, { error: "Image is too large or has an invalid encoding. Try a smaller image." });
  }

  const framingNote =
    kind === "cylinder"
      ? "This is a wide horizontal panoramic sweep photo (much wider than tall)."
      : "This is a full 360-degree equirectangular panorama photo (exactly 2:1 width-to-height).";

  const prompt = [
    framingNote,
    "Improve only the lighting, exposure, color balance, sharpness, and reduce noise/grain.",
    "Do NOT crop, resize, rotate, warp, zoom, or recompose the image in any way.",
    "Preserve the exact framing and every detail's position, especially at the far left and far right edges — they must remain exactly as they were so the panorama still wraps seamlessly.",
    "Return only the corrected image with the same content and composition, just cleaner and better lit.",
  ].join(" ");

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 35_000);

  try {
    const { response } = await callGemini(
      "image",
      {
        contents: [
          {
            parts: [
              { text: prompt },
              { inline_data: { mime_type: mimeType, data: imageBase64 } },
            ],
          },
        ],
        generationConfig: {
          responseModalities: ["IMAGE"],
        },
      },
      { signal: controller.signal, functionName: "enhance-panorama" }
    );

    const data = await response.json();
    const parts = data?.candidates?.[0]?.content?.parts ?? [];
    const imagePart = parts.find((p: any) => p.inlineData || p.inline_data);
    const inline = imagePart?.inlineData ?? imagePart?.inline_data;

    if (!inline?.data) {
      return jsonResponse(502, { error: "No image returned by Gemini" });
    }

    return jsonResponse(200, {
      imageBase64: inline.data,
      mimeType: inline.mimeType ?? inline.mime_type ?? mimeType,
    });
  } catch (err: any) {
    if (err instanceof GeminiError) {
      return jsonResponse(err.httpStatus, { error: err.safeMessage, retryable: err.retryable });
    }
    if (err?.name === "AbortError") {
      return jsonResponse(504, { error: "Enhancement timed out" });
    }
    return jsonResponse(500, { error: "Enhancement failed" });
  } finally {
    clearTimeout(timeout);
  }
};

export const config: Config = {
  path: "/api/enhance-panorama",
};
