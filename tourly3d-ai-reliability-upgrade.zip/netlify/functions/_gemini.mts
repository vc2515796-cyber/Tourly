/**
 * Server-side Gemini client + provider fallback coordinator with model
 * fallback, bounded retries, circuit breaker, concurrency limits and honest
 * errors. EVERY AI feature in this app goes through callGemini() so the
 * reliability policy lives in exactly one place.
 *
 * Providers:
 *   PRIMARY   — Gemini (this module's own adapter, unchanged behaviour)
 *   SECONDARY — optional Groq or Mistral via the adapter layer in
 *               _providers.mts, used ONLY when Gemini fails in a way a
 *               different provider can plausibly survive AND the operator
 *               configured its API key. With no secondary configured the
 *               behaviour is bit-for-bit the previous Gemini-only logic.
 *
 * Gemini models are configured through environment variables (all optional):
 *
 *   GEMINI_TEXT_MODEL            primary text/vision model
 *   GEMINI_TEXT_MODEL_FALLBACK   fallback text/vision model ("" disables)
 *   GEMINI_IMAGE_MODEL           primary image-generation model
 *   GEMINI_IMAGE_MODEL_FALLBACK  fallback image-generation model ("" disables)
 *   GEMINI_MAX_RETRIES           bounded retries PER MODEL (default 2, max 5)
 *   GEMINI_TIMEOUT_MS            per-attempt timeout (default 20000)
 *   GEMINI_TOTAL_BUDGET_MS       wall-clock budget across ALL attempts and
 *                                providers (default 24000) — keeps the
 *                                function inside Netlify's synchronous
 *                                execution limit even in the worst case
 *   GEMINI_BACKOFF_BASE_MS       exponential-backoff base (default 500)
 *
 * Secondary provider (see _providers.mts for the official-doc links):
 *   GROQ_API_KEY / GROQ_MODEL, MISTRAL_API_KEY / MISTRAL_MODEL,
 *   AI_DISABLE_FALLBACK_PROVIDER (kill switch), AI_FALLBACK_ALLOW_VISION,
 *   AI_FALLBACK_MAX_RETRIES (default 1 — the secondary is an emergency
 *   path, not a load balancer).
 *
 * Default model IDs were verified against Google's official model catalogue
 * (https://ai.google.dev/gemini-api/docs/models, page dated 2026-10-06):
 *   gemini-3.8-flash        — STABLE, newest Flash text model
 *   gemini-3.1-flash-lite        — STABLE, lower-cost Flash-Lite fallback for text/vision
 *   gemini-3.1-flash-image  — STABLE "Nano Banana 2" image model
 *   gemini-nano-banana-2.1  — STABLE, newer image model (image fallback)
 * Never invent model IDs — check the catalogue (and the deprecations page)
 * before changing these defaults.
 *
 * Retry policy (deliberately narrow):
 *   RETRIED (bounded, exponential backoff + jitter, Retry-After aware):
 *     HTTP 429 (short-term), 500, 503, 504, per-attempt timeouts, and
 *     network-level fetch failures — all genuinely transient.
 *   NOT retried on the same model, but the FALLBACK model gets a fresh
 *     attempt (its quota is per-model): a 429 whose body identifies a
 *     DAILY quota (PerDay quota ids), plus HTTP 400 (params can be
 *     model-specific) and 404 (model retired or misspelled).
 *   NOT retried and NOT fallen back (within Gemini):
 *     HTTP 401/403 — the API key is invalid or lacks permission, and the
 *     same key is used for every Gemini model, so switching models cannot
 *     help; any other 4xx — the request itself is the problem.
 *   SECONDARY PROVIDER eligibility: rate-limit, quota-exhausted, server,
 *     timeout, network AND Gemini auth failures (the secondary has its own
 *     credentials). NOT eligible: bad-request/other-4xx (the request would
 *     fail there too), image-generation (kind "image" — no equivalent
 *     API), and multimodal payloads unless AI_FALLBACK_ALLOW_VISION is
 *     explicitly enabled (default secondary models are text-only).
 *
 * Reliability controls:
 *   - per-provider CIRCUIT BREAKER (in-memory per instance): after
 *     AI_BREAKER_THRESHOLD (default 4) consecutive failures a provider is
 *     skipped for AI_BREAKER_COOLDOWN_MS (default 60s), then retried.
 *   - per-provider CONCURRENCY CAP (AI_MAX_CONCURRENT_PER_PROVIDER,
 *     default 4 in-flight per instance) with a FIFO queue that respects
 *     the wall-clock budget.
 *   - No key rotation, no multi-provider fan-out: one request → at most
 *     one Gemini model chain + one secondary provider.
 *
 * This function NEVER fabricates output: it either returns a real 2xx
 * Response (Gemini's, or a secondary provider's normalized into Gemini's
 * response shape) or throws a classified GeminiError. Callers translate
 * that into honest HTTP responses — no fake success, ever.
 */

export const GEMINI_API_BASE = "https://generativelanguage.googleapis.com/v1beta";

export function getGeminiApiKey(): string | null {
  return process.env.GEMINI_API_KEY ?? null;
}

const VERIFIED_DEFAULTS = {
  text: { primary: "gemini-3.8-flash", fallback: "gemini-3.1-flash-lite" },
  image: { primary: "gemini-3.1-flash-image", fallback: "gemini-nano-banana-2.1" },
} as const;

export type GeminiModelKind = "text" | "image";

/** Resolves the ordered model list for a kind from env vars. Exported for
 *  tests and for logging config problems early. */
export function resolveModels(kind: GeminiModelKind): string[] {
  const prefix = kind === "text" ? "GEMINI_TEXT_MODEL" : "GEMINI_IMAGE_MODEL";
  const primary = (process.env[`${prefix}`] ?? VERIFIED_DEFAULTS[kind].primary).trim();
  const fallbackRaw = process.env[`${prefix}_FALLBACK`];
  // unset → default fallback; empty string → fallback deliberately disabled
  const fallback =
    fallbackRaw === undefined ? VERIFIED_DEFAULTS[kind].fallback : fallbackRaw.trim();
  const models = [primary];
  if (fallback && fallback !== primary) models.push(fallback);
  // Not a hard gate — Google may publish new id patterns — but a typo in an
  // env var is far more likely than a new pattern, so warn loudly.
  for (const m of models) {
    if (!/^[a-z0-9][a-z0-9.-]*$/i.test(m)) {
      console.warn(`[gemini] model id "${m}" doesn't look like a Gemini model id — check the ${prefix}* env vars against https://ai.google.dev/gemini-api/docs/models`);
    }
  }
  return models;
}

// --- error classification ---------------------------------------------------

export type GeminiFailureKind =
  | "auth" // 401/403 — server's key is invalid/permissionless
  | "bad-request" // 400 — API rejected the request payload
  | "not-found" // 404 — model id doesn't exist / retired
  | "rate-limit" // 429 (short-term) — exhausted retries
  | "quota-exhausted" // 429 — provider says a DAILY/PerDay quota is gone
  | "server" // 500/503/504 — exhausted retries
  | "timeout" // per-attempt timeouts — exhausted retries
  | "network" // fetch-level failures — exhausted retries
  | "breaker-open" // every viable provider is in its cooldown window
  | "malformed" // 2xx whose body is unusable (never a fake success)
  | "unknown"; // anything unrecognised

export class GeminiError extends Error {
  constructor(
    public kind: GeminiFailureKind,
    /** HTTP status the Netlify Function should answer with. */
    public httpStatus: number,
    /** Safe, user-facing message (no key material, no internal URLs). */
    public safeMessage: string,
    /** Whether trying again after a short wait can realistically help. */
    public retryable: boolean,
    /** Sanitized diagnostic for the function logs. */
    public detail: string,
    /** What was attempted, for the function logs only. */
    public attempts: AttemptLog[]
  ) {
    super(safeMessage);
    this.name = "GeminiError";
  }
}

export type AttemptLog = {
  /** Provider actually attempted ("gemini" | "groq" | "mistral"). */
  provider?: string;
  model: string;
  outcome: "ok" | "timeout" | "network" | "http" | "malformed" | "budget-exhausted" | "skipped-breaker" | "skipped-concurrency";
  status?: number;
  /** True when the provider body identified a DAILY (PerDay) quota. */
  quotaExhausted?: boolean;
  detail?: string;
};

function classifyHttp(status: number): { kind: GeminiFailureKind; retryable: boolean } {
  if (status === 429) return { kind: "rate-limit", retryable: true };
  if (status === 500 || status === 503 || status === 504) return { kind: "server", retryable: true };
  if (status === 401 || status === 403) return { kind: "auth", retryable: false };
  if (status === 400) return { kind: "bad-request", retryable: false };
  if (status === 404) return { kind: "not-found", retryable: false };
  return { kind: "unknown", retryable: false };
}

/** Transient = a bounded same-model retry is reasonable. A DAILY-quota 429
 *  is handled separately (see looksLikeDailyQuota) — same-model retries
 *  can't help there, but the fallback model's own daily quota can. */
function isTransientStatus(status: number): boolean {
  return status === 429 || status === 500 || status === 503 || status === 504;
}

/**
 * Best-effort detection of an EXHAUSTED DAILY quota in a 429 body. Google
 * signals this with QuotaFailure violations whose quota ids contain
 * "PerDay" (e.g. GenerateRequestsPerDayPerProjectPerModel) — as opposed to
 * a short-term rate limit, which carries a RetryInfo with a small delay.
 * Detection is deliberately conservative: if the evidence is inconclusive
 * the 429 is treated as transient (today's behaviour), which only costs a
 * bounded retry, never a wrong success.
 */
function looksLikeDailyQuota(detail: string): boolean {
  return /PerDay|DailyRequest|daily[_-]?quota/i.test(detail);
}

/** Strips anything key-shaped before a string is logged or echoed. */
export function sanitizeDetail(text: unknown): string {
  return String(text ?? "")
    .replace(/AIza[0-9A-Za-z_-]{10,}/g, "[redacted]")
    .replace(/([?&])key=[^&\s"']+/gi, "$1key=[redacted]")
    .replace(/\b(Bearer)\s+[A-Za-z0-9._~+/=-]{16,}/gi, "$1 [redacted]")
    .slice(0, 300);
}

function finalError(attempts: AttemptLog[], context: string): GeminiError {
  // The LAST meaningful outcome decides the classification, so the client
  // gets the most accurate reason (e.g. both providers rate-limited → 429).
  // Skip- outcomes (breaker/concurrency) aren't failures in themselves.
  const last = [...attempts]
    .reverse()
    .find((a) => a.outcome !== "budget-exhausted" && !a.outcome.startsWith("skipped-"));

  let kind: GeminiFailureKind = "unknown";
  let status = 502;
  if (!last) {
    // Every provider was skipped (breaker open) or starved — say so.
    kind = "breaker-open";
    status = 503;
  } else if (last.outcome === "timeout") {
    kind = "timeout";
    status = 504;
  } else if (last.outcome === "network") {
    kind = "network";
    status = 502;
  } else if (last.outcome === "malformed") {
    kind = "malformed";
    status = 502;
  } else if (last.outcome === "http") {
    if (last.quotaExhausted) {
      kind = "quota-exhausted";
      status = 429;
    } else {
      const cls = classifyHttp(last.status ?? 0);
      kind = cls.kind;
      status = cls.kind === "rate-limit" ? 429 : cls.kind === "auth" ? 503 : 502;
    }
  }

  const messages: Record<GeminiFailureKind, string> = {
    "rate-limit": "The AI service is rate-limiting requests right now — wait a minute and try again.",
    "quota-exhausted": "The AI provider's daily limit is used up — please try again tomorrow, or ask the site owner to check the provider limits.",
    server: "The AI service is temporarily unavailable — please try again.",
    timeout: "The AI service took too long to respond — please try again.",
    network: "Could not reach the AI service — please try again.",
    auth: "The AI service rejected the server's API key — the site owner must check the GEMINI_API_KEY setting.",
    "bad-request": "The AI service rejected the request parameters — the site owner should check the server logs.",
    "not-found": "The configured AI model is unavailable — the site owner must check the GEMINI_*_MODEL settings.",
    "breaker-open": "The AI service is taking a short break after repeated failures — please try again in a minute.",
    malformed: "The AI service returned an unreadable response — please try again.",
    unknown: "The AI service returned an unexpected error — please try again.",
  };
  const retryable = ["rate-limit", "server", "timeout", "network", "breaker-open", "malformed"].includes(kind);
  const err = new GeminiError(
    kind,
    status,
    messages[kind],
    retryable,
    sanitizeDetail(`${context}; attempts=${JSON.stringify(attempts.map((a) => ({ provider: a.provider ?? "gemini", model: a.model, outcome: a.outcome, status: a.status, quotaExhausted: a.quotaExhausted, detail: a.detail })))}`),
    attempts
  );
  // One log line for the function logs — sanitized, no key material.
  console.warn(`[gemini] ${context}: all providers failed (${kind}) — ${err.detail}`);
  return err;
}

// --- knobs ------------------------------------------------------------------

function envInt(name: string, def: number): number {
  const raw = process.env[name];
  if (raw === undefined || raw === "") return def;
  const n = Number(raw);
  return Number.isFinite(n) && n >= 0 ? n : def;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, Math.max(0, ms)));

/** Exponential backoff with full jitter — never exceeds `cap`. */
function backoffDelay(attempt: number, baseMs: number, capMs: number): number {
  const exp = baseMs * 2 ** attempt;
  return Math.min(capMs, exp * (0.5 + Math.random() * 0.5));
}

/** Parses Retry-After (integer-seconds form) — capped so a hostile header
 *  can't stall the whole request budget. Falls back to null. */
function retryAfterMs(response: Response, capMs: number): number | null {
  const raw = response.headers.get("retry-after");
  if (!raw) return null;
  const seconds = Number(raw);
  if (!Number.isFinite(seconds) || seconds < 0) return null;
  return Math.min(seconds * 1000, capMs);
}

// --- the client --------------------------------------------------------------

export type CallGeminiOptions = {
  /** The function's own AbortController — if it fires, the abort is rethrown
   *  unchanged so the caller's existing AbortError handling still works. */
  signal?: AbortSignal;
  /** Overrides for testing / per-endpoint tuning (default: env vars). */
  maxRetries?: number;
  timeoutMs?: number;
  totalBudgetMs?: number;
  backoffBaseMs?: number;
  /** Function name for log lines, e.g. "analyze-scene". */
  functionName?: string;
  /** The incoming Request — used ONLY to attribute usage to the caller's IP
   *  when no pre-resolved scope is given (aggregate counters, no personal
   *  data). Ignored when `usage.scope` is provided. */
  request?: Request;
  /** Pre-resolved caller scope (from enforceAiQuota) for accurate per-USER
   *  usage tracking on endpoints that enforce quotas. Pass `null` scope to
   *  skip tracking. */
  usage?: { scope: AiScope | null; feature: string };
};

export type GeminiPayload = Record<string, unknown>;

// Usage tracking (Stage D) — imported lazily-free: _aiusage has no imports
// back into this module, so there is no cycle.
import type { AiScope } from "./_aiusage.mts";
import { recordAiUsage, recordProviderOutcome, recordBreakerTrip } from "./_aiusage.mts";
import {
  resolveSecondaryProvider,
  toOpenAiChatRequest,
  fromOpenAiChatResponse,
  payloadHasImages,
  visionFallbackAllowed,
  breakerSnapshot,
  noteProviderSuccess,
  noteProviderFailure,
  withProviderSlot,
  type SecondaryProvider,
} from "./_providers.mts";

// Re-exported so TESTS (and the diagnostics tooling) can observe/reset the
// reliability state through THIS module's instance — when esbuild bundles
// _gemini.mts it inlines _providers.mts, and a separately-bundled
// _providers.mjs would be a DIFFERENT instance with its own state. Reaching
// the state through this module guarantees the same copy callGemini uses.
export {
  resolveSecondaryProvider,
  payloadHasImages,
  breakerSnapshot,
  resetReliabilityStateForTests,
} from "./_providers.mts";

/** Internal result of one provider leg. */
type LegResult =
  | { ok: true; response: Response; model: string; provider: string }
  | { ok: false; fallbackEligible: boolean };

/**
 * Sends a generateContent payload to the primary Gemini model for `kind`,
 * retrying only transient failures (bounded, backoff + jitter, Retry-After
 * aware), then trying the Gemini fallback model with a fresh (but still
 * bounded) retry budget — and, when Gemini fails in a way a different
 * provider can survive and one is configured, the secondary provider
 * (Groq/Mistral) through the adapter layer. All of it stays inside a
 * wall-clock budget so the Netlify function can never be killed mid-flight
 * by the platform's execution limit.
 *
 * Returns the successful (2xx) Response — either Gemini's own or a
 * secondary response NORMALIZED into the Gemini response shape, so every
 * caller's parsing keeps working. Throws GeminiError when every attempt
 * failed. NEVER returns a fabricated response.
 */
export async function callGemini(
  kind: GeminiModelKind,
  payload: GeminiPayload,
  opts: CallGeminiOptions = {}
): Promise<{ response: Response; model: string; provider: string; attempts: AttemptLog[] }> {
  const startedAt = Date.now();

  // Best-effort usage recording: one row per AI REQUEST (not per attempt),
  // with the outcome + model + provider + latency merged when the call
  // settles. Never throws, never blocks a result on a usage-store hiccup.
  const recordUsage = async (ok: boolean, model: string | null, provider = "gemini") => {
    try {
      let scope: AiScope | null = opts.usage?.scope ?? null;
      if (!scope && opts.usage?.scope !== null && opts.request) {
        const { clientIp } = await import("./_shared.mts");
        scope = { kind: "ip", id: clientIp(opts.request) };
      }
      await recordAiUsage(scope, opts.usage?.feature ?? opts.functionName ?? "gemini", {
        ok,
        model: model ?? undefined,
        provider,
        latencyMs: Date.now() - startedAt,
      });
    } catch {
      /* usage tracking must never break the feature */
    }
  };

  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    // A secondary provider configured WITHOUT a Gemini key is an odd but
    // possible setup — honour it (text-only) instead of failing outright.
    const secondary = kind === "text" ? resolveSecondaryProvider() : null;
    const multimodal = payloadHasImages(payload);
    if (secondary && (!multimodal || visionFallbackAllowed())) {
      const attempts: AttemptLog[] = [];
      const leg = await trySecondaryProvider(secondary, payload, opts, attempts, startedAt);
      if (leg.ok) {
        attempts.push({ provider: leg.provider, model: leg.model, outcome: "ok" });
        await recordUsage(true, leg.model, leg.provider);
        return { response: leg.response, model: leg.model, provider: leg.provider, attempts };
      }
      throw finalError(attempts, secondaryContext(opts));
    }
    throw new GeminiError(
      "auth",
      503,
      "AI features aren't configured on this server (GEMINI_API_KEY missing).",
      false,
      "GEMINI_API_KEY not set",
      []
    );
  }

  const models = resolveModels(kind);
  const maxRetries = Math.min(5, Math.max(0, Math.floor(opts.maxRetries ?? envInt("GEMINI_MAX_RETRIES", 2))));
  // 100ms floor: a sub-100ms attempt can never complete a real API round
  // trip, so smaller values (typos, test misconfiguration) are clamped.
  const timeoutMs = Math.max(100, opts.timeoutMs ?? envInt("GEMINI_TIMEOUT_MS", 20_000));
  const totalBudgetMs = Math.max(1_000, opts.totalBudgetMs ?? envInt("GEMINI_TOTAL_BUDGET_MS", 24_000));
  const backoffBaseMs = Math.max(0, opts.backoffBaseMs ?? envInt("GEMINI_BACKOFF_BASE_MS", 500));
  const context = opts.functionName ? `${opts.functionName} (${kind})` : `gemini ${kind}`;

  const attempts: AttemptLog[] = [];

  const remainingMs = () => totalBudgetMs - (Date.now() - startedAt);
  // Don't start an attempt that certainly can't finish in the budget.
  const MIN_VIABLE_ATTEMPT_MS = 500;

  // --- Gemini leg (primary + its model fallback), guarded by breaker/slot ---

  let geminiEligibleForSecondary = false;
  const geminiBreaker = breakerSnapshot("gemini");

  if (geminiBreaker.open) {
    attempts.push({ provider: "gemini", model: models[0]!, outcome: "skipped-breaker" });
    // The breaker only opens after repeated hard failures — a secondary
    // provider is worth trying if one exists.
    geminiEligibleForSecondary = true;
  } else {
    const geminiDeadline = startedAt + totalBudgetMs;
    const leg = await withProviderSlot("gemini", geminiDeadline, () =>
      runGeminiModels({
        apiKey,
        models,
        maxRetries,
        timeoutMs,
        backoffBaseMs,
        remainingMs,
        minViableMs: MIN_VIABLE_ATTEMPT_MS,
        payload,
        opts,
        attempts,
      })
    );
    if (leg === null) {
      // Couldn't get a concurrency slot in time — record and move on to
      // the secondary (if any); the budget guard below will stop hopeless
      // secondary attempts too.
      attempts.push({ provider: "gemini", model: models[0]!, outcome: "skipped-concurrency" });
      geminiEligibleForSecondary = true;
    } else if (leg.ok) {
      noteProviderSuccess("gemini");
      recordProviderOutcome("gemini", { ok: true });
      attempts.push({ provider: "gemini", model: leg.model, outcome: "ok" });
      await recordUsage(true, leg.model, "gemini");
      return { response: leg.response, model: leg.model, provider: "gemini", attempts };
    } else {
      geminiEligibleForSecondary = leg.fallbackEligible;
      const tripped = noteProviderFailure("gemini");
      if (tripped) recordBreakerTrip("gemini");
      recordProviderOutcome("gemini", {
        ok: false,
        kind: classifyLegFailure(attempts),
      });
    }
  }

  // --- Secondary provider leg (optional) --------------------------------------

  const secondary = kind === "text" ? resolveSecondaryProvider() : null;
  if (secondary && geminiEligibleForSecondary) {
    const multimodal = payloadHasImages(payload);
    if (multimodal && !visionFallbackAllowed()) {
      // Never silently send images to a text-only model — record WHY the
      // fallback was skipped so logs/diagnostics can explain it.
      attempts.push({
        provider: secondary.id,
        model: secondary.model,
        outcome: "skipped-breaker", // closest existing semantics: deliberately not attempted
        detail: "multimodal request; secondary fallback is text-only (enable AI_FALLBACK_ALLOW_VISION to override)",
      });
    } else if (remainingMs() < Math.max(MIN_VIABLE_ATTEMPT_MS, 2_000)) {
      // No useful time left — don't start a doomed request.
      attempts.push({ provider: secondary.id, model: secondary.model, outcome: "budget-exhausted" });
    } else {
      const leg = await trySecondaryProvider(secondary, payload, opts, attempts, startedAt);
      if (leg.ok) {
        noteProviderSuccess(secondary.id);
        recordProviderOutcome(secondary.id, { ok: true });
        attempts.push({ provider: secondary.id, model: leg.model, outcome: "ok" });
        await recordUsage(true, leg.model, secondary.id);
        return { response: leg.response, model: leg.model, provider: secondary.id, attempts };
      }
      const tripped = noteProviderFailure(secondary.id);
      if (tripped) recordBreakerTrip(secondary.id);
      recordProviderOutcome(secondary.id, {
        ok: false,
        kind: classifyLegFailure(attempts, secondary.id),
      });
    }
  }

  const finalErr = finalError(attempts, context);
  await recordUsage(false, null, lastProvider(attempts));
  throw finalErr;
}

function secondaryContext(opts: CallGeminiOptions): string {
  return opts.functionName ? `${opts.functionName} (secondary)` : "gemini secondary";
}

function lastProvider(attempts: AttemptLog[]): string {
  for (let i = attempts.length - 1; i >= 0; i--) {
    const p = attempts[i]?.provider;
    if (p) return p;
  }
  return "gemini";
}

/** Maps a leg's attempts to a sanitized failure kind for metrics. */
function classifyLegFailure(attempts: AttemptLog[], provider?: string): string {
  const relevant = provider ? attempts.filter((a) => a.provider === provider) : attempts;
  const last = [...relevant].reverse().find((a) => !a.outcome.startsWith("skipped-"));
  if (!last) return "unknown";
  if (last.quotaExhausted) return "quota-exhausted";
  if (last.outcome === "malformed") return "malformed";
  if (last.outcome === "timeout") return "timeout";
  if (last.outcome === "network") return "network";
  if (last.outcome === "http") return classifyHttp(last.status ?? 0).kind;
  return "unknown";
}

// --- Gemini leg ---------------------------------------------------------------

type GeminiLegArgs = {
  apiKey: string;
  models: string[];
  maxRetries: number;
  timeoutMs: number;
  backoffBaseMs: number;
  remainingMs: () => number;
  minViableMs: number;
  payload: GeminiPayload;
  opts: CallGeminiOptions;
  attempts: AttemptLog[];
};

/** Runs the Gemini model chain (primary then fallback model). Returns the
 *  2xx Response, or { ok:false, fallbackEligible } explaining whether a
 *  DIFFERENT provider could plausibly succeed. */
async function runGeminiModels(args: GeminiLegArgs): Promise<LegResult> {
  const { apiKey, models, maxRetries, timeoutMs, backoffBaseMs, remainingMs, minViableMs, payload, opts, attempts } = args;

  for (let modelIndex = 0; modelIndex < models.length; modelIndex++) {
    const model = models[modelIndex]!;
    let attempt = 0;

    // eslint-disable-next-line no-constant-condition
    while (true) {
      // If the caller's signal aborted while we were sleeping between
      // attempts, `addEventListener("abort")` won't fire again (the event
      // already fired) — check explicitly so we never start an attempt the
      // caller has already cancelled.
      if (opts.signal?.aborted) {
        throw new DOMException("The operation was aborted", "AbortError");
      }
      if (remainingMs() < minViableMs) {
        attempts.push({ provider: "gemini", model, outcome: "budget-exhausted" });
        break;
      }

      const attemptTimeout = Math.min(timeoutMs, remainingMs());
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), attemptTimeout);
      let callerAborted = false;
      const onCallerAbort = () => {
        callerAborted = true;
        controller.abort();
      };
      opts.signal?.addEventListener("abort", onCallerAbort, { once: true });

      try {
        const response = await fetch(`${GEMINI_API_BASE}/models/${model}:generateContent`, {
          method: "POST",
          headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
          signal: controller.signal,
          body: JSON.stringify(payload), // sent verbatim — multimodal parts preserved
        });

        if (response.ok) {
          return { ok: true, response, model, provider: "gemini" };
        }

        const status = response.status;
        const detail = sanitizeDetail(await response.text().catch(() => ""));

        // Invalid key / no permission: the SAME key is used for every Gemini
        // model, so retrying or falling back within Gemini can never help —
        // but a SECONDARY provider has its own credentials, so mark eligible.
        if (status === 401 || status === 403) {
          attempts.push({ provider: "gemini", model, outcome: "http", status, detail });
          return { ok: false, fallbackEligible: true };
        }

        if (isTransientStatus(status)) {
          const dailyQuota = status === 429 && looksLikeDailyQuota(detail);
          attempts.push({ provider: "gemini", model, outcome: "http", status, detail, quotaExhausted: dailyQuota });
          if (dailyQuota) {
            // A daily quota never resets within this request — don't waste
            // budget retrying THIS model. The fallback model keeps its own
            // daily quota (per-model quota ids), so continue to it.
            break;
          }
          if (attempt < maxRetries && remainingMs() >= minViableMs) {
            const ra = status === 429 ? retryAfterMs(response, 5_000) : null;
            const delay = ra ?? backoffDelay(attempt, backoffBaseMs, 5_000);
            await sleep(Math.min(delay, remainingMs() - minViableMs + 1));
            attempt++;
            continue;
          }
          break; // retries exhausted (or no budget left) → try the fallback model
        }

        // 400 (params may be model-specific) and 404 (model retired/misspelled):
        // a retry of the SAME model can't help, but the fallback model might.
        if (status === 400 || status === 404) {
          attempts.push({ provider: "gemini", model, outcome: "http", status, detail });
          break; // → next model, no same-model retry
        }

        // Any other 4xx: the request itself is the problem for every
        // provider — the secondary would reject it too.
        attempts.push({ provider: "gemini", model, outcome: "http", status, detail });
        return { ok: false, fallbackEligible: false };
      } catch (err: any) {
        // The function's own AbortController fired — rethrow untouched so the
        // caller's existing `AbortError → 504` handling keeps working.
        if (callerAborted || opts.signal?.aborted) {
          throw err;
        }
        if (err instanceof GeminiError) throw err;

        if (err?.name === "AbortError" || err?.name === "TimeoutError") {
          // our per-attempt timeout — transient, retry within bounds
          attempts.push({ provider: "gemini", model, outcome: "timeout" });
          if (attempt < maxRetries && remainingMs() >= minViableMs) {
            await sleep(Math.min(backoffDelay(attempt, backoffBaseMs, 5_000), remainingMs() - minViableMs + 1));
            attempt++;
            continue;
          }
          break; // → next model
        }

        // Network-level failure (fetch rejects: DNS, connection reset, TLS…) —
        // eligible for a bounded retry, then the fallback model.
        attempts.push({ provider: "gemini", model, outcome: "network", detail: sanitizeDetail(err?.message) });
        if (attempt < maxRetries && remainingMs() >= minViableMs) {
          await sleep(Math.min(backoffDelay(attempt, backoffBaseMs, 5_000), remainingMs() - minViableMs + 1));
          attempt++;
          continue;
        }
        break; // → next model
      } finally {
        clearTimeout(timer);
        opts.signal?.removeEventListener("abort", onCallerAbort);
      }
    } // end attempt loop (while true)
  } // end model loop (for)

  // Exhausted every Gemini model. Every path that reaches this point is a
  // transient-class failure (short-term 429, daily quota, 5xx, timeout,
  // network, budget starvation) — the non-transient shapes (auth 401/403,
  // other 4xx) returned early with their own eligibility. A DIFFERENT
  // provider is therefore worth trying.
  return { ok: false, fallbackEligible: true };
}

// --- Secondary provider leg -----------------------------------------------------

/** Attempts the secondary provider with its own bounded retry loop inside
 *  the remaining time budget. On success, returns the provider's response
 *  NORMALIZED into Gemini's response shape (same 2xx contract). */
async function trySecondaryProvider(
  secondary: SecondaryProvider,
  payload: GeminiPayload,
  opts: CallGeminiOptions,
  attempts: AttemptLog[],
  startedAt: number
): Promise<LegResult> {
  const breaker = breakerSnapshot(secondary.id);
  if (breaker.open) {
    attempts.push({ provider: secondary.id, model: secondary.model, outcome: "skipped-breaker" });
    return { ok: false, fallbackEligible: false };
  }

  const totalBudgetMs = Math.max(1_000, opts.totalBudgetMs ?? envInt("GEMINI_TOTAL_BUDGET_MS", 24_000));
  const timeoutMs = Math.max(100, opts.timeoutMs ?? envInt("GEMINI_TIMEOUT_MS", 20_000));
  const maxRetries = Math.min(
    3,
    Math.max(0, Math.floor(envInt("AI_FALLBACK_MAX_RETRIES", 1)))
  );
  const backoffBaseMs = Math.max(0, opts.backoffBaseMs ?? envInt("GEMINI_BACKOFF_BASE_MS", 500));
  const remainingMs = () => totalBudgetMs - (Date.now() - startedAt);
  const MIN_VIABLE = 500;

  const body = JSON.stringify(toOpenAiChatRequest(payload, secondary.model));

  return withProviderSlot(secondary.id, startedAt + totalBudgetMs, async () => {
    let attempt = 0;
    // eslint-disable-next-line no-constant-condition
    while (true) {
      if (opts.signal?.aborted) {
        throw new DOMException("The operation was aborted", "AbortError");
      }
      if (remainingMs() < MIN_VIABLE) {
        attempts.push({ provider: secondary.id, model: secondary.model, outcome: "budget-exhausted" });
        return { ok: false, fallbackEligible: false } as LegResult;
      }

      const attemptTimeout = Math.min(timeoutMs, remainingMs());
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), attemptTimeout);
      let callerAborted = false;
      const onCallerAbort = () => {
        callerAborted = true;
        controller.abort();
      };
      opts.signal?.addEventListener("abort", onCallerAbort, { once: true });

      try {
        const response = await fetch(secondary.endpoint, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${secondary.apiKey}`,
          },
          signal: controller.signal,
          body,
        });

        if (response.ok) {
          const json = await response.json().catch(() => null);
          if (!json || !Array.isArray(json?.choices) || json.choices.length === 0) {
            // 2xx but unusable body — a malformed response, NOT a success.
            attempts.push({
              provider: secondary.id,
              model: secondary.model,
              outcome: "malformed",
              status: response.status,
              detail: sanitizeDetail("2xx without choices[]"),
            });
            return { ok: false, fallbackEligible: false } as LegResult;
          }
          // Normalize into the Gemini response shape and re-wrap as a real
          // Response so every existing caller parses it unchanged.
          const normalized = fromOpenAiChatResponse(json, secondary.model);
          return {
            ok: true,
            response: new Response(JSON.stringify(normalized), {
              status: 200,
              headers: { "Content-Type": "application/json" },
            }),
            model: secondary.model,
            provider: secondary.id,
          } as LegResult;
        }

        const status = response.status;
        const detail = sanitizeDetail(await response.text().catch(() => ""));
        const dailyQuota = status === 429 && looksLikeDailyQuota(detail);
        attempts.push({ provider: secondary.id, model: secondary.model, outcome: "http", status, detail, quotaExhausted: dailyQuota });

        if (status === 401 || status === 403) {
          // The secondary's OWN key is bad — retrying can't help.
          return { ok: false, fallbackEligible: false } as LegResult;
        }
        const transient = status === 429 || status === 500 || status === 503 || status === 504;
        if (transient && !dailyQuota && attempt < maxRetries && remainingMs() >= MIN_VIABLE) {
          const ra = status === 429 ? retryAfterMs(response, 5_000) : null;
          const delay = ra ?? backoffDelay(attempt, backoffBaseMs, 5_000);
          await sleep(Math.min(delay, remainingMs() - MIN_VIABLE + 1));
          attempt++;
          continue;
        }
        return { ok: false, fallbackEligible: false } as LegResult;
      } catch (err: any) {
        if (callerAborted || opts.signal?.aborted) {
          throw err;
        }
        if (err?.name === "AbortError" || err?.name === "TimeoutError") {
          attempts.push({ provider: secondary.id, model: secondary.model, outcome: "timeout" });
        } else {
          attempts.push({
            provider: secondary.id,
            model: secondary.model,
            outcome: "network",
            detail: sanitizeDetail(err?.message),
          });
        }
        if (attempt < maxRetries && remainingMs() >= MIN_VIABLE) {
          await sleep(Math.min(backoffDelay(attempt, backoffBaseMs, 5_000), remainingMs() - MIN_VIABLE + 1));
          attempt++;
          continue;
        }
        return { ok: false, fallbackEligible: false } as LegResult;
      } finally {
        clearTimeout(timer);
        opts.signal?.removeEventListener("abort", onCallerAbort);
      }
    }
  }).then((r) => (r === null ? ({ ok: false, fallbackEligible: false } as LegResult) : r));
}
