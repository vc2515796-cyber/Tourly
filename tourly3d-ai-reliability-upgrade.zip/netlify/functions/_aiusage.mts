/**
 * Stage D (Phase 9 of the AI upgrade) — the central AI usage-control layer.
 *
 * Every AI feature goes through this module for:
 *   - per-user (verified Firebase token) DAILY QUOTAS, falling back to
 *     per-IP quotas for anonymous callers;
 *   - usage tracking per feature (count, outcomes, model, latency) —
 *     aggregate numbers only, never prompts or personal data;
 *   - a safe result CACHE keyed by source-content hash + prompt/schema
 *     version, so re-analysing the same panorama doesn't re-bill the API.
 *
 * Storage (Netlify Blobs — same family as the app's other stores):
 *   store "waypoint-ai-usage":
 *     usage:{scope}:{YYYY-MM-DD} → { features: { [feature]: {
 *       count, ok, failed, totalLatencyMs, models: { [model]: n } } } }
 *     scope = "uid:<uid>" | "ip:<ip>"
 *   store "waypoint-ai-cache":
 *     {feature}:{sha256(feature|schemaVersion|model|contentHash)}
 *     → { savedAt, value }   (TTL via AI_CACHE_TTL_HOURS, default 24)
 *
 * Privacy rules enforced here:
 *   - No API keys, tokens, prompts, buyer details or tour content are ever
 *     written to the usage store or logs — only aggregate counters.
 *   - The cache stores only the VALIDATED analysis result (already
 *     sanitized server output), keyed by a hash of the input image.
 *
 * Quotas are env-configurable (all optional):
 *   AI_DAILY_QUOTA_DEFAULT             (default 40)
 *   AI_DAILY_QUOTA_<FEATURE>           per-feature override, e.g.
 *     AI_DAILY_QUOTA_ANALYZE_FLOORPLAN (default 10)
 *   AI_CACHE_TTL_HOURS                 (default 24)
 *
 * This module never fabricates success and never blocks on Blobs hiccups:
 * every store operation is best-effort (fail-open) so an analytics backend
 * problem can't take down the AI features themselves.
 */
import { getStore } from "@netlify/blobs";
import { clientIp, jsonResponse, verifyAuthToken } from "./_shared.mts";

export const AI_USAGE_STORE = "waypoint-ai-usage";
export const AI_CACHE_STORE = "waypoint-ai-cache";

// --- provider/cache metrics (admin diagnostics, Phase 8) ----------------------
//
// Aggregate, privacy-safe counters persisted in the SAME usage store under
// "metrics:global": per-provider success/failure counts, last ok/err
// timestamps, error KINDS (never messages), rate-limit/quota event counts,
// breaker trips, and cache hit/miss counts. NO prompts, images, user ids or
// keys are ever written here — the same privacy rule as the usage docs.
// Best-effort by design: concurrent function instances may lose a counter
// increment occasionally (last-writer-wins); diagnostics present these as
// approximate operational signals, not exact billing records.

export type ProviderMetrics = {
  okCount: number;
  errCount: number;
  lastOkAt: number | null;
  lastErrAt: number | null;
  /** sanitized failure kind, e.g. "rate-limit" — never a raw message */
  lastErrKind: string | null;
  rateLimitEvents: number;
  quotaEvents: number;
  breakerTrips: number;
};

export type AiMetrics = {
  providers: Record<string, ProviderMetrics>;
  cache: { hits: number; misses: number };
  updatedAt: number | null;
};

const EMPTY_PROVIDER_METRICS: ProviderMetrics = {
  okCount: 0,
  errCount: 0,
  lastOkAt: null,
  lastErrAt: null,
  lastErrKind: null,
  rateLimitEvents: 0,
  quotaEvents: 0,
  breakerTrips: 0,
};

function emptyMetrics(): AiMetrics {
  return { providers: {}, cache: { hits: 0, misses: 0 }, updatedAt: null };
}

async function loadMetrics(): Promise<AiMetrics> {
  try {
    const store = getStore({ name: AI_USAGE_STORE });
    const doc = (await store.get("metrics:global", { type: "json" })) as AiMetrics | null;
    if (!doc || typeof doc !== "object" || typeof doc.providers !== "object") return emptyMetrics();
    return {
      providers: doc.providers ?? {},
      cache: {
        hits: doc.cache?.hits ?? 0,
        misses: doc.cache?.misses ?? 0,
      },
      updatedAt: doc.updatedAt ?? null,
    };
  } catch {
    return emptyMetrics();
  }
}

async function saveMetrics(m: AiMetrics): Promise<void> {
  try {
    const store = getStore({ name: AI_USAGE_STORE });
    m.updatedAt = Date.now();
    await store.setJSON("metrics:global", m, { metadata: { expiresIn: 30 * 86400 } });
  } catch {
    /* best-effort by design */
  }
}

/** Fire-and-forget outcome recording for one provider attempt.
 *  `kind` values are the sanitized failure kinds ("rate-limit",
 *  "quota-exhausted", "timeout", …) or "breaker-trip" / "skipped-breaker". */
export function recordProviderOutcome(
  provider: string,
  outcome: { ok: boolean; kind?: string }
): void {
  void (async () => {
    try {
      const m = await loadMetrics();
      const p = { ...EMPTY_PROVIDER_METRICS, ...(m.providers[provider] ?? {}) };
      if (outcome.ok) {
        p.okCount += 1;
        p.lastOkAt = Date.now();
      } else {
        p.errCount += 1;
        p.lastErrAt = Date.now();
        if (outcome.kind) p.lastErrKind = outcome.kind;
        if (outcome.kind === "rate-limit") p.rateLimitEvents += 1;
        if (outcome.kind === "quota-exhausted") p.quotaEvents += 1;
      }
      m.providers[provider] = p;
      await saveMetrics(m);
    } catch {
      /* never let metrics break a feature */
    }
  })();
}

/** Records a circuit-breaker trip (called exactly once per trip). */
export function recordBreakerTrip(provider: string): void {
  recordProviderOutcome(provider, { ok: false, kind: "breaker-trip" });
  void (async () => {
    try {
      const m = await loadMetrics();
      const p = { ...EMPTY_PROVIDER_METRICS, ...(m.providers[provider] ?? {}) };
      p.breakerTrips += 1;
      m.providers[provider] = p;
      await saveMetrics(m);
    } catch {
      /* best-effort */
    }
  })();
}

/** Reads the current metrics snapshot for admin diagnostics (safe fields). */
export async function readAiMetrics(): Promise<AiMetrics> {
  return loadMetrics();
}

/** Cache hit/miss counter (called from getCachedAnalysis — best-effort). */
function recordCacheLookup(hit: boolean): void {
  void (async () => {
    try {
      const m = await loadMetrics();
      m.cache[hit ? "hits" : "misses"] = (m.cache[hit ? "hits" : "misses"] ?? 0) + 1;
      await saveMetrics(m);
    } catch {
      /* best-effort */
    }
  })();
}

/** Feature quota: per-feature env override → default env → built-in default. */
export function aiFeatureQuota(feature: string): number {
  const envName = `AI_DAILY_QUOTA_${feature.toUpperCase().replace(/-/g, "_")}`;
  const raw = process.env[envName] ?? process.env.AI_DAILY_QUOTA_DEFAULT;
  const n = Number(raw);
  return Number.isFinite(n) && n >= 0 ? Math.floor(n) : 40;
}

export function aiCacheTtlHours(): number {
  const n = Number(process.env.AI_CACHE_TTL_HOURS);
  return Number.isFinite(n) && n > 0 ? n : 24;
}

export type AiScope = { kind: "user"; id: string } | { kind: "ip"; id: string };

export type AiCallerResolution =
  | { status: "ok"; scope: AiScope; user: { uid: string; email: string | null } | null }
  | { status: "invalid-token" };

/**
 * Resolves who is calling: a VERIFIED Firebase user when an Authorization
 * header is present (invalid token → "invalid-token", the caller must
 * answer 401), otherwise the client IP. When server auth isn't configured
 * the token is simply absent — the IP scope is used (quota still applies).
 */
export async function resolveAiCaller(req: Request): Promise<AiCallerResolution> {
  const hasHeader = req.headers.get("authorization")?.startsWith("Bearer ");
  if (hasHeader) {
    try {
      const verified = await verifyAuthToken(req);
      if (verified) {
        return { status: "ok", scope: { kind: "user", id: verified.uid }, user: verified };
      }
      // Token present but verifyAuthToken returned null → admin not
      // configured; fall through to IP scope (no identity was proven).
    } catch {
      return { status: "invalid-token" };
    }
  }
  return { status: "ok", scope: { kind: "ip", id: clientIp(req) }, user: null };
}

function todayKey(): string {
  return new Date().toISOString().slice(0, 10); // YYYY-MM-DD (UTC)
}

type FeatureUsage = {
  count: number;
  ok: number;
  failed: number;
  totalLatencyMs: number;
  models: Record<string, number>;
  /** Aggregate provider counters (additive Stage-F field; old docs lack it). */
  providers?: Record<string, number>;
};
type UsageDayDoc = { features: Record<string, FeatureUsage> };

async function loadDayDoc(scope: AiScope): Promise<UsageDayDoc> {
  try {
    const store = getStore({ name: AI_USAGE_STORE });
    const doc = (await store.get(`usage:${scope.kind}:${scope.id}:${todayKey()}`, {
      type: "json",
    })) as UsageDayDoc | null;
    return doc && typeof doc === "object" && typeof doc.features === "object" ? doc : { features: {} };
  } catch {
    return { features: {} };
  }
}

async function saveDayDoc(scope: AiScope, doc: UsageDayDoc): Promise<boolean> {
  try {
    const store = getStore({ name: AI_USAGE_STORE });
    // Keep 2 days of docs (expiry in ms metadata).
    await store.setJSON(`usage:${scope.kind}:${scope.id}:${todayKey()}`, doc, {
      metadata: { expiresIn: 2 * 86400 },
    });
    return true;
  } catch {
    /* best-effort by design */
    return false;
  }
}

export type QuotaInfo = { feature: string; limit: number; used: number; remaining: number };

/**
 * Enforces the daily quota for a feature. Returns:
 *   - null → caller is under the quota (and the request has been COUNTED);
 *   - a ready-to-return 429/401 Response when over quota / bad token.
 * Counting happens before the AI call (a request is a request), outcome
 * stats are merged afterwards by recordAiUsage.
 */
export async function enforceAiQuota(
  req: Request,
  feature: string,
  opts: { requireAuth?: boolean; failMode?: "open" | "closed" } = {}
): Promise<Response | null> {
  const who = await resolveAiCaller(req);
  if (who.status === "invalid-token") {
    return jsonResponse(401, { error: "Your session has expired — sign in again." });
  }
  if (opts.requireAuth && !who.user) {
    return jsonResponse(401, { error: "Sign in to use this feature." });
  }
  const limit = aiFeatureQuota(feature);
  try {
    const doc = await loadDayDoc(who.scope);
    const used = doc.features[feature]?.count ?? 0;
    if (used >= limit) {
      return jsonResponse(429, {
        error: `Daily AI limit reached for this feature (${limit} per day). Try again tomorrow — or sooner if the site owner raises the AI_DAILY_QUOTA_* setting.`,
        quota: { feature, limit, used, remaining: 0 },
      });
    }
    // count the request now (before the call — attempts are usage too)
    const f = doc.features[feature] ?? { count: 0, ok: 0, failed: 0, totalLatencyMs: 0, models: {} };
    f.count += 1;
    doc.features[feature] = f;
    const saved = await saveDayDoc(who.scope, doc);
    if (!saved) throw new Error("usage store write failed");
    return null;
  } catch {
    // Fail-OPEN by default (a usage-store hiccup must not block a
    // legitimate request) but fail-CLOSED for expensive operations: when
    // the operator opts a feature into "closed" mode, an uncheckable
    // quota means the request is refused — an attacker hammering the API
    // during a store outage must not get uncapped image-generation calls.
    if (opts.failMode === "closed") {
      return jsonResponse(503, {
        error: "The AI usage limiter can't be reached right now, so this feature is paused for safety — please try again shortly. Your saved work is untouched.",
      });
    }
    return null;
  }
}

/** Merges the OUTCOME of one AI request into the day doc (best-effort). */
export async function recordAiUsage(
  scope: AiScope | null,
  feature: string,
  outcome: { ok: boolean; model?: string; provider?: string; latencyMs: number }
): Promise<void> {
  if (!scope) return;
  try {
    const doc = await loadDayDoc(scope);
    const f = doc.features[feature] ?? { count: 0, ok: 0, failed: 0, totalLatencyMs: 0, models: {} };
    if (outcome.ok) f.ok += 1;
    else f.failed += 1;
    f.totalLatencyMs += Math.max(0, Math.round(outcome.latencyMs));
    if (outcome.model) f.models[outcome.model] = (f.models[outcome.model] ?? 0) + 1;
    // Providers are tracked as aggregate counters only (never per-user
    // content) — enough for diagnostics, useless for identification.
    const providers = (f as any).providers ?? {};
    if (outcome.provider) providers[outcome.provider] = (providers[outcome.provider] ?? 0) + 1;
    (f as any).providers = providers;
    doc.features[feature] = f;
    await saveDayDoc(scope, doc);
  } catch {
    /* best-effort by design */
  }
}

// --- safe result cache ---------------------------------------------------------

async function sha256Hex(input: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(input));
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

/** Stable cache key: feature + schema/prompt version + model + content. */
export async function aiCacheKey(
  feature: string,
  schemaVersion: string,
  model: string,
  content: string
): Promise<string> {
  return `${feature}:${await sha256Hex(`${feature}|${schemaVersion}|${model}|${content}`)}`;
}

export async function getCachedAnalysis<T>(key: string): Promise<T | null> {
  try {
    const store = getStore({ name: AI_CACHE_STORE });
    const doc = (await store.get(key, { type: "json" })) as { savedAt: number; value: T } | null;
    if (!doc || typeof doc.savedAt !== "number") {
      recordCacheLookup(false);
      return null;
    }
    if (Date.now() - doc.savedAt > aiCacheTtlHours() * 3600_000) {
      recordCacheLookup(false);
      return null; // expired
    }
    recordCacheLookup(true);
    return doc.value;
  } catch {
    return null;
  }
}

// --- request coalescing (Phase 4) ---------------------------------------------
//
// When two concurrent requests ask for the SAME deterministic AI result
// (same canonical cache key), they share one provider call instead of
// billing the API twice. Safe because the result is derived purely from
// the shared input content — user A's private data never influences user
// B's answer (both supplied byte-identical inputs, so both would have
// received byte-identical outputs anyway). Failures are never coalesced
// into successes: an error rejects every sharer honestly.

const inFlight = new Map<string, Promise<unknown>>();

export async function withCoalescing<T>(
  key: string,
  fn: () => Promise<T>
): Promise<T> {
  const existing = inFlight.get(key) as Promise<T> | undefined;
  if (existing) return existing;
  const p = fn().finally(() => {
    inFlight.delete(key);
  });
  inFlight.set(key, p);
  return p;
}

export async function putCachedAnalysis<T>(key: string, value: T): Promise<void> {
  try {
    const store = getStore({ name: AI_CACHE_STORE });
    await store.setJSON(
      key,
      { savedAt: Date.now(), value },
      { metadata: { expiresIn: Math.ceil(aiCacheTtlHours() * 3600) } }
    );
  } catch {
    /* best-effort by design */
  }
}

// --- one-line cache+quota+coalesce wrapper (Phase 4/5) -------------------------
//
// Standard flow for deterministic AI features, so every endpoint gets the
// same semantics without copy-pasting the order of operations:
//   1. cache lookup (hit → FREE, no quota consumed, no AI call)
//   2. quota check (counted per request; a request is usage, success or not)
//   3. coalesced execution (concurrent identical inputs share ONE AI call)
//   4. cache write (only for results `run` actually returned — failures
//      throw and are never cached as successes)
// `model` must be passed by the caller (it imports _gemini; this module
// must not, to avoid an import cycle).

export type CachedAiOutcome<T> =
  | { ok: true; result: T; cached: boolean; cacheKey: string }
  | { ok: false; response: Response };

export async function cachedAiCall<T>(
  req: Request,
  feature: string,
  opts: {
    schemaVersion: string;
    model: string;
    /** Canonical input representation — EVERYTHING that can change the
     *  result (inputs, options, prompt-affecting fields). */
    cacheContent: string;
    quota?: { requireAuth?: boolean; failMode?: "open" | "closed" };
  },
  run: () => Promise<T>
): Promise<CachedAiOutcome<T>> {
  const cacheKey = await aiCacheKey(feature, opts.schemaVersion, opts.model, opts.cacheContent);
  const cached = await getCachedAnalysis<T>(cacheKey);
  if (cached !== null) return { ok: true, result: cached, cached: true, cacheKey };
  const quotaResponse = await enforceAiQuota(req, feature, opts.quota ?? {});
  if (quotaResponse) return { ok: false, response: quotaResponse };
  const result = await withCoalescing(cacheKey, run);
  await putCachedAnalysis(cacheKey, result);
  return { ok: true, result, cached: false, cacheKey };
}
