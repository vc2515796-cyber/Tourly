import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import {
  jsonResponse,
  extractJson,
  enforceAiRateLimit,
  firebaseAdminConfigured,
  verifyAuthToken,
  AdminSetupError,
  TokenProjectMismatchError,
} from "./_shared.mts";
import { callGemini, GeminiError, getGeminiApiKey } from "./_gemini.mts";
import { enforceAiQuota, type AiScope } from "./_aiusage.mts";
import { LEADS_STORE_NAME, TOURS_STORE, loadLead, isLeadStage, type LeadStage } from "./_leads.mts";

/**
 * Stage D (Phase 7 of the AI upgrade) — AI lead insights.
 *
 * For one of the caller's OWN leads: an enquiry summary, a summary of what
 * the buyer actually asked for, and 2-4 suggested next actions tailored to
 * the lead's CURRENT stage. Everything is grounded STRICTLY in the lead's
 * own message + the tour's public content; the model is told to invent
 * nothing (no prices, availability, promises) and every response is marked
 * AI-generated. Nothing is ever sent anywhere by this endpoint.
 *
 * Privacy: the prompt contains only what the summary needs — the enquiry
 * message, the scene title, the tour name/content and the stage. The
 * buyer's name/phone/email are deliberately NOT included, and nothing
 * personal is logged.
 */

const MAX_NEXT_ACTIONS = 4;

export default async (req: Request) => {
  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  const limited = await enforceAiRateLimit(req, "lead-insights", 10);
  if (limited) return limited;

  if (!firebaseAdminConfigured()) {
    return jsonResponse(503, { error: "Lead management isn't available on this deployment (FIREBASE_SERVICE_ACCOUNT_KEY missing — see AUTH-SETUP.md §4)." });
  }

  let caller: Awaited<ReturnType<typeof verifyAuthToken>>;
  try {
    caller = await verifyAuthToken(req);
  } catch (err) {
    if (err instanceof AdminSetupError) return jsonResponse(503, { error: err.message });
    if (err instanceof TokenProjectMismatchError) return jsonResponse(401, { error: err.message });
    return jsonResponse(401, { error: "Your session has expired — sign in again." });
  }
  if (!caller) {
    return jsonResponse(401, { error: "Sign in to use AI lead insights." });
  }
  const scope: AiScope = { kind: "user", id: caller.uid };

  let body: { leadId?: string };
  try {
    body = await req.json();
  } catch {
    return jsonResponse(400, { error: "Invalid JSON body" });
  }
  const leadId = typeof body.leadId === "string" ? body.leadId.trim().slice(0, 64) : "";
  if (!leadId) return jsonResponse(400, { error: "leadId is required" });

  // Authorize FIRST (is this the caller's lead?), then report AI config —
  // access decisions must not depend on AI configuration.
  let lead;
  try {
    const store = getStore({ name: LEADS_STORE_NAME });
    lead = await loadLead(store, caller.uid, leadId);
  } catch {
    return jsonResponse(500, { error: "Couldn't load the lead." });
  }
  if (!lead) {
    return jsonResponse(404, { error: "Lead not found." });
  }
  if (lead.ownerUid !== caller.uid) {
    return jsonResponse(403, { error: "This lead belongs to a different account." });
  }

  if (!getGeminiApiKey()) {
    return jsonResponse(503, { error: "AI lead insights aren't configured on this deployment (GEMINI_API_KEY missing)." });
  }

  const quotaResponse = await enforceAiQuota(req, "lead-insights", { requireAuth: false });
  if (quotaResponse) return quotaResponse;

  // Grounding: the tour's own public content (rooms/notes) — same rule as
  // lead-draft. Buyer's name/phone/email deliberately NOT included.
  let roomList = "(tour content unavailable)";
  try {
    const toursStore = getStore({ name: TOURS_STORE });
    const tour = (await toursStore.get(lead.tourId, { type: "json" })) as
      | { stops?: { title?: string; note?: string }[] }
      | null;
    roomList =
      tour?.stops
        ?.slice(0, 20)
        .map((s) => `- ${s.title ?? "Scene"}${s.note ? `: ${s.note.slice(0, 120)}` : ""}`)
        .join("\n") ?? "(tour content unavailable)";
  } catch {
    /* grounding is best-effort */
  }

  const stage: LeadStage = isLeadStage(lead.stage) ? lead.stage : "new";
  const prompt = [
    "You are helping a real-estate agent triage one enquiry about a property tour.",
    `The buyer's enquiry message (verbatim): "${lead.message.slice(0, 800)}"`,
    lead.stopTitle ? `They were viewing the scene "${lead.stopTitle}" when they enquired.` : "",
    `Property tour: "${lead.tourName}"`,
    `Tour content:\n${roomList}`,
    `Current lead stage in the agent's CRM: ${stage}.`,
    "",
    "Produce, using ONLY the information above:",
    "1. enquirySummary — 1-2 factual sentences summarizing what the buyer actually asked.",
    "2. buyerRequirements — up to 5 short bullet strings listing ONLY requirements the buyer explicitly stated. If they stated none, return an empty array — never infer or invent requirements.",
    "3. suggestedNextActions — 2 to 4 short, practical next actions for the agent, appropriate for the CURRENT stage. They must be suggestions to DO things (e.g. call, schedule a visit, share more photos), never claims that something already happened, and never promises about price or availability.",
    'Respond with ONLY this JSON object, no other text: {"enquirySummary": string, "buyerRequirements": [string], "suggestedNextActions": [string]}',
  ]
    .filter(Boolean)
    .join(" ");

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30_000);

  try {
    const { response } = await callGemini(
      "text",
      {
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { responseMimeType: "application/json" },
      },
      { signal: controller.signal, functionName: "lead-insights", usage: { scope, feature: "lead-insights" } }
    );

    const data = await response.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
    const parsed = extractJson<{
      enquirySummary?: unknown;
      buyerRequirements?: unknown;
      suggestedNextActions?: unknown;
    }>(text);

    const cleanStrings = (raw: unknown, cap: number, maxLen: number): string[] =>
      Array.isArray(raw)
        ? raw
            .filter((s): s is string => typeof s === "string" && Boolean(s.trim()))
            .slice(0, cap)
            .map((s) => s.trim().slice(0, maxLen))
        : [];

    const enquirySummary =
      typeof parsed?.enquirySummary === "string" ? parsed.enquirySummary.trim().slice(0, 400) : "";
    if (!enquirySummary) {
      return jsonResponse(502, { error: "Could not summarize this enquiry — try again in a moment." });
    }

    return jsonResponse(200, {
      enquirySummary,
      buyerRequirements: cleanStrings(parsed?.buyerRequirements, 5, 120),
      suggestedNextActions: cleanStrings(parsed?.suggestedNextActions, MAX_NEXT_ACTIONS, 120),
      stage,
      aiGenerated: true,
      disclaimer: "AI-generated suggestions — review before acting. Nothing has been sent.",
    });
  } catch (err: any) {
    if (err instanceof GeminiError) {
      return jsonResponse(err.httpStatus, { error: err.safeMessage, retryable: err.retryable });
    }
    if (err?.name === "AbortError") {
      return jsonResponse(504, { error: "Lead insights timed out" });
    }
    return jsonResponse(500, { error: "Lead insights failed" });
  } finally {
    clearTimeout(timeout);
  }
};

export const config: Config = {
  path: "/api/lead-insights",
};
