import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import {
  jsonResponse,
  verifyAuthToken,
  firebaseAdminConfigured,
  AdminSetupError,
  TokenProjectMismatchError,
  extractJson,
  enforceAiRateLimit,
} from "./_shared.mts";
import { callGemini, GeminiError, getGeminiApiKey, resolveModels } from "./_gemini.mts";
import { cachedAiCall } from "./_aiusage.mts";
import { LEADS_STORE_NAME, TOURS_STORE, loadLead, leadStoreKey, type Lead, type LeadActivity } from "./_leads.mts";

/** Bump when the prompt or validation below changes (cache identity). */
const SCHEMA_VERSION = "1";

/**
 * Stage B5 — drafts a follow-up message for one of the caller's leads
 * (POST /api/lead-draft). Grounded STRICTLY in the actual enquiry + the
 * property tour's own content; the model is told to never invent prices,
 * availability, offers or promises. The DRAFT comes back for the agent to
 * edit and approve — nothing is sent by this endpoint, and the client UI
 * labels the result "draft — not sent" until the agent explicitly acts.
 */

export default async (req: Request) => {
  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  const limited = await enforceAiRateLimit(req, "lead-draft", 10);
  if (limited) return limited;

  if (!firebaseAdminConfigured()) {
    return jsonResponse(503, { error: "Lead management isn't available on this deployment (FIREBASE_SERVICE_ACCOUNT_KEY missing — see AUTH-SETUP.md §4)." });
  }

  let caller: Awaited<ReturnType<typeof verifyAuthToken>>;
  try {
    caller = await verifyAuthToken(req);
  } catch (err) {
    if (err instanceof AdminSetupError) return jsonResponse(503, { error: err.message });
    if (err instanceof TokenProjectMismatchError) return jsonResponse(401, { error: err.message });
    return jsonResponse(401, { error: "Your session has expired — sign in again." });
  }
  if (!caller) {
    return jsonResponse(401, { error: "Sign in to draft follow-ups." });
  }

  let body: { leadId?: string; channel?: string; language?: string };
  try {
    body = await req.json();
  } catch {
    return jsonResponse(400, { error: "Invalid JSON body" });
  }
  const leadId = typeof body.leadId === "string" ? body.leadId.trim().slice(0, 64) : "";
  if (!leadId) return jsonResponse(400, { error: "leadId is required" });
  const channel = ["whatsapp", "email", "sms"].includes(body.channel ?? "") ? body.channel! : "whatsapp";
  const language = ["en", "hi", "hinglish"].includes(body.language ?? "") ? body.language! : "en";

  // Authorize FIRST (is this the caller's lead?), then report service
  // availability — access decisions must not depend on AI configuration.
  let lead;
  try {
    const store = getStore({ name: LEADS_STORE_NAME });
    lead = await loadLead(store, caller.uid, leadId);
  } catch (err) {
    return jsonResponse(500, { error: "Couldn't load the lead.", detail: String(err) });
  }
  if (!lead) {
    return jsonResponse(404, { error: "Lead not found." });
  }
  if (lead.ownerUid !== caller.uid) {
    return jsonResponse(403, { error: "This lead belongs to a different account." });
  }

  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    return jsonResponse(503, { error: "AI follow-up drafting isn't configured on this deployment (GEMINI_API_KEY missing). You can still write the message yourself." });
  }

  try {
    const store = getStore({ name: LEADS_STORE_NAME });

    // Grounding: the tour's own public content (rooms/notes), which the
    // agent authored — plus the visitor's actual enquiry.
    const toursStore = getStore({ name: TOURS_STORE });
    const tour = (await toursStore.get(lead.tourId, { type: "json" })) as
      | { name?: string; subtitle?: string; stops?: { title?: string; note?: string }[] }
      | null;
    const roomList =
      tour?.stops
        ?.slice(0, 20)
        .map((s) => `- ${s.title ?? "Scene"}${s.note ? `: ${s.note.slice(0, 120)}` : ""}`)
        .join("\n") ?? "(tour content unavailable)";

    const languageRule =
      language === "hi"
        ? "Write in simple, warm Hindi (Devanagari)."
        : language === "hinglish"
        ? "Write in natural Hinglish (Roman script, Hindi-English mix) like an Indian agent's WhatsApp message."
        : "Write in clear, simple English.";

    const prompt = [
      `You are drafting a FOLLOW-UP message an estate agent can send to someone who enquired about a property tour.`,
      `Enquiry details: name ${lead.name ? `"${lead.name}"` : "(not given)"}, message: "${lead.message.slice(0, 500)}"`,
      lead.stopTitle ? `They were viewing the scene "${lead.stopTitle}" when they enquired.` : "",
      `Property tour: "${lead.tourName}"${tour?.subtitle ? ` — ${String(tour.subtitle).slice(0, 160)}` : ""}`,
      `Tour content:\n${roomList}`,
      "",
      `Channel: ${channel}. ${languageRule}`,
      "HARD RULES: use ONLY the facts above. Do NOT invent prices, offers, discounts, availability dates, addresses, or promises (site visits can be OFFERED as a suggestion to schedule, not confirmed).",
      "Do NOT claim any message was already sent. Keep it under 120 words, friendly, and end with one clear question.",
      'Place the tour link as {tourLink}. Respond with ONLY this JSON: {"draft": string}',
    ]
      .filter(Boolean)
      .join(" ");

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30_000);
    let draftText = "";
    let cached = false;
    try {
      // Deterministic per (enquiry, tour content, channel, language) → cache
      // + per-user quota + coalescing. The activity trail below is written
      // on EVERY call (cached or not) so the agent's audit trail stays true.
      const outcome = await cachedAiCall<string>(
        req,
        "lead-draft",
        {
          schemaVersion: SCHEMA_VERSION,
          model: resolveModels("text")[0]!,
          cacheContent: JSON.stringify({
            message: lead.message,
            stopTitle: lead.stopTitle ?? "",
            tourName: lead.tourName,
            subtitle: tour?.subtitle ?? "",
            roomList,
            channel,
            language,
          }),
          quota: {},
        },
        async () => {
      const { response } = await callGemini(
        "text",
        {
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { responseMimeType: "application/json" },
        },
        { signal: controller.signal, functionName: "lead-draft" }
      );
      const data = await response.json();
      const text = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
      const parsed = extractJson<{ draft?: string }>(text);
      const out = typeof parsed?.draft === "string" ? parsed.draft.slice(0, 1500).trim() : "";
      if (!out) {
        throw Object.assign(new Error("bad-draft"), {
          endpointStatus: 502,
          endpointPayload: { error: "Could not parse a draft from the AI — write it yourself below." },
        });
      }
      return out;
        }
      );
      if (!outcome.ok) return outcome.response;
      draftText = outcome.result;
      cached = outcome.cached;
    } finally {
      clearTimeout(timeout);
    }

    // Record the draft in the lead's activity trail (it is a draft, not a send).
    const now = Date.now();
    const activity: LeadActivity = { id: crypto.randomUUID(), kind: "draft", at: now, text: draftText, channel, language };
    const updated: Lead = { ...lead, activities: [...lead.activities, activity].slice(-200), updatedAt: now };
    await store.setJSON(leadStoreKey(caller.uid, leadId), updated);

    return jsonResponse(200, {
      draft: draftText,
      cached,
      disclaimer: "AI draft — review and edit before sending. Nothing has been sent.",
    });
  } catch (err: any) {
    if (err?.endpointStatus) {
      return jsonResponse(err.endpointStatus, err.endpointPayload);
    }
    if (err instanceof GeminiError) {
      // Keep the lead-flow UX honest but specific: a rate-limited or busy AI
      // is temporary (the agent can retry), anything else falls back to the
      // manual-write path.
      return jsonResponse(err.httpStatus, {
        error: err.retryable
          ? `${err.safeMessage} You can also write the follow-up yourself below.`
          : "Couldn't draft the follow-up — write it yourself below.",
        retryable: err.retryable,
      });
    }
    return jsonResponse(500, { error: "Couldn't draft the follow-up — write it yourself below." });
  }
};

export const config: Config = {
  path: "/api/lead-draft",
};
