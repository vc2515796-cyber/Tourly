import type { Config } from "@netlify/functions";
import { jsonResponse, extractJson, enforceAiRateLimit } from "./_shared.mts";
import { callGemini, GeminiError, getGeminiApiKey, resolveModels } from "./_gemini.mts";
import { cachedAiCall } from "./_aiusage.mts";

/** Bump when the prompt or validation below changes (cache identity). */
const SCHEMA_VERSION = "1";

/**
 * Suggests which stops in a tour would sensibly connect to which others
 * (e.g. Living Room -> Kitchen), based only on room titles/notes — this
 * has no access to the actual photos, so it's a starting point, not a
 * layout fact. The editor always presents these as pending suggestions
 * the creator must add (or ignore) one at a time — nothing here writes
 * a hotspot directly.
 */
export default async (req: Request) => {
  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  const limited = await enforceAiRateLimit(req, "suggest-hotspots", 15);
  if (limited) return limited;

  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    return jsonResponse(503, { error: "Hotspot suggestions not configured" });
  }

  let body: { stops?: { id: string; title: string; note?: string }[] };
  try {
    body = await req.json();
  } catch {
    return jsonResponse(400, { error: "Invalid JSON body" });
  }

  const stops = body.stops ?? [];
  if (stops.length < 2) {
    return jsonResponse(400, { error: "Need at least 2 stops to suggest connections" });
  }
  // Sanitize: ids/titles/notes only, bounded — never trust raw client text.
  const clean = stops
    .filter((s) => typeof s?.id === "string" && typeof s?.title === "string")
    .slice(0, 60)
    .map((s) => ({ id: s.id!.slice(0, 64), title: s.title!.slice(0, 80), note: typeof s.note === "string" ? s.note.slice(0, 200) : undefined }));
  if (clean.length < 2) {
    return jsonResponse(400, { error: "Stops need ids and titles" });
  }

  const roomList = clean.map((s) => `- id: ${s.id}, name: "${s.title}"${s.note ? `, note: "${s.note}"` : ""}`).join("\n");

  const prompt = [
    "Here is the list of rooms/stops in a property walkthrough, each with an id:",
    roomList,
    "",
    "Suggest sensible one-way walk connections between rooms that are likely to be adjacent",
    "or naturally reached from each other (e.g. a Living Room typically connects to a Kitchen",
    "and a Hallway; a Bedroom typically connects to a Bathroom). Suggest at most 2 connections",
    "per room, and only use the ids given above for both fromId and toId — never invent an id.",
    'Respond with ONLY this JSON object, no other text: {"suggestions": [{"fromId": string, "toId": string, "label": string}]}',
    'where "label" is a short button label like "To Kitchen".',
  ].join(" ");

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30_000);

  // Deterministic per input list → cache + per-user quota + coalescing.
  try {
    const outcome = await cachedAiCall<{ suggestions: { fromId: string; toId: string; label: string }[] }>(
      req,
      "suggest-hotspots",
      {
        schemaVersion: SCHEMA_VERSION,
        model: resolveModels("text")[0]!,
        cacheContent: JSON.stringify(clean),
        quota: {},
      },
      async () => {
    const { response } = await callGemini(
      "text",
      {
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { responseMimeType: "application/json" },
      },
      { signal: controller.signal, functionName: "suggest-hotspots" }
    );

    const data = await response.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
    const parsed = extractJson<{ suggestions?: { fromId: string; toId: string; label: string }[] }>(text);

    const validIds = new Set(clean.map((s) => s.id));
    const suggestions = (parsed?.suggestions ?? []).filter(
      (s) => validIds.has(s.fromId) && validIds.has(s.toId) && s.fromId !== s.toId
    );

    return { suggestions };
      }
    );
    if (!outcome.ok) return outcome.response;
    return jsonResponse(200, { ...outcome.result, cached: outcome.cached });
  } catch (err: any) {
    if (err instanceof GeminiError) {
      return jsonResponse(err.httpStatus, { error: err.safeMessage, retryable: err.retryable });
    }
    if (err?.name === "AbortError") {
      return jsonResponse(504, { error: "Suggestion timed out" });
    }
    return jsonResponse(500, { error: "Suggestion failed" });
  } finally {
    clearTimeout(timeout);
  }
};

export const config: Config = {
  path: "/api/suggest-hotspots",
};
