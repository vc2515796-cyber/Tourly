import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import { jsonResponse, rateLimit, clientIp } from "./_shared.mts";
import {
  ANALYTICS_STORE_NAME,
  PUBLIC_EVENT_KINDS,
  hashVisitorToken,
  isEventSource,
  isPublicEventKind,
  recordTourEvent,
} from "./_analytics.mts";
import { TOURS_STORE } from "./_leads.mts";

/**
 * Stage C — PUBLIC endpoint that records engagement events from a
 * published tour's public page (/tour/:id). Fires: tour-view (once per
 * visitor session, guarded client-side), scene-view, hotspot.
 *
 * Security posture (mirrors capture-lead):
 *  - strict payload validation + whitelisted kinds/sources
 *  - enquiry/visit-request are REJECTED here — only capture-lead.mts
 *    records those, server-side, so conversion numbers can't be inflated
 *    from the browser
 *  - per-IP rate limit, fails open on infra errors like the rest of the app
 *  - only the tour's existence is checked — nothing about the owner is
 *    returned, and nothing personal about the visitor is stored (see
 *    _analytics.mts for the privacy model)
 *  - analytics failures must never break the tour page — the client
 *    fire-and-forgets, and a 500 here is invisible to the visitor
 */

type TrackBody = {
  tourId?: string;
  kind?: string;
  source?: string;
  sceneId?: string;
  visitorId?: string;
};

const RATE_LIMIT = 60; // events per IP per minute — enough for an engaged
// visitor walking a large tour (a scene-view per stop + hotspots), still
// cheap to abuse-test.

export default async (req: Request) => {
  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  let body: TrackBody;
  try {
    body = await req.json();
  } catch {
    return jsonResponse(400, { error: "Invalid JSON body" });
  }

  const tourId = typeof body.tourId === "string" ? body.tourId.trim().slice(0, 64) : "";
  const kind = typeof body.kind === "string" ? body.kind.trim() : "";
  const source = typeof body.source === "string" ? body.source.trim() : "direct";
  const sceneId = typeof body.sceneId === "string" ? body.sceneId.trim().slice(0, 64) : undefined;
  const visitorId = typeof body.visitorId === "string" ? body.visitorId.trim().slice(0, 64) : undefined;

  if (!tourId) return jsonResponse(400, { error: "Missing tourId" });
  if (!isPublicEventKind(kind)) {
    if (kind === "enquiry" || kind === "visit-request") {
      return jsonResponse(400, { error: "That event kind is recorded server-side only." });
    }
    return jsonResponse(400, { error: "Unknown event kind" });
  }
  if (!isEventSource(source)) return jsonResponse(400, { error: "Unknown source" });
  if ((kind === "scene-view" || kind === "hotspot") && !sceneId) {
    return jsonResponse(400, { error: "Missing sceneId" });
  }
  if (visitorId !== undefined && !/^[A-Za-z0-9_-]{8,64}$/.test(visitorId)) {
    return jsonResponse(400, { error: "Invalid visitorId" });
  }

  try {
    const analyticsStore = getStore({ name: ANALYTICS_STORE_NAME });
    const toursStore = getStore({ name: TOURS_STORE });

    const { limited } = await rateLimit(analyticsStore, `track:${clientIp(req)}`, RATE_LIMIT, 60);
    if (limited) {
      return jsonResponse(429, { error: "Too many events from this connection." });
    }

    // Only PUBLISHED tours exist in the tours store, so drafts and
    // made-up ids are rejected before anything is written.
    const tour = await toursStore.get(tourId, { type: "json" });
    if (!tour) {
      return jsonResponse(404, { error: "Unknown tour" });
    }

    const visitorHash = kind === "tour-view" && visitorId ? await hashVisitorToken(visitorId) : undefined;
    await recordTourEvent(analyticsStore, tourId, { kind, source, sceneId, visitorHash });
    return jsonResponse(200, { ok: true });
  } catch {
    // Generic 500 — no internals leaked; the client ignores this anyway.
    return jsonResponse(500, { error: "Couldn't record event" });
  }
};

export const config: Config = {
  path: "/api/track-event",
};
