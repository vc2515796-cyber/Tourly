import type { Config } from "@netlify/functions";
import { jsonResponse, extractJson, enforceAiRateLimit } from "./_shared.mts";
import { callGemini, GeminiError, getGeminiApiKey, resolveModels } from "./_gemini.mts";
import { cachedAiCall } from "./_aiusage.mts";

/** Bump when the prompt or validation below changes (cache identity). */
const SCHEMA_VERSION = "1";

/**
 * Scene-sequence suggestion (Feature B). Given the tour's scene titles and
 * notes, proposes a logical visiting order (e.g. entrance → living →
 * kitchen → bedrooms → outdoor). Purely a suggestion — the creator reviews
 * the proposed order and explicitly applies it; nothing is auto-applied,
 * and the ordering is inferred from titles/notes only, never presented as a
 * verified floor-plan walk-through.
 */
export default async (req: Request) => {
  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  const limited = await enforceAiRateLimit(req, "suggest-sequence", 10);
  if (limited) return limited;

  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    return jsonResponse(503, { error: "Sequence suggestion not configured" });
  }

  let body: { stops?: { id?: string; title?: string; note?: string }[] };
  try {
    body = await req.json();
  } catch {
    return jsonResponse(400, { error: "Invalid JSON body" });
  }

  const stops = Array.isArray(body.stops) ? body.stops : [];
  if (stops.length < 2 || stops.length > 60) {
    return jsonResponse(400, { error: "A list of 2–60 scenes is required" });
  }

  // Only pass through well-formed entries — the model must echo these exact
  // ids back, so garbage in would mean garbage (or missing) ids out.
  const clean = stops
    .filter((s) => typeof s.id === "string" && typeof s.title === "string")
    .map((s) => ({ id: s.id!, title: s.title!.slice(0, 80), note: (s.note ?? "").slice(0, 200) }));
  if (clean.length < 2) {
    return jsonResponse(400, { error: "Scenes need ids and titles" });
  }

  const prompt = [
    "You are ordering the scenes of a property or venue walkthrough so a visitor walks it",
    "naturally: entrance/reception first, then main living areas, then kitchen, then bedrooms",
    "and bathrooms, then outdoor/balcony/garage last. For construction sites, order by the",
    "natural site path instead. Here are the scenes:",
    ...clean.map((s, i) => `${i + 1}. id=${s.id} title="${s.title}"${s.note ? ` note="${s.note}"` : ""}`),
    "Return the ids in the best visiting order, using EVERY id exactly once and inventing none.",
    "Also give a one-sentence rationale for the order.",
    'Respond with ONLY this JSON object: {"orderedIds": string[], "rationale": string}',
  ].join("\n");

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 25_000);

  // Deterministic per input list → cache + per-user quota + coalescing.
  try {
    const outcome = await cachedAiCall<{ orderedIds: string[]; rationale: string }>(
      req,
      "suggest-sequence",
      {
        schemaVersion: SCHEMA_VERSION,
        model: resolveModels("text")[0]!,
        cacheContent: JSON.stringify(clean),
        quota: {},
      },
      async () => {
    const { response } = await callGemini(
      "text",
      {
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { responseMimeType: "application/json" },
      },
      { signal: controller.signal, functionName: "suggest-sequence" }
    );

    const data = await response.json();
    if (!data?.candidates?.length) {
      throw Object.assign(new Error("no-candidates"), {
        endpointStatus: 502,
        endpointPayload: { error: "Gemini returned no sequence." },
      });
    }
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
    const parsed = extractJson<{ orderedIds?: unknown; rationale?: unknown }>(text);

    if (!Array.isArray(parsed?.orderedIds)) {
      throw Object.assign(new Error("bad-json"), {
        endpointStatus: 502,
        endpointPayload: {
          error: "Could not parse a sequence from Gemini's response.",
          detail: text.slice(0, 300),
        },
      });
    }

    // Strict validation: keep only known ids, dedupe, and require a
    // permutation (every scene exactly once). Anything less is rejected —
    // a partial reordering would silently drop scenes on apply.
    const known = new Set(clean.map((s) => s.id));
    const seen = new Set<string>();
    const orderedIds: string[] = [];
    for (const id of parsed.orderedIds) {
      if (typeof id === "string" && known.has(id) && !seen.has(id)) {
        seen.add(id);
        orderedIds.push(id);
      }
    }
    if (orderedIds.length !== clean.length) {
      throw Object.assign(new Error("bad-sequence"), {
        endpointStatus: 502,
        endpointPayload: { error: "Gemini's sequence didn't include every scene exactly once — try again." },
      });
    }

    return {
      orderedIds,
      rationale: typeof parsed.rationale === "string" ? parsed.rationale.slice(0, 300) : "",
    };
      }
    );
    if (!outcome.ok) return outcome.response;
    return jsonResponse(200, { ...outcome.result, cached: outcome.cached });
  } catch (err: any) {
    if (err?.endpointStatus) {
      return jsonResponse(err.endpointStatus, err.endpointPayload);
    }
    if (err instanceof GeminiError) {
      return jsonResponse(err.httpStatus, { error: err.safeMessage, retryable: err.retryable });
    }
    if (err?.name === "AbortError") {
      return jsonResponse(504, { error: "Sequence suggestion timed out" });
    }
    return jsonResponse(500, { error: "Sequence suggestion failed" });
  } finally {
    clearTimeout(timeout);
  }
};

export const config: Config = {
  path: "/api/suggest-sequence",
};
