/**
 * Provider adapter layer (AI reliability upgrade, Phase 2).
 *
 * Gemini remains the PRIMARY provider (handled by _gemini.mts). This module
 * adds an OPTIONAL secondary provider — Groq or Mistral — used only when
 * Gemini fails in a way a different provider can plausibly survive
 * (rate limit, daily quota, outage, timeout, network), and only when its
 * API key is configured. With no secondary configured the app behaves
 * EXACTLY as before — this module is a no-op.
 *
 * Why adapters instead of "it's all OpenAI-compatible": Groq and Mistral
 * both expose OpenAI-style /chat/completions endpoints, but each has its
 * own base URL, model id namespace, auth header, response quirks and
 * rate-limit semantics. The provider-specific knowledge lives HERE, in
 * per-provider config + conversion functions, so _gemini.mts stays a
 * single coordinator and every endpoint above it keeps its existing
 * Gemini-shaped response contract (candidates[0].content.parts[0].text).
 *
 * Official documentation verified 2026-10-18 (re-check before changing):
 *   Groq    — https://console.groq.com/docs/openai  (OpenAI-compatible)
 *             endpoint https://api.groq.com/openai/v1/chat/completions
 *             production text models include openai/gpt-oss-120b,
 *             openai/gpt-oss-20b, llama-3.3-70b-versatile,
 *             llama-3.1-8b-instant; free tier limits per model are listed
 *             at https://console.groq.com/docs/rate-limits (e.g.
 *             gpt-oss-120b: 30 RPM / 1K RPD / 8K TPM at verification time
 *             — providers change these, so numbers are NOT hardcoded as
 *             facts anywhere in this codebase).
 *   Mistral — https://docs.mistral.ai/api (chat completions at
 *             https://api.mistral.ai/v1/chat/completions); models include
 *             mistral-small-latest; response_format is supported. Free
 *             "Experiment" plan limits vary — check the Mistral console.
 *
 * Security: provider keys are read from SERVER-ONLY env vars and never
 * appear in logs, responses or client bundles (sanitizeDetail in
 * _gemini.mts strips key-shaped strings from anything logged).
 */

// --- provider identity --------------------------------------------------------

export type SecondaryProviderId = "groq" | "mistral";

export type SecondaryProvider = {
  id: SecondaryProviderId;
  apiKey: string;
  model: string;
  /** Full chat-completions URL (official, per-provider). */
  endpoint: string;
};

/** Verified default models per provider — see the links in the header.
 *  Deliberately TEXT-ONLY choices: neither provider's current default
 *  model is used for vision here (see payloadHasImages). */
const SECONDARY_DEFAULTS: Record<
  SecondaryProviderId,
  { model: string; endpoint: string }
> = {
  groq: {
    model: "openai/gpt-oss-120b",
    endpoint: "https://api.groq.com/openai/v1/chat/completions",
  },
  mistral: {
    model: "mistral-small-latest",
    endpoint: "https://api.mistral.ai/v1/chat/completions",
  },
};

export function fallbackProviderDisabled(): boolean {
  return /^(1|true|yes)$/i.test(process.env.AI_DISABLE_FALLBACK_PROVIDER ?? "");
}

/**
 * Resolves the (at most ONE) secondary provider from env vars:
 *   GROQ_API_KEY / GROQ_MODEL        → Groq
 *   MISTRAL_API_KEY / MISTRAL_MODEL  → Mistral (used only if Groq is absent)
 * Groq wins when both are configured (documented precedence, no rotation —
 * one request NEVER fans out to multiple providers). Returns null when
 * nothing is configured or the feature is disabled — callers must then
 * keep their existing single-provider behaviour untouched.
 */
export function resolveSecondaryProvider(): SecondaryProvider | null {
  if (fallbackProviderDisabled()) return null;
  const groqKey = process.env.GROQ_API_KEY?.trim();
  if (groqKey) {
    return {
      id: "groq",
      apiKey: groqKey,
      model: (process.env.GROQ_MODEL?.trim() || SECONDARY_DEFAULTS.groq.model),
      endpoint: SECONDARY_DEFAULTS.groq.endpoint,
    };
  }
  const mistralKey = process.env.MISTRAL_API_KEY?.trim();
  if (mistralKey) {
    return {
      id: "mistral",
      apiKey: mistralKey,
      model: (process.env.MISTRAL_MODEL?.trim() || SECONDARY_DEFAULTS.mistral.model),
      endpoint: SECONDARY_DEFAULTS.mistral.endpoint,
    };
  }
  return null;
}

// --- request / response conversion (Gemini payload ⇄ OpenAI-style) -----------

type AnyPart = Record<string, any>;

/**
 * Converts a Gemini generateContent payload into an OpenAI-style
 * chat-completions request body for the secondary provider.
 * - systemInstruction.parts[].text  → one system message
 * - contents[].role "model"         → "assistant" (any other → "user")
 * - parts[].text                    → { type: "text" }
 * - parts[].inline_data             → { type: "image_url", data: URL }
 *   (only reached when AI_FALLBACK_ALLOW_VISION is enabled — see
 *    payloadHasImages; the default models are text-only)
 * - generationConfig.responseMimeType "application/json"
 *                                   → response_format { type: "json_object" }
 *   (supported by both providers; verified in their docs)
 * - generationConfig.temperature / maxOutputTokens → temperature / max_tokens
 * Unknown fields are DROPPED, never guessed at.
 */
export function toOpenAiChatRequest(
  geminiPayload: Record<string, unknown>,
  model: string
): Record<string, unknown> {
  const messages: AnyPart[] = [];

  const systemParts = (geminiPayload as any)?.systemInstruction?.parts;
  if (Array.isArray(systemParts)) {
    const sysText = systemParts
      .map((p: AnyPart) => (typeof p?.text === "string" ? p.text : ""))
      .filter(Boolean)
      .join("\n\n");
    if (sysText) messages.push({ role: "system", content: sysText });
  }

  const contents = Array.isArray((geminiPayload as any)?.contents)
    ? (geminiPayload as any).contents
    : [];
  for (const turn of contents) {
    const role = turn?.role === "model" ? "assistant" : "user";
    const parts = Array.isArray(turn?.parts) ? turn.parts : [];
    const content: AnyPart[] = [];
    for (const part of parts) {
      if (typeof part?.text === "string" && part.text) {
        content.push({ type: "text", text: part.text });
      } else if (part?.inline_data?.data) {
        const mime = part.inline_data.mime_type ?? "image/jpeg";
        content.push({
          type: "image_url",
          image_url: { url: `data:${mime};base64,${part.inline_data.data}` },
        });
      }
    }
    if (content.length) messages.push({ role, content });
  }
  // A request with no messages is invalid everywhere — fail fast upstream.
  if (!messages.length) messages.push({ role: "user", content: { type: "text", text: "" } });

  const gen = (geminiPayload as any)?.generationConfig ?? {};
  const body: Record<string, unknown> = { model, messages };
  if (gen.responseMimeType === "application/json") {
    body.response_format = { type: "json_object" };
  }
  if (typeof gen.temperature === "number") body.temperature = gen.temperature;
  if (typeof gen.maxOutputTokens === "number" && gen.maxOutputTokens > 0) {
    body.max_tokens = gen.maxOutputTokens;
  }
  return body;
}

/**
 * Normalizes an OpenAI-style chat-completions JSON body into the GEMINI
 * response shape every existing endpoint already parses:
 *   { candidates: [{ content: { parts: [{ text }] } }] }
 * This is the compatibility seam that lets 14 endpoints and their tests
 * keep working without knowing which provider answered.
 */
export function fromOpenAiChatResponse(
  providerJson: any,
  model: string
): { candidates: { content: { parts: { text: string }[]; role: string } }[]; modelVersion: string } {
  let text = "";
  const msg = providerJson?.choices?.[0]?.message;
  if (typeof msg?.content === "string") {
    text = msg.content;
  } else if (Array.isArray(msg?.content)) {
    // Some providers return segmented content — join the text segments.
    text = msg.content
      .map((seg: AnyPart) => (typeof seg?.text === "string" ? seg.text : ""))
      .join("");
  }
  return {
    candidates: [{ content: { parts: [{ text }], role: "model" } }],
    modelVersion: model,
  };
}

/** True when the payload carries image/video input (inline_data parts). */
export function payloadHasImages(geminiPayload: Record<string, unknown>): boolean {
  const contents = Array.isArray((geminiPayload as any)?.contents)
    ? (geminiPayload as any).contents
    : [];
  for (const turn of contents) {
    for (const part of Array.isArray(turn?.parts) ? turn.parts : []) {
      if (part?.inline_data?.data) return true;
    }
  }
  return false;
}

/** Vision requests only go to the secondary provider when the operator has
 *  EXPLICITLY opted in — the default secondary models are text-only, and
 *  silently sending an image to a text model would fail (or worse, produce
 *  a confidently wrong answer). */
export function visionFallbackAllowed(): boolean {
  return /^(1|true|yes)$/i.test(process.env.AI_FALLBACK_ALLOW_VISION ?? "");
}

// --- circuit breaker (per provider, per function instance) --------------------
//
// A short-lived, in-memory breaker: after N consecutive failures a provider
// is skipped for a cooldown window, then automatically retried (half-open).
// Scope honesty: Netlify may run several function instances, so this breaker
// protects EACH INSTANCE from retry storms — it is not a global switch. The
// trip is also recorded in the persisted metrics (see recordProviderOutcome)
// so admin diagnostics can see it.

export type BreakerSnapshot = { open: boolean; msUntilRetry: number; consecutiveFailures: number };

const breakers = new Map<string, { consecutiveFailures: number; openUntil: number }>();

function envInt(name: string, def: number): number {
  const n = Number(process.env[name]);
  return Number.isFinite(n) && n >= 0 ? n : def;
}

export function breakerSnapshot(provider: string, now = Date.now()): BreakerSnapshot {
  const b = breakers.get(provider);
  if (!b) return { open: false, msUntilRetry: 0, consecutiveFailures: 0 };
  const open = b.openUntil > now;
  return {
    open,
    msUntilRetry: open ? b.openUntil - now : 0,
    consecutiveFailures: b.consecutiveFailures,
  };
}

export function noteProviderSuccess(provider: string): void {
  breakers.delete(provider);
}

/** Records a provider failure; returns true when THIS call tripped the
 *  breaker (so the caller can log/record the trip exactly once). */
export function noteProviderFailure(provider: string, now = Date.now()): boolean {
  const threshold = Math.max(1, Math.floor(envInt("AI_BREAKER_THRESHOLD", 4)));
  const cooldownMs = Math.max(1_000, envInt("AI_BREAKER_COOLDOWN_MS", 60_000));
  const b = breakers.get(provider) ?? { consecutiveFailures: 0, openUntil: 0 };
  b.consecutiveFailures += 1;
  let tripped = false;
  if (b.consecutiveFailures >= threshold && b.openUntil <= now) {
    b.openUntil = now + cooldownMs;
    tripped = true;
  }
  breakers.set(provider, b);
  return tripped;
}

/** TEST-ONLY hook: clears breaker + concurrency state so unit tests can
 *  exercise scenarios independently. Never called by production code. */
export function resetReliabilityStateForTests(): void {
  breakers.clear();
  for (const slot of slots.values()) {
    slot.running = 0;
    slot.queue.length = 0;
  }
  slots.clear();
}

// --- concurrency limiter (per provider, per function instance) -----------------
//
// Caps how many requests THIS instance has in flight at a provider, so a
// burst of user actions can't stampede one API key. Requests queue FIFO and
// abandon the wait once their deadline passes (the caller treats that like
// a budget miss, not an error).

type Slot = { running: number; queue: (() => void)[] };

const slots = new Map<string, Slot>();

export function maxConcurrentPerProvider(): number {
  return Math.max(1, Math.floor(envInt("AI_MAX_CONCURRENT_PER_PROVIDER", 4)));
}

/**
 * Runs `fn` while holding one of the provider's concurrency slots. If a
 * slot can't be acquired before `deadlineMs` (epoch ms), resolves null —
 * the caller decides what that means (skip provider / classify as timeout).
 */
export async function withProviderSlot<T>(
  provider: string,
  deadlineMs: number,
  fn: () => Promise<T>
): Promise<T | null> {
  const slot = slots.get(provider) ?? { running: 0, queue: [] };
  slots.set(provider, slot);

  if (slot.running >= maxConcurrentPerProvider()) {
    // Wait in the FIFO queue until a slot is released or the deadline hits.
    const acquired = await new Promise<boolean>((resolve) => {
      let timer: ReturnType<typeof setTimeout> | null = null;
      const wake = () => {
        if (timer) clearTimeout(timer);
        resolve(true);
      };
      timer = setTimeout(() => {
        const idx = slot.queue.indexOf(wake);
        if (idx >= 0) slot.queue.splice(idx, 1);
        resolve(false);
      }, Math.max(0, deadlineMs - Date.now()));
      slot.queue.push(wake);
    });
    // Deadline passed while queued, or woken but lost a race to another
    // waiter — either way, never over-admit past the cap.
    if (!acquired || slot.running >= maxConcurrentPerProvider()) return null;
  }
  slot.running += 1;
  try {
    return await fn();
  } finally {
    slot.running -= 1;
    const next = slot.queue.shift();
    if (next) next();
  }
}
