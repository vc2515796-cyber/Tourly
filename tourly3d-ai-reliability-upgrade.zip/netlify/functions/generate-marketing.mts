import type { Config } from "@netlify/functions";
import { jsonResponse, extractJson, enforceAiRateLimit } from "./_shared.mts";
import { callGemini, GeminiError, getGeminiApiKey, resolveModels } from "./_gemini.mts";
import {
  enforceAiQuota,
  resolveAiCaller,
  aiCacheKey,
  getCachedAnalysis,
  putCachedAnalysis,
  withCoalescing,
  type AiScope,
} from "./_aiusage.mts";

/**
 * Stage B4 — the grounded AI listing copywriter.
 *
 * Evolves the original generate-marketing endpoint (same path, same 7
 * response fields kept for backward compatibility) with:
 *  - user-supplied FACTS (type, location, size, price, beds, baths,
 *    amenities, audience, tone, language, channel)
 *  - an explicit "never invent" contract: missing facts are reported in
 *    `missingFields`, not fabricated into the copy
 *  - EN / Hindi / Hinglish output
 *  - two new fields: `headline` (short listing headline) and `tourIntro`
 *    (a 1-2 sentence property-tour introduction)
 *
 * Everything stays a DRAFT the creator edits/approves — nothing here
 * publishes anywhere automatically.
 */

const MAX_STOPS = 40;

export type MarketingFacts = {
  propertyType?: string;
  location?: string;
  size?: string;
  price?: string;
  bedrooms?: string;
  bathrooms?: string;
  amenities?: string[];
  audience?: string;
  tone?: string;
  language?: "en" | "hi" | "hinglish";
  channel?: string;
  /** Total floor-plan area in m², computed from the CALIBRATED plan geometry
   *  (never sent unless scale.calibrated). */
  planAreaM2?: number;
};

const str = (v: unknown, max = 200): string => (typeof v === "string" ? v.trim().slice(0, max) : "");
const num = (v: unknown): number | undefined => (typeof v === "number" && Number.isFinite(v) && v > 0 ? v : undefined);

function sanitizeFacts(body: any): { facts: MarketingFacts; missing: string[] } {
  const facts: MarketingFacts = {
    propertyType: str(body?.facts?.propertyType, 60),
    location: str(body?.facts?.location, 120),
    size: str(body?.facts?.size, 60),
    price: str(body?.facts?.price, 60),
    bedrooms: str(body?.facts?.bedrooms, 20),
    bathrooms: str(body?.facts?.bathrooms, 20),
    amenities: Array.isArray(body?.facts?.amenities)
      ? body.facts.amenities.filter((a: unknown) => typeof a === "string").slice(0, 15).map((a: string) => a.slice(0, 40))
      : [],
    audience: str(body?.facts?.audience, 60),
    tone: str(body?.facts?.tone, 40),
    language: ["en", "hi", "hinglish"].includes(body?.facts?.language) ? body.facts.language : "en",
    channel: str(body?.facts?.channel, 40),
    planAreaM2: num(body?.facts?.planAreaM2),
  };
  const missing: string[] = [];
  if (!facts.price) missing.push("price");
  if (!facts.location) missing.push("location/address");
  if (!facts.size && !facts.planAreaM2) missing.push("size");
  if (!facts.bedrooms) missing.push("bedrooms");
  if (!facts.bathrooms) missing.push("bathrooms");
  return { facts, missing };
}

export default async (req: Request) => {
  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  const limited = await enforceAiRateLimit(req, "generate-marketing", 10);
  if (limited) return limited;

  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    return jsonResponse(503, { error: "Marketing generation not configured" });
  }

  // Resolve the caller up front for usage attribution (per VERIFIED account
  // when a token is sent, per IP for anonymous callers). A stale/invalid
  // token is still a hard 401: an invalid credential must never widen
  // access. The QUOTA itself is enforced further down, after the cache
  // lookup — cached results don't consume quota.
  const who = await resolveAiCaller(req);
  if (who.status === "invalid-token") {
    return jsonResponse(401, { error: "Your session has expired — sign in again." });
  }
  const usageScope: AiScope = who.scope;

  let body: { tourName?: string; subtitle?: string; stops?: { title: string; note?: string }[]; facts?: unknown };
  try {
    body = await req.json();
  } catch {
    return jsonResponse(400, { error: "Invalid JSON body" });
  }

  const { tourName = "", subtitle = "" } = body;
  const stops = Array.isArray(body.stops) ? body.stops.slice(0, MAX_STOPS) : [];
  const roomList = stops.map((s) => `- ${String(s?.title ?? "").slice(0, 80)}${s?.note ? `: ${String(s.note).slice(0, 160)}` : ""}`).join("\n") || "(no rooms added yet)";
  const { facts, missing } = sanitizeFacts(body);

  const factLines = [
    facts.propertyType && `Property type: ${facts.propertyType}`,
    facts.location && `Location (as supplied by the owner): ${facts.location}`,
    (facts.size || facts.planAreaM2) &&
      `Size: ${facts.size || `${facts.planAreaM2!.toFixed(1)} m² (measured from the calibrated floor-plan geometry)`}`,
    facts.price && `Price: ${facts.price}`,
    facts.bedrooms && `Bedrooms: ${facts.bedrooms}`,
    facts.bathrooms && `Bathrooms: ${facts.bathrooms}`,
    facts.amenities?.length && `Amenities: ${facts.amenities.join(", ")}`,
    facts.audience && `Target audience: ${facts.audience}`,
    facts.tone && `Tone: ${facts.tone}`,
    facts.planAreaM2 && facts.size && `Floor-plan measured total: ${facts.planAreaM2.toFixed(1)} m² (from calibrated plan geometry)`,
  ].filter(Boolean);

  const languageRule =
    facts.language === "hi"
      ? "Write ALL fields in natural Hindi (Devanagari script), except brand names/numbers. Keep it simple, spoken-style Hindi — not stiff translationese."
      : facts.language === "hinglish"
      ? "Write ALL fields in natural Hinglish — the way Indian real-estate agents actually message on WhatsApp: Roman script, Hindi-English mix (e.g. \"Bhk\", \"Ready to move\", \"Bada balcony\")."
      : "Write all fields in clear, simple English.";

  const prompt = [
    `Property/venue walkthrough name: "${tourName}".`,
    subtitle ? `Description given by the owner: "${subtitle}".` : "",
    `Rooms/stops in the tour:\n${roomList}`,
    factLines.length ? `Verified facts supplied by the owner (these are the ONLY facts you may state):\n${factLines.map((l) => `- ${l}`).join("\n")}` : "",
    missing.length ? `NOT provided (never mention, imply, or invent these): ${missing.join(", ")}.` : "",
    "",
    `Write marketing copy for this property tour. ${languageRule}`,
    facts.channel ? `Primary marketing channel: ${facts.channel} — shape the longDescription and headline for that channel.` : "",
    "HARD RULES: Use ONLY the information above. Do NOT invent or estimate price, address, size, measurements, legal approvals (RERA etc.), floor number, furnishing status, or any amenity not listed.",
    "Do NOT describe ordinary photos as 360° panoramas. Do NOT add emojis to the SEO fields.",
    "If something wasn't provided, write around it — never fill the gap with a guess.",
    'Respond with ONLY this JSON object, no other text: {"title": string, "headline": string, "shortDescription": string,',
    '"longDescription": string, "instagramCaption": string, "whatsappMessage": string, "seoTitle": string,',
    '"seoDescription": string, "tourIntro": string, "highlights": [string], "buyerSummary": string}',
    "title: listing title (under 70 chars). headline: a punchy 5-9 word headline.",
    "shortDescription: 1 sentence. longDescription: 2-4 sentences. instagramCaption: casual, 3-5 relevant hashtags.",
    "whatsappMessage: a short shareable message with the tour link as {tourLink}.",
    "seoTitle: under 60 characters. seoDescription: under 155 characters. tourIntro: 1-2 spoken sentences to introduce a property tour video.",
    "highlights: 3-5 short key selling points, each grounded ONLY in the verified facts and room list above — never invent amenities.",
    "buyerSummary: 1-2 warm sentences addressed to a buyer, same facts-only rule.",
  ]
    .filter(Boolean)
    .join(" ");

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 35_000);

  // Deterministic per (facts, rooms, tour, language) → content-hash cache.
  // Cache hits skip the quota (no AI call happens) and return byte-identical
  // copy for byte-identical inputs — re-generating while tweaking nothing
  // never re-bills the API.
  const cacheKey = await aiCacheKey(
    "generate-marketing",
    "1",
    resolveModels("text")[0]!,
    JSON.stringify({ facts, roomList, tourName, subtitle })
  );
  const cachedResult = await getCachedAnalysis<Record<string, unknown>>(cacheKey);
  if (cachedResult) {
    return jsonResponse(200, { ...cachedResult, cached: true });
  }

  const quotaResponse = await enforceAiQuota(req, "generate-marketing", { requireAuth: false });
  if (quotaResponse) return quotaResponse;

  try {
    const result = await withCoalescing(cacheKey, async () => {
    const { response } = await callGemini(
      "text",
      {
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { responseMimeType: "application/json" },
      },
      { signal: controller.signal, functionName: "generate-marketing", usage: { scope: usageScope, feature: "generate-marketing" } }
    );

    const data = await response.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
    const parsed = extractJson<Record<string, unknown>>(text);

    if (!parsed?.title) {
      throw Object.assign(new Error("bad-copy"), {
        endpointStatus: 502,
        endpointPayload: { error: "Could not parse marketing copy from Gemini" },
      });
    }

    const field = (key: string, max = 2000): string =>
      typeof parsed[key] === "string" ? String(parsed[key]).slice(0, max) : "";
    const stringList = (key: string, cap: number, maxLen: number): string[] =>
      Array.isArray(parsed[key])
        ? (parsed[key] as unknown[])
            .filter((s): s is string => typeof s === "string" && Boolean(s.trim()))
            .slice(0, cap)
            .map((s) => s.trim().slice(0, maxLen))
        : [];

    const payload = {
      // Original 7 fields — unchanged contract for existing callers.
      title: field("title", 200),
      shortDescription: field("shortDescription"),
      longDescription: field("longDescription"),
      instagramCaption: field("instagramCaption"),
      whatsappMessage: field("whatsappMessage"),
      seoTitle: field("seoTitle", 120),
      seoDescription: field("seoDescription", 300),
      // Stage B4 additions (optional for old callers).
      headline: field("headline", 120),
      tourIntro: field("tourIntro", 500),
      // Stage D (Phase 4) additions — optional, validated, facts-grounded.
      highlights: stringList("highlights", 5, 100),
      buyerSummary: field("buyerSummary", 300),
      language: facts.language,
      missingFields: missing,
      note:
        "AI draft — verify every fact before publishing. Missing details were not invented; add them in the form for stronger copy.",
    };
    await putCachedAnalysis(cacheKey, payload);
    return payload;
    });
    return jsonResponse(200, { ...result, cached: false });
  } catch (err: any) {
    if (err?.endpointStatus) {
      return jsonResponse(err.endpointStatus, err.endpointPayload);
    }
    if (err instanceof GeminiError) {
      return jsonResponse(err.httpStatus, { error: err.safeMessage, retryable: err.retryable });
    }
    if (err?.name === "AbortError") {
      return jsonResponse(504, { error: "Generation timed out" });
    }
    return jsonResponse(500, { error: "Generation failed" });
  } finally {
    clearTimeout(timeout);
  }
};

export const config: Config = {
  path: "/api/generate-marketing",
};
