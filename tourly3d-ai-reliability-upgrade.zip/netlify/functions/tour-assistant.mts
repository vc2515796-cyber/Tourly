import type { Config } from "@netlify/functions";
import { jsonResponse, enforceAiRateLimit } from "./_shared.mts";
import { callGemini, GeminiError, getGeminiApiKey, resolveModels } from "./_gemini.mts";
import { cachedAiCall } from "./_aiusage.mts";

/** Bump when the prompt or validation below changes (cache identity). */
const SCHEMA_VERSION = "1";

/**
 * Answers visitor questions about a specific tour using ONLY the data the
 * creator entered (tour name/subtitle, stop titles/notes, WhatsApp number).
 * Explicitly instructed to say it doesn't know rather than invent details
 * like price, exact area, or amenities that were never entered — see the
 * README's stance against presenting invented content as real.
 */
export default async (req: Request) => {
  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  const limited = await enforceAiRateLimit(req, "tour-assistant", 20);
  if (limited) return limited;

  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    return jsonResponse(503, { error: "Assistant not configured" });
  }

  let body: {
    question?: string;
    tourName?: string;
    subtitle?: string;
    whatsappNumber?: string;
    stops?: { title: string; note?: string }[];
    history?: { role: "user" | "assistant"; text: string }[];
  };
  try {
    body = await req.json();
  } catch {
    return jsonResponse(400, { error: "Invalid JSON body" });
  }

  const { question, tourName = "", subtitle = "", whatsappNumber, stops = [], history = [] } = body;
  // Keep only the last few turns, trimmed, so long chats don't balloon the prompt.
  const recentHistory = history
    .slice(-8)
    .map((m) => `${m.role === "user" ? "Visitor" : "Assistant"}: ${String(m.text).slice(0, 500)}`)
    .join("\n");
  if (!question || !question.trim()) {
    return jsonResponse(400, { error: "question is required" });
  }
  if (question.length > 2_000) {
    return jsonResponse(400, { error: "Question is too long." });
  }

  // Sanitize the tour content the caller supplied (public endpoint — never
  // trust raw client text).
  const cleanStops = stops
    .filter((s) => typeof s?.title === "string")
    .slice(0, 40)
    .map((s) => ({ title: s.title.slice(0, 80), note: typeof s.note === "string" ? s.note.slice(0, 200) : "" }));

  const roomList =
    cleanStops.map((s) => `- ${s.title}${s.note ? `: ${s.note}` : ""}`).join("\n") || "(no rooms listed)";

  const systemPrompt = [
    "You are a helpful assistant answering a visitor's question about ONE specific property/venue",
    `walkthrough called "${tourName}".`,
    subtitle ? `Owner's description: "${subtitle}".` : "",
    `Rooms/stops and their notes:\n${roomList}`,
    whatsappNumber
      ? `A WhatsApp enquiry number is available for this listing — you may suggest contacting via the WhatsApp button on the page for anything you can't answer.`
      : `No contact number was provided for this listing.`,
    "",
    "Rules: Answer ONLY using the information given above. If the answer isn't in that information",
    "(for example: exact price, exact square footage/area, availability dates, or amenities never",
    "mentioned), say plainly that you don't have that information — do NOT guess or invent a value.",
    "Keep answers short (1-3 sentences), friendly, and factual.",
  ]
    .filter(Boolean)
    .join(" ");

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30_000);

  // Public buyer-facing endpoint: anonymous callers get a PER-IP daily quota
  // (AI_DAILY_QUOTA_TOUR_ASSISTANT, default 40) on top of the burst limit —
  // an anonymous visitor must not be able to drain the API key in a day.
  // Identical question+tour+history is deterministic → cached (no quota used).
  try {
    const outcome = await cachedAiCall<string>(
      req,
      "tour-assistant",
      {
        schemaVersion: SCHEMA_VERSION,
        model: resolveModels("text")[0]!,
        cacheContent: JSON.stringify({
          question: question.trim(),
          tourName: String(tourName).slice(0, 120),
          subtitle: String(subtitle).slice(0, 300),
          hasWhatsapp: Boolean(whatsappNumber),
          cleanStops,
          recentHistory,
        }),
        quota: {}, // per-IP for anonymous callers (scope resolved server-side)
      },
      async () => {
    const { response } = await callGemini(
      "text",
      {
        contents: [
          {
            parts: [
              {
                text: `${systemPrompt}${recentHistory ? `\n\nConversation so far:\n${recentHistory}` : ""}\n\nVisitor's new question: "${question}"`,
              },
            ],
          },
        ],
      },
      { signal: controller.signal, functionName: "tour-assistant" }
    );

    const data = await response.json();
    const answer = data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim();

    if (!answer) {
      throw Object.assign(new Error("no-answer"), {
        endpointStatus: 502,
        endpointPayload: { error: "No answer returned by the assistant" },
      });
    }
    return answer;
      }
    );
    if (!outcome.ok) return outcome.response;
    return jsonResponse(200, { answer: outcome.result, cached: outcome.cached });
  } catch (err: any) {
    if (err?.endpointStatus) {
      return jsonResponse(err.endpointStatus, err.endpointPayload);
    }
    if (err instanceof GeminiError) {
      return jsonResponse(err.httpStatus, { error: err.safeMessage, retryable: err.retryable });
    }
    if (err?.name === "AbortError") {
      return jsonResponse(504, { error: "Assistant timed out" });
    }
    return jsonResponse(500, { error: "Assistant failed" });
  } finally {
    clearTimeout(timeout);
  }
};

export const config: Config = {
  path: "/api/tour-assistant",
};
