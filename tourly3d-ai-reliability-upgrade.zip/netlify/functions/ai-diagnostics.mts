import type { Config } from "@netlify/functions";
import {
  jsonResponse,
  verifyAuthToken,
  firebaseAdminConfigured,
  AdminSetupError,
  TokenProjectMismatchError,
  enforceAiRateLimit,
} from "./_shared.mts";
import { getGeminiApiKey, resolveModels } from "./_gemini.mts";
import { resolveSecondaryProvider } from "./_providers.mts";
import { readAiMetrics, aiFeatureQuota } from "./_aiusage.mts";

/**
 * ADMIN-ONLY AI diagnostics (Phase 8 of the reliability upgrade).
 *
 *   GET  /api/ai-diagnostics          → safe operational status snapshot
 *   POST /api/ai-diagnostics {test}   → one tiny LIVE request per configured
 *                                       provider (explicit, rate-limited)
 *
 * Authorization: the caller must present a VERIFIED Firebase ID token whose
 * email is listed in the server-side ADMIN_EMAILS env var (comma-separated,
 * case-insensitive). There is no frontend admin flag to spoof — the check
 * happens here, server-side, on every request. Anonymous, invalid-token and
 * non-admin callers get 401/403 with no operational detail.
 *
 * Safety rules enforced here:
 *   - API keys and secret env VALUES are never returned — only booleans
 *     ("configured: true") and non-secret identifiers (model ids, provider
 *     names, quota numbers).
 *   - No other customer's prompts, photos, leads or personal data: the
 *     metrics doc only ever contains aggregate counters and sanitized
 *     failure KINDS (enforced where they're written, re-checked here).
 *   - The status snapshot makes NO provider requests — it reads persisted
 *     metrics. "Test connection" is the only live path, is rate-limited
 *     (max 1 per 30s per admin IP), and spends one minimal request per
 *     configured provider (a ~10-token ping — never an image generation).
 *   - A stored success timestamp is NEVER presented as proof a provider is
 *     healthy right now — the UI shows it as "last successful request at …".
 */

const ADMIN_EMAILS_ENV = "ADMIN_EMAILS";

function adminEmails(): Set<string> {
  return new Set(
    (process.env[ADMIN_EMAILS_ENV] ?? "")
      .split(",")
      .map((e) => e.trim().toLowerCase())
      .filter(Boolean)
  );
}

function isAdminEmail(email: string | null | undefined): boolean {
  if (!email) return false;
  return adminEmails().has(email.toLowerCase());
}

/** A minimal, cheap text ping — one short round trip, JSON mode. */
function pingPayload(): Record<string, unknown> {
  return {
    contents: [{ parts: [{ text: 'Reply with exactly: {"ok":true}' }] }],
    generationConfig: { responseMimeType: "application/json", maxOutputTokens: 16, temperature: 0 },
  };
}

function openAiPingBody(model: string): Record<string, unknown> {
  return {
    model,
    messages: [{ role: "user", content: "Reply with exactly: {\"ok\":true}" }],
    max_tokens: 16,
    temperature: 0,
  };
}

export default async (req: Request) => {
  if (req.method !== "GET" && req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  // The diagnostics endpoint itself is rate-limited per IP (cheap reads, but
  // still) — and the TEST action has its own tighter limit below.
  const limited = await enforceAiRateLimit(req, "ai-diagnostics", 30);
  if (limited) return limited;

  // --- authorization (server-side, every request) ---------------------------
  if (!firebaseAdminConfigured()) {
    // Don't reveal deployment details to anonymous callers — generic 503.
    return jsonResponse(503, { error: "Diagnostics aren't configured on this deployment." });
  }
  let caller: Awaited<ReturnType<typeof verifyAuthToken>>;
  try {
    caller = await verifyAuthToken(req);
  } catch (err) {
    if (err instanceof AdminSetupError) return jsonResponse(503, { error: "Server auth is misconfigured — check FIREBASE_SERVICE_ACCOUNT_KEY." });
    if (err instanceof TokenProjectMismatchError) return jsonResponse(401, { error: "Token project mismatch — see server logs." });
    return jsonResponse(401, { error: "Your session has expired — sign in again." });
  }
  if (!caller) {
    return jsonResponse(401, { error: "Sign in as an administrator to view AI diagnostics." });
  }
  if (!isAdminEmail(caller.email)) {
    return jsonResponse(403, { error: "This account isn't an administrator for this deployment." });
  }

  // --- configuration snapshot (names + model ids only, never values) --------
  const geminiConfigured = Boolean(getGeminiApiKey());
  const secondary = resolveSecondaryProvider();
  const textModels = resolveModels("text");
  const imageModels = resolveModels("image");

  const providers = [
    {
      id: "gemini",
      configured: geminiConfigured,
      models: { text: textModels, image: imageModels },
    },
    ...(secondary
      ? [{ id: secondary.id, configured: true, models: { text: [secondary.model] } }]
      : []),
  ];

  const features = [
    "analyze-scene",
    "classify-scenes",
    "suggest-hotspots",
    "suggest-sequence",
    "lead-draft",
    "tour-assistant",
    "enhance-panorama",
    "generate-3d-render",
    "generate-panorama",
    "analyze-floorplan",
    "generate-marketing",
    "interior-concept",
    "lead-insights",
  ].map((f) => ({ feature: f, dailyQuota: aiFeatureQuota(f) }));

  const metrics = await readAiMetrics();

  // --- GET: status snapshot (no provider requests) ---------------------------
  if (req.method === "GET") {
    return jsonResponse(200, {
      ok: true,
      providers,
      // Honest notes: breaker state is per function INSTANCE (in-memory) —
      // a fresh instance always starts closed; persisted metrics are the
      // cross-instance view (best-effort counters).
      metrics,
      features,
      config: {
        geminiConfigured,
        secondaryProvider: secondary ? secondary.id : null,
        secondaryDisabledByEnv: Boolean(process.env.AI_DISABLE_FALLBACK_PROVIDER),
        visionFallbackAllowed: /^(1|true|yes)$/i.test(process.env.AI_FALLBACK_ALLOW_VISION ?? ""),
        adminConfigured: adminEmails().size > 0,
      },
      note:
        "Metrics are best-effort aggregate counters (no user data). A last-success timestamp is history, not a live health guarantee — use 'Test connection' for a live check.",
    });
  }

  // --- POST: explicit live test (rate-limited, one tiny ping per provider) ---
  const testLimited = await enforceAiRateLimit(req, "ai-diagnostics-test", 1, 30);
  if (testLimited) {
    return jsonResponse(429, { error: "Live test limit reached (max once per 30s) — try again shortly." });
  }

  const results: Record<string, unknown>[] = [];
  const startedAt = Date.now();

  // Gemini ping (only when configured)
  if (geminiConfigured) {
    const t0 = Date.now();
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 8_000);
      try {
        const res = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/${textModels[0]}:generateContent`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json", "x-goog-api-key": getGeminiApiKey()! },
            signal: controller.signal,
            body: JSON.stringify(pingPayload()),
          }
        );
        // A 2xx with candidates = genuinely alive. Anything else is a
        // classified failure kind — the STATUS only, never the body.
        results.push({
          provider: "gemini",
          model: textModels[0],
          ok: res.ok,
          httpStatus: res.status,
          latencyMs: Date.now() - t0,
          errorKind: res.ok ? null : res.status === 429 ? "rate-limit" : res.status === 401 || res.status === 403 ? "auth" : res.status === 404 ? "not-found" : "server",
        });
      } finally {
        clearTimeout(timer);
      }
    } catch (err: any) {
      results.push({
        provider: "gemini",
        model: textModels[0],
        ok: false,
        httpStatus: null,
        latencyMs: Date.now() - t0,
        errorKind: err?.name === "AbortError" ? "timeout" : "network",
      });
    }
  }

  // Secondary provider ping (only when configured)
  if (secondary) {
    const t0 = Date.now();
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 8_000);
      try {
        const res = await fetch(secondary.endpoint, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${secondary.apiKey}`,
          },
          signal: controller.signal,
          body: JSON.stringify(openAiPingBody(secondary.model)),
        });
        results.push({
          provider: secondary.id,
          model: secondary.model,
          ok: res.ok,
          httpStatus: res.status,
          latencyMs: Date.now() - t0,
          errorKind: res.ok ? null : res.status === 429 ? "rate-limit" : res.status === 401 || res.status === 403 ? "auth" : res.status === 404 ? "not-found" : "server",
        });
      } finally {
        clearTimeout(timer);
      }
    } catch (err: any) {
      results.push({
        provider: secondary.id,
        model: secondary.model,
        ok: false,
        httpStatus: null,
        latencyMs: Date.now() - t0,
        errorKind: err?.name === "AbortError" ? "timeout" : "network",
      });
    }
  }

  return jsonResponse(200, {
    ok: true,
    testedAt: new Date().toISOString(),
    totalMs: Date.now() - startedAt,
    results,
    note: "One minimal request per configured provider. Error kinds are sanitized categories — no provider response bodies are ever returned.",
  });
};

export const config: Config = {
  path: "/api/ai-diagnostics",
};
