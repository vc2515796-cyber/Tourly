import type { Config } from "@netlify/functions";
import jpeg from "jpeg-js";
import { jsonResponse } from "./_shared.mts";

/**
 * Fixes the visible "seam" at the left/right wrap boundary of an
 * equirectangular (or wide-sweep) panorama — the classic issue where one
 * side is a touch brighter/warmer than the other after stitching, which
 * shows up as a hard line right where the image loops back on itself.
 *
 * This is a deterministic PHOTOMETRIC correction, not AI, and not a
 * structural blend: it does not try to merge or ghost actual scene
 * content together (that would blur/double-expose real objects near the
 * edge). It only nudges color/brightness so the two edges match, with
 * the correction fading to zero by the center of the image — the part a
 * viewer actually looks at first stays untouched.
 *
 * Only JPEG is supported right now (jpeg-js is a pure-JS codec — no
 * native binaries, which matters because this deploys from an ARM64
 * Termux environment to Netlify's x64 Linux functions; a native image
 * lib like sharp would ship the wrong architecture and crash at runtime).
 */
export default async (req: Request) => {
  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  let body: { imageBase64?: string; mimeType?: string };
  try {
    body = await req.json();
  } catch {
    return jsonResponse(400, { error: "Invalid JSON body" });
  }

  const { imageBase64, mimeType } = body;
  if (!imageBase64 || !mimeType) {
    return jsonResponse(400, { error: "imageBase64 and mimeType are required" });
  }
  // Keep JSON payloads below typical serverless request limits and reject
  // non-image MIME types before forwarding user input to the paid AI API.
  if (!/^image\/(jpeg|png|webp)$/.test(mimeType)) {
    return jsonResponse(415, { error: "Use a JPEG, PNG, or WebP image." });
  }
  if (imageBase64.length > 4_500_000 || !/^[A-Za-z0-9+/]*={0,2}$/.test(imageBase64)) {
    return jsonResponse(413, { error: "Image is too large or has an invalid encoding. Try a smaller image." });
  }

  if (!/jpe?g/i.test(mimeType)) {
    return jsonResponse(415, {
      error: "Only JPEG is supported for seam fixing right now.",
    });
  }

  try {
    const inputBuffer = Buffer.from(imageBase64, "base64");
    const decoded = jpeg.decode(inputBuffer, { useTArray: true });
    const { width, height, data } = decoded; // data: Uint8Array, RGBA, 4 bytes/pixel

    const EDGE_SAMPLE = Math.max(4, Math.min(40, Math.round(width * 0.01)));

    // Average color of the strip right at the left edge, and right at
    // the right edge — these two strips are physically adjacent once
    // the panorama wraps around.
    const sumLeft = [0, 0, 0];
    const sumRight = [0, 0, 0];
    for (let y = 0; y < height; y++) {
      const rowStart = y * width * 4;
      for (let x = 0; x < EDGE_SAMPLE; x++) {
        const li = rowStart + x * 4;
        const ri = rowStart + (width - 1 - x) * 4;
        sumLeft[0] += data[li]; sumLeft[1] += data[li + 1]; sumLeft[2] += data[li + 2];
        sumRight[0] += data[ri]; sumRight[1] += data[ri + 1]; sumRight[2] += data[ri + 2];
      }
    }
    const sampleCount = height * EDGE_SAMPLE;
    const diff = [0, 1, 2].map((c) => sumRight[c] / sampleCount - sumLeft[c] / sampleCount);

    // Half the gap gets closed from each side, tapering linearly to zero
    // correction by the horizontal center — so the seam meets in the
    // middle with no discontinuity, and the "front" view is untouched.
    const half = width / 2;
    for (let x = 0; x < width; x++) {
      let t: number; // -1 at x=0 .. 0 at center .. +1 at x=width-1
      if (x < half) {
        t = 1 - x / half; // 1 at edge, 0 at center
      } else {
        t = -((x - half) / half); // 0 at center, -1 at far edge
      }
      const correction = diff.map((d) => (d / 2) * t);

      for (let y = 0; y < height; y++) {
        const idx = (y * width + x) * 4;
        data[idx] = clamp8(data[idx] + correction[0]);
        data[idx + 1] = clamp8(data[idx + 1] + correction[1]);
        data[idx + 2] = clamp8(data[idx + 2] + correction[2]);
      }
    }

    const encoded = jpeg.encode({ width, height, data }, 92);
    const outBase64 = Buffer.from(encoded.data).toString("base64");

    return jsonResponse(200, { imageBase64: outBase64, mimeType: "image/jpeg" });
  } catch (err) {
    return jsonResponse(500, { error: "Seam fix failed", detail: String(err) });
  }
};

function clamp8(v: number): number {
  return v < 0 ? 0 : v > 255 ? 255 : v;
}

export const config: Config = {
  path: "/api/fix-seam",
};
