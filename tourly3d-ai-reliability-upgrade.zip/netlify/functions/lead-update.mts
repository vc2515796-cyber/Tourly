import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import {
  jsonResponse,
  verifyAuthToken,
  firebaseAdminConfigured,
  AdminSetupError,
  TokenProjectMismatchError,
} from "./_shared.mts";
import { LEADS_STORE_NAME, isLeadStage, leadStoreKey, loadLead, type Lead, type LeadActivity, type LeadStage } from "./_leads.mts";

/**
 * Stage B5 — updates one of the caller's leads (stage, notes, manual
 * contact history, next-action date). POST /api/lead-update.
 *
 * Concurrency: clients send the lead's updatedAt as `expectedUpdatedAt`;
 * when it doesn't match the stored doc the update is refused with 409 —
 * the CRM reloads instead of silently clobbering a parallel edit.
 */

const MAX_NOTE = 1000;

export default async (req: Request) => {
  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  if (!firebaseAdminConfigured()) {
    return jsonResponse(503, { error: "Lead management isn't available on this deployment (FIREBASE_SERVICE_ACCOUNT_KEY missing — see AUTH-SETUP.md §4)." });
  }

  let caller: Awaited<ReturnType<typeof verifyAuthToken>>;
  try {
    caller = await verifyAuthToken(req);
  } catch (err) {
    if (err instanceof AdminSetupError) return jsonResponse(503, { error: err.message });
    if (err instanceof TokenProjectMismatchError) return jsonResponse(401, { error: err.message });
    return jsonResponse(401, { error: "Your session has expired — sign in again." });
  }
  if (!caller) {
    return jsonResponse(401, { error: "Sign in to manage your leads." });
  }

  let body: {
    leadId?: string;
    expectedUpdatedAt?: number;
    stage?: string;
    note?: string;
    contactLog?: string;
    nextActionAt?: number | null;
  };
  try {
    body = await req.json();
  } catch {
    return jsonResponse(400, { error: "Invalid JSON body" });
  }

  const leadId = typeof body.leadId === "string" ? body.leadId.trim().slice(0, 64) : "";
  if (!leadId) return jsonResponse(400, { error: "leadId is required" });

  const note = typeof body.note === "string" ? body.note.trim().slice(0, MAX_NOTE) : "";
  const contactLog = typeof body.contactLog === "string" ? body.contactLog.trim().slice(0, MAX_NOTE) : "";
  const hasStage = typeof body.stage === "string";
  const stage: LeadStage | undefined = hasStage && isLeadStage(body.stage) ? (body.stage as LeadStage) : undefined;
  if (hasStage && !stage) {
    return jsonResponse(400, { error: "Unknown lead stage." });
  }
  const nextActionAt =
    body.nextActionAt === null
      ? null
      : typeof body.nextActionAt === "number" && Number.isFinite(body.nextActionAt)
      ? Math.min(body.nextActionAt, Date.now() + 366 * 24 * 60 * 60 * 1000)
      : undefined;
  if (!stage && !note && !contactLog && nextActionAt === undefined) {
    return jsonResponse(400, { error: "Nothing to update — send a stage, note, contact log or next action." });
  }

  try {
    const store = getStore({ name: LEADS_STORE_NAME });
    const lead = await loadLead(store, caller.uid, leadId);
    if (!lead) {
      // Either the id is wrong or the lead belongs to someone else — the
      // response is identical so one agent can't probe another's lead ids.
      return jsonResponse(404, { error: "Lead not found." });
    }
    // Defense in depth: the key prefix already scopes access, and the
    // document's ownerUid must also match the verified caller.
    if (lead.ownerUid !== caller.uid) {
      return jsonResponse(403, { error: "This lead belongs to a different account." });
    }
    if (typeof body.expectedUpdatedAt === "number" && body.expectedUpdatedAt !== lead.updatedAt) {
      return jsonResponse(409, { error: "This lead changed just now — reload and try again.", conflict: true });
    }

    const now = Date.now();
    const activities: LeadActivity[] = [...lead.activities];
    const patch: Partial<Lead> = {};

    if (stage && stage !== lead.stage) {
      activities.push({ id: crypto.randomUUID(), kind: "stage-change", at: now, fromStage: lead.stage, toStage: stage });
      patch.stage = stage;
    }
    if (note) {
      activities.push({ id: crypto.randomUUID(), kind: "note", at: now, text: note });
    }
    if (contactLog) {
      activities.push({ id: crypto.randomUUID(), kind: "contact-logged", at: now, text: contactLog });
    }
    if (nextActionAt !== undefined) {
      patch.nextActionAt = nextActionAt === null ? undefined : nextActionAt;
    }
    // Cap the activity log so a chatty CRM can't grow a lead blob forever —
    // the newest 200 entries are kept.
    const trimmed = activities.slice(-200);

    const updated: Lead = { ...lead, ...patch, activities: trimmed, updatedAt: now };
    await store.setJSON(leadStoreKey(caller.uid, leadId), updated);
    return jsonResponse(200, {
      ok: true,
      lead: {
        id: updated.id,
        stage: updated.stage,
        nextActionAt: updated.nextActionAt ?? null,
        updatedAt: updated.updatedAt,
        activities: updated.activities.slice(-20),
      },
    });
  } catch (err) {
    return jsonResponse(500, { error: "Couldn't update the lead.", detail: String(err) });
  }
};

export const config: Config = {
  path: "/api/lead-update",
};
