import type { Config } from "@netlify/functions";
import { jsonResponse, extractJson, enforceAiRateLimit } from "./_shared.mts";
import { callGemini, GeminiError, getGeminiApiKey, resolveModels } from "./_gemini.mts";
import { cachedAiCall } from "./_aiusage.mts";

/** Bump when the prompt or validation below changes (cache identity). */
const SCHEMA_VERSION = "1";

/**
 * Stage B1 — batch scene classification. Receives up to 12 downscaled images
 * and returns, per image, a room CATEGORY from a fixed list, a suggested
 * title, a short description, a self-reported confidence and a suggested
 * tour order. The GEMINI key never leaves the server.
 *
 * Honesty constraints enforced in the prompt AND in post-processing:
 * - categories are suggestions, never presented as verified truth
 * - room dimensions are explicitly NOT requested (they can't be measured
 *   from an ordinary photo)
 * - a plain photo is never described as a 360° panorama (panorama format
 *   detection happens client-side from image dimensions, not from a model
 *   opinion)
 */

const MAX_IMAGES = 12;
const MAX_BASE64_PER_IMAGE = 900_000; // ~650 KB decoded — enough for a 640px JPEG
const CATEGORY_WHITELIST = new Set([
  "living-room",
  "bedroom",
  "kitchen",
  "bathroom",
  "balcony",
  "exterior",
  "dining-room",
  "hallway",
  "stairs",
  "parking",
  "amenity",
  "other",
  "unknown",
]);

type InImage = { id?: string; imageBase64?: string; mimeType?: string };

export default async (req: Request) => {
  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  // One call classifies up to 12 images, so its per-IP budget is lower than
  // single-image endpoints. Fails open on infra hiccups (see _shared).
  const limited = await enforceAiRateLimit(req, "classify-scenes", 6);
  if (limited) return limited;

  // Validate the REQUEST before reporting configuration state — a malformed
  // body is the caller's bug no matter how the server is configured, so it
  // gets the 400 first.
  let body: { images?: InImage[]; existingTitles?: unknown };
  try {
    body = await req.json();
  } catch {
    return jsonResponse(400, { error: "Invalid JSON body" });
  }

  if (!Array.isArray(body.images) || body.images.length === 0) {
    return jsonResponse(400, { error: "images (non-empty array) is required" });
  }
  if (body.images.length > MAX_IMAGES) {
    return jsonResponse(400, { error: `Too many images in one request — send at most ${MAX_IMAGES}.` });
  }

  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    return jsonResponse(503, { error: "AI suggestions aren't configured on this deployment (GEMINI_API_KEY missing)." });
  }

  const seenIds = new Set<string>();
  const parts: Record<string, unknown>[] = [];
  const validImages: { id: string }[] = [];
  for (const img of body.images) {
    const id = typeof img?.id === "string" ? img.id.slice(0, 64) : "";
    const b64 = typeof img?.imageBase64 === "string" ? img.imageBase64 : "";
    const mimeType = typeof img?.mimeType === "string" && /^image\/(jpeg|png|webp)$/.test(img.mimeType) ? img.mimeType : "image/jpeg";
    if (!id || !b64) {
      return jsonResponse(400, { error: "Each image needs an id and imageBase64." });
    }
    if (seenIds.has(id)) {
      return jsonResponse(400, { error: `Duplicate image id "${id}" in one request.` });
    }
    seenIds.add(id);
    if (b64.length > MAX_BASE64_PER_IMAGE) {
      return jsonResponse(413, { error: "One of the images is too large — downscale before sending." });
    }
    parts.push({ text: `Image id: ${id}` });
    parts.push({ inline_data: { mime_type: mimeType, data: b64 } });
    validImages.push({ id });
  }

  const existingTitles = Array.isArray(body.existingTitles)
    ? body.existingTitles.filter((t): t is string => typeof t === "string").slice(0, 60).map((t) => t.slice(0, 80))
    : [];

  const prompt = [
    `You are helping organise a property-tour photo shoot. You will see ${validImages.length} photos, each preceded by its "Image id".`,
    existingTitles.length ? `Scenes that ALREADY exist in this tour: ${existingTitles.join(", ")}.` : "",
    "For EACH image, choose the single best room category from exactly this list:",
    "living-room, bedroom, kitchen, bathroom, balcony, exterior, dining-room, hallway, stairs, parking, amenity, other, unknown.",
    "Use \"unknown\" when you genuinely can't tell. Also write a short readable scene title (max 6 words), a one-sentence description of what is visible,",
    "your confidence between 0 and 1, and a suggested 1-based position in a sensible tour order (1 = first thing a visitor should see, e.g. exterior and entry areas early, bedrooms and baths later).",
    "IMPORTANT honesty rules: base everything ONLY on what is visible; do NOT estimate room dimensions, area, prices or addresses;",
    "do NOT claim any photo is a 360-degree panorama; if two photos show the same room, still classify each one.",
    'Respond with ONLY this JSON object, no other text: {"results":[{"id": string, "category": string, "title": string, "description": string, "confidence": number, "order": number}]}',
  ]
    .filter(Boolean)
    .join(" ");

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 55_000);

  // One AI call classifies up to 12 images: per-user daily quota
  // (AI_DAILY_QUOTA_CLASSIFY_SCENES, default 40) + a content-hash cache so
  // re-staging the same photos never re-bills. Cached hits skip the quota.
  try {
    const outcome = await cachedAiCall<{ results: Record<string, unknown>[] }>(
      req,
      "classify-scenes",
      {
        schemaVersion: SCHEMA_VERSION,
        model: resolveModels("text")[0]!,
        cacheContent: JSON.stringify({
          images: validImages.map((v) => v.id),
          imageBytes: parts.filter((p) => (p as any).inline_data).map((p) => String((p as any).inline_data!.data)),
          existingTitles,
        }),
        quota: {},
      },
      async () => {
    const { response } = await callGemini(
      "text",
      {
        contents: [{ role: "user", parts }],
        systemInstruction: {
          parts: [{ text: prompt }],
        },
        generationConfig: { responseMimeType: "application/json" },
      },
      { signal: controller.signal, functionName: "classify-scenes" }
    );

    const data = await response.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
    const parsed = extractJson<{ results?: unknown[] }>(text);

    const results: Record<string, unknown>[] = [];
    const validIds = new Set(validImages.map((v) => v.id));
    for (const item of Array.isArray(parsed?.results) ? parsed!.results! : []) {
      if (!item || typeof item !== "object") continue;
      const r = item as Record<string, unknown>;
      const id = typeof r.id === "string" ? r.id : "";
      if (!validIds.has(id)) continue; // drop hallucinated ids
      const category = typeof r.category === "string" && CATEGORY_WHITELIST.has(r.category) ? r.category : "unknown";
      results.push({
        id,
        category,
        title: typeof r.title === "string" ? r.title.slice(0, 80) : "",
        description: typeof r.description === "string" ? r.description.slice(0, 400) : "",
        confidence: typeof r.confidence === "number" && r.confidence >= 0 && r.confidence <= 1 ? r.confidence : 0.5,
        order: Number.isFinite(r.order) ? Math.max(1, Math.min(99, Math.round(Number(r.order)))) : 1,
      });
    }
    // Every requested image must get an answer — a missing one becomes an
    // explicit "unknown" instead of silently vanishing from the UI.
    for (const v of validImages) {
      if (!results.some((r) => r.id === v.id)) {
        results.push({ id: v.id, category: "unknown", title: "", description: "", confidence: 0, order: 1 });
      }
    }

    return { results };
      }
    );
    if (!outcome.ok) return outcome.response;
    return jsonResponse(200, { ...outcome.result, cached: outcome.cached });
  } catch (err: any) {
    if (err instanceof GeminiError) {
      return jsonResponse(err.httpStatus, { error: err.safeMessage, retryable: err.retryable });
    }
    if (err?.name === "AbortError") {
      return jsonResponse(504, { error: "Classification timed out" });
    }
    return jsonResponse(500, { error: "Classification failed" });
  } finally {
    clearTimeout(timeout);
  }
};

export const config: Config = {
  path: "/api/classify-scenes",
};
