import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import {
  jsonResponse,
  verifyAuthToken,
  firebaseAdminConfigured,
  AdminSetupError,
  TokenProjectMismatchError,
} from "./_shared.mts";
import { TOURS_STORE, TOUR_OWNER_PREFIX } from "./_leads.mts";
import {
  ANALYTICS_STORE_NAME,
  dateKeyRange,
  loadDay,
  utcDateKey,
  type EventSource,
  type TourDayStats,
} from "./_analytics.mts";

/**
 * Stage C — GET /api/analytics-summary?ids=t1,t2&days=7
 *
 * Returns aggregated, ownership-scoped engagement numbers for the CALLER's
 * published tours. Security model (same as leads-list):
 *  - Firebase admin must be configured (honest 503 otherwise)
 *  - the caller's identity comes from a VERIFIED ID token
 *  - each requested tour is checked against its server-side owner record;
 *    tours the caller doesn't own are silently EXCLUDED from the response
 *    (never an error, never data)
 *
 * Cost model: per tour, one get() per day document in the window (plus the
 * previous window when days=7, for the week-over-week delta). Gets are
 * chunked in parallel; ids are capped at 15 and windows at 90 days, which
 * keeps the function well inside the default execution budget.
 */

const MAX_TOUR_IDS = 15;
const ALLOWED_WINDOWS = [7, 30, 90] as const;
const GET_CHUNK = 20;

type TourSummary = {
  id: string;
  name: string;
  views: number;
  uniques: number;
  uniquesCapped: boolean;
  sceneViews: number;
  hotspotClicks: number;
  enquiries: number;
  visitRequests: number;
  /** enquiries ÷ views, or null when views = 0 (never a fake 0%). */
  conversionRate: number | null;
  sources: Partial<Record<EventSource, number>>;
  topScenes: { sceneId: string; views: number }[];
};

type Totals = {
  views: number;
  uniques: number;
  uniquesCapped: boolean;
  sceneViews: number;
  hotspotClicks: number;
  enquiries: number;
  visitRequests: number;
  conversionRate: number | null;
  sources: Partial<Record<EventSource, number>>;
};

export default async (req: Request) => {
  if (req.method !== "GET") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  if (!firebaseAdminConfigured()) {
    return jsonResponse(503, {
      error:
        "Analytics isn't available on this deployment yet — FIREBASE_SERVICE_ACCOUNT_KEY isn't set (see AUTH-SETUP.md §4).",
    });
  }

  let caller: Awaited<ReturnType<typeof verifyAuthToken>>;
  try {
    caller = await verifyAuthToken(req);
  } catch (err) {
    if (err instanceof AdminSetupError) {
      return jsonResponse(503, { error: err.message });
    }
    if (err instanceof TokenProjectMismatchError) {
      return jsonResponse(401, { error: err.message });
    }
    return jsonResponse(401, { error: "Your session has expired — sign in again." });
  }
  if (!caller) {
    return jsonResponse(401, { error: "Sign in to see your analytics." });
  }

  const url = new URL(req.url);
  const idsParam = (url.searchParams.get("ids") ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, MAX_TOUR_IDS);
  const daysParam = Number(url.searchParams.get("days") ?? 7);
  const days = (ALLOWED_WINDOWS as readonly number[]).includes(daysParam) ? daysParam : 7;

  if (idsParam.length === 0) {
    return jsonResponse(400, { error: "Pass ?ids= with at least one tour id." });
  }

  try {
    const analyticsStore = getStore({ name: ANALYTICS_STORE_NAME });
    const toursStore = getStore({ name: TOURS_STORE });

    const today = utcDateKey(Date.now());
    const windowStart = utcDateKey(Date.now() - (days - 1) * 24 * 60 * 60 * 1000);
    // Week-over-week delta is only computed for the 7-day view — for 30/90
    // days doubling the document reads isn't worth it (the UI hides it).
    const prevStart =
      days === 7 ? utcDateKey(Date.now() - (2 * days - 1) * 24 * 60 * 60 * 1000) : null;
    const windowKeys = dateKeyRange(windowStart, today);
    const prevKeys = prevStart ? dateKeyRange(prevStart, utcDateKey(Date.now() - days * 24 * 60 * 60 * 1000)) : [];

    const tours: TourSummary[] = [];
    let overall: Totals = emptyTotals();
    let prevViews = 0;
    let prevEnquiries = 0;

    for (const id of idsParam) {
      // Ownership: the ONLY source of truth is the server-side owner
      // record, exactly like capture-lead. Not owned by caller → skip.
      const owner = (await toursStore.get(TOUR_OWNER_PREFIX + id, { type: "json" })) as { uid?: string } | null;
      if (owner?.uid !== caller.uid) continue;

      const tourDoc = (await toursStore.get(id, { type: "json" })) as { name?: string } | null;
      const name = typeof tourDoc?.name === "string" ? tourDoc.name.slice(0, 120) : "Property tour";

      const dayDocs = await loadDays(analyticsStore, id, windowKeys);
      const prevDocs = prevKeys.length > 0 ? await loadDays(analyticsStore, id, prevKeys) : [];

      const summary = summarize(id, name, dayDocs);
      tours.push(summary);
      overall = addInto(overall, summary);
      for (const doc of prevDocs) {
        prevViews += doc.events["tour-view"] ?? 0;
        prevEnquiries += doc.events["enquiry"] ?? 0;
      }
    }

    tours.sort((a, b) => b.views - a.views);
    overall.conversionRate =
      overall.views > 0 ? Math.round((overall.enquiries / overall.views) * 1000) / 10 : null;

    return jsonResponse(200, {
      ok: true,
      window: { days, from: windowStart, to: today },
      tours,
      overall: { ...overall, prevViews, prevEnquiries },
      generatedAt: Date.now(),
    });
  } catch {
    return jsonResponse(500, { error: "Couldn't load analytics right now — try again." });
  }
};

async function loadDays(store: ReturnType<typeof getStore>, tourId: string, dateKeys: string[]): Promise<TourDayStats[]> {
  const docs: TourDayStats[] = [];
  for (let i = 0; i < dateKeys.length; i += GET_CHUNK) {
    const chunk = dateKeys.slice(i, i + GET_CHUNK);
    const loaded = await Promise.all(chunk.map((k) => loadDay(store, tourId, k)));
    for (const d of loaded) if (d) docs.push(d);
  }
  return docs;
}

function emptyTotals(): Totals {
  return {
    views: 0,
    uniques: 0,
    uniquesCapped: false,
    sceneViews: 0,
    hotspotClicks: 0,
    enquiries: 0,
    visitRequests: 0,
    conversionRate: null,
    sources: {},
  };
}

function summarize(id: string, name: string, days: TourDayStats[]): TourSummary {
  const summary: TourSummary = {
    id,
    name,
    views: 0,
    uniques: 0,
    uniquesCapped: false,
    sceneViews: 0,
    hotspotClicks: 0,
    enquiries: 0,
    visitRequests: 0,
    conversionRate: null,
    sources: {},
    topScenes: [],
  };
  const scenes = new Map<string, number>();
  for (const day of days) {
    summary.views += day.events["tour-view"] ?? 0;
    summary.sceneViews += day.events["scene-view"] ?? 0;
    summary.hotspotClicks += day.events["hotspot"] ?? 0;
    summary.enquiries += day.events["enquiry"] ?? 0;
    summary.visitRequests += day.events["visit-request"] ?? 0;
    // Per-day hashed token sets → summing counts visitor-DAYS. Labelled
    // honestly in the UI; it is an estimate of interest, not people.
    summary.uniques += day.uniques.length;
    if (day.uniquesCapped) summary.uniquesCapped = true;
    for (const [src, n] of Object.entries(day.sources)) {
      summary.sources[src as EventSource] = (summary.sources[src as EventSource] ?? 0) + (n ?? 0);
    }
    for (const [sceneId, n] of Object.entries(day.scenes)) {
      scenes.set(sceneId, (scenes.get(sceneId) ?? 0) + (n ?? 0));
    }
  }
  summary.topScenes = [...scenes.entries()]
    .map(([sceneId, views]) => ({ sceneId, views }))
    .sort((a, b) => b.views - a.views)
    .slice(0, 10);
  summary.conversionRate = summary.views > 0 ? Math.round((summary.enquiries / summary.views) * 1000) / 10 : null;
  return summary;
}

function addInto(totals: Totals, t: TourSummary): Totals {
  totals.views += t.views;
  totals.uniques += t.uniques;
  totals.uniquesCapped = totals.uniquesCapped || t.uniquesCapped;
  totals.sceneViews += t.sceneViews;
  totals.hotspotClicks += t.hotspotClicks;
  totals.enquiries += t.enquiries;
  totals.visitRequests += t.visitRequests;
  for (const [src, n] of Object.entries(t.sources)) {
    totals.sources[src as EventSource] = (totals.sources[src as EventSource] ?? 0) + (n ?? 0);
  }
  return totals;
}

export const config: Config = {
  path: "/api/analytics-summary",
};
