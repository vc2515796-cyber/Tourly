import type { Config } from "@netlify/functions";
import {
  jsonResponse,
  extractJson,
  enforceAiRateLimit,
  firebaseAdminConfigured,
} from "./_shared.mts";
import { callGemini, GeminiError, getGeminiApiKey, resolveModels } from "./_gemini.mts";
import {
  enforceAiQuota,
  resolveAiCaller,
  aiCacheKey,
  getCachedAnalysis,
  putCachedAnalysis,
  type AiScope,
} from "./_aiusage.mts";

/**
 * Stage D (Phase 5C of the AI upgrade) — AI CONCEPT FLOOR PLAN analysis.
 *
 * Receives one equirectangular panorama (plus up to 4 client-rendered
 * perspective crops of the SAME panorama, clearly labelled as views of one
 * image) and asks a verified Gemini vision model for a structured,
 * top-down CONCEPT layout of the single visible room:
 * room type, outline polygon, wall segments, door/window markers,
 * furniture positions, and explicit uncertainty notes.
 *
 * Returns STRUCTURED JSON only — never a generated floor-plan image. The
 * client converts the analysis into editable plan geometry (see
 * src/lib/conceptPlan.ts) inside the existing Plan Studio editor.
 *
 * Honesty rules baked into the prompt AND the validation:
 * - coordinates are APPROXIMATE CONCEPT positions on a 0..1 grid, never
 *   measurements; the client keeps the plan uncalibrated and watermarks it
 *   "CONCEPTUAL FLOOR PLAN — NOT TO SCALE";
 * - items the model could not actually see must be marked certain:false;
 * - no invented rooms, no real-world dimensions, no area claims.
 *
 * Access control: server-verified sign-in REQUIRED (this is an agent
 * feature), per-IP burst limit + per-user daily quota, and a content-hash
 * cache so re-analysing the same panorama doesn't re-bill the API.
 */

export const CONCEPT_SCHEMA_VERSION = 1;

export const FURNITURE_KINDS = [
  "bed", "sofa", "table", "chair", "tv", "wardrobe",
  "counter", "fridge", "stove", "toilet", "sink", "bathtub",
  "plant", "rug", "stairs", "other",
] as const;
export type FurnitureKind = (typeof FURNITURE_KINDS)[number];

export type ConceptPoint = { x: number; y: number };

export type ConceptAnalysis = {
  schemaVersion: typeof CONCEPT_SCHEMA_VERSION;
  roomType: string;
  confidence: number;
  roomOutline: ConceptPoint[];
  walls: { a: ConceptPoint; b: ConceptPoint; certain: boolean }[];
  openings: { kind: "door" | "window"; x: number; y: number; certain: boolean }[];
  furniture: {
    kind: FurnitureKind;
    label?: string;
    x: number;
    y: number;
    w?: number;
    h?: number;
    rotation?: number;
    certain: boolean;
  }[];
  uncertaintyNotes: string[];
};

const DISCLAIMER = "CONCEPTUAL FLOOR PLAN — NOT TO SCALE";

// --- validation ---------------------------------------------------------------

const clamp01 = (v: unknown): number | null => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.min(1, Math.max(0, n)) : null;
};

function toPoint(raw: unknown): ConceptPoint | null {
  if (!raw || typeof raw !== "object") return null;
  const x = clamp01((raw as any).x);
  const y = clamp01((raw as any).y);
  if (x === null || y === null) return null;
  return { x, y };
}

/**
 * Validates (and sanitizes) a model response into a ConceptAnalysis.
 * Returns null when the response is too broken to render honestly —
 * the endpoint then answers 502 with a "no usable layout" message.
 * NEVER repairs garbage into a fake-looking plan.
 */
export function validateConceptAnalysis(parsed: unknown): ConceptAnalysis | null {
  if (!parsed || typeof parsed !== "object") return null;
  const p = parsed as Record<string, unknown>;

  const roomType = typeof p.roomType === "string" ? p.roomType.trim().slice(0, 60) : "";
  if (!roomType) return null;

  const confidenceRaw = Number(p.confidence);
  const confidence = Number.isFinite(confidenceRaw) ? Math.min(1, Math.max(0, confidenceRaw)) : 0.5;

  if (!Array.isArray(p.roomOutline) || p.roomOutline.length < 3 || p.roomOutline.length > 24) return null;
  const roomOutline: ConceptPoint[] = [];
  for (const raw of p.roomOutline) {
    const pt = toPoint(raw);
    if (!pt) return null;
    roomOutline.push(pt);
  }

  const walls: ConceptAnalysis["walls"] = [];
  if (Array.isArray(p.walls)) {
    for (const raw of p.walls.slice(0, 40)) {
      if (!raw || typeof raw !== "object") continue;
      const r = raw as Record<string, unknown>;
      const a = toPoint(r.a);
      const b = toPoint(r.b);
      if (!a || !b) continue; // a broken wall is dropped, not fatal
      walls.push({ a, b, certain: r.certain === true });
    }
  }

  const openings: ConceptAnalysis["openings"] = [];
  if (Array.isArray(p.openings)) {
    for (const raw of p.openings.slice(0, 24)) {
      if (!raw || typeof raw !== "object") continue;
      const r = raw as Record<string, unknown>;
      const x = clamp01(r.x);
      const y = clamp01(r.y);
      if (x === null || y === null) continue;
      const kind = r.kind === "window" ? "window" : r.kind === "door" ? "door" : null;
      if (!kind) continue;
      openings.push({ kind, x, y, certain: r.certain === true });
    }
  }

  const furniture: ConceptAnalysis["furniture"] = [];
  if (Array.isArray(p.furniture)) {
    for (const raw of p.furniture.slice(0, 40)) {
      if (!raw || typeof raw !== "object") continue;
      const r = raw as Record<string, unknown>;
      const x = clamp01(r.x);
      const y = clamp01(r.y);
      if (x === null || y === null) continue;
      const kind = (FURNITURE_KINDS as readonly string[]).includes(String(r.kind))
        ? (String(r.kind) as FurnitureKind)
        : "other";
      const w = clamp01(r.w) ?? undefined;
      const h = clamp01(r.h) ?? undefined;
      const rotRaw = Number(r.rotation);
      const rotation = Number.isFinite(rotRaw) ? ((rotRaw % 360) + 360) % 360 : undefined;
      furniture.push({
        kind,
        label: typeof r.label === "string" ? r.label.trim().slice(0, 40) || undefined : undefined,
        x, y, w, h, rotation,
        certain: r.certain === true,
      });
    }
  }

  const uncertaintyNotes: string[] = [];
  if (Array.isArray(p.uncertaintyNotes)) {
    for (const raw of p.uncertaintyNotes.slice(0, 6)) {
      if (typeof raw === "string" && raw.trim()) uncertaintyNotes.push(raw.trim().slice(0, 160));
    }
  }

  // A "layout" with no walls around the outline is still renderable (the
  // outline itself becomes the walls client-side) — but zero furniture AND
  // zero walls AND a degenerate outline (< 3 distinct points) is not.
  const distinct = new Set(roomOutline.map((pt) => `${pt.x.toFixed(3)},${pt.y.toFixed(3)}`));
  if (distinct.size < 3 && walls.length === 0 && furniture.length === 0) return null;

  return {
    schemaVersion: CONCEPT_SCHEMA_VERSION,
    roomType,
    confidence,
    roomOutline,
    walls,
    openings,
    furniture,
    uncertaintyNotes,
  };
}

// --- endpoint -------------------------------------------------------------------

export default async (req: Request) => {
  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  const limited = await enforceAiRateLimit(req, "analyze-floorplan", 10);
  if (limited) return limited;

  if (!firebaseAdminConfigured()) {
    return jsonResponse(503, {
      error: "Floor-plan analysis isn't available on this deployment (FIREBASE_SERVICE_ACCOUNT_KEY missing — see AUTH-SETUP.md §4).",
    });
  }

  // Server-verified sign-in REQUIRED — this is an agent feature, and the
  // quota is per account, not per IP.
  const caller = await resolveAiCaller(req);
  if (caller.status === "invalid-token") {
    return jsonResponse(401, { error: "Your session has expired — sign in again." });
  }
  if (!caller.user) {
    return jsonResponse(401, { error: "Sign in to use AI floor-plan analysis." });
  }
  const scope: AiScope = caller.scope;

  if (!getGeminiApiKey()) {
    return jsonResponse(503, {
      error: "AI floor-plan analysis isn't configured on this deployment (GEMINI_API_KEY missing).",
    });
  }

  let body: {
    imageBase64?: string;
    mimeType?: string;
    crops?: { imageBase64?: string; label?: string }[];
  };
  try {
    body = await req.json();
  } catch {
    return jsonResponse(400, { error: "Invalid JSON body" });
  }

  const { imageBase64, mimeType, crops } = body;
  if (!imageBase64 || !mimeType) {
    return jsonResponse(400, { error: "imageBase64 and mimeType are required" });
  }
  if (!/^image\/(jpeg|png)$/.test(mimeType)) {
    return jsonResponse(415, { error: "The panorama must be a JPEG or PNG image." });
  }
  if (imageBase64.length > 4_000_000 || !/^[A-Za-z0-9+/]*={0,2}$/.test(imageBase64)) {
    return jsonResponse(413, { error: "Panorama is too large or has an invalid encoding. Use a smaller image." });
  }

  // Perspective crops (same panorama, client-rendered): up to 4, each capped.
  const validCrops: { imageBase64: string; label: string }[] = [];
  if (Array.isArray(crops)) {
    for (const crop of crops.slice(0, 4)) {
      const data = typeof crop?.imageBase64 === "string" ? crop.imageBase64 : "";
      if (!data || data.length > 1_500_000 || !/^[A-Za-z0-9+/]*={0,2}$/.test(data)) continue;
      const label = typeof crop.label === "string" ? crop.label.trim().slice(0, 60) : "view";
      validCrops.push({ imageBase64: data, label });
    }
  }

  // Content-hash cache: the same panorama (and prompt/schema version, and
  // model) must not re-bill the API. Cache hits don't consume quota.
  const primaryModel = resolveModels("text")[0];
  // Cache identity must include every image input that can affect the model
  // result. Previously only the panorama was hashed, so a request with the
  // same panorama but different perspective crops could incorrectly reuse a
  // result generated from a different set of views.
  const cacheContent = JSON.stringify({
    mimeType,
    imageBase64,
    crops: validCrops.map(({ imageBase64: cropImage, label }) => ({ imageBase64: cropImage, label })),
  });
  const cacheKey = await aiCacheKey(
    "analyze-floorplan",
    String(CONCEPT_SCHEMA_VERSION),
    primaryModel,
    cacheContent,
  );
  const cached = await getCachedAnalysis<ConceptAnalysis>(cacheKey);
  if (cached) {
    return jsonResponse(200, { ...cached, model: primaryModel, cached: true, disclaimer: DISCLAIMER });
  }

  const quotaResponse = await enforceAiQuota(req, "analyze-floorplan", { requireAuth: false });
  if (quotaResponse) return quotaResponse;

  const prompt = [
    "You are looking at ONE room of a property, shown as an equirectangular 360-degree panorama",
    "(the whole room wraps around the image; left and right edges join).",
    validCrops.length
      ? `The same panorama is also shown as ${validCrops.length} straightened perspective views (${validCrops.map((c) => `"${c.label}"`).join(", ")}) — these are DIFFERENT VIEWS OF THE SAME ROOM, not different rooms.`
      : "",
    "Sketch a rough TOP-DOWN CONCEPT layout of this single room on a normalized grid:",
    "x goes 0 (left) to 1 (right), y goes 0 (top/north) to 1 (bottom/south). The room's outline should span most of the grid.",
    "Rules:",
    "- Positions are APPROXIMATE CONCEPT positions only. Do NOT estimate or state any real-world measurement (no metres, feet, square units).",
    "- Mark every element you could not clearly see (occluded, behind the camera, ambiguous) with certain:false. Be honest — guessed items MUST be certain:false.",
    "- Do NOT invent rooms, furniture or openings that are not visible. An empty room is a valid answer.",
    "- Openings: place each door/window at its approximate position on the outline.",
    `Furniture kinds must come from this list: ${FURNITURE_KINDS.join(", ")}.`,
    "Include short uncertaintyNotes (e.g. 'walls behind the camera are inferred', 'layout compressed by lens distortion').",
    'Respond with ONLY this JSON object, no other text: {"schemaVersion": 1, "roomType": string, "confidence": number, "roomOutline": [{"x": number, "y": number}], "walls": [{"a": {"x": number, "y": number}, "b": {"x": number, "y": number}, "certain": boolean}], "openings": [{"kind": "door"|"window", "x": number, "y": number, "certain": boolean}], "furniture": [{"kind": string, "label": string, "x": number, "y": number, "w": number, "h": number, "rotation": number, "certain": boolean}], "uncertaintyNotes": [string]}',
  ]
    .filter(Boolean)
    .join(" ");

  const parts: Record<string, unknown>[] = [
    { text: prompt },
    { inline_data: { mime_type: mimeType, data: imageBase64 } },
  ];
  for (const crop of validCrops) {
    parts.push({ text: `Perspective view "${crop.label}" of the SAME panorama:` });
    parts.push({ inline_data: { mime_type: "image/jpeg", data: crop.imageBase64 } });
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30_000);

  try {
    const { response, model } = await callGemini(
      "text",
      {
        contents: [{ parts }],
        generationConfig: { responseMimeType: "application/json" },
      },
      { signal: controller.signal, functionName: "analyze-floorplan", usage: { scope, feature: "analyze-floorplan" } }
    );

    const data = await response.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
    const parsed = extractJson<unknown>(text);

    if (data?.promptFeedback?.blockReason) {
      return jsonResponse(502, {
        error: `Gemini declined to analyse this panorama (${data.promptFeedback.blockReason}).`,
      });
    }

    const analysis = validateConceptAnalysis(parsed);
    if (!analysis) {
      // Honest failure — never a fabricated or "repaired" layout.
      return jsonResponse(502, {
        error: "The AI couldn't produce a usable room layout from this panorama. Try a clearer, higher-quality 360 image — or draw the plan manually.",
        detail: text.slice(0, 200),
      });
    }

    // Cache the validated analysis (safe server output only).
    await putCachedAnalysis(cacheKey, analysis);

    return jsonResponse(200, { ...analysis, model, cached: false, disclaimer: DISCLAIMER });
  } catch (err: any) {
    if (err instanceof GeminiError) {
      return jsonResponse(err.httpStatus, { error: err.safeMessage, retryable: err.retryable });
    }
    if (err?.name === "AbortError") {
      return jsonResponse(504, { error: "Floor-plan analysis timed out" });
    }
    return jsonResponse(500, { error: "Floor-plan analysis failed" });
  } finally {
    clearTimeout(timeout);
  }
};

export const config: Config = {
  path: "/api/analyze-floorplan",
};
