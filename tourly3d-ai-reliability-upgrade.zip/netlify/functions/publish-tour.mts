import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import {
  jsonResponse,
  TOURS_STORE_NAME,
  TOUR_META_PREFIX,
  TOUR_PREVIEW_PREFIX,
  TOUR_OWNER_PREFIX,
  hashPassword,
  randomSalt,
  rateLimit,
  clientIp,
  verifyAuthToken,
  firebaseAdminConfigured,
  AdminSetupError,
  TokenProjectMismatchError,
} from "./_shared.mts";

/**
 * Stores a tour so /tour/:id works from ANY device, not just the browser
 * that created it. This is an explicit action the user takes (a "Publish"
 * button), not automatic — editing a tour after publishing does NOT
 * update the shared copy until they publish again.
 */
// Matches MAX_BODY_BYTES in src/lib/publish.ts, plus headroom for the
// password/previewImage fields alongside the tour itself.
const MAX_REQUEST_BYTES = 6_500_000;

export default async (req: Request) => {
  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  const contentLength = Number(req.headers.get("content-length") ?? 0);
  if (contentLength > MAX_REQUEST_BYTES) {
    return jsonResponse(413, { error: "Walkthrough is too large to publish." });
  }

  let body: { tour?: { id?: string; viewPassword?: string }; password?: string; previewImage?: string };
  let rawText: string;
  try {
    rawText = await req.text();
    if (rawText.length > MAX_REQUEST_BYTES) {
      return jsonResponse(413, { error: "Walkthrough is too large to publish." });
    }
    body = JSON.parse(rawText);
  } catch {
    return jsonResponse(400, { error: "Invalid JSON body" });
  }

  const tour = body.tour;
  if (!tour?.id || typeof tour.id !== "string") {
    return jsonResponse(400, { error: "A tour with an id is required" });
  }
  if (
    tour.id.startsWith(TOUR_META_PREFIX) ||
    tour.id.startsWith(TOUR_PREVIEW_PREFIX) ||
    tour.id.startsWith(TOUR_OWNER_PREFIX) ||
    tour.id.includes("ratelimit:")
  ) {
    return jsonResponse(400, { error: "Invalid tour id" });
  }

  // Server-side published-config validation (Feature I) — the editor's UI
  // checks these too, but the API is reachable directly, so a tour that
  // can't render a single scene is rejected with a useful message instead
  // of publishing a blank page.
  const stops = Array.isArray((tour as any).stops) ? (tour as any).stops : [];
  const scenesWithMedia = stops.filter((s: any) => s?.media);
  if (scenesWithMedia.length === 0) {
    return jsonResponse(400, {
      error: "Nothing to publish yet — add at least one scene with a photo, panorama or video first.",
    });
  }
  if (typeof (tour as any).name === "string" && (tour as any).name.length > 200) {
    return jsonResponse(400, { error: "Walkthrough name is too long (200 characters max)." });
  }
  // Hotspot targets must reference scenes that actually exist — a broken
  // target renders a pin that does nothing on the public page.
  const stopIds = new Set(stops.map((s: any) => s?.id).filter(Boolean));
  for (const stop of stops) {
    for (const h of stop?.hotspots ?? []) {
      if (h?.targetStopId && !stopIds.has(h.targetStopId)) {
        return jsonResponse(400, {
          error: `A hotspot in "${stop?.title ?? "a scene"}" points to a scene that no longer exists — remove or relink it, then publish again.`,
        });
      }
    }
  }

  // Real, server-verified auth — NOT a client-supplied flag. Previously
  // this endpoint had no auth check at all: the editor's UI only *looked*
  // protected (ProtectedRoute), but anyone who knew a tour's id could call
  // this function directly, signed in or not, and overwrite it. A verified
  // Firebase ID token is the only thing that actually proves who's calling.
  if (!firebaseAdminConfigured()) {
    return jsonResponse(
      503,
      {
        error:
          "Publishing isn't available on this deployment yet — the FIREBASE_SERVICE_ACCOUNT_KEY environment variable isn't set (Netlify UI → Site configuration → Environment variables; see AUTH-SETUP.md §4).",
      }
    );
  }
  let caller: Awaited<ReturnType<typeof verifyAuthToken>>;
  try {
    caller = await verifyAuthToken(req);
  } catch (err) {
    if (err instanceof AdminSetupError) {
      // The server's own key is broken — a config problem (503), not the
      // user's session. Log enough to debug, never the key itself.
      console.error("[publish-tour] admin setup error:", err.message);
      return jsonResponse(503, { error: err.message });
    }
    if (err instanceof TokenProjectMismatchError) {
      return jsonResponse(401, {
        error:
          `Sign-in is split across two Firebase projects: this site's browser build uses "${err.tokenAudience}" but the server key is for "${err.serverProjectId}". ` +
          "The VITE_FIREBASE_* build variables and FIREBASE_SERVICE_ACCOUNT_KEY must come from the SAME Firebase project (see AUTH-SETUP.md §5).",
      });
    }
    console.warn("[publish-tour] rejecting unauthenticated publish:",
      (err as any)?.errorInfo?.code ?? (err as any)?.code ?? "unknown-error");
    return jsonResponse(401, { error: "Your session has expired — sign in again and retry." });
  }
  if (!caller) {
    return jsonResponse(401, { error: "Sign in to publish a walkthrough." });
  }

  try {
    const store = getStore({ name: TOURS_STORE_NAME });

    // Cheap abuse guard: 20 publishes per IP per minute. Fails open on any
    // Blobs error, and never blocks reading tours — only writing them.
    const { limited } = await rateLimit(store, clientIp(req), 20, 60);
    if (limited) {
      return jsonResponse(429, { error: "Too many publishes from this connection — wait a minute and try again." });
    }

    // Ownership: the first person to publish a given tour id "claims" it —
    // anyone else trying to publish over the same id is rejected, even if
    // they're signed in. (There's no full per-user tour database yet — see
    // README "Authentication" — so this is enforced at publish-time against
    // this one stored uid, not a real foreign-key relationship.)
    const existingOwner = (await store.get(TOUR_OWNER_PREFIX + tour.id, { type: "json" })) as
      | { uid: string }
      | null;
    if (existingOwner && existingOwner.uid !== caller.uid) {
      return jsonResponse(403, { error: "This walkthrough was published by a different account." });
    }
    if (!existingOwner) {
      await store.setJSON(TOUR_OWNER_PREFIX + tour.id, { uid: caller.uid });
    }

    // Never persist a plaintext password inside the tour JSON that get-tour
    // returns to viewers — strip it, and keep only a salted PBKDF2 hash in a
    // separate metadata key.
    const { viewPassword: _ignored, ...publicTour } = tour as Record<string, unknown> & { viewPassword?: string };
    await store.setJSON(tour.id, publicTour);

    const password = typeof body.password === "string" ? body.password.trim() : "";
    if (password) {
      const salt = randomSalt();
      const hash = await hashPassword(password, salt);
      await store.setJSON(TOUR_META_PREFIX + tour.id, { salt, hash });
    } else {
      // Republishing without a password removes protection (explicit choice).
      await store.delete(TOUR_META_PREFIX + tour.id);
    }

    // Small JPEG cover crop for link-preview crawlers (see the tour-meta
    // edge function). Skipped for password-protected tours by the client,
    // but enforce it here too in case a future caller forgets to.
    if (typeof body.previewImage === "string" && body.previewImage.startsWith("data:image/") && !password) {
      if (body.previewImage.length < 500_000) {
        await store.set(TOUR_PREVIEW_PREFIX + tour.id, body.previewImage, { metadata: { contentType: "text" } });
      }
    } else {
      await store.delete(TOUR_PREVIEW_PREFIX + tour.id);
    }

    return jsonResponse(200, { ok: true, id: tour.id, protected: Boolean(password) });
  } catch (err) {
    return jsonResponse(500, { error: "Could not publish tour", detail: String(err) });
  }
};

export const config: Config = {
  path: "/api/publish-tour",
};
