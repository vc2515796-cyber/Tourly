import type { Config } from "@netlify/functions";
import { jsonResponse, verifyAuthToken, firebaseAdminConfigured, rateLimit, clientIp, AdminSetupError, TokenProjectMismatchError } from "./_shared.mts";

/**
 * Cloud media storage (Feature G) — S3-compatible presigned uploads.
 *
 * All S3 credentials live in SERVER-ONLY env vars (S3_BUCKET, S3_REGION,
 * S3_ACCESS_KEY_ID, S3_SECRET_ACCESS_KEY, optional S3_ENDPOINT for
 * R2/MinIO/Wasabi and S3_PUBLIC_URL_BASE for a CDN). The browser never
 * sees any of them — it only receives a short-lived (15 min) presigned PUT
 * URL for one specific object key.
 *
 * SigV4 is implemented directly on Web Crypto — no AWS SDK dependency to
 * bundle or keep patched. When the env vars are missing, GET reports
 * { configured: false } and the frontend falls back to its legacy
 * embedded-media flow WITH a visible notice (never silently).
 *
 * ACCESS MODEL (documented in README): uploaded objects must be readable
 * through the bucket's public URL or a CDN in front of it, because a
 * published tour's viewers need to load them. The tour JSON itself can
 * still be password-protected; media URLs have the same share-once
 * characteristic as the previous embedded-dataUrl media.
 */

const enc = new TextEncoder();

function env(name: string): string | undefined {
  const v = process.env[name];
  return v && v.trim() ? v.trim() : undefined;
}

function s3Configured(): boolean {
  return Boolean(env("S3_BUCKET") && env("S3_REGION") && env("S3_ACCESS_KEY_ID") && env("S3_SECRET_ACCESS_KEY"));
}

// --- allowlists + limits ---------------------------------------------------

const ALLOWED_IMAGE_TYPES = new Set(["image/jpeg", "image/png", "image/webp"]);
const ALLOWED_VIDEO_TYPES = new Set(["video/mp4", "video/webm", "video/quicktime"]);
const MAX_IMAGE_BYTES = 60 * 1024 * 1024;
const MAX_VIDEO_BYTES = 300 * 1024 * 1024;

function objectHost(): string {
  const endpoint = env("S3_ENDPOINT");
  if (endpoint) return endpoint.replace(/^https?:\/\//, "").replace(/\/$/, "");
  return `${env("S3_BUCKET")}.s3.${env("S3_REGION")}.amazonaws.com`;
}

function objectBasePath(): string {
  // Path-style addressing when a custom endpoint is in play (R2, MinIO);
  // virtual-host style on vanilla AWS S3.
  return env("S3_ENDPOINT") ? `/${env("S3_BUCKET")}` : "";
}

function publicUrlFor(key: string): string {
  const base = env("S3_PUBLIC_URL_BASE");
  if (base) return `${base.replace(/\/$/, "")}/${key}`;
  return `https://${objectHost()}${objectBasePath()}/${key}`;
}

function safeExtension(filename: string, contentType: string): string {
  const fromName = filename.toLowerCase().match(/\.([a-z0-9]{1,5})$/)?.[1];
  if (fromName && /^[a-z0-9]+$/.test(fromName)) return fromName;
  const map: Record<string, string> = {
    "image/jpeg": "jpg",
    "image/png": "png",
    "image/webp": "webp",
    "video/mp4": "mp4",
    "video/webm": "webm",
    "video/quicktime": "mov",
  };
  return map[contentType] ?? "bin";
}

// --- SigV4 (query-string presign, UNSIGNED-PAYLOAD) ------------------------

function toHex(buf: ArrayBuffer): string {
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function sha256Hex(text: string): Promise<string> {
  return toHex(await crypto.subtle.digest("SHA-256", enc.encode(text)));
}

async function hmac(key: ArrayBuffer | Uint8Array, text: string): Promise<ArrayBuffer> {
  // new Uint8Array(...) always copies into a fresh ArrayBuffer, which keeps
  // the type (and the runtime view) unambiguous for Web Crypto.
  const keyBytes = new Uint8Array(key);
  const cryptoKey = await crypto.subtle.importKey(
    "raw",
    keyBytes,
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  return crypto.subtle.sign("HMAC", cryptoKey, enc.encode(text));
}

function encodeRfc3986(text: string): string {
  return encodeURIComponent(text).replace(
    /[!'()*]/g,
    (c) => "%" + c.charCodeAt(0).toString(16).toUpperCase()
  );
}

type PresignOptions = {
  method: "PUT" | "DELETE";
  key: string;
  contentType?: string;
  expiresSeconds: number;
};

/** Builds a presigned URL for a single S3 object operation. */
async function presign({ method, key, contentType, expiresSeconds }: PresignOptions): Promise<string> {
  const region = env("S3_BUCKET") && env("S3_REGION") ? env("S3_REGION")! : "";
  const accessKey = env("S3_ACCESS_KEY_ID")!;
  const secretKey = env("S3_SECRET_ACCESS_KEY")!;
  const host = objectHost();
  const objectPath = `${objectBasePath()}/${key.split("/").map(encodeRfc3986).join("/")}`;

  const now = new Date();
  const amzDate = now.toISOString().replace(/[:-]|\.\d{3}/g, ""); // 20260101T000000Z
  const dateStamp = amzDate.slice(0, 8);
  const scope = `${dateStamp}/${region}/s3/aws4_request`;

  // Signed headers: host always; content-type for PUT (the browser must
  // send the identical header or S3 rejects the signature).
  const signedHeaders = method === "PUT" && contentType ? "content-type;host" : "host";

  const query = new Map<string, string>([
    ["X-Amz-Algorithm", "AWS4-HMAC-SHA256"],
    ["X-Amz-Credential", `${accessKey}/${scope}`],
    ["X-Amz-Date", amzDate],
    ["X-Amz-Expires", String(expiresSeconds)],
    ["X-Amz-SignedHeaders", signedHeaders],
  ]);
  const canonicalQuery = Array.from(query.keys())
    .sort()
    .map((k) => `${encodeRfc3986(k)}=${encodeRfc3986(query.get(k)!)}`)
    .join("&");

  const canonicalRequest = [
    method,
    objectPath,
    canonicalQuery,
    method === "PUT" && contentType ? `content-type:${contentType}\nhost:${host}\n` : `host:${host}\n`,
    signedHeaders,
    "UNSIGNED-PAYLOAD",
  ].join("\n");

  const stringToSign = [
    "AWS4-HMAC-SHA256",
    amzDate,
    scope,
    await sha256Hex(canonicalRequest),
  ].join("\n");

  let signingKey: ArrayBuffer = await hmac(enc.encode(`AWS4${secretKey}`), dateStamp);
  signingKey = await hmac(signingKey, region);
  signingKey = await hmac(signingKey, "s3");
  signingKey = await hmac(signingKey, "aws4_request");
  const signature = toHex(await hmac(signingKey, stringToSign));

  return `https://${host}${objectPath}?${canonicalQuery}&X-Amz-Signature=${signature}`;
}

// --- handler ---------------------------------------------------------------

export default async (req: Request) => {
  // Cheap, unauthenticated capability probe used by the editor to decide
  // between cloud and embedded storage. Reveals nothing but a boolean.
  if (req.method === "GET") {
    return jsonResponse(200, {
      configured: s3Configured(),
      reason: s3Configured() ? undefined : "S3_* environment variables are not set on this deployment.",
    });
  }

  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  if (!s3Configured()) {
    return jsonResponse(501, {
      error: "Cloud media storage isn't configured on this deployment (missing S3_* environment variables).",
    });
  }
  if (!firebaseAdminConfigured()) {
    return jsonResponse(503, {
      error: "Cloud uploads need server-side auth verification — set FIREBASE_SERVICE_ACCOUNT_KEY in Netlify environment variables (see AUTH-SETUP.md §4).",
    });
  }

  let caller: Awaited<ReturnType<typeof verifyAuthToken>>;
  try {
    caller = await verifyAuthToken(req);
  } catch (err) {
    if (err instanceof AdminSetupError) {
      console.error("[media-upload] admin setup error:", err.message);
      return jsonResponse(503, { error: err.message });
    }
    if (err instanceof TokenProjectMismatchError) {
      return jsonResponse(401, {
        error: `Client/server Firebase project mismatch ("${err.tokenAudience}" vs "${err.serverProjectId}") — see AUTH-SETUP.md §5.`,
      });
    }
    console.warn("[media-upload] auth rejected:",
      (err as any)?.errorInfo?.code ?? (err as any)?.code ?? "unknown-error");
    return jsonResponse(401, { error: "Your session has expired — sign in again and retry." });
  }
  if (!caller) {
    return jsonResponse(401, { error: "Sign in to upload media to cloud storage." });
  }

  let body: {
    action?: string;
    filename?: string;
    contentType?: string;
    size?: number;
    key?: string;
  };
  try {
    body = await req.json();
  } catch {
    return jsonResponse(400, { error: "Invalid JSON body" });
  }

  try {
    const { getStore } = await import("@netlify/blobs");
    const store = getStore({ name: "waypoint-media-ratelimit" });
    const { limited } = await rateLimit(store, `upload:${caller.uid}`, 60, 3600);
    if (limited) {
      return jsonResponse(429, { error: "Too many uploads this hour — try again later." });
    }
    void clientIp; // per-uid limit covers this endpoint; keep import honest
  } catch {
    // Rate limiting fails open by design (see _shared.rateLimit).
  }

  const action = body.action;

  if (action === "sign") {
    const { filename = "file", contentType, size } = body;
    if (typeof contentType !== "string" || typeof size !== "number") {
      return jsonResponse(400, { error: "filename, contentType and size are required" });
    }
    const isImage = ALLOWED_IMAGE_TYPES.has(contentType);
    const isVideo = ALLOWED_VIDEO_TYPES.has(contentType);
    if (!isImage && !isVideo) {
      return jsonResponse(415, {
        error: `Unsupported media type ${contentType}. Allowed: JPEG, PNG, WebP images; MP4, WebM, QuickTime video.`,
      });
    }
    const maxBytes = isVideo ? MAX_VIDEO_BYTES : MAX_IMAGE_BYTES;
    if (size <= 0 || size > maxBytes) {
      return jsonResponse(413, {
        error: `File is too large — the limit is ${Math.round(maxBytes / 1024 / 1024)} MB for ${isVideo ? "video" : "images"}.`,
      });
    }

    const uuid = crypto.randomUUID();
    const ext = safeExtension(String(filename).slice(0, 120), contentType);
    // Per-user prefix = ownership boundary for deletes; random uuid = no
    // collisions, no overwrite of anyone's media.
    const key = `tours/${caller.uid}/${new Date().toISOString().slice(0, 7)}/${uuid}.${ext}`;

    const uploadUrl = await presign({
      method: "PUT",
      key,
      contentType,
      expiresSeconds: 900,
    });

    return jsonResponse(200, { uploadUrl, publicUrl: publicUrlFor(key), key });
  }

  if (action === "delete") {
    const key = body.key;
    if (typeof key !== "string" || !key.startsWith(`tours/${caller.uid}/`)) {
      return jsonResponse(403, { error: "You can only delete your own media." });
    }
    const uploadUrl = await presign({ method: "DELETE", key, expiresSeconds:300 });
    return jsonResponse(200, { ok: true, deleteUrl: uploadUrl });
  }

  return jsonResponse(400, { error: "Unknown action — use \"sign\" or \"delete\"." });
};

export const config: Config = {
  path: "/api/media-upload",
};
