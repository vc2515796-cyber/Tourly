import type { Config } from "@netlify/functions";
import { jsonResponse, safeEqual, clientIp, rateLimit } from "./_shared.mts";
import {
  appendMediaToLinkedTour,
  alreadyProcessed,
  handleCommandText,
  setStatus,
  siteBaseUrl,
  type PipelineResult,
} from "./_messaging.mts";

/**
 * Telegram bot webhook (Feature H).
 *
 * POST — updates from the Bot API. Authenticated by the constant
 *        X-Telegram-Bot-Api-Secret-Token header, which Telegram echoes on
 *        every delivery once you set it when registering the webhook (see
 *        DEPLOY.md). A mismatched/missing header is rejected with 401 and
 *        the update is never processed.
 *
 * External setup still required (cannot be done from code):
 *   1. Create a bot with @BotFather → TELEGRAM_BOT_TOKEN.
 *   2. Pick a long random string → TELEGRAM_WEBHOOK_SECRET.
 *   3. Register the webhook once:
 *      curl "https://api.telegram.org/bot<TOKEN>/setWebhook" \
 *        -d "url=https://YOUR-SITE/api/telegram-webhook" \
 *        -d "secret_token=<TELEGRAM_WEBHOOK_SECRET>"
 *   4. Send /start <CODE> to the bot after generating a code in the
 *      Tourly dashboard.
 */

function env(name: string): string | undefined {
  const v = process.env[name];
  return v && v.trim() ? v.trim() : undefined;
}

function telegramConfigured(): boolean {
  return Boolean(env("TELEGRAM_BOT_TOKEN") && env("TELEGRAM_WEBHOOK_SECRET"));
}

async function sendTelegramText(chatId: number | string, text: string): Promise<void> {
  const token = env("TELEGRAM_BOT_TOKEN")!;
  const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text, disable_web_page_preview: false }),
  });
  if (!response.ok) {
    const detail = (await response.text()).slice(0, 200);
    console.error(`telegram send failed (${response.status}): ${detail}`);
  }
}

export default async (req: Request) => {
  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  if (!telegramConfigured()) {
    return jsonResponse(503, {
      error: "Telegram integration isn't configured on this deployment (TELEGRAM_BOT_TOKEN / TELEGRAM_WEBHOOK_SECRET missing).",
    });
  }

  const secret = req.headers.get("x-telegram-bot-api-secret-token") ?? "";
  if (!secret || !safeEqual(secret, env("TELEGRAM_WEBHOOK_SECRET")!)) {
    return jsonResponse(401, { error: "Invalid secret token" });
  }

  try {
    const { getStore } = await import("@netlify/blobs");
    const store = getStore({ name: "waypoint-messaging-ratelimit" });
    const { limited } = await rateLimit(store, `tg-webhook:${clientIp(req)}`, 120, 60);
    if (limited) return jsonResponse(429, { error: "Too many webhook calls" });
  } catch {
    /* fail open */
  }

  let update: any;
  try {
    update = await req.json();
  } catch {
    return jsonResponse(400, { error: "Invalid JSON" });
  }

  const message = update?.message;
  if (!message?.chat?.id || !message?.from?.id) {
    return jsonResponse(200, { ok: true }); // non-message updates: acknowledge only
  }

  const messageId = `tg-${message.chat.id}-${message.message_id}`;

  const publicBase = siteBaseUrl(req);
  const chatId = message.chat.id;
  const fromId = String(message.from.id);
  const displayName = [message.from.first_name, message.from.last_name].filter(Boolean).join(" ") || undefined;

  let result: PipelineResult;
  try {
    // Duplicate check inside the guard — a storage hiccup becomes a clean,
    // honest failure instead of an unhandled crash.
    if (await alreadyProcessed("telegram", messageId)) {
      return jsonResponse(200, { ok: true, deduped: true });
    }

    await setStatus({ provider: "telegram", messageId, state: "processing", at: Date.now() });

    if (typeof message.text === "string") {
      result = await handleCommandText("telegram", fromId, displayName, message.text, publicBase);
    } else if (Array.isArray(message.photo) && message.photo.length > 0) {
      // Telegram sends several resolutions; take the largest.
      const largest = message.photo.reduce((a: any, b: any) => ((b.width ?? 0) > (a.width ?? 0) ? b : a));
      result = await appendMediaToLinkedTour(
        {
          provider: "telegram",
          providerUserId: fromId,
          displayName,
          messageId,
          mimeType: "image/jpeg", // Telegram photos are always JPEG
          mediaId: largest.file_id,
          fetchMedia: async () => {
            const token = env("TELEGRAM_BOT_TOKEN")!;
            const fileResponse = await fetch(`https://api.telegram.org/bot${token}/getFile?file_id=${largest.file_id}`);
            if (!fileResponse.ok) return { ok: false, error: `getFile ${fileResponse.status}` };
            const file = await fileResponse.json();
            if (!file?.result?.file_path) return { ok: false, error: "no file path" };
            const mediaResponse = await fetch(
              `https://api.telegram.org/file/bot${token}/${file.result.file_path}`
            );
            if (!mediaResponse.ok) return { ok: false, error: `download ${mediaResponse.status}` };
            return { ok: true, bytes: await mediaResponse.arrayBuffer(), mimeType: "image/jpeg" };
          },
        },
        publicBase
      );
    } else if (message.video?.file_id) {
      const mime = typeof message.video.mime_type === "string" ? message.video.mime_type : "video/mp4";
      result = await appendMediaToLinkedTour(
        {
          provider: "telegram",
          providerUserId: fromId,
          displayName,
          messageId,
          mimeType: mime,
          mediaId: message.video.file_id,
          fetchMedia: async () => {
            const token = env("TELEGRAM_BOT_TOKEN")!;
            const fileResponse = await fetch(
              `https://api.telegram.org/bot${token}/getFile?file_id=${message.video.file_id}`
            );
            if (!fileResponse.ok) return { ok: false, error: `getFile ${fileResponse.status}` };
            const file = await fileResponse.json();
            if (!file?.result?.file_path) return { ok: false, error: "no file path" };
            const mediaResponse = await fetch(
              `https://api.telegram.org/file/bot${token}/${file.result.file_path}`
            );
            if (!mediaResponse.ok) return { ok: false, error: `download ${mediaResponse.status}` };
            return { ok: true, bytes: await mediaResponse.arrayBuffer(), mimeType: mime };
          },
        },
        publicBase
      );
    } else {
      result = {
        ok: false,
        reply: "I can't process that message type yet — send a photo, a video, or \"help\".",
      };
    }

    await setStatus({
      provider: "telegram",
      messageId,
      state: result.ok ? "done" : "error",
      error: result.ok ? undefined : result.reply.slice(0, 200),
      at: Date.now(),
    });
    await sendTelegramText(chatId, result.reply);
  } catch (err) {
    console.error(`telegram webhook error (msg ${messageId}): ${String(err).slice(0, 300)}`);
    await setStatus({
      provider: "telegram",
      messageId,
      state: "error",
      error: "processing failed",
      at: Date.now(),
    }).catch(() => {});
    await sendTelegramText(chatId, "Something went wrong processing that message — please try again.").catch(() => {});
  }

  return jsonResponse(200, { ok: true });
};

export const config: Config = {
  path: "/api/telegram-webhook",
};
