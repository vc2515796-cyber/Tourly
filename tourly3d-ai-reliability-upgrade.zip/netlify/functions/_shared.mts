import type { Store } from "@netlify/blobs";

export function jsonResponse(status: number, body: unknown): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

// NOTE: everything Gemini-related (API key access, model ids, the fallback
// + retry client) lives in ./_gemini.mts — one home for the AI reliability
// policy. This module keeps the non-AI shared helpers (auth, rate limits,
// password hashing, JSON helpers).

export const TOURS_STORE_NAME = "waypoint-tours";

/** Pulls the first JSON object/array out of a Gemini text response, tolerant
 *  of ```json fences or stray prose around it — models don't always obey
 *  responseMimeType perfectly. Returns null if nothing parseable is found. */
export function extractJson<T = any>(text: string): T | null {
  const cleaned = text.replace(/```json|```/g, "").trim();
  try {
    return JSON.parse(cleaned) as T;
  } catch {
    const match = cleaned.match(/[[{][\s\S]*[\]}]/);
    if (!match) return null;
    try {
      return JSON.parse(match[0]) as T;
    } catch {
      return null;
    }
  }
}


// --- Password protection helpers (Web Crypto; available in Netlify Functions) ---
const enc = new TextEncoder();

function toHex(buf: ArrayBuffer): string {
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export function randomSalt(): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

/** PBKDF2-SHA256, so a leaked blob can't be brute-forced as cheaply as a bare hash. */
export async function hashPassword(password: string, salt: string): Promise<string> {
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: enc.encode(salt), iterations: 100_000, hash: "SHA-256" },
    key,
    256
  );
  return toHex(bits);
}

/** Constant-time string compare (equal-length hex strings). */
export function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export const TOUR_META_PREFIX = "meta:";
export const TOUR_PREVIEW_PREFIX = "preview:";
export const TOUR_OWNER_PREFIX = "owner:";

/**
 * Best-effort per-IP rate limit backed by Netlify Blobs (shared across
 * function instances, unlike an in-memory counter). Fails OPEN — if Blobs
 * has a hiccup, requests are allowed through rather than blocking real
 * users over an infra blip.
 */
export async function rateLimit(
  store: Store,
  key: string,
  limit: number,
  windowSeconds: number
): Promise<{ limited: boolean }> {
  try {
    const bucket = Math.floor(Date.now() / (windowSeconds * 1000));
    const blobKey = `ratelimit:${key}:${bucket}`;
    const current = ((await store.get(blobKey, { type: "json" })) as number | null) ?? 0;
    if (current >= limit) return { limited: true };
    await store.setJSON(blobKey, current + 1, { metadata: { expiresIn: windowSeconds } });
    return { limited: false };
  } catch {
    return { limited: false };
  }
}

/**
 * Verifies a Firebase ID token sent from the browser as
 * `Authorization: Bearer <token>`. This is the SERVER-SIDE half of
 * authentication — without this, "being signed in" was purely a client-side
 * UI gate (ProtectedRoute hides the page, but nothing stopped a direct
 * `fetch('/api/publish-tour', ...)` call from anyone, signed in or not).
 * A verified, Google-signed token is the only thing that proves who's
 * actually calling — a client-supplied email/uid field proves nothing, since
 * the caller could put anything there.
 *
 * Requires `FIREBASE_SERVICE_ACCOUNT_KEY` (server-only env var, the full
 * JSON of a Firebase service account key, as one line) — see README
 * "Server-side auth verification" for how to generate one. Returns `null`
 * (not configured) vs a rejected promise (token present but invalid) so
 * callers can tell "nobody set this up yet" apart from "someone sent a bad
 * token" and respond with the right status code for each.
 */
let adminAuthPromise: Promise<import("firebase-admin/auth").Auth> | null = null;

export function firebaseAdminConfigured(): boolean {
  return Boolean(process.env.FIREBASE_SERVICE_ACCOUNT_KEY);
}

/** Thrown when FIREBASE_SERVICE_ACCOUNT_KEY is present but can't be used
 *  (malformed JSON, missing required fields, bad credential). Callers must
 *  answer 503 — NOT 401: a server misconfiguration is not the user's
 *  session expiring, and reporting it as such sends people down the wrong
 *  debugging path (this exact bug shipped before). */
export class AdminSetupError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "AdminSetupError";
  }
}

/** The Firebase project id the server's service account belongs to — used
 *  to diagnose client/server project mismatches (see verifyAuthToken). */
let adminProjectId: string | null = null;

async function getAdminAuth() {
  if (!adminAuthPromise) {
    adminAuthPromise = (async () => {
      const { initializeApp, getApps, cert } = await import("firebase-admin/app");
      const { getAuth } = await import("firebase-admin/auth");
      const raw = process.env.FIREBASE_SERVICE_ACCOUNT_KEY!;
      let serviceAccount: Record<string, unknown>;
      try {
        serviceAccount = JSON.parse(raw);
      } catch {
        throw new AdminSetupError(
          "FIREBASE_SERVICE_ACCOUNT_KEY is not valid JSON — paste the FULL service-account key file as a single minified line (see AUTH-SETUP.md §4)."
        );
      }
      if (!serviceAccount.project_id || !serviceAccount.client_email || !serviceAccount.private_key) {
        throw new AdminSetupError(
          "FIREBASE_SERVICE_ACCOUNT_KEY is missing required fields (project_id / client_email / private_key) — regenerate the key in Firebase Console → Project settings → Service accounts (see AUTH-SETUP.md §4)."
        );
      }
      adminProjectId = String(serviceAccount.project_id);
      const app = getApps().length ? getApps()[0]! : initializeApp({ credential: cert(serviceAccount) });
      return getAuth(app);
    })();
    // A failed init must not poison the cache forever: without this, one bad
    // key (or one transient error) permanently broke verification until the
    // function instance was recycled, even after the env var was fixed.
    adminAuthPromise.catch(() => {
      adminAuthPromise = null;
    });
  }
  return adminAuthPromise;
}

export type VerifiedUser = { uid: string; email: string | null };

/** Thrown by verifyAuthToken when a token's project doesn't match the
 *  server's service-account project — i.e. the browser bundle was built
 *  with a DIFFERENT Firebase project's VITE_FIREBASE_* values than the
 *  server key. Both must come from the same project; neither id is a
 *  secret, so naming them is safe and pinpoints the cause. */
export class TokenProjectMismatchError extends Error {
  constructor(public tokenAudience: string, public serverProjectId: string) {
    super(
      `token-project-mismatch (client project "${tokenAudience}" vs server project "${serverProjectId}")`
    );
    this.name = "TokenProjectMismatchError";
  }
}

/** Best-effort decode of a JWT's payload (middle segment) WITHOUT verifying
 *  the signature — verification already failed at this point; this is only
 *  used to extract the token's `aud` (its Firebase project id) so the 401
 *  can say WHICH project the token came from. Never throws. */
function unsafeDecodeAudience(token: string): string | null {
  try {
    const payloadB64 = token.split(".")[1];
    if (!payloadB64) return null;
    // base64url → base64 (swap alphabet, restore the padding atob requires)
    const b64 = payloadB64.replace(/-/g, "+").replace(/_/g, "/");
    const padded = b64 + "=".repeat((4 - (b64.length % 4)) % 4);
    const json = JSON.parse(atob(padded));
    return typeof json.aud === "string" ? json.aud : null;
  } catch {
    return null;
  }
}

/** Returns the verified caller, or null if not configured / no header sent.
 *  Throws if a token WAS sent but is invalid/expired — callers should treat
 *  that as "reject the request", not "treat as anonymous".
 *  - AdminSetupError → the server's key is unusable (answer 503)
 *  - TokenProjectMismatchError → client and server use different Firebase
 *    projects (answer 401 with the specific cause)
 *  - anything else → invalid/expired token (answer 401) */
export async function verifyAuthToken(req: Request): Promise<VerifiedUser | null> {
  if (!firebaseAdminConfigured()) return null;
  const header = req.headers.get("authorization") ?? req.headers.get("Authorization");
  if (!header?.startsWith("Bearer ")) return null;
  const token = header.slice("Bearer ".length).trim();
  const auth = await getAdminAuth();
  try {
    const decoded = await auth.verifyIdToken(token); // throws on invalid/expired
    return { uid: decoded.uid, email: decoded.email ?? null };
  } catch (err: any) {
    // Diagnostic detail for the function logs — the error CODE only, never
    // the token itself or any user data (tokens are credentials).
    console.warn(
      "[auth] ID-token verification failed:",
      err?.errorInfo?.code ?? err?.code ?? String(err?.message ?? err).slice(0, 120)
    );
    // Most common cross-project mistake: the token verifies fine against a
    // real Firebase project, but a DIFFERENT one than the server's key —
    // surface which two projects are fighting instead of "session expired".
    const aud = unsafeDecodeAudience(token);
    if (aud && adminProjectId && aud !== adminProjectId) {
      throw new TokenProjectMismatchError(aud, adminProjectId);
    }
    throw err;
  }
}

export function clientIp(req: Request): string {
  return req.headers.get("x-nf-client-connection-ip") ?? req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
}

export const AI_RATELIMIT_STORE_NAME = "waypoint-ai-ratelimit";

/**
 * One-line per-IP rate limit for the Gemini-backed functions, which
 * previously had NO cap at all — anyone (signed in or not) could call them
 * as fast as they wanted, at this project's Gemini API cost.
 * Returns a ready-to-return 429 Response when the caller is over the
 * limit, or null when they're fine to proceed. Fails open (see
 * `rateLimit`) rather than blocking real usage over a Blobs hiccup.
 */
export async function enforceAiRateLimit(
  req: Request,
  functionName: string,
  limit: number,
  windowSeconds = 60
): Promise<Response | null> {
  try {
    const { getStore } = await import("@netlify/blobs");
    const store = getStore({ name: AI_RATELIMIT_STORE_NAME });
    const { limited } = await rateLimit(store, `${functionName}:${clientIp(req)}`, limit, windowSeconds);
    if (!limited) return null;
    return jsonResponse(429, {
      error: "Too many requests — wait a minute and try again.",
    });
  } catch {
    // Fail OPEN, including when the Blobs environment itself isn't configured
    // (local dev without Netlify, or a Blobs outage) — a rate-limit backend
    // hiccup must never crash the endpoint or block real usage.
    return null;
  }
}
