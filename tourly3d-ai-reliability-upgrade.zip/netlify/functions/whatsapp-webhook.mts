import type { Config } from "@netlify/functions";
import {
  jsonResponse,
  safeEqual,
  clientIp,
  rateLimit,
} from "./_shared.mts";
import {
  appendMediaToLinkedTour,
  alreadyProcessed,
  handleCommandText,
  setStatus,
  siteBaseUrl,
  type PipelineResult,
} from "./_messaging.mts";

/**
 * WhatsApp Cloud API webhook (Feature H).
 *
 * GET  — Meta's subscription verification (hub.challenge handshake).
 * POST — signed webhook events. The raw body is HMAC-SHA256-verified
 *        against WHATSAPP_APP_SECRET (X-Hub-Signature-256) BEFORE anything
 *        is parsed; an invalid signature is rejected with 401 and nothing
 *        from the payload is trusted or processed.
 *
 * External setup still required (cannot be done from code):
 *   1. A Meta app + WhatsApp Business Account with Cloud API access.
 *   2. A permanent access token (System User token) → WHATSAPP_TOKEN.
 *   3. The app secret → WHATSAPP_APP_SECRET.
 *   4. A verify token of your choosing → WHATSAPP_VERIFY_TOKEN.
 *   5. The phone number id → WHATSAPP_PHONE_NUMBER_ID.
 *   6. Subscribe the webhook at developers.facebook.com → your app →
 *      Webhooks → WhatsApp, callback URL https://YOUR-SITE/api/whatsapp-webhook
 *      with the verify token, and subscribe to the "messages" field.
 * See DEPLOY.md for the full walkthrough.
 */

function env(name: string): string | undefined {
  const v = process.env[name];
  return v && v.trim() ? v.trim() : undefined;
}

function whatsappConfigured(): boolean {
  return Boolean(env("WHATSAPP_TOKEN") && env("WHATSAPP_APP_SECRET") && env("WHATSAPP_PHONE_NUMBER_ID"));
}

async function hmacSha256Hex(secret: string, body: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(body));
  return Array.from(new Uint8Array(sig))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

async function sendWhatsAppText(to: string, body: string): Promise<void> {
  const token = env("WHATSAPP_TOKEN");
  const phoneNumberId = env("WHATSAPP_PHONE_NUMBER_ID");
  const response = await fetch(`https://graph.facebook.com/v20.0/${phoneNumberId}/messages`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to,
      type: "text",
      text: { body, preview_url: true },
    }),
  });
  if (!response.ok) {
    // Log status + a short, credential-free fragment for debugging — never
    // the token, never the full media payload.
    const detail = (await response.text()).slice(0, 200);
    console.error(`whatsapp send failed (${response.status}): ${detail}`);
  }
}

type WaMessage = {
  from?: string;
  id?: string;
  type?: string;
  text?: { body?: string };
  image?: { id?: string; mime_type?: string };
  video?: { id?: string; mime_type?: string };
};

export default async (req: Request) => {
  // --- Meta webhook verification handshake ---
  if (req.method === "GET") {
    const params = new URL(req.url).searchParams;
    if (params.get("hub.mode") === "subscribe" && params.get("hub.verify_token")) {
      if (params.get("hub.verify_token") === env("WHATSAPP_VERIFY_TOKEN")) {
        return new Response(params.get("hub.challenge") ?? "", { status: 200 });
      }
      return new Response("Verification token mismatch", { status: 403 });
    }
    return jsonResponse(200, { ok: true }); // health probe
  }

  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  if (!whatsappConfigured()) {
    // Honest, machine-readable "not set up" — never a fake 200.
    return jsonResponse(503, {
      error: "WhatsApp integration isn't configured on this deployment (WHATSAPP_TOKEN / WHATSAPP_APP_SECRET / WHATSAPP_PHONE_NUMBER_ID missing).",
    });
  }

  // --- signature verification on the RAW body, before parsing ---
  const rawBody = await req.text();
  const signature = req.headers.get("x-hub-signature-256") ?? "";
  const expected = "sha256=" + (await hmacSha256Hex(env("WHATSAPP_APP_SECRET")!, rawBody));
  if (!signature.startsWith("sha256=") || !safeEqual(signature, expected)) {
    return jsonResponse(401, { error: "Invalid signature" });
  }

  // --- per-IP burst limit (fails open, see _shared.rateLimit) ---
  try {
    const { getStore } = await import("@netlify/blobs");
    const store = getStore({ name: "waypoint-messaging-ratelimit" });
    const { limited } = await rateLimit(store, `wa-webhook:${clientIp(req)}`, 120, 60);
    if (limited) return jsonResponse(429, { error: "Too many webhook calls" });
  } catch {
    /* fail open */
  }

  let payload: any;
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return jsonResponse(400, { error: "Invalid JSON" });
  }

  const publicBase = siteBaseUrl(req);
  const messages: WaMessage[] =
    payload?.entry?.flatMap((e: any) =>
      e?.changes?.flatMap((c: any) => c?.value?.messages ?? []) ?? []
    ) ?? [];

  // Always 200 once the signature checks out — Meta retries non-2xx
  // aggressively, and individual message failures are reported to the
  // SENDER (truthfully) rather than failing the whole delivery.
  for (const message of messages) {
    const messageId = message.id;
    const from = message.from;
    if (!messageId || !from) continue;

    let result: PipelineResult;
    try {
      // Duplicate check first, inside the guard — a Blobs hiccup here is
      // reported to the sender as a failed message instead of crashing the
      // webhook with a non-JSON error.
      if (await alreadyProcessed("whatsapp", messageId)) continue;

      await setStatus({ provider: "whatsapp", messageId, state: "processing", at: Date.now() });

      if (message.type === "text" && message.text?.body) {
        result = await handleCommandText("whatsapp", from, undefined, message.text.body, publicBase);
      } else if (message.type === "image" && message.image?.id) {
        result = await appendMediaToLinkedTour(
          {
            provider: "whatsapp",
            providerUserId: from,
            messageId,
            mimeType: message.image.mime_type ?? "image/jpeg",
            mediaId: message.image.id,
            fetchMedia: async () => {
              const token = env("WHATSAPP_TOKEN")!;
              const metaResponse = await fetch(`https://graph.facebook.com/v20.0/${message.image!.id}`, {
                headers: { Authorization: `Bearer ${token}` },
              });
              if (!metaResponse.ok) return { ok: false, error: `media lookup ${metaResponse.status}` };
              const meta = await metaResponse.json();
              if (!meta?.url) return { ok: false, error: "no media url" };
              const mediaResponse = await fetch(meta.url, {
                headers: { Authorization: `Bearer ${token}` },
              });
              if (!mediaResponse.ok) return { ok: false, error: `media download ${mediaResponse.status}` };
              return {
                ok: true,
                bytes: await mediaResponse.arrayBuffer(),
                mimeType: message.image!.mime_type ?? meta.mime_type ?? "image/jpeg",
              };
            },
          },
          publicBase
        );
      } else if (message.type === "video" && message.video?.id) {
        result = await appendMediaToLinkedTour(
          {
            provider: "whatsapp",
            providerUserId: from,
            messageId,
            mimeType: message.video.mime_type ?? "video/mp4",
            mediaId: message.video.id,
            fetchMedia: async () => {
              const token = env("WHATSAPP_TOKEN")!;
              const metaResponse = await fetch(`https://graph.facebook.com/v20.0/${message.video!.id}`, {
                headers: { Authorization: `Bearer ${token}` },
              });
              if (!metaResponse.ok) return { ok: false, error: `media lookup ${metaResponse.status}` };
              const meta = await metaResponse.json();
              if (!meta?.url) return { ok: false, error: "no media url" };
              const mediaResponse = await fetch(meta.url, {
                headers: { Authorization: `Bearer ${token}` },
              });
              if (!mediaResponse.ok) return { ok: false, error: `media download ${mediaResponse.status}` };
              return {
                ok: true,
                bytes: await mediaResponse.arrayBuffer(),
                mimeType: message.video!.mime_type ?? "video/mp4",
              };
            },
          },
          publicBase
        );
      } else {
        result = {
          ok: false,
          reply: `I can't process "${message.type ?? "unknown"}" messages yet — send a photo, a video, or "help".`,
        };
      }

      await setStatus({
        provider: "whatsapp",
        messageId,
        state: result.ok ? "done" : "error",
        error: result.ok ? undefined : result.reply.slice(0, 200),
        at: Date.now(),
      });
      await sendWhatsAppText(from, result.reply);
    } catch (err) {
      // Unexpected failure: record it honestly, tell the sender, but keep
      // the delivery ack 200 so Meta doesn't retry-storm a broken message.
      console.error(`whatsapp webhook error (msg ${messageId}): ${String(err).slice(0, 300)}`);
      await setStatus({
        provider: "whatsapp",
        messageId,
        state: "error",
        error: "processing failed",
        at: Date.now(),
      }).catch(() => {});
      await sendWhatsAppText(from, "Something went wrong processing that message — please try again.").catch(() => {});
    }
  }

  return jsonResponse(200, { processed: messages.length });
};

export const config: Config = {
  path: "/api/whatsapp-webhook",
};
