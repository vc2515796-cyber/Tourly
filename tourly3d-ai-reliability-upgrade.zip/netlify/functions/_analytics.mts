import type { Store } from "@netlify/blobs";

/**
 * Stage C — shared types + helpers for buyer-engagement analytics.
 *
 * Storage model (Netlify Blobs, store "waypoint-analytics"):
 *   stats:{tourId}:{YYYY-MM-DD} → one TourDayStats aggregate per tour per UTC day
 *
 * Privacy model (deliberately minimal):
 *  - Only aggregate counts are stored. No IP addresses, no user agents,
 *    no referrers, no timestamps of individual events.
 *  - "Unique visitors" are counted from a CLIENT-GENERATED RANDOM token
 *    (no PII — it is not derived from anything about the person). The
 *    server stores only a truncated SHA-256 hash of that token, per tour
 *    per day, capped at MAX_UNIQUES_PER_DAY entries. Beyond the cap the
 *    counter stops growing and the day is flagged uniquesCapped (the UI
 *    must say "5000+" rather than invent a number).
 *  - Because the hashed tokens are per-day, summing them across days
 *    counts "visitor-days", not distinct humans. The dashboard labels
 *    this honestly.
 *  - enquiry / visit-request events are recorded SERVER-SIDE by
 *    capture-lead.mts only. The public track-event endpoint refuses
 *    those kinds, so a client can never inflate conversion numbers.
 *
 * Consistency model: each event is a read-modify-write of the day
 * document. Under a burst, two concurrent writes can lose one increment
 * (last-write-wins). These are best-effort engagement counts, not
 * billing records — a small undercount under extreme concurrency is the
 * documented trade-off for staying on a single small document per day.
 */

export const ANALYTICS_STORE_NAME = "waypoint-analytics";
export const STATS_KEY_PREFIX = "stats:";

/** Events the PUBLIC endpoint accepts. enquiry + visit-request are
 *  server-recorded only (see capture-lead.mts). */
export const PUBLIC_EVENT_KINDS = ["tour-view", "scene-view", "hotspot"] as const;
export const ALL_EVENT_KINDS = [...PUBLIC_EVENT_KINDS, "enquiry", "visit-request"] as const;
export type EventKind = (typeof ALL_EVENT_KINDS)[number];

/** Where the open came from. The share tools append ?src=… to the tour
 *  URL; embeds are detected by the client running inside an iframe. */
export const EVENT_SOURCES = ["direct", "link", "qr", "wa", "embed"] as const;
export type EventSource = (typeof EVENT_SOURCES)[number];

export const MAX_UNIQUES_PER_DAY = 5000;
/** Daily docs older than this are ignored when reading (retention bound).
 *  Writes never backfill old dates; a future cleanup may prune them. */
export const ANALYTICS_RETENTION_DAYS = 370;

export type TourDayStats = {
  /** UTC date this document covers, YYYY-MM-DD. */
  date: string;
  events: Partial<Record<EventKind, number>>;
  sources: Partial<Record<EventSource, number>>;
  /** sceneId → scene-view count for this day (hotspot clicks are counted
   *  in `events`, not here). */
  scenes: Record<string, number>;
  /** Truncated SHA-256 hashes of random visitor tokens — never the raw
   *  tokens, never anything derived from personal data. */
  uniques: string[];
  uniquesCapped: boolean;
  updatedAt: number;
};

export function isPublicEventKind(v: unknown): v is (typeof PUBLIC_EVENT_KINDS)[number] {
  return typeof v === "string" && (PUBLIC_EVENT_KINDS as readonly string[]).includes(v);
}

export function isAllEventKind(v: unknown): v is EventKind {
  return typeof v === "string" && (ALL_EVENT_KINDS as readonly string[]).includes(v);
}

export function isEventSource(v: unknown): v is EventSource {
  return typeof v === "string" && (EVENT_SOURCES as readonly string[]).includes(v);
}

/** UTC YYYY-MM-DD for a timestamp — analytics days are UTC so a tour's
 *  numbers don't shift when the agent's device timezone changes. */
export function utcDateKey(at: number): string {
  return new Date(at).toISOString().slice(0, 10);
}

export function statsKey(tourId: string, dateKey: string): string {
  return `${STATS_KEY_PREFIX}${tourId}:${dateKey}`;
}

export function emptyDay(dateKey: string): TourDayStats {
  return { date: dateKey, events: {}, sources: {}, scenes: {}, uniques: [], uniquesCapped: false, updatedAt: 0 };
}

export type AnalyticsEvent = {
  kind: EventKind;
  source: EventSource;
  /** Required for scene-view and hotspot. */
  sceneId?: string;
  /** Pre-hashed visitor token (see hashVisitorToken). Only used by
   *  tour-view for unique counting. */
  visitorHash?: string;
};

/** Pure, side-effect-free merge of one event into a day document.
 *  Returns the SAME object mutated for efficiency — clone first if you
 *  need the original. */
export function mergeEventIntoDay(day: TourDayStats, ev: AnalyticsEvent): TourDayStats {
  day.events[ev.kind] = (day.events[ev.kind] ?? 0) + 1;
  day.sources[ev.source] = (day.sources[ev.source] ?? 0) + 1;
  if (ev.sceneId && ev.kind === "scene-view") {
    // Scene attribution counts OPENS of a scene; hotspot clicks are in
    // `events` (and carry their sceneId in the request if we ever want
    // per-scene hotspot analytics — mixing the two here would make
    // "most-opened scene" mean something different).
    day.scenes[ev.sceneId] = (day.scenes[ev.sceneId] ?? 0) + 1;
  }
  if (ev.kind === "tour-view" && ev.visitorHash) {
    if (day.uniques.includes(ev.visitorHash)) {
      // Same browser session/day — the event itself was counted above;
      // only the unique set skips duplicates.
    } else if (day.uniques.length >= MAX_UNIQUES_PER_DAY) {
      day.uniquesCapped = true;
    } else {
      day.uniques.push(ev.visitorHash);
    }
  }
  day.updatedAt = Date.now();
  return day;
}

/** SHA-256 of the client's random token, truncated to 16 hex chars.
 *  The token is already random and PII-free; hashing means the raw token
 *  never rests in analytics storage at all. */
export async function hashVisitorToken(token: string): Promise<string> {
  const data = new TextEncoder().encode(`tourly-visitor:${token}`);
  const digest = await crypto.subtle.digest("SHA-256", data);
  const bytes = new Uint8Array(digest.slice(0, 8));
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

export async function loadDay(store: Store, tourId: string, dateKey: string): Promise<TourDayStats | null> {
  const raw = await store.get(statsKey(tourId, dateKey), { type: "json" });
  if (!raw || typeof raw !== "object") return null;
  const day = raw as Partial<TourDayStats>;
  if (typeof day.date !== "string") return null;
  return {
    date: day.date,
    events: day.events && typeof day.events === "object" ? day.events : {},
    sources: day.sources && typeof day.sources === "object" ? day.sources : {},
    scenes: day.scenes && typeof day.scenes === "object" ? day.scenes : {},
    uniques: Array.isArray(day.uniques) ? day.uniques.filter((u) => typeof u === "string") : [],
    uniquesCapped: Boolean(day.uniquesCapped),
    updatedAt: typeof day.updatedAt === "number" ? day.updatedAt : 0,
  };
}

/** Records one event by loading the tour's day document, merging, and
 *  saving. Best-effort by design — callers decide whether a failure is
 *  worth surfacing (track-event answers 500; capture-lead swallows it so
 *  an analytics hiccup can never lose a lead). */
export async function recordTourEvent(
  store: Store,
  tourId: string,
  ev: AnalyticsEvent,
  at: number = Date.now()
): Promise<void> {
  const dateKey = utcDateKey(at);
  const day = (await loadDay(store, tourId, dateKey)) ?? emptyDay(dateKey);
  mergeEventIntoDay(day, ev);
  await store.setJSON(statsKey(tourId, dateKey), day);
}

/** All UTC date keys in [start, end] inclusive. */
export function dateKeyRange(startDate: string, endDate: string): string[] {
  const out: string[] = [];
  const start = new Date(`${startDate}T00:00:00Z`).getTime();
  const end = new Date(`${endDate}T00:00:00Z`).getTime();
  if (!Number.isFinite(start) || !Number.isFinite(end) || start > end) return out;
  for (let t = start; t <= end; t += 24 * 60 * 60 * 1000) {
    out.push(new Date(t).toISOString().slice(0, 10));
  }
  return out.length <= ANALYTICS_RETENTION_DAYS ? out : out.slice(-ANALYTICS_RETENTION_DAYS);
}
