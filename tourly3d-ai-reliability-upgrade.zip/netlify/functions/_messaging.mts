/**
 * Shared messaging pipeline (Feature H) for the WhatsApp and Telegram
 * webhooks. One honest, idempotent pipeline behind two provider adapters:
 *
 *   1. dedupe by provider message id (providers retry — we must not create
 *      duplicate stops for the same message)
 *   2. resolve the sender to a Tourly account via a link code the creator
 *      generates in the dashboard (no account can be touched without it)
 *   3. fetch + validate the incoming media (type allowlist, size cap)
 *   4. append a stop to the sender's linked tour (created on first media)
 *   5. best-effort Gemini room-labelling — never blocks the tour
 *   6. store + publish (same store, same ownership records as /api/publish-tour)
 *   7. reply with the public tour URL through the provider
 *
 * No fake success: if any step fails, the sender gets a truthful error
 * message and the status record reflects the failure. Credentials are never
 * logged; provider errors are logged message-id + status code only.
 */

import { getStore, Store } from "@netlify/blobs";
import {
  extractJson,
  TOURS_STORE_NAME,
  TOUR_OWNER_PREFIX,
} from "./_shared.mts";
import { callGemini, getGeminiApiKey } from "./_gemini.mts";

export const LINKS_STORE = "waypoint-messaging-links";
export const CODES_STORE = "waypoint-messaging-codes";
export const STATUS_STORE = "waypoint-messaging-status";
export const DEDUPE_STORE = "waypoint-messaging-dedupe";

export type Provider = "whatsapp" | "telegram";

export type MessagingLink = {
  uid: string;
  provider: Provider;
  providerUserId: string;
  displayName?: string;
  defaultTourId?: string;
  linkedAt: number;
};

// Tour JSON must stay under the same limit the editor's publish path uses
// (Netlify function body caps) — enforced BEFORE the append, not after.
const MAX_TOUR_JSON_BYTES = 5_000_000;
export const MAX_MEDIA_BYTES = 15 * 1024 * 1024;

const ALLOWED_MEDIA: Record<string, "image" | "video"> = {
  "image/jpeg": "image",
  "image/png": "image",
  "image/webp": "image",
  "video/mp4": "video",
  "video/webm": "video",
  "video/quicktime": "video",
};

const CODE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"; // no I/L/O/0/1 — readable aloud

export function generateLinkCode(): string {
  const bytes = new Uint8Array(6);
  crypto.getRandomValues(bytes);
  return Array.from(bytes).map((b) => CODE_ALPHABET[b % CODE_ALPHABET.length]).join("");
}

export function linkKey(provider: Provider, providerUserId: string): string {
  return `${provider}:${providerUserId}`;
}

export async function getLink(provider: Provider, providerUserId: string): Promise<MessagingLink | null> {
  const store = getStore({ name: LINKS_STORE });
  return ((await store.get(linkKey(provider, providerUserId), { type: "json" })) as MessagingLink | null) ?? null;
}

export async function saveLink(link: MessagingLink): Promise<void> {
  const store = getStore({ name: LINKS_STORE });
  await store.setJSON(linkKey(link.provider, link.providerUserId), link);
}

/** Dashboard-side: create a short-lived code bound to the signed-in uid. */
export async function createLinkCode(uid: string): Promise<{ code: string; expiresAt: number }> {
  const store = getStore({ name: CODES_STORE });
  const code = generateLinkCode();
  const expiresAt = Date.now() + 24 * 60 * 60 * 1000;
  await store.setJSON(code, { uid, createdAt: Date.now() }, { metadata: { expiresIn: 86400 } });
  return { code, expiresAt };
}

/** Bot-side: consume a code. Codes are single-use and expire in 24 h. */
export async function consumeLinkCode(
  code: string
): Promise<{ uid: string } | null> {
  const store = getStore({ name: CODES_STORE });
  const normalized = code.trim().toUpperCase();
  if (!/^[A-Z0-9]{4,10}$/.test(normalized)) return null;
  const entry = (await store.get(normalized, { type: "json" })) as { uid?: string; createdAt?: number } | null;
  if (!entry?.uid) return null;
  await store.delete(normalized); // single use
  if (typeof entry.createdAt === "number" && Date.now() - entry.createdAt > 24 * 60 * 60 * 1000) return null;
  return { uid: entry.uid };
}

export type MessageStatus = {
  provider: Provider;
  messageId: string;
  state: "processing" | "done" | "error";
  tourId?: string;
  publicUrl?: string;
  error?: string;
  at: number;
};

export async function setStatus(status: MessageStatus): Promise<void> {
  const store = getStore({ name: STATUS_STORE });
  await store.setJSON(`${status.provider}:${status.messageId}`, status, {
    metadata: { expiresIn: 7 * 86400 },
  });
}

export async function getStatus(provider: Provider, messageId: string): Promise<MessageStatus | null> {
  const store = getStore({ name: STATUS_STORE });
  return ((await store.get(`${provider}:${messageId}`, { type: "json" })) as MessageStatus | null) ?? null;
}

/** Duplicate-message protection. Returns true when this message id was
 *  already seen (caller should return 200 immediately — the work is either
 *  done or in flight from the first delivery attempt). */
export async function alreadyProcessed(provider: Provider, messageId: string): Promise<boolean> {
  const store = getStore({ name: DEDUPE_STORE });
  const key = `${provider}:${messageId}`;
  if (await store.get(key)) return true;
  await store.set(key, "1", { metadata: { expiresIn: 7 * 86400 } });
  return false;
}

// --- Gemini room labelling (best-effort, never blocks the pipeline) --------

async function analyzeImageForTitle(
  base64: string,
  mimeType: string
): Promise<{ roomLabel: string; description: string } | null> {
  const apiKey = getGeminiApiKey();
  if (!apiKey) return null;
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 20_000);
    const { response } = await callGemini(
      "text",
      {
        contents: [
          {
            parts: [
              {
                text:
                  'This photo was just sent by a property agent to build a walkthrough. What room is it? Reply ONLY as JSON: {"roomLabel": string, "description": string} — description is one short factual sentence, no invented details.',
              },
              { inline_data: { mime_type: mimeType, data: base64 } },
            ],
          },
        ],
        generationConfig: { responseMimeType: "application/json" },
      },
      { signal: controller.signal, functionName: "messaging-label" }
    ).finally(() => clearTimeout(timeout));
    const data = await response.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
    const parsed = extractJson<{ roomLabel?: string; description?: string }>(text);
    if (!parsed?.roomLabel) return null;
    return { roomLabel: parsed.roomLabel.slice(0, 80), description: (parsed.description ?? "").slice(0, 300) };
  } catch {
    return null; // AI is a bonus here, never a dependency
  }
}

// --- the pipeline -----------------------------------------------------------

export type MediaFetchResult =
  | { ok: true; bytes: ArrayBuffer; mimeType: string }
  | { ok: false; error: string };

export type InboundMedia = {
  provider: Provider;
  providerUserId: string;
  displayName?: string;
  messageId: string;
  mimeType: string;
  /** Provider-specific media handle (WhatsApp media id / Telegram file_id). */
  mediaId: string;
  /** Fetches the actual bytes through the provider's authenticated API. */
  fetchMedia: () => Promise<MediaFetchResult>;
};

export type PipelineResult = { ok: boolean; reply: string };

function toursStore(): Store {
  return getStore({ name: TOURS_STORE_NAME });
}

type WebhookTour = {
  id: string;
  name: string;
  subtitle: string;
  createdAt: number;
  updatedAt: number;
  stops: {
    id: string;
    title: string;
    note: string;
    media: { kind: string; dataUrl: string } | null;
    hotspots: { id: string; targetStopId: string; label: string; yaw: number; pitch: number }[];
  }[];
};

export async function appendMediaToLinkedTour(
  media: InboundMedia,
  publicBase: string
): Promise<PipelineResult> {
  const link = await getLink(media.provider, media.providerUserId);
  if (!link) {
    return {
      ok: false,
      reply:
        "This number isn't linked to a Tourly account yet. Open Tourly → Dashboard → Messaging, generate a connect code, and send me: start YOURCODE",
    };
  }

  const kind = ALLOWED_MEDIA[media.mimeType];
  if (!kind) {
    return { ok: false, reply: `I can't add ${media.mimeType || "that file type"} yet — send a JPEG, PNG, WebP photo or an MP4/WebM video.` };
  }

  const fetched = await media.fetchMedia();
  if (!fetched.ok) {
    return { ok: false, reply: `Couldn't download that media (${fetched.error}). Please try sending it again.` };
  }
  if (fetched.bytes.byteLength > MAX_MEDIA_BYTES) {
    return { ok: false, reply: "That file is over 15 MB — too large to add through chat. Add it in the Tourly editor instead." };
  }

  const store = toursStore();

  // Find or create the sender's messaging tour. First media message creates
  // it; ownership is recorded exactly like a normal publish, so the creator
  // can later publish over it from the editor using the same account.
  let tour: WebhookTour | null = link.defaultTourId
    ? ((await store.get(link.defaultTourId, { type: "json" })) as WebhookTour | null)
    : null;
  let createdNewTour = false;
  if (!tour) {
    tour = {
      id: crypto.randomUUID(),
      name: `Messaging tour — ${new Date().toISOString().slice(0, 10)}`,
      subtitle: "Created via chat",
      createdAt: Date.now(),
      updatedAt: Date.now(),
      stops: [],
    };
    createdNewTour = true;
  }

  const base64 = arrayBufferToBase64(fetched.bytes);
  const dataUrl = `data:${fetched.mimeType};base64,${base64}`;

  const stopId = crypto.randomUUID();
  let title = kind === "video" ? "Video scene" : "Photo scene";
  let note = "";
  if (kind === "image") {
    const analysis = await analyzeImageForTitle(base64, fetched.mimeType);
    if (analysis) {
      title = analysis.roomLabel;
      note = analysis.description;
    }
  }

  const nextTour: WebhookTour = {
    ...tour,
    updatedAt: Date.now(),
    stops: [
      ...tour.stops,
      {
        id: stopId,
        title,
        note,
        media: { kind, dataUrl },
        hotspots: [],
      },
    ],
  };

  const jsonSize = JSON.stringify(nextTour).length;
  if (jsonSize > MAX_TOUR_JSON_BYTES) {
    return {
      ok: false,
      reply: "This tour is full (about 5 MB of embedded media) — send me \"new\" to start a fresh tour, then keep sending photos.",
    };
  }

  await store.setJSON(nextTour.id, nextTour);
  if (createdNewTour || link.defaultTourId !== nextTour.id) {
    await store.setJSON(TOUR_OWNER_PREFIX + nextTour.id, { uid: link.uid });
    const updatedLink: MessagingLink = { ...link, defaultTourId: nextTour.id };
    await saveLink(updatedLink);
  }

  const publicUrl = `${publicBase}/tour/${nextTour.id}`;
  return {
    ok: true,
    reply: createdNewTour
      ? `New tour created ✅ Added "${title}" as scene 1. Keep sending photos to add more. View: ${publicUrl}`
      : `Added "${title}" as scene ${nextTour.stops.length}. View: ${publicUrl}`,
  };
}

export async function handleCommandText(
  provider: Provider,
  providerUserId: string,
  displayName: string | undefined,
  text: string,
  publicBase: string
): Promise<PipelineResult> {
  const trimmed = text.trim();
  const lower = trimmed.toLowerCase();

  if (lower.startsWith("start")) {
    const code = trimmed.split(/\s+/)[1] ?? "";
    const consumed = await consumeLinkCode(code);
    if (!consumed) {
      return { ok: false, reply: "That code isn't valid (or has expired). Generate a fresh one in Tourly → Dashboard → Messaging." };
    }
    await saveLink({
      uid: consumed.uid,
      provider,
      providerUserId,
      displayName,
      linkedAt: Date.now(),
    });
    return { ok: true, reply: "Linked ✅ Now send photos or videos — I'll build a walkthrough from them. Send \"new\" anytime to start a fresh tour." };
  }

  const link = await getLink(provider, providerUserId);
  if (!link) {
    return { ok: false, reply: 'Send "start YOURCODE" first — get a code from Tourly → Dashboard → Messaging.' };
  }

  if (lower === "new") {
    const updated: MessagingLink = { ...link, defaultTourId: undefined };
    await saveLink(updated);
    return { ok: true, reply: "OK — your next photo starts a brand-new tour." };
  }

  if (lower === "publish" || lower === "link") {
    if (!link.defaultTourId) return { ok: false, reply: "No tour yet — send a photo first." };
    const publicUrl = `${publicBase}/tour/${link.defaultTourId}`;
    return { ok: true, reply: `Your tour: ${publicUrl}` };
  }

  if (lower === "help" || lower === "hi" || lower === "hello") {
    return {
      ok: true,
      reply:
        'I build walkthroughs from your media. Commands: "start CODE" links your account · send photos/videos to add scenes · "new" starts a fresh tour · "link" resends your tour URL.',
    };
  }

  return { ok: true, reply: 'Send a photo or video to add it to your tour, or "help" for commands.' };
}

export function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = "";
  const CHUNK = 0x8000; // 32k chars per push — avoids arg-count blowups
  for (let i = 0; i < bytes.length; i += CHUNK) {
    binary += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
  }
  return btoa(binary);
}

export function siteBaseUrl(req: Request): string {
  const fromEnv = process.env.URL || process.env.VITE_SITE_URL;
  if (fromEnv) return fromEnv.replace(/\/$/, "");
  try {
    return new URL(req.url).origin;
  } catch {
    return "";
  }
}
