import type { Config } from "@netlify/functions";
import { jsonResponse, enforceAiRateLimit } from "./_shared.mts";
import { callGemini, GeminiError, getGeminiApiKey } from "./_gemini.mts";
import { enforceAiQuota } from "./_aiusage.mts";

/**
 * Generates a full 2:1 equirectangular panorama from a single regular
 * photo, by asking Gemini to imagine/extend the room around what's
 * actually visible. This is NOT a real capture — most of the resulting
 * image is invented, not photographed. Callers must keep some honest
 * marker on this content (StopMedia.synthetic) rather than presenting
 * it as a real scan.
 *
 * Kept intentionally cheap: input is downscaled client-side before this
 * runs, and this function is called through a client-side usage cap
 * (see src/lib/generatePanorama.ts) to bound Gemini spend.
 */
export default async (req: Request) => {
  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  const limited = await enforceAiRateLimit(req, "generate-panorama", 5);
  if (limited) return limited;

  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    return jsonResponse(503, { error: "Generation not configured" });
  }
  // Expensive IMAGE-GENERATION call: a per-user daily quota
  // (AI_DAILY_QUOTA_{FEATURE}, default 10) enforced in FAIL-CLOSED mode —
  // if the usage limiter can't be reached, the request is refused rather
  // than risking uncapped image-generation usage during a store outage.
  const quotaResponse = await enforceAiQuota(req, "generate-panorama", { failMode: "closed" });
  if (quotaResponse) return quotaResponse;


  let body: { imageBase64?: string; mimeType?: string };
  try {
    body = await req.json();
  } catch {
    return jsonResponse(400, { error: "Invalid JSON body" });
  }

  const { imageBase64, mimeType } = body;
  if (!imageBase64 || !mimeType) {
    return jsonResponse(400, { error: "imageBase64 and mimeType are required" });
  }
  // Keep JSON payloads below typical serverless request limits and reject
  // non-image MIME types before forwarding user input to the paid AI API.
  if (!/^image\/(jpeg|png|webp)$/.test(mimeType)) {
    return jsonResponse(415, { error: "Use a JPEG, PNG, or WebP image." });
  }
  if (imageBase64.length > 4_500_000 || !/^[A-Za-z0-9+/]*={0,2}$/.test(imageBase64)) {
    return jsonResponse(413, { error: "Image is too large or has an invalid encoding. Try a smaller image." });
  }

  const prompt = [
    "This photo shows part of a room. Generate a full 360-degree equirectangular panorama",
    "(exactly 2:1 width-to-height, e.g. 1920x960) that plausibly extends this room in every direction —",
    "keep the visible furniture, colors, lighting, and style consistent with the original photo,",
    "and continue the walls, floor, and ceiling naturally around the rest of the space.",
    "Match the visual style of a professional real-estate panorama photo: bright even interior",
    "lighting, natural perspective distortion typical of equirectangular projection (the floor and",
    "ceiling curve smoothly near the top and bottom of the frame), sharp furniture and clean lines,",
    "no fisheye or double-exposure artifacts. The left and right edges of the output must match up",
    "seamlessly, since the image wraps around when viewed as a sphere.",
    "Return only the generated equirectangular panorama image.",
  ].join(" ");

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 50_000);

  try {
    const { response } = await callGemini(
      "image",
      {
        contents: [
          {
            parts: [
              { text: prompt },
              { inline_data: { mime_type: mimeType, data: imageBase64 } },
            ],
          },
        ],
        generationConfig: {
          responseModalities: ["IMAGE"],
        },
      },
      { signal: controller.signal, functionName: "generate-panorama" }
    );

    const data = await response.json();
    const parts = data?.candidates?.[0]?.content?.parts ?? [];
    const imagePart = parts.find((p: any) => p.inlineData || p.inline_data);
    const inline = imagePart?.inlineData ?? imagePart?.inline_data;

    if (!inline?.data) {
      return jsonResponse(502, { error: "No image returned by Gemini" });
    }

    return jsonResponse(200, {
      imageBase64: inline.data,
      mimeType: inline.mimeType ?? inline.mime_type ?? "image/jpeg",
    });
  } catch (err: any) {
    if (err instanceof GeminiError) {
      return jsonResponse(err.httpStatus, { error: err.safeMessage, retryable: err.retryable });
    }
    if (err?.name === "AbortError") {
      return jsonResponse(504, { error: "Generation timed out" });
    }
    return jsonResponse(500, { error: "Generation failed" });
  } finally {
    clearTimeout(timeout);
  }
};

export const config: Config = {
  path: "/api/generate-panorama",
};
