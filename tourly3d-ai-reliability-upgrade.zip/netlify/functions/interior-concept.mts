import type { Config } from "@netlify/functions";
import {
  jsonResponse,
  enforceAiRateLimit,
  firebaseAdminConfigured,
} from "./_shared.mts";
import { callGemini, GeminiError, getGeminiApiKey } from "./_gemini.mts";
import { enforceAiQuota, resolveAiCaller, type AiScope } from "./_aiusage.mts";

/**
 * Stage D (Phase 6 of the AI upgrade) — OPTIONAL AI interior concept.
 *
 * Takes one ordinary room photo and a style from a small whitelist, and asks
 * the configured Gemini IMAGE model for an illustrative restyle of that
 * room. The result is ALWAYS labelled as an AI interior concept — it is a
 * visual idea of what the room COULD look like, never a representation of
 * the property's actual condition.
 *
 * Honest states: unconfigured key/admin → clear 503 "not configured"
 * (never a fake image); unsupported style → 415; quota → 429. This feature
 * is completely separate from the concept floor-plan geometry.
 */

const STYLES = ["modern", "minimal", "contemporary"] as const;
export type InteriorStyle = (typeof STYLES)[number];

const STYLE_PROMPTS: Record<InteriorStyle, string> = {
  modern: "a modern interior style — clean lines, warm neutral palette, contemporary furniture",
  minimal: "a minimal interior style — uncluttered, light tones, simple functional furniture",
  contemporary: "a contemporary interior style — current design trends, layered lighting, tasteful accents",
};

export default async (req: Request) => {
  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  const limited = await enforceAiRateLimit(req, "interior-concept", 10);
  if (limited) return limited;

  if (!firebaseAdminConfigured()) {
    return jsonResponse(503, {
      error: "Interior concepts aren't available on this deployment (FIREBASE_SERVICE_ACCOUNT_KEY missing — see AUTH-SETUP.md §4).",
    });
  }
  const caller = await resolveAiCaller(req);
  if (caller.status === "invalid-token") {
    return jsonResponse(401, { error: "Your session has expired — sign in again." });
  }
  if (!caller.user) {
    return jsonResponse(401, { error: "Sign in to use AI interior concepts." });
  }
  const scope: AiScope = caller.scope;

  if (!getGeminiApiKey()) {
    return jsonResponse(503, {
      error: "AI interior concepts aren't configured on this deployment (GEMINI_API_KEY missing).",
    });
  }

  let body: { imageBase64?: string; mimeType?: string; style?: string };
  try {
    body = await req.json();
  } catch {
    return jsonResponse(400, { error: "Invalid JSON body" });
  }

  const { imageBase64, mimeType } = body;
  const style = STYLES.includes(body.style as InteriorStyle) ? (body.style as InteriorStyle) : null;
  if (!imageBase64 || !mimeType) {
    return jsonResponse(400, { error: "imageBase64 and mimeType are required" });
  }
  if (!style) {
    return jsonResponse(415, { error: `Style must be one of: ${STYLES.join(", ")}.` });
  }
  if (!/^image\/(jpeg|png|webp)$/.test(mimeType)) {
    return jsonResponse(415, { error: "Use a JPEG, PNG or WebP photo." });
  }
  if (imageBase64.length > 4_000_000 || !/^[A-Za-z0-9+/]*={0,2}$/.test(imageBase64)) {
    return jsonResponse(413, { error: "Photo is too large or has an invalid encoding. Try a smaller image." });
  }

  const quotaResponse = await enforceAiQuota(req, "interior-concept", { requireAuth: false });
  if (quotaResponse) return quotaResponse;

  const prompt = [
    "Restyle this room photo as an interior design CONCEPT in",
    STYLE_PROMPTS[style] + ".",
    "Keep the room's actual layout, walls, windows and overall camera angle recognizable — this is a restyle of THIS room, not a new room.",
    "Return only the restyled image.",
  ].join(" ");

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 35_000);

  try {
    const { response } = await callGemini(
      "image",
      {
        contents: [
          {
            parts: [
              { text: prompt },
              { inline_data: { mime_type: mimeType, data: imageBase64 } },
            ],
          },
        ],
        generationConfig: { responseModalities: ["IMAGE"] },
      },
      { signal: controller.signal, functionName: "interior-concept", usage: { scope, feature: "interior-concept" } }
    );

    const data = await response.json();
    const parts = data?.candidates?.[0]?.content?.parts ?? [];
    const imagePart = parts.find((p: any) => p.inlineData || p.inline_data);
    const inline = imagePart?.inlineData ?? imagePart?.inline_data;

    if (!inline?.data) {
      return jsonResponse(502, { error: "No image returned by the AI — try again or use a different photo." });
    }

    return jsonResponse(200, {
      imageBase64: inline.data,
      mimeType: inline.mimeType ?? inline.mime_type ?? "image/jpeg",
      style,
      note: "AI interior concept — illustrative only. This is NOT a photo of the actual property condition.",
    });
  } catch (err: any) {
    if (err instanceof GeminiError) {
      return jsonResponse(err.httpStatus, { error: err.safeMessage, retryable: err.retryable });
    }
    if (err?.name === "AbortError") {
      return jsonResponse(504, { error: "Interior concept generation timed out" });
    }
    return jsonResponse(500, { error: "Interior concept generation failed" });
  } finally {
    clearTimeout(timeout);
  }
};

export const config: Config = {
  path: "/api/interior-concept",
};
