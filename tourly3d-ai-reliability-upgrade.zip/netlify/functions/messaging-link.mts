import type { Config } from "@netlify/functions";
import { jsonResponse, verifyAuthToken, firebaseAdminConfigured, AdminSetupError, TokenProjectMismatchError } from "./_shared.mts";
import { createLinkCode, LINKS_STORE } from "./_messaging.mts";

/**
 * Dashboard-side messaging API (Feature H).
 *
 * POST { action: "create-code" }  → generates a fresh single-use link code
 *   (24 h expiry) that the creator sends to the WhatsApp/Telegram bot as
 *   "start CODE" to link their chat to this account. Requires a verified
 *   Firebase ID token — codes are what grant a chat access to create
 *   tours under someone's account, so they're only ever issued to the
 *   authenticated account owner.
 *
 * GET → { whatsappConfigured, telegramConfigured } so the dashboard can
 *   honestly show which providers are live on this deployment instead of
 *   implying both work when only one (or neither) has credentials.
 */
function providerConfigured(name: string): boolean {
  const v = process.env[name];
  return Boolean(v && v.trim());
}

export default async (req: Request) => {
  if (req.method === "GET") {
    return jsonResponse(200, {
      whatsappConfigured: providerConfigured("WHATSAPP_TOKEN") && providerConfigured("WHATSAPP_APP_SECRET") && providerConfigured("WHATSAPP_PHONE_NUMBER_ID"),
      telegramConfigured: providerConfigured("TELEGRAM_BOT_TOKEN") && providerConfigured("TELEGRAM_WEBHOOK_SECRET"),
    });
  }

  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }
  if (!firebaseAdminConfigured()) {
    return jsonResponse(503, {
      error: "Messaging needs server-side auth verification — set FIREBASE_SERVICE_ACCOUNT_KEY in Netlify environment variables (see AUTH-SETUP.md §4).",
    });
  }

  let caller: Awaited<ReturnType<typeof verifyAuthToken>>;
  try {
    caller = await verifyAuthToken(req);
  } catch (err) {
    if (err instanceof AdminSetupError) {
      console.error("[messaging-link] admin setup error:", err.message);
      return jsonResponse(503, { error: err.message });
    }
    if (err instanceof TokenProjectMismatchError) {
      return jsonResponse(401, {
        error: `Client/server Firebase project mismatch ("${err.tokenAudience}" vs "${err.serverProjectId}") — see AUTH-SETUP.md §5.`,
      });
    }
    console.warn("[messaging-link] auth rejected:",
      (err as any)?.errorInfo?.code ?? (err as any)?.code ?? "unknown-error");
    return jsonResponse(401, { error: "Your session has expired — sign in again and retry." });
  }
  if (!caller) {
    return jsonResponse(401, { error: "Sign in to manage messaging." });
  }

  let body: { action?: string };
  try {
    body = await req.json();
  } catch {
    return jsonResponse(400, { error: "Invalid JSON body" });
  }

  if (body.action !== "create-code") {
    return jsonResponse(400, { error: "Unknown action" });
  }

  try {
    const { code, expiresAt } = await createLinkCode(caller.uid);
    // Count this user's existing links so the dashboard can hint at what's
    // connected (best-effort; listing is bounded by prefix scan).
    let linkedChats = 0;
    try {
      const { getStore } = await import("@netlify/blobs");
      const store = getStore({ name: LINKS_STORE });
      const all = await store.list();
      for (const key of all.blobs ?? []) {
        const link = (await store.get(key.key, { type: "json" })) as { uid?: string } | null;
        if (link?.uid === caller.uid) linkedChats++;
      }
    } catch {
      /* cosmetic only */
    }
    return jsonResponse(200, { code, expiresAt, linkedChats });
  } catch (err) {
    return jsonResponse(500, { error: "Could not create a link code", detail: String(err).slice(0, 200) });
  }
};

export const config: Config = {
  path: "/api/messaging-link",
};
