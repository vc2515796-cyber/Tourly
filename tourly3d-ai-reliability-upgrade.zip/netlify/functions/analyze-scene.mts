import type { Config } from "@netlify/functions";
import { jsonResponse, extractJson, enforceAiRateLimit } from "./_shared.mts";
import { callGemini, GeminiError, getGeminiApiKey, resolveModels } from "./_gemini.mts";
import { cachedAiCall } from "./_aiusage.mts";

/** Bump when the prompt or validation below changes (cache identity). */
const SCHEMA_VERSION = "1";

/**
 * Spatial analysis v2 (Feature B). Looks at a stop's photo and returns:
 *  - a room label (Living Room, Bedroom, Kitchen, Bathroom, Balcony, Office,
 *    Construction Site, …)
 *  - a short description grounded ONLY in visible evidence
 *  - a self-reported confidence (0..1) shown as a review hint — NOT a fact
 *  - a construction-stage label ONLY when the photo visibly shows an active
 *    construction site (never invented for finished rooms)
 *
 * This is a SUGGESTION only — the editor always shows it as an editable
 * fill-in, never auto-publishes it, so the creator can correct or reject
 * anything the model gets wrong (see README's approval-before-publish rule
 * for every AI suggestion in this app).
 */
export default async (req: Request) => {
  if (req.method !== "POST") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  const limited = await enforceAiRateLimit(req, "analyze-scene", 15);
  if (limited) return limited;

  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    return jsonResponse(503, { error: "Scene analysis not configured" });
  }

  let body: { imageBase64?: string; mimeType?: string; otherRoomTitles?: string[] };
  try {
    body = await req.json();
  } catch {
    return jsonResponse(400, { error: "Invalid JSON body" });
  }

  const { imageBase64, mimeType, otherRoomTitles = [] } = body;
  if (!imageBase64 || !mimeType) {
    return jsonResponse(400, { error: "imageBase64 and mimeType are required" });
  }
  // Size guard: the client downsizes to ~1024px before sending; anything
  // much larger than that is a broken/malicious caller, not our UI.
  if (imageBase64.length > 4_000_000) {
    return jsonResponse(413, { error: "Image payload too large for analysis" });
  }
  const titles = Array.isArray(otherRoomTitles)
    ? otherRoomTitles.filter((t) => typeof t === "string").slice(0, 60).map((t) => t.slice(0, 80))
    : [];

  // Cache + per-user daily quota + coalescing (identical concurrent
  // analyses share one AI call). Cached hits never consume quota.
  try {
    const outcome = await cachedAiCall<Record<string, unknown>>(
      req,
      "analyze-scene",
      {
        schemaVersion: SCHEMA_VERSION,
        model: resolveModels("text")[0]!,
        cacheContent: JSON.stringify({ imageBase64, mimeType, titles }),
        quota: {}, // fail-open (matches the app-wide default posture)
      },
      () => analyzeViaAi(imageBase64, mimeType!, titles)
    );
    if (!outcome.ok) return outcome.response;
    return jsonResponse(200, { ...outcome.result, cached: outcome.cached });
  } catch (err: any) {
    if (err instanceof EndpointError) {
      return jsonResponse(err.status, err.payload);
    }
    if (err instanceof GeminiError) {
      return jsonResponse(err.httpStatus, { error: err.safeMessage, retryable: err.retryable });
    }
    if (err?.name === "AbortError") {
      return jsonResponse(504, { error: "Analysis timed out" });
    }
    return jsonResponse(500, { error: "Analysis failed" });
  }
};

/** A failure the endpoint should answer with a specific status/body.
 *  Thrown by analyzeViaAi so the cache layer never stores failures. */
class EndpointError extends Error {
  constructor(public status: number, public payload: Record<string, unknown>) {
    super(String(payload.error ?? status));
    this.name = "EndpointError";
  }
}

/** The actual AI call + validation, run only on a cache miss. Throws on any
 *  failure (never cached as success); returns the VALIDATED result. */
async function analyzeViaAi(
  imageBase64: string,
  mimeType: string,
  titles: string[]
): Promise<Record<string, unknown>> {
  const prompt = [
    "You are looking at one photo from a real-estate, venue, or construction-site walkthrough.",
    titles.length
      ? `Other rooms already in this tour: ${titles.join(", ")}.`
      : "",
    "Identify what kind of room or space this most likely is (e.g. Living Room, Bedroom,",
    "Kitchen, Bathroom, Balcony, Office, Reception, Hallway, Conference Room, Construction Site, or similar).",
    "Then write one short, factual sentence describing only what is visibly in the photo",
    "(lighting, layout, notable visible features). Do not invent square footage, price,",
    "amenities, or anything not visible in the image.",
    "If AND ONLY IF the photo clearly shows an active construction or renovation site (exposed",
    "brick/blockwork, scaffolding, formwork, unfinished concrete, debris, workers' materials),",
    'also set "constructionStage" to a short stage label you can justify from what is visible',
    "(e.g. \"Structural blockwork\", \"Plaster stage\", \"Finishing\"). Otherwise set it to an empty string.",
    "Rate your confidence in the room label from 0 to 1 — be honest, lower it for ambiguous or",
    "unusual spaces.",
    'Respond with ONLY this JSON object, no other text: {"roomLabel": string, "description": string, "confidence": number, "constructionStage": string}',
  ]
    .filter(Boolean)
    .join(" ");

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30_000);

  try {
    const { response } = await callGemini(
      "text",
      {
        contents: [
          {
            parts: [
              { text: prompt },
              { inline_data: { mime_type: mimeType, data: imageBase64 } },
            ],
          },
        ],
        generationConfig: { responseMimeType: "application/json" },
      },
      { signal: controller.signal, functionName: "analyze-scene" }
    );

    const data = await response.json();

    if (!data?.candidates?.length) {
      const blockReason = data?.promptFeedback?.blockReason;
      throw new EndpointError(502, {
        error: blockReason
          ? `Gemini declined to analyze this photo (${blockReason}).`
          : "Gemini returned no result for this photo.",
      });
    }

    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
    const parsed = extractJson<{
      roomLabel?: string;
      description?: string;
      confidence?: number;
      constructionStage?: string;
    }>(text);

    if (!parsed?.roomLabel || typeof parsed.roomLabel !== "string") {
      throw new EndpointError(502, {
        error: "Could not parse a room label from Gemini's response.",
        detail: text.slice(0, 300),
      });
    }

    // Server-side validation + clamping so a weird model reply can't push
    // junk into the editor state.
    const confidence =
      typeof parsed.confidence === "number" && Number.isFinite(parsed.confidence)
        ? Math.max(0, Math.min(1, parsed.confidence))
        : 0.5;
    const constructionStage =
      typeof parsed.constructionStage === "string" ? parsed.constructionStage.trim().slice(0, 60) : "";

    return {
      roomLabel: parsed.roomLabel.slice(0, 80),
      description: (parsed.description ?? "").slice(0, 400),
      confidence,
      constructionStage: constructionStage || undefined,
    };
  } finally {
    clearTimeout(timeout);
  }
}

export const config: Config = {
  path: "/api/analyze-scene",
};
