import type { Context } from "@netlify/edge-functions";
import { getStore } from "@netlify/blobs";

const TOURS_STORE_NAME = "waypoint-tours";
const TOUR_META_PREFIX = "meta:";
const TOUR_PREVIEW_PREFIX = "preview:";

function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
}

/**
 * Rewrites the Open Graph/Twitter meta tags in index.html for a specific
 * /tour/:id request, BEFORE the SPA's JS ever runs. Link-preview crawlers
 * (WhatsApp, iMessage, Slack, Twitter/X, Facebook) fetch the HTML and read
 * these tags directly — they don't execute client-side usePageMeta().
 * A real person's browser gets the exact same rewritten HTML and then the
 * SPA boots normally on top of it.
 */
export default async (request: Request, context: Context) => {
  const response = await context.next();

  const url = new URL(request.url);
  const match = url.pathname.match(/^\/tour\/([^/]+)\/?$/);
  if (!match) return response;
  const id = match[1];
  if (id.startsWith(TOUR_META_PREFIX) || id.startsWith(TOUR_PREVIEW_PREFIX)) return response;

  let title = "Walkthrough — Tourly";
  let description = "An interactive photo and 360° walkthrough, built with Tourly.";
  let image: string | null = null;

  try {
    const store = getStore({ name: TOURS_STORE_NAME });
    const tour = (await store.get(id, { type: "json" })) as { name?: string; subtitle?: string } | null;
    const isProtected = Boolean(await store.get(TOUR_META_PREFIX + id));

    if (tour?.name) {
      title = `${tour.name} — Tourly`;
      description = isProtected
        ? "This walkthrough is password protected."
        : tour.subtitle?.trim() || description;
      if (!isProtected) image = await store.get(TOUR_PREVIEW_PREFIX + id);
    }
  } catch {
    // Blobs hiccup — fall back to the generic tags already in the HTML
    // rather than failing the page load.
    return response;
  }

  const html = await response.text();
  const absoluteImage = image ?? `${url.origin}/og-default.png`;
  const rewritten = html
    .replace(/<title>.*?<\/title>/, `<title>${escapeHtml(title)}</title>`)
    .replace(/(<meta property="og:title" content=")[^"]*(")/, `$1${escapeHtml(title)}$2`)
    .replace(/(<meta name="twitter:title" content=")[^"]*(")/, `$1${escapeHtml(title)}$2`)
    .replace(/(<meta name="description" content=")[^"]*(")/, `$1${escapeHtml(description)}$2`)
    .replace(/(<meta property="og:description" content=")[^"]*(")/, `$1${escapeHtml(description)}$2`)
    .replace(/(<meta name="twitter:description" content=")[^"]*(")/, `$1${escapeHtml(description)}$2`)
    .replace(/(<meta property="og:url" content=")[^"]*(")/, `$1${url.href}$2`)
    .replace(/(<meta property="og:image" content=")[^"]*(")/, `$1${absoluteImage}$2`)
    .replace(/(<meta name="twitter:image" content=")[^"]*(")/, `$1${absoluteImage}$2`)
    .replace(/(<meta name="robots" content=")[^"]*(")/, `$1noindex, nofollow$2`)
    .replace(/(<link rel="canonical" href=")[^"]*(")/, `$1${url.href}$2`);

  return new Response(rewritten, response);
};

export const config = { path: "/tour/*" };
