import { Link } from "react-router-dom";
import LegalPage from "../components/LegalPage";

export default function Terms() {
  return (
    <LegalPage eyebrow="Legal" title="Terms & Conditions" updated="September 2026">
      <p className="rounded-md border border-brass/30 bg-brass/10 px-4 py-3 text-xs text-charcoal/70">
        Plain-language starting point, not legal advice — have a lawyer review before relying on
        this, especially the bracketed placeholders and anything specific to your country.
      </p>

      <section>
        <h2 className="font-medium text-charcoal">Who can use Tourly</h2>
        <p className="mt-2">
          You must be at least 13 years old, or the minimum age of digital consent in your
          country if that's older, and able to agree to these terms.
        </p>
      </section>

      <section>
        <h2 className="font-medium text-charcoal">Your content</h2>
        <p className="mt-2">
          You keep ownership of the photos, video, and text you upload. You're responsible for
          having the rights to anything you upload — don't upload photos, music, or other assets
          you don't own or don't have permission to use.
        </p>
      </section>

      <section>
        <h2 className="font-medium text-charcoal">AI-generated content</h2>
        <p className="mt-2">
          Some features use AI to suggest room names, descriptions, marketing copy, hotspot
          connections, or a 3D render from a floor plan. These are drafts — review them before
          relying on them. AI-generated images are always marked as such inside the app and are
          not real photographs of a property. Don't treat AI-suggested facts (room names,
          descriptions) as verified without checking them yourself.
        </p>
      </section>

      <section>
        <h2 className="font-medium text-charcoal">Pricing</h2>
        <p className="mt-2">
          Pricing shown on the site is illustrative for now — <strong>no payment or billing is
          currently processed</strong>, and no plan limits are enforced in the app yet. This
          section will be updated with a real refund/cancellation policy once paid billing goes
          live. <span className="rounded bg-charcoal/5 px-1">[replace this paragraph once billing exists]</span>.
        </p>
      </section>

      <section>
        <h2 className="font-medium text-charcoal">Availability</h2>
        <p className="mt-2">
          Tourly is provided "as is," in active development, without uptime guarantees.
          Published tours depend on our hosting provider staying available.
        </p>
      </section>

      <section>
        <h2 className="font-medium text-charcoal">Changes</h2>
        <p className="mt-2">
          We may update these terms as the product changes. Material changes will update the
          "Last updated" date above.
        </p>
      </section>

      <p className="text-xs text-charcoal/40">
        Questions: <span className="rounded bg-charcoal/5 px-1">[add your support email here]</span>.
        See also the <Link to="/privacy" className="text-brass hover:underline">Privacy Policy</Link>.
      </p>
    </LegalPage>
  );
}
