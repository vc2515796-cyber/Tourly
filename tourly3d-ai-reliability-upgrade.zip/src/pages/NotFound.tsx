import { Link } from "react-router-dom";
import { MapPin } from "lucide-react";
import { usePageMeta } from "../lib/usePageMeta";

export default function NotFound() {
  usePageMeta({ title: "Page not found — Tourly", noindex: true });

  return (
    <div className="flex min-h-full flex-col items-center justify-center gap-5 bg-bone px-6 text-center text-charcoal">
      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-brass/15">
        <MapPin className="text-brass" size={22} strokeWidth={2.5} />
      </div>
      <p className="font-mono text-xs uppercase tracking-[0.2em] text-charcoal/65">Error 404</p>
      <h1 className="font-serif text-4xl tracking-tight sm:text-5xl">This stop isn't on the map.</h1>
      <p className="max-w-sm text-sm text-charcoal/65">
        The page you're looking for doesn't exist, or the link may have been typed wrong. Head back and
        pick up the route from the start.
      </p>
      <div className="flex flex-col gap-3 sm:flex-row">
        <Link
          to="/"
          className="rounded-full bg-brass px-6 py-3 text-sm font-medium text-bone hover:opacity-90"
        >
          Back to home
        </Link>
        <Link
          to="/dashboard"
          className="rounded-full border border-charcoal/20 px-6 py-3 text-sm font-medium text-charcoal/80 hover:border-charcoal/40"
        >
          Go to my walkthroughs
        </Link>
      </div>
    </div>
  );
}
