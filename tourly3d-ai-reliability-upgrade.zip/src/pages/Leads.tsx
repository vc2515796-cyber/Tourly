import { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Loader2,
  RefreshCw,
  AlertTriangle,
  Search,
  MessageCircle,
  Send,
  Copy,
  CheckCircle2,
  Download,
  Plus,
  CalendarCheck,
  CalendarClock,
  History,
  ExternalLink,
  Mail,
  Phone,
  User,
  Sparkles,
} from "lucide-react";
import { useAuth } from "../lib/auth";
import { usePageMeta } from "../lib/usePageMeta";
import {
  listLeads,
  updateLead,
  draftFollowUp,
  LEAD_STAGES,
  STAGE_LABELS,
  type LeadSummary,
  type LeadStage,
  type LeadActivityClient,
} from "../lib/leads";
import { formatDateIN } from "../lib/format";
import { fetchLeadInsights, type LeadInsights } from "../lib/leadInsights";

/**
 * Stage B5 — the agent's lead inbox (CRM). Lists enquiries captured from
 * public tours, scoped by the signed-in agent (the server enforces this —
 * this UI just renders what the verified token is allowed to see).
 *
 * Honesty rules: AI follow-up results are always labelled DRAFTS; "sending"
 * only ever opens WhatsApp with the text pre-filled — the agent presses
 * send, and nothing here claims delivery.
 */

const STAGE_COLORS: Record<LeadStage, string> = {
  new: "bg-brass/15 text-brass",
  contacted: "bg-blue-100 text-blue-700",
  qualified: "bg-emerald-100 text-emerald-700",
  "visit-requested": "bg-violet-100 text-violet-700",
  "visit-scheduled": "bg-teal-100 text-teal-700",
  closed: "bg-charcoal/10 text-charcoal/60",
  "not-interested": "bg-red-100 text-red-600",
};

export default function Leads() {
  usePageMeta({ title: "Leads · Tourly", noindex: true });
  const { user } = useAuth();
  const navigate = useNavigate();
  const [leads, setLeads] = useState<LeadSummary[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notConfigured, setNotConfigured] = useState(false);
  const [search, setSearch] = useState("");
  const [stageFilter, setStageFilter] = useState<LeadStage | "all">("all");
  const [openLeadId, setOpenLeadId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    setNotConfigured(false);
    const result = await listLeads();
    if (result.ok) {
      setLeads(result.leads);
    } else {
      setLeads([]);
      setError(result.error);
      setNotConfigured(Boolean(result.notConfigured));
      if (result.needsAuth && !user) navigate("/login");
    }
  }, [navigate, user]);

  useEffect(() => {
    void load();
  }, [load]);

  const filtered = useMemo(() => {
    if (!leads) return [];
    const q = search.trim().toLowerCase();
    return leads.filter((l) => {
      if (stageFilter !== "all" && l.stage !== stageFilter) return false;
      if (!q) return true;
      return [l.name, l.phone, l.email, l.message, l.tourName]
        .filter(Boolean)
        .some((v) => String(v).toLowerCase().includes(q));
    });
  }, [leads, search, stageFilter]);

  const counts = useMemo(() => {
    const byStage = new Map<LeadStage, number>();
    for (const l of leads ?? []) byStage.set(l.stage, (byStage.get(l.stage) ?? 0) + 1);
    return byStage;
  }, [leads]);

  return (
    <div className="min-h-full bg-bone px-3 py-5 sm:px-6 lg:px-10">
      <div className="mx-auto max-w-5xl">
        {/* header */}
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h1 className="font-display text-xl font-semibold tracking-tight">Leads</h1>
            <p className="mt-0.5 text-xs text-charcoal/50">
              Enquiries from your published tours. Only you can see these — leads are scoped to your account.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => exportLeadsCsv(filtered)}
              disabled={filtered.length === 0}
              className="flex items-center gap-1.5 rounded-md border border-charcoal/15 px-2.5 py-1.5 text-xs font-medium text-charcoal/70 hover:border-charcoal/30 disabled:opacity-30"
              title="Download the leads currently shown (search + filter applied) as a CSV file"
            >
              <Download size={12} /> Export CSV
            </button>
            <button
              onClick={load}
              className="flex items-center gap-1.5 rounded-md border border-charcoal/15 px-2.5 py-1.5 text-xs font-medium text-charcoal/70 hover:border-charcoal/30"
            >
              <RefreshCw size={12} /> Refresh
            </button>
          </div>
        </div>

        {error && (
          <div className="mt-4 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
            <p className="flex items-center gap-1.5 font-medium">
              <AlertTriangle size={14} /> {error}
            </p>
            {notConfigured && (
              <p className="mt-1 text-xs leading-relaxed text-amber-700">
                Lead management needs server-side sign-in verification. Set FIREBASE_SERVICE_ACCOUNT_KEY on the
                deployment (see AUTH-SETUP.md §4) — publishing uses the same setup.
              </p>
            )}
          </div>
        )}

        {leads === null ? (
          <div className="flex items-center justify-center py-16 text-charcoal/40">
            <Loader2 className="animate-spin" size={20} />
          </div>
        ) : (
          <>
            {/* filters */}
            <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:items-center">
              <div className="relative flex-1">
                <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-charcoal/35" />
                <input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search name, phone, email, message…"
                  className="w-full rounded-md border border-charcoal/15 bg-white py-2 pl-8 pr-3 text-sm outline-none focus:border-brass"
                />
              </div>
              <div className="flex flex-wrap gap-1">
                <FilterChip label={`All (${leads.length})`} active={stageFilter === "all"} onClick={() => setStageFilter("all")} />
                {LEAD_STAGES.filter((s) => counts.get(s)).map((s) => (
                  <FilterChip
                    key={s}
                    label={`${STAGE_LABELS[s]} (${counts.get(s)})`}
                    active={stageFilter === s}
                    onClick={() => setStageFilter(s)}
                  />
                ))}
              </div>
            </div>

            {filtered.length === 0 ? (
              <div className="mt-8 rounded-lg border border-dashed border-charcoal/20 bg-white/60 px-6 py-12 text-center">
                <MessageCircle size={22} className="mx-auto text-charcoal/25" />
                <p className="mt-2 text-sm font-medium text-charcoal/55">
                  {leads.length === 0 ? "No enquiries yet" : "Nothing matches this filter"}
                </p>
                <p className="mx-auto mt-1 max-w-sm text-xs leading-relaxed text-charcoal/40">
                  {leads.length === 0
                    ? "When someone enquires from one of your published tours (/tour/…), their message lands here with the property and scene they were viewing."
                    : "Try a different stage or clear the search."}
                </p>
              </div>
            ) : (
              <ul className="mt-4 space-y-2.5">
                {filtered.map((lead) => (
                  <li key={lead.id}>
                    <LeadCard
                      lead={lead}
                      open={openLeadId === lead.id}
                      onToggle={() => setOpenLeadId((cur) => (cur === lead.id ? null : lead.id))}
                      onChanged={(patch) =>
                        setLeads((prev) =>
                          prev
                            ? prev.map((l) =>
                                l.id === lead.id
                                  ? { ...l, ...patch, activityCount: l.activityCount + 1, updatedAt: Date.now() }
                                  : l
                              )
                            : prev
                        )
                      }
                      onConflict={() => void load()}
                    />
                  </li>
                ))}
              </ul>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function FilterChip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full border px-2.5 py-1 text-[11px] font-medium ${
        active ? "border-charcoal bg-charcoal text-bone" : "border-charcoal/15 bg-white text-charcoal/60 hover:border-charcoal/30"
      }`}
    >
      {label}
    </button>
  );
}

function LeadCard({
  lead,
  open,
  onToggle,
  onChanged,
  onConflict,
}: {
  lead: LeadSummary;
  open: boolean;
  onToggle: () => void;
  onChanged: (patch: Partial<LeadSummary>) => void;
  onConflict: () => void;
}) {
  const [busy, setBusy] = useState(false);
  const [cardError, setCardError] = useState<string | null>(null);
  const [note, setNote] = useState("");
  const [activities, setActivities] = useState<LeadActivityClient[] | null>(null);
  const [draft, setDraft] = useState("");
  const [drafting, setDrafting] = useState(false);
  const [draftError, setDraftError] = useState<string | null>(null);
  const [draftLang, setDraftLang] = useState<"en" | "hi" | "hinglish">("en");
  const [insights, setInsights] = useState<LeadInsights | null>(null);
  const [insightsLoading, setInsightsLoading] = useState(false);
  const [insightsError, setInsightsError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [nextAction, setNextAction] = useState(
    lead.nextActionAt ? new Date(lead.nextActionAt).toISOString().slice(0, 10) : ""
  );

  async function apply(patch: Parameters<typeof updateLead>[2]) {
    setBusy(true);
    setCardError(null);
    const result = await updateLead(lead.id, lead.updatedAt, patch);
    setBusy(false);
    if (result.ok) {
      onChanged({ stage: result.lead.stage as LeadStage, nextActionAt: result.lead.nextActionAt });
      setActivities(result.lead.activities);
    } else if (result.conflict) {
      onConflict();
    } else {
      setCardError(result.error);
    }
  }

  async function runDraft() {
    setDrafting(true);
    setDraftError(null);
    const result = await draftFollowUp(lead.id, "whatsapp", draftLang);
    setDrafting(false);
    if (result.ok) {
      setDraft(result.draft);
      onChanged({});
    } else {
      setDraftError(result.error);
    }
  }

  async function runInsights() {
    setInsightsLoading(true);
    setInsightsError(null);
    const result = await fetchLeadInsights(lead.id);
    setInsightsLoading(false);
    if (result.ok) {
      setInsights(result.insights);
    } else {
      setInsightsError(result.error);
    }
  }

  const waHref =
    lead.phone && draft
      ? `https://wa.me/${lead.phone.replace(/[^0-9]/g, "")}?text=${encodeURIComponent(draft)}`
      : null;

  return (
    <div className={`overflow-hidden rounded-lg border bg-white ${open ? "border-brass/50" : "border-charcoal/10"}`}>
      {/* summary row */}
      <button onClick={onToggle} className="flex w-full items-start gap-3 px-3.5 py-3 text-left sm:px-4">
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-sm font-semibold">{lead.name || "Anonymous enquiry"}</span>
            <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${STAGE_COLORS[lead.stage]}`}>
              {STAGE_LABELS[lead.stage]}
            </span>
            {lead.visitRequested && (
              <span className="flex items-center gap-1 rounded-full bg-teal-50 px-2 py-0.5 text-[10px] font-medium text-teal-700 ring-1 ring-teal-200">
                <CalendarCheck size={9} /> Visit requested
              </span>
            )}
            {lead.nextActionAt && (
              <span className="flex items-center gap-1 rounded-full bg-charcoal/5 px-2 py-0.5 text-[10px] text-charcoal/60">
                <CalendarClock size={9} /> {new Date(lead.nextActionAt).toLocaleDateString()}
              </span>
            )}
          </div>
          <p className="mt-1 line-clamp-1 text-xs text-charcoal/60">{lead.message}</p>
          <p className="mt-1 flex flex-wrap items-center gap-x-2.5 gap-y-0.5 text-[10px] text-charcoal/40">
            <span className="flex items-center gap-1">
              <ExternalLink size={9} /> {lead.tourName}
              {lead.stopTitle ? ` · ${lead.stopTitle}` : ""}
            </span>
            <span>{new Date(lead.createdAt).toLocaleString()}</span>
          </p>
        </div>
      </button>

      {open && (
        <div className="border-t border-charcoal/10 bg-bone/40 px-3.5 py-3 sm:px-4">
          {/* contact */}
          <div className="flex flex-wrap gap-3 text-xs text-charcoal/70">
            {lead.phone && (
              <a href={`tel:${lead.phone}`} className="flex items-center gap-1 text-brass hover:underline">
                <Phone size={11} /> {lead.phone}
              </a>
            )}
            {lead.email && (
              <a href={`mailto:${lead.email}`} className="flex items-center gap-1 text-brass hover:underline">
                <Mail size={11} /> {lead.email}
              </a>
            )}
            {!lead.name && (
              <span className="flex items-center gap-1 text-charcoal/40">
                <User size={11} /> name not given
              </span>
            )}
          </div>

          <p className="mt-2.5 rounded-md bg-white p-2.5 text-xs leading-relaxed text-charcoal/75">{lead.message}</p>

          {/* stage */}
          <div className="mt-3">
            <p className="text-[10px] font-medium uppercase tracking-wide text-charcoal/40">Stage</p>
            <div className="mt-1 flex flex-wrap gap-1">
              {LEAD_STAGES.map((s) => (
                <button
                  key={s}
                  disabled={busy || s === lead.stage}
                  onClick={() => apply({ stage: s })}
                  className={`rounded-full border px-2.5 py-1 text-[10px] font-medium transition-colors ${
                    s === lead.stage
                      ? `${STAGE_COLORS[s]} border-transparent`
                      : "border-charcoal/15 bg-white text-charcoal/60 hover:border-charcoal/30 disabled:opacity-40"
                  }`}
                >
                  {STAGE_LABELS[s]}
                </button>
              ))}
            </div>
          </div>

          {/* next action */}
          <div className="mt-3 flex flex-wrap items-end gap-2">
            <label className="text-[10px] font-medium uppercase tracking-wide text-charcoal/40">
              Next action date
              <input
                type="date"
                value={nextAction}
                onChange={(e) => setNextAction(e.target.value)}
                className="mt-1 block rounded border border-charcoal/15 bg-white px-2 py-1.5 text-xs font-normal text-charcoal/80"
              />
            </label>
            <button
              disabled={busy}
              onClick={() => apply({ nextActionAt: nextAction ? new Date(nextAction).getTime() : null })}
              className="rounded-md border border-charcoal/15 bg-white px-2.5 py-1.5 text-[11px] font-medium text-charcoal/65 hover:border-charcoal/30 disabled:opacity-40"
            >
              Save date
            </button>
          </div>

          {/* note + contact log */}
          <div className="mt-3">
            <p className="text-[10px] font-medium uppercase tracking-wide text-charcoal/40">Add note / log a contact</p>
            <div className="mt-1 flex flex-col gap-1.5 sm:flex-row">
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value.slice(0, 1000))}
                rows={2}
                placeholder="e.g. Called — asked about parking, will visit Saturday"
                className="min-w-0 flex-1 resize-y rounded border border-charcoal/15 bg-white px-2 py-1.5 text-xs outline-none focus:border-brass"
              />
              <div className="flex gap-1.5">
                <button
                  disabled={busy || !note.trim()}
                  onClick={async () => {
                    await apply({ note: note.trim() });
                    setNote("");
                  }}
                  className="flex items-center gap-1 rounded-md border border-charcoal/15 bg-white px-2.5 py-1.5 text-[11px] font-medium text-charcoal/65 hover:border-charcoal/30 disabled:opacity-40"
                >
                  <Plus size={11} /> Note
                </button>
                <button
                  disabled={busy || !note.trim()}
                  onClick={async () => {
                    await apply({ contactLog: note.trim() });
                    setNote("");
                  }}
                  className="flex items-center gap-1 rounded-md border border-charcoal/15 bg-white px-2.5 py-1.5 text-[11px] font-medium text-charcoal/65 hover:border-charcoal/30 disabled:opacity-40"
                  title="Record that you contacted them (you describe what happened — nothing is sent)"
                >
                  <History size={11} /> Log contact
                </button>
              </div>
            </div>
          </div>

          {/* Stage D: AI lead insights */}
          <div className="mt-3 rounded-md border border-charcoal/10 bg-white p-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="flex items-center gap-1 text-[11px] font-semibold text-charcoal/70">
                <Sparkles size={12} className="text-brass" /> AI insights
                {insights && <span className="rounded bg-brass/15 px-1.5 py-0.5 text-[9px] font-medium text-brass">AI-generated</span>}
              </p>
              <button
                onClick={runInsights}
                disabled={insightsLoading}
                className="flex items-center gap-1 rounded bg-charcoal px-2.5 py-1 text-[10px] font-semibold text-bone disabled:opacity-40"
              >
                {insightsLoading ? <Loader2 size={10} className="animate-spin" /> : <Sparkles size={10} />}
                {insightsLoading ? "Thinking…" : insights ? "Refresh" : "Summarize"}
              </button>
            </div>
            {insightsError && (
              <p className="mt-1.5 flex items-start gap-1 text-[10px] text-red-600">
                <AlertTriangle size={10} className="mt-0.5 shrink-0" /> {insightsError}
              </p>
            )}
            {insights && (
              <div className="mt-2 space-y-2 text-[11px] leading-relaxed text-charcoal/75">
                <p>
                  <span className="font-semibold text-charcoal/85">Enquiry:</span> {insights.enquirySummary}
                </p>
                {insights.buyerRequirements.length > 0 && (
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-wide text-charcoal/45">Stated requirements</p>
                    <ul className="mt-1 space-y-0.5">
                      {insights.buyerRequirements.map((r, i) => (
                        <li key={i} className="flex items-start gap-1">
                          <span className="mt-1 h-1 w-1 shrink-0 rounded-full bg-brass" /> {r}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {insights.suggestedNextActions.length > 0 && (
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-wide text-charcoal/45">
                      Suggested next steps (stage: {insights.stage})
                    </p>
                    <ul className="mt-1 space-y-0.5">
                      {insights.suggestedNextActions.map((a, i) => (
                        <li key={i} className="flex items-start gap-1">
                          <span className="mt-1 h-1 w-1 shrink-0 rounded-full bg-sage" /> {a}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                <p className="text-[9px] text-charcoal/40">{insights.disclaimer}</p>
              </div>
            )}
          </div>

          {/* AI follow-up draft */}
          <div className="mt-3 rounded-md border border-charcoal/10 bg-white p-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="flex items-center gap-1 text-[11px] font-semibold text-charcoal/70">
                <MessageCircle size={12} className="text-brass" /> AI follow-up draft
              </p>
              <div className="flex items-center gap-1.5">
                <select
                  value={draftLang}
                  onChange={(e) => setDraftLang(e.target.value as "en" | "hi" | "hinglish")}
                  className="rounded border border-charcoal/15 px-1.5 py-1 text-[10px]"
                  aria-label="Draft language"
                >
                  <option value="en">English</option>
                  <option value="hi">हिंदी</option>
                  <option value="hinglish">Hinglish</option>
                </select>
                <button
                  onClick={runDraft}
                  disabled={drafting}
                  className="flex items-center gap-1 rounded bg-charcoal px-2.5 py-1 text-[10px] font-semibold text-bone disabled:opacity-40"
                >
                  {drafting ? <Loader2 size={10} className="animate-spin" /> : <MessageCircle size={10} />}
                  {drafting ? "Drafting…" : "Draft"}
                </button>
              </div>
            </div>
            {draftError && <p className="mt-1.5 text-[10px] text-red-600">{draftError}</p>}
            {draft && (
              <>
                <textarea
                  value={draft}
                  onChange={(e) => setDraft(e.target.value.slice(0, 1500))}
                  rows={4}
                  className="mt-2 w-full resize-y rounded border border-charcoal/15 bg-bone/40 px-2 py-1.5 text-xs leading-relaxed outline-none focus:border-brass"
                />
                <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                  <button
                    onClick={async () => {
                      try {
                        await navigator.clipboard.writeText(draft);
                        setCopied(true);
                        setTimeout(() => setCopied(false), 1600);
                      } catch {
                        /* clipboard blocked — text stays selectable */
                      }
                    }}
                    className={`flex items-center gap-1 rounded-md border px-2 py-1 text-[10px] font-medium ${
                      copied ? "border-emerald-200 bg-emerald-50 text-emerald-700" : "border-charcoal/15 text-charcoal/65"
                    }`}
                  >
                    {copied ? <CheckCircle2 size={10} /> : <Copy size={10} />} {copied ? "Copied" : "Copy"}
                  </button>
                  {waHref && (
                    <a
                      href={waHref}
                      target="_blank"
                      rel="noreferrer noopener"
                      className="flex items-center gap-1 rounded-md bg-sage px-2 py-1 text-[10px] font-semibold text-white"
                      title="Opens WhatsApp with the draft pre-filled — you press send there"
                    >
                      <Send size={10} /> Open in WhatsApp
                    </a>
                  )}
                  <span className="text-[9px] leading-tight text-charcoal/40">
                    Draft only — nothing has been sent. Opening WhatsApp pre-fills the message; you press send.
                  </span>
                </div>
              </>
            )}
          </div>

          {cardError && <p className="mt-2 text-[11px] text-red-600">{cardError}</p>}

          {/* activity trail */}
          {activities !== null && activities.length > 0 && (
            <div className="mt-3">
              <p className="text-[10px] font-medium uppercase tracking-wide text-charcoal/40">History (latest first)</p>
              <ul className="mt-1 max-h-40 space-y-1 overflow-y-auto">
                {[...activities].reverse().map((a) => (
                  <li key={a.id} className="rounded bg-white px-2 py-1.5 text-[10px] text-charcoal/60">
                    <span className="font-mono text-charcoal/35">{new Date(a.at).toLocaleString()}</span>{" "}
                    {a.kind === "stage-change"
                      ? `Stage: ${STAGE_LABELS[(a as any).fromStage as LeadStage] ?? "—"} → ${STAGE_LABELS[a.toStage as LeadStage] ?? a.toStage}`
                      : a.kind === "draft"
                      ? `AI draft (${a.channel}, ${a.language}): ${(a as any).text.slice(0, 120)}…`
                      : `${a.kind === "note" ? "Note" : "Contact logged"}: ${a.text}`}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/**
 * Safe CSV export of the agent's OWN leads (the list is already scoped
 * server-side; this only formats what the verified token was allowed to
 * see). Excel-compatible: CRLF line endings, quotes doubled, and a BOM so
 * Excel opens UTF-8 properly.
 */
function exportLeadsCsv(leads: LeadSummary[]) {
  if (leads.length === 0) return;
  const esc = (v: string | number | boolean | null | undefined) => {
    const s = v === null || v === undefined ? "" : String(v);
    return `"${s.replace(/"/g, '""')}"`;
  };
  const header = [
    "Name", "Phone", "Email", "Stage", "Visit requested", "Property", "Scene",
    "Message", "Received", "Next action", "Activities",
  ];
  const rows = leads.map((l) =>
    [
      esc(l.name), esc(l.phone), esc(l.email), esc(STAGE_LABELS[l.stage]), esc(l.visitRequested ? "yes" : "no"),
      esc(l.tourName), esc(l.stopTitle), esc(l.message), esc(formatDateIN(l.createdAt)),
      esc(l.nextActionAt ? formatDateIN(l.nextActionAt) : ""), esc(l.activityCount),
    ].join(",")
  );
  const csv = "\uFEFF" + [header.map(esc).join(","), ...rows].join("\r\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `tourly-leads-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}
