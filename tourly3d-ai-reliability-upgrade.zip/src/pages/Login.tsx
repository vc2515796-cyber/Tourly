import { useState, FormEvent } from "react";
import { useNavigate, Navigate, Link } from "react-router-dom";
import { MapPin } from "lucide-react";
import { useAuth } from "../lib/auth";
import { usePageMeta } from "../lib/usePageMeta";

export default function Login() {
  usePageMeta({ title: "Sign in — Tourly", noindex: true });
  const { user, loading, configured, signIn, signUp, signInWithGoogle, resetPassword } = useAuth();
  const navigate = useNavigate();

  const [mode, setMode] = useState<"signin" | "signup" | "reset">("signin");
  const [resetSent, setResetSent] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [agreed, setAgreed] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (!loading && user) return <Navigate to="/dashboard" replace />;

  async function handleReset(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await resetPassword(email);
      // Always show success, whether or not the address has an account —
      // confirming account existence via this form is an enumeration risk.
      setResetSent(true);
    } catch (err: any) {
      console.error("[auth] password reset failed:", err?.code ?? err);
      setError(friendlyError(err?.code));
    } finally {
      setBusy(false);
    }
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (mode === "signup" && !agreed) {
      setError("Please agree to the Terms and Privacy Policy to create an account.");
      return;
    }
    if (mode === "signup" && passwordStrength(password).level === "weak") {
      setError("Please choose a stronger password — see the requirements below.");
      return;
    }
    setBusy(true);
    try {
      if (mode === "signin") {
        await signIn(email, password);
      } else {
        await signUp(email, password);
      }
      navigate("/dashboard");
    } catch (err: any) {
      // Never hide the real failure: the raw code goes to the console (for
      // the person debugging) and a mapped, actionable message to the UI.
      console.error("[auth] sign-in failed:", err?.code ?? err, err);
      setError(friendlyError(err?.code));
    } finally {
      setBusy(false);
    }
  }

  async function handleGoogle() {
    setError(null);
    if (mode === "signup" && !agreed) {
      setError("Please agree to the Terms and Privacy Policy to create an account.");
      return;
    }
    setBusy(true);
    try {
      await signInWithGoogle();
      navigate("/dashboard");
    } catch (err: any) {
      console.error("[auth] Google sign-in failed:", err?.code ?? err, err);
      setError(friendlyError(err?.code));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-full items-center justify-center bg-bone px-6 text-charcoal">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex items-center justify-center gap-2">
          <MapPin className="text-brass" size={22} strokeWidth={2.5} />
          <span className="font-display text-lg font-semibold tracking-tight">Tourly</span>
        </div>

        {!configured && (
          <div className="mb-6 rounded-md border border-brass/30 bg-brass/10 px-4 py-3 text-xs text-charcoal/70">
            Firebase isn't configured yet — set the <code>VITE_FIREBASE_*</code>{" "}
            environment variables and redeploy. See <b>AUTH-SETUP.md</b> in the project.
          </div>
        )}

        <div className="rounded-lg border border-charcoal/10 bg-white/60 p-6">
          <h1 className="font-display text-xl font-semibold tracking-tight">
            {mode === "signin" ? "Sign in" : mode === "signup" ? "Create an account" : "Reset your password"}
          </h1>
          <p className="mt-1 text-sm text-charcoal/50">
            {mode === "signin"
              ? "Sign in to build and manage your walkthroughs."
              : mode === "signup"
              ? "Set up an account to start building walkthroughs."
              : resetSent
              ? "Check your inbox for a link to set a new password."
              : "Enter your account's email and we'll send you a reset link."}
          </p>

          {mode === "reset" ? (
            resetSent ? (
              <button
                onClick={() => {
                  setMode("signin");
                  setResetSent(false);
                }}
                className="mt-5 w-full rounded-md bg-charcoal px-5 py-2.5 text-sm font-medium text-bone hover:bg-ink"
              >
                Back to sign in
              </button>
            ) : (
              <form onSubmit={handleReset} className="mt-5 flex flex-col gap-3">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Email"
                  className="rounded-md border border-charcoal/15 bg-white px-4 py-2.5 text-sm outline-none placeholder:text-charcoal/35 focus:border-brass"
                />
                {error && <p className="text-xs text-red-600">{error}</p>}
                <button
                  type="submit"
                  disabled={busy || !configured}
                  className="mt-1 rounded-md bg-charcoal px-5 py-2.5 text-sm font-medium text-bone transition-colors hover:bg-ink disabled:opacity-40"
                >
                  {busy ? "Sending…" : "Send reset link"}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMode("signin");
                    setError(null);
                  }}
                  className="text-xs text-charcoal/50 hover:underline"
                >
                  Back to sign in
                </button>
              </form>
            )
          ) : (
          <form onSubmit={handleSubmit} className="mt-5 flex flex-col gap-3">
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email"
              className="rounded-md border border-charcoal/15 bg-white px-4 py-2.5 text-sm outline-none placeholder:text-charcoal/35 focus:border-brass"
            />
            <input
              type="password"
              required
              minLength={mode === "signup" ? 8 : 6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              className="rounded-md border border-charcoal/15 bg-white px-4 py-2.5 text-sm outline-none placeholder:text-charcoal/35 focus:border-brass"
            />
            {mode === "signup" && password.length > 0 && (() => {
              const { level, hints } = passwordStrength(password);
              return (
                <div className="-mt-1">
                  <div className="flex gap-1">
                    {(["weak", "fair", "strong"] as const).map((l, i) => {
                      const order = { weak: 0, fair: 1, strong: 2 }[level];
                      const filled = i <= order;
                      const color = level === "weak" ? "bg-red-400" : level === "fair" ? "bg-amber-400" : "bg-emerald-500";
                      return <div key={l} className={`h-1 flex-1 rounded-full ${filled ? color : "bg-charcoal/10"}`} />;
                    })}
                  </div>
                  {hints.length > 0 && (
                    <p className="mt-1 text-[11px] text-charcoal/40">Still needs: {hints.join(", ")}</p>
                  )}
                </div>
              );
            })()}

            {mode === "signup" && (
              <label className="flex items-start gap-2 text-xs text-charcoal/60">
                <input
                  type="checkbox"
                  checked={agreed}
                  onChange={(e) => setAgreed(e.target.checked)}
                  className="mt-0.5 h-3.5 w-3.5 shrink-0 accent-brass"
                />
                <span>
                  I agree to the{" "}
                  <Link to="/terms" target="_blank" className="text-brass hover:underline">Terms</Link>{" "}
                  and{" "}
                  <Link to="/privacy" target="_blank" className="text-brass hover:underline">Privacy Policy</Link>.
                </span>
              </label>
            )}

            {error && <p className="text-xs text-red-600">{error}</p>}

            <button
              type="submit"
              disabled={busy || !configured}
              className="mt-1 rounded-md bg-charcoal px-5 py-2.5 text-sm font-medium text-bone transition-colors hover:bg-ink disabled:opacity-40"
            >
              {mode === "signin" ? "Sign in" : "Create account"}
            </button>
          </form>
          )}

          {mode !== "reset" && (
            <>
              <div className="my-4 flex items-center gap-3">
                <div className="h-px flex-1 bg-charcoal/10" />
                <span className="text-[11px] uppercase tracking-wide text-charcoal/30">or</span>
                <div className="h-px flex-1 bg-charcoal/10" />
              </div>

              <button
                onClick={handleGoogle}
                disabled={busy || !configured}
                className="flex w-full items-center justify-center gap-2 rounded-md border border-charcoal/15 px-5 py-2.5 text-sm font-medium transition-colors hover:border-charcoal/30 disabled:opacity-40"
              >
                Continue with Google
              </button>

              <p className="mt-5 text-center text-xs text-charcoal/50">
                {mode === "signin" ? "No account yet?" : "Already have an account?"}{" "}
                <button
                  onClick={() => {
                    setError(null);
                    setAgreed(false);
                    setMode(mode === "signin" ? "signup" : "signin");
                  }}
                  className="font-medium text-brass hover:underline"
                >
                  {mode === "signin" ? "Create one" : "Sign in"}
                </button>
              </p>
              {mode === "signin" && (
                <p className="mt-2 text-center text-xs text-charcoal/50">
                  <button
                    onClick={() => {
                      setError(null);
                      setMode("reset");
                    }}
                    className="hover:underline"
                  >
                    Forgot password?
                  </button>
                </p>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

type PasswordStrength = "weak" | "fair" | "strong";

/** Simple, transparent rule set — not a clever entropy estimate, just the
 *  kind of checklist a person can read and satisfy: length plus a mix of
 *  character classes. Enforced on signup only; sign-in never blocks on it
 *  (an old, weaker password must still be able to log in). */
function passwordStrength(pw: string): { level: PasswordStrength; hints: string[] } {
  const hints: string[] = [];
  if (pw.length < 8) hints.push("At least 8 characters");
  if (!/[a-z]/.test(pw)) hints.push("A lowercase letter");
  if (!/[A-Z]/.test(pw)) hints.push("An uppercase letter");
  if (!/[0-9]/.test(pw)) hints.push("A number");
  const score = Number(pw.length >= 8) + Number(/[a-z]/.test(pw)) + Number(/[A-Z]/.test(pw)) + Number(/[0-9]/.test(pw));
  const level: PasswordStrength = score >= 4 ? "strong" : score >= 2 ? "fair" : "weak";
  return { level, hints };
}

/** Maps Firebase auth error codes to messages that say what to DO about
 *  them. Every code that occurs on a real Netlify deployment is covered;
 *  anything unmapped still shows its code so the cause is never hidden
 *  (the previous "Something went wrong" default masked exactly the
 *  misconfigurations that break sign-in in production). */
function friendlyError(code?: string): string {
  switch (code) {
    case "app/firebase-not-configured":
      return "Sign-in isn't configured on this deployment — the site owner must set the VITE_FIREBASE_* environment variables and redeploy (see AUTH-SETUP.md).";
    case "auth/invalid-email":
      return "That email address doesn't look right.";
    case "auth/user-not-found":
    case "auth/wrong-password":
    case "auth/invalid-credential":
      return "Incorrect email or password.";
    case "auth/email-already-in-use":
      return "An account already exists with that email.";
    case "auth/weak-password":
      return "Password should be at least 6 characters.";
    case "auth/too-many-requests":
      return "Too many attempts — wait a minute and try again, or reset your password.";
    case "auth/user-disabled":
      return "This account has been disabled. Contact the site owner.";
    case "auth/network-request-failed":
      return "Couldn't reach Firebase — check your connection and try again.";
    case "auth/popup-closed-by-user":
      return "Google sign-in was closed before finishing.";
    case "auth/popup-blocked":
      return "The Google sign-in popup was blocked — allow popups for this site and try again.";
    case "auth/configuration-not-found":
    case "auth/operation-not-allowed":
      return "This sign-in method isn't enabled for the Firebase project. The site owner must enable it in Firebase Console → Authentication → Sign-in method (see AUTH-SETUP.md §2).";
    case "auth/invalid-api-key":
    case "auth/api-key-not-valid.-please-pass-a-valid-api-key.":
      return "Firebase rejected the configured API key — VITE_FIREBASE_API_KEY must match the Firebase Console project exactly (see AUTH-SETUP.md §1).";
    case "auth/unauthorized-domain": {
      const host = typeof window !== "undefined" ? window.location.hostname : "this domain";
      return `This domain (${host}) isn't authorized for Firebase sign-in. The site owner must add it under Firebase Console → Authentication → Settings → Authorized domains. Note: Firebase doesn't support wildcards, so every deploy-preview subdomain needs its own entry (see AUTH-SETUP.md §3).`;
    }
    default:
      // Unknown code: show it rather than hiding it behind a generic line.
      return code
        ? `Sign-in failed (${code}) — the full error is in the browser console. If it persists, see AUTH-SETUP.md.`
        : "Sign-in failed — the full error is in the browser console.";
  }
}
