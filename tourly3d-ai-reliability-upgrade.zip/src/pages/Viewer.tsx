import { useEffect, useRef, useState } from "react";
import { useParams, Link } from "react-router-dom";
import {
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  MapPin,
  Maximize,
  Minimize,
  MessageCircle,
  Send,
  X,
  Loader2,
  Lock,
} from "lucide-react";
import { getTour, recordView } from "../lib/storage";
import { fetchRemoteTour } from "../lib/publish";
import { askTourAssistant } from "../lib/tourAssistant";
import { Tour, Hotspot, mediaSrc } from "../types";
import RouteStrip from "../components/RouteStrip";
import PanoramaViewer from "../components/PanoramaViewer";
import FloorPlanHUD from "../components/FloorPlanHUD";
import EnquiryForm from "../components/EnquiryForm";
import { applyBrandingFavicon, safeLogoSrc, normalizeHex, DEFAULT_BRANDING } from "../lib/branding";
import { usePageMeta } from "../lib/usePageMeta";
import { trackTourEvent, markTourViewedSession, tourSourceFromLocation } from "../lib/tourAnalytics";

export default function Viewer() {
  const { id } = useParams();
  const [tour, setTour] = useState<Tour | null | undefined>(undefined);
  usePageMeta({ title: tour ? `${tour.name} — Tourly tour` : "Walkthrough — Tourly", noindex: true });
  const [activeIndex, setActiveIndex] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<{ role: "user" | "assistant"; text: string; isError?: boolean }[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [chatLoading, setChatLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const [needsPassword, setNeedsPassword] = useState(false);
  const [passwordInput, setPasswordInput] = useState("");
  const [passwordWrong, setPasswordWrong] = useState(false);
  const [passwordBusy, setPasswordBusy] = useState(false);
  const [cameraYaw, setCameraYaw] = useState(0);
  const [splashDone, setSplashDone] = useState(false);
  // ?embed=1 → the tour is running inside an agent's iframe. The page is
  // already iframe-safe (framing is deliberately not blocked); embed mode
  // just adds an "open the full tour" escape hatch and tags analytics.
  const embedMode = tourSourceFromLocation() === "embed";

  /** Fires the one-per-session tour-view event. All three load paths call
   *  this (local draft, published link, password unlock) — the session
   *  guard is what stops refreshes from double-counting. */
  function trackTourOpenOnce(tourId: string) {
    if (markTourViewedSession(tourId)) trackTourEvent(tourId, "tour-view");
  }

  const branding = tour?.branding;
  const primaryColor = branding?.primaryColor ? normalizeHex(branding.primaryColor) : DEFAULT_BRANDING.primaryColor;
  const agencyName = branding?.agencyName?.trim();
  const logo = safeLogoSrc(branding?.logoUrl);

  useEffect(() => {
    function onFsChange() {
      setIsFullscreen(!!document.fullscreenElement);
    }
    document.addEventListener("fullscreenchange", onFsChange);
    return () => document.removeEventListener("fullscreenchange", onFsChange);
  }, []);

  function toggleFullscreen() {
    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else {
      document.documentElement.requestFullscreen().catch(() => {});
    }
  }

  useEffect(() => {
    if (!id) return;
    const local = getTour(id) ?? null;
    if (local) {
      setTour(local);
      recordView(id);
      trackTourOpenOnce(id);
      return;
    }
    // Not in this browser's storage — this might be a link shared from
    // another device. Try the published copy before giving up. We don't
    // save it into this browser's own tour list — viewing someone's
    // shared link shouldn't make it show up as "yours" on /dashboard.
    fetchRemoteTour(id).then((result) => {
      if (result.status === "ok") {
        setTour(result.tour);
        recordView(id);
        trackTourOpenOnce(id);
      } else if (result.status === "password-required") {
        setNeedsPassword(true);
      } else {
        setTour(null);
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "ArrowRight") setActiveIndex((i) => Math.min((tour?.stops.length ?? 1) - 1, i + 1));
      if (e.key === "ArrowLeft") setActiveIndex((i) => Math.max(0, i - 1));
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [tour]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages, chatLoading]);

  // Runtime favicon + branded splash lifetime (Feature E).
  useEffect(() => {
    if (!tour) return;
    applyBrandingFavicon(tour.branding);
    if (!tour.branding?.splashEnabled) {
      setSplashDone(true);
      return;
    }
    const timer = setTimeout(() => setSplashDone(true), 2200);
    return () => clearTimeout(timer);
  }, [tour?.id, tour?.branding?.splashEnabled]);

  // Lazy preloading of NEIGHBOURING scenes (Feature F): warms the browser
  // cache for the next/previous stop's remote media so tapping through the
  // tour feels instant. Embedded dataUrls are already in memory; remote
  // https URLs are the ones that need warming. Videos are left alone —
  // preloading those would burn the visitor's data.
  useEffect(() => {
    if (!tour) return;
    for (const delta of [1, -1]) {
      const neighbour = tour.stops[activeIndex + delta];
      const src = neighbour?.media ? mediaSrc(neighbour.media) : "";
      if (src && /^https:\/\//.test(src) && neighbour!.media!.kind !== "video") {
        const img = new Image();
        img.decoding = "async";
        img.src = src;
      }
    }
  }, [tour, activeIndex]);

  // Scene-view tracking: every scene the visitor opens, including the
  // first one. Fires AFTER the tour is loaded; a failed load tracks
  // nothing (a 404/password page is not an engagement event).
  useEffect(() => {
    if (!tour || !id) return;
    const stop = tour.stops[activeIndex];
    if (stop) trackTourEvent(id, "scene-view", stop.id);
  }, [tour?.id, activeIndex]);

  async function submitPassword() {
    if (!id || !passwordInput || passwordBusy) return;
    setPasswordBusy(true);
    setPasswordWrong(false);
    const result = await fetchRemoteTour(id, passwordInput);
    setPasswordBusy(false);
    if (result.status === "ok") {
      setNeedsPassword(false);
      setTour(result.tour);
      recordView(id);
      trackTourOpenOnce(id);
    } else if (result.status === "password-required") {
      setPasswordWrong(true);
    } else {
      setNeedsPassword(false);
      setTour(null);
    }
  }

  if (needsPassword && !tour) {
    return (
      <div className="flex min-h-full flex-col items-center justify-center gap-4 bg-ink px-6 text-bone">
        <Lock style={{ color: primaryColor }} size={26} />
        <p className="font-display text-lg">This walkthrough is password protected</p>
        <div className="flex w-full max-w-xs flex-col gap-2">
          <input
            type="password"
            value={passwordInput}
            onChange={(e) => setPasswordInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && submitPassword()}
            placeholder="Enter password"
            autoFocus
            className="rounded-md bg-bone/10 px-3 py-2.5 text-sm text-bone outline-none placeholder:text-bone/30"
          />
          {passwordWrong && <p className="text-xs text-red-400">Incorrect password — try again.</p>}
          <button
            onClick={submitPassword}
            disabled={!passwordInput || passwordBusy}
            className="rounded-md px-4 py-2.5 text-sm font-medium text-bone disabled:opacity-40"
            style={{ backgroundColor: primaryColor }}
          >
            {passwordBusy ? "Checking…" : "View walkthrough"}
          </button>
        </div>
      </div>
    );
  }

  if (tour === undefined) return null;

  if (tour === null || tour.stops.length === 0) {
    return (
      <div className="flex min-h-full flex-col items-center justify-center gap-3 bg-ink text-bone">
        <MapPin style={{ color: primaryColor }} size={28} />
        <p className="font-display text-lg">This walkthrough isn't ready yet</p>
        <Link to="/" className="text-sm text-brass hover:underline" style={{ color: primaryColor }}>
          Back to Tourly
        </Link>
      </div>
    );
  }

  const stop = tour.stops[activeIndex];
  const isFirst = activeIndex === 0;
  const isLast = activeIndex === tour.stops.length - 1;

  function goToStop(hotspot: Hotspot) {
    const idx = tour!.stops.findIndex((s) => s.id === hotspot.targetStopId);
    if (idx !== -1) {
      // Hotspot click = engagement on the CURRENT scene — that's the
      // scene the buyer was looking at when they chose to walk on.
      if (id) trackTourEvent(id, "hotspot", tour!.stops[activeIndex]?.id);
      setActiveIndex(idx);
    }
  }

  function goToStopId(stopId: string) {
    const idx = tour!.stops.findIndex((s) => s.id === stopId);
    if (idx !== -1) setActiveIndex(idx);
  }

  async function sendChatMessage() {
    const question = chatInput.trim();
    if (!question || !tour || chatLoading) return;
    setChatInput("");
    const priorHistory = chatMessages.filter((m) => !m.isError);
    setChatMessages((m) => [...m, { role: "user", text: question }]);
    setChatLoading(true);
    const result = await askTourAssistant(
      question,
      {
        name: tour.name,
        subtitle: tour.subtitle,
        whatsappNumber: tour.whatsappNumber,
        stops: tour.stops.map((s) => ({ title: s.title, note: s.note })),
      },
      priorHistory.map((m) => ({ role: m.role, text: m.text }))
    );
    setChatLoading(false);
    setChatMessages((m) => [
      ...m,
      { role: "assistant", text: result.ok ? result.answer : result.error, isError: !result.ok },
    ]);
  }

  const whatsappHref = tour.whatsappNumber
    ? `https://wa.me/${tour.whatsappNumber.replace(/[^0-9]/g, "")}?text=${encodeURIComponent(
        `Hi, I'm interested in "${tour.name}" — I saw the virtual tour. ${window.location.origin}/tour/${tour.id}?src=wa`
      )}`
    : null;

  const showSplash = branding?.splashEnabled && !splashDone;

  return (
    <div className="flex min-h-full flex-col bg-ink text-bone">
      {/* Embed escape hatch: someone browsing this tour inside an iframe
          can always break out to the full experience. */}
      {embedMode && (
        <a
          href={`${window.location.origin}/tour/${tour.id}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-center gap-1.5 bg-bone/10 px-3 py-1.5 text-[11px] font-medium text-bone/70 hover:text-bone"
        >
          <ExternalLink size={11} /> Open the full tour
        </a>
      )}
      {/* Branded splash (Feature E) — fades out as soon as the first scene
          has had a moment to load, or after ~2s; never blocks interaction. */}
      {showSplash && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center gap-4 bg-ink transition-opacity duration-500">
          {logo ? (
            <img src={logo} alt={agencyName ?? "Logo"} className="max-h-20 max-w-[60%] object-contain" />
          ) : (
            <MapPin style={{ color: primaryColor }} size={34} strokeWidth={2.5} />
          )}
          <div className="text-center">
            <p className="font-display text-lg font-semibold">{agencyName ?? tour.name}</p>
            {agencyName && <p className="mt-1 text-xs text-bone/50">{tour.name}</p>}
          </div>
          <Loader2 size={18} className="animate-spin text-bone/40" />
        </div>
      )}

      <header className="flex items-center justify-between px-6 py-4 sm:px-10">
        <Link to="/" className="flex items-center gap-2">
          {logo ? (
            <img src={logo} alt={agencyName ?? "Tourly"} className="max-h-8 max-w-[140px] object-contain" />
          ) : (
            <>
              <MapPin style={{ color: primaryColor }} size={18} strokeWidth={2.5} />
              <span className="font-display text-sm font-semibold tracking-tight">Tourly</span>
            </>
          )}
        </Link>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <p className="font-display text-sm font-semibold">{tour.name}</p>
            {tour.subtitle && <p className="text-xs text-bone/50">{tour.subtitle}</p>}
          </div>
          {whatsappHref && (
            <a
              href={whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              className="flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-medium text-white hover:opacity-90"
              style={{ backgroundColor: primaryColor }}
            >
              <MessageCircle size={14} /> Enquire
            </a>
          )}
        </div>
      </header>

      {/* Stage */}
      <div className="relative flex flex-1 items-center justify-center overflow-hidden px-4 py-4 sm:px-10">
        <button
          onClick={toggleFullscreen}
          className="absolute right-4 top-4 z-20 rounded-full bg-ink/60 p-2.5 backdrop-blur transition-colors hover:bg-ink/80 sm:right-8"
          aria-label="Toggle fullscreen"
        >
          {isFullscreen ? <Minimize size={16} /> : <Maximize size={16} />}
        </button>
        <button
          onClick={() => setActiveIndex((i) => Math.max(0, i - 1))}
          disabled={isFirst}
          className="absolute left-4 z-10 rounded-full bg-ink/60 p-2.5 backdrop-blur transition-opacity hover:bg-ink/80 disabled:opacity-0 sm:left-8"
          aria-label="Previous stop"
        >
          <ChevronLeft size={20} />
        </button>
        <button
          onClick={() => setActiveIndex((i) => Math.min(tour.stops.length - 1, i + 1))}
          disabled={isLast}
          className="absolute right-4 z-10 rounded-full bg-ink/60 p-2.5 backdrop-blur transition-opacity hover:bg-ink/80 disabled:opacity-0 sm:right-8"
          aria-label="Next stop"
        >
          <ChevronRight size={20} />
        </button>

        <div key={stop.id} className="wp-fade-in flex w-full max-w-4xl flex-col items-center">
          <div className="flex aspect-video w-full items-center justify-center overflow-hidden rounded-lg bg-black">
            {stop.media ? (
              stop.media.kind === "panorama" || stop.media.kind === "wide" ? (
                <PanoramaViewer
                  key={stop.id}
                  imageUrl={mediaSrc(stop.media)}
                  mode={stop.media.kind === "wide" ? "cylinder" : "sphere"}
                  hotspots={stop.hotspots}
                  onHotspotClick={goToStop}
                  onCameraMove={(yaw) => setCameraYaw(yaw)}
                />
              ) : stop.media.kind === "image" ? (
                <img src={mediaSrc(stop.media)} alt={stop.title} className="h-full w-full object-cover" />
              ) : (
                <video
                  key={stop.id}
                  src={mediaSrc(stop.media)}
                  className="h-full w-full object-cover"
                  controls
                  autoPlay
                  muted
                />
              )
            ) : (
              <span className="text-bone/30">No media for this stop</span>
            )}
          </div>
          {(stop.media?.kind === "panorama" || stop.media?.kind === "wide") && (
            <p className="mt-2 text-xs text-bone/40">Drag to look around · click a pin to walk through</p>
          )}
          <div className="mt-5 text-center">
            <p className="font-mono text-[11px] tracking-widest" style={{ color: primaryColor }}>
              STOP {String(activeIndex + 1).padStart(2, "0")} / {String(tour.stops.length).padStart(2, "0")}
            </p>
            <h2 className="mt-1 font-display text-2xl font-semibold">{stop.title}</h2>
            {stop.note && <p className="mx-auto mt-1 max-w-xl text-sm text-bone/60">{stop.note}</p>}
          </div>
        </div>
      </div>

      <RouteStrip stops={tour.stops} activeIndex={activeIndex} onSelect={setActiveIndex} variant="dark" />

      {/* Floor-plan HUD (Feature C) — only renders when the creator uploaded
          a plan AND placed at least one marker. */}
      <FloorPlanHUD
        tour={tour}
        activeStopId={stop.id}
        cameraYawDeg={cameraYaw}
        onSelectStop={goToStopId}
        accentColor={branding?.primaryColor}
      />

      {/* AI assistant */}
      <div className="fixed bottom-24 right-4 z-30 sm:bottom-28 sm:right-8">
        {chatOpen ? (
          <div className="flex h-96 w-72 flex-col overflow-hidden rounded-xl border border-bone/10 bg-ink shadow-2xl sm:w-80">
            <div className="flex items-center justify-between border-b border-bone/10 px-3.5 py-2.5">
              <p className="text-xs font-medium text-bone/80">Ask about this tour</p>
              <button onClick={() => setChatOpen(false)} className="text-bone/40 hover:text-bone">
                <X size={15} />
              </button>
            </div>
            <div className="flex-1 space-y-2.5 overflow-y-auto px-3.5 py-3">
              {chatMessages.length === 0 && (
                <p className="text-xs text-bone/40">
                  Ask a question about {tour.name} — I can only answer from what's on this page.
                </p>
              )}
              {chatMessages.map((m, i) => (
                <div
                  key={i}
                  className={`max-w-[85%] rounded-lg px-3 py-2 text-xs ${
                    m.role === "user" ? "ml-auto text-bone" : "bg-bone/10 text-bone/90"
                  }`}
                  style={m.role === "user" ? { backgroundColor: primaryColor } : undefined}
                >
                  {m.text}
                </div>
              ))}
              {chatLoading && (
                <div className="flex items-center gap-1.5 text-xs text-bone/40">
                  <Loader2 size={12} className="animate-spin" /> Thinking…
                </div>
              )}
              <div ref={chatEndRef} />
            </div>
            <div className="flex items-center gap-1.5 border-t border-bone/10 p-2.5">
              <input
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && sendChatMessage()}
                placeholder="Type a question…"
                className="flex-1 rounded-md bg-bone/10 px-3 py-2 text-xs text-bone outline-none placeholder:text-bone/30"
              />
              <button
                onClick={sendChatMessage}
                disabled={!chatInput.trim() || chatLoading}
                className="rounded-md p-2 text-bone disabled:opacity-30"
                style={{ backgroundColor: primaryColor }}
              >
                <Send size={14} />
              </button>
            </div>
          </div>
        ) : (
          <button
            onClick={() => setChatOpen(true)}
            className="flex items-center gap-2 rounded-full px-4 py-3 text-sm font-medium text-bone shadow-xl hover:opacity-90"
            style={{ backgroundColor: primaryColor }}
          >
            <MessageCircle size={16} /> Ask a question
          </button>
        )}
      </div>

      {/* Stage B5 — public enquiry capture. Light section on the dark tour
          page; posts to /api/capture-lead, which routes it to the tour
          owner's CRM (owner resolved server-side). */}
      <div className="bg-bone px-4 py-6 text-charcoal sm:px-10">
        <div className="mx-auto max-w-2xl">
          <EnquiryForm tour={tour} stopTitle={stop.title} />
        </div>
      </div>
    </div>
  );
}
