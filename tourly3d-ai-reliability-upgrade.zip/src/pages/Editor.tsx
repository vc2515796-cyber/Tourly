import { useEffect, useRef, useState } from "react";
import React from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  ArrowLeft,
  Upload,
  Trash2,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  ChevronDown,
  ExternalLink,
  X,
  Circle,
  ArrowUpRight,
  Share2,
  Check,
  Loader2,
  MapPin,
  Plus,
  MousePointer2,
  Link2,
  MapPinned,
  Type,
  ImageIcon,
  ZoomIn,
  RotateCw,
  PanelTop,
  Sparkles,
  Wand2,
  RefreshCw,
  AlertTriangle,
  MessageCircle,
  Megaphone,
  Box,
  Lock,
  Folder,
  Palette,
  History,
  CloudUpload,
  Route,
  CheckCircle2,
} from "lucide-react";
import { getTour, saveTour, newStop, StorageFullError } from "../lib/storage";
import SmartUploadPanel, { SmartUploadItem } from "../components/SmartUploadPanel";
import SharePanel from "../components/SharePanel";
const PlanStudio = React.lazy(() => import("../components/plan/PlanStudio"));
import { compressImage, UPLOAD_MAX_DIM } from "../lib/imageCompress";
import { enhancePanorama } from "../lib/enhance";
import { fixSeam } from "../lib/seamFix";
import { generatePanoramaFromPhoto } from "../lib/generatePanorama";
import { generate3DRender, remaining3DRenders, RenderStyle } from "../lib/generate3DRender";
import { publishTour } from "../lib/publish";
import { checkEquirectangular, PanoramaCheck } from "../lib/panoramaCheck";
import { checkBlurriness } from "../lib/qualityCheck";
import { analyzeScene, type SceneAnalysis } from "../lib/analyzeScene";
import { runBatch, summarize, type BatchItem } from "../lib/batchRunner";
import { generateInteriorConcept, INTERIOR_STYLES, type InteriorStyle } from "../lib/interiorConcept";
import { suggestHotspots, HotspotSuggestion } from "../lib/suggestHotspots";
import { Tour, Stop, Hotspot, mediaSrc } from "../types";
import PanoramaViewer from "../components/PanoramaViewer";
import { PanoramaWarningModal, GeneratingPanoramaModal } from "../components/PanoramaWarningModal";
import { MarketingModal } from "../components/MarketingModal";
import FloorPlanEditor from "../components/FloorPlanEditor";
import ConstructionPanel from "../components/ConstructionPanel";
import BrandingPanel from "../components/BrandingPanel";
import { suggestSequence, SequenceSuggestion } from "../lib/suggestSequence";
import { getCloudStorageStatus, uploadToCloud, CloudStorageStatus } from "../lib/cloudStorage";
import { usePageMeta } from "../lib/usePageMeta";

type Tool = "select" | "hotspot" | "location" | "text" | "image" | "zoom";
const COMING_SOON_TOOLS: Tool[] = ["text", "zoom"];

// Upload validation (Feature A). Raw file caps: images get client-compressed
// after acceptance; videos can't be cheaply re-encoded in the browser, so
// the raw cap is the real cap.
const MAX_RAW_IMAGE_BYTES = 30 * 1024 * 1024;
const MAX_EMBEDDED_VIDEO_BYTES = 15 * 1024 * 1024;
const MAX_CLOUD_VIDEO_BYTES = 200 * 1024 * 1024;
const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];
const ACCEPTED_VIDEO_TYPES = ["video/mp4", "video/webm", "video/quicktime"];

export default function Editor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [tour, setTour] = useState<Tour | null>(null);
  usePageMeta({ title: `${tour?.name || "Editor"} — Edit · Tourly`, noindex: true });
  const [activeIndex, setActiveIndex] = useState(0);
  const [uploadKind, setUploadKind] = useState<"image" | "video" | "panorama" | "wide">("panorama");
  const [activeTool, setActiveTool] = useState<Tool>("select");
  const [publishState, setPublishState] = useState<"idle" | "publishing" | "done" | "error">("idle");
  const [publishError, setPublishError] = useState<string | null>(null);
  const [panoramaWarning, setPanoramaWarning] = useState<
    { stopId: string; dataUrl: string; check: PanoramaCheck } | null
  >(null);
  const [generatingPanorama, setGeneratingPanorama] = useState(false);
  const [blurWarningStopId, setBlurWarningStopId] = useState<string | null>(null);
  const [panoramaGenError, setPanoramaGenError] = useState<string | null>(null);
  const [storageError, setStorageError] = useState<string | null>(null);
  const [analyzingScene, setAnalyzingScene] = useState(false);
  const [analyzeSceneError, setAnalyzeSceneError] = useState<string | null>(null);
  const [hotspotSuggestions, setHotspotSuggestions] = useState<HotspotSuggestion[]>([]);
  const [suggestingHotspots, setSuggestingHotspots] = useState(false);
  const [showMarketing, setShowMarketing] = useState(false);
  const [render3dStyle, setRender3dStyle] = useState<RenderStyle>("modern");
  const [generating3D, setGenerating3D] = useState(false);
  const [render3dError, setRender3dError] = useState<string | null>(null);
  // Stage D (Phase 6): optional AI interior concept
  const [interiorStyle, setInteriorStyle] = useState<InteriorStyle>("modern");
  const [interiorBusy, setInteriorBusy] = useState(false);
  const [interiorError, setInteriorError] = useState<string | null>(null);
  const [interiorPreview, setInteriorPreview] = useState<string | null>(null);
  const [interiorPreviewMime, setInteriorPreviewMime] = useState("image/jpeg");
  const [selectedStopIds, setSelectedStopIds] = useState<Set<string>>(new Set());
  const [batchProgress, setBatchProgress] = useState<{ done: number; total: number } | null>(null);
  const [batchError, setBatchError] = useState<string | null>(null);
  /** Per-scene states of the last auto-detect run (resumable; completed
   *  scenes are kept and never re-billed on a retry-failed pass). */
  const [batchStates, setBatchStates] = useState<BatchItem<SceneAnalysis>[] | null>(null);
  const [floorPlanOpen, setFloorPlanOpen] = useState(false);
  const [smartUploadOpen, setSmartUploadOpen] = useState(false);
  const [planStudioOpen, setPlanStudioOpen] = useState(false);
  const [constructionOpen, setConstructionOpen] = useState(false);
  const [brandingOpen, setBrandingOpen] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{ stopId: string; pct: number; label: string } | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [cloudNotice, setCloudNotice] = useState<string | null>(null);
  const [cloudStatus, setCloudStatus] = useState<CloudStorageStatus | null>(null);
  const [sequenceSuggestion, setSequenceSuggestion] = useState<SequenceSuggestion | null>(null);
  const [suggestingSequence, setSuggestingSequence] = useState(false);
  const [sequenceError, setSequenceError] = useState<string | null>(null);
  /** Latest AI construction-stage suggestion for the active scene, offered
   *  as a prefill in the construction panel — never auto-applied. */
  const [suggestedStage, setSuggestedStage] = useState<string | undefined>(undefined);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const floorPlanInputRef = useRef<HTMLInputElement>(null);

  // Feature G: one cheap status check per editor session — decides whether
  // uploads go to cloud object storage (full-res + small embedded preview)
  // or the legacy embedded path, and surfaces an honest notice for the
  // latter instead of pretending media is cloud-persisted.
  useEffect(() => {
    getCloudStorageStatus().then((status) => {
      setCloudStatus(status);
      if (!status.configured) {
        setCloudNotice(
          "Cloud media storage isn't configured on this deployment — media is embedded in the tour (smaller limits). Set the S3_* env vars to enable full-resolution cloud uploads."
        );
      }
    });
  }, []);

  const placingHotspot = activeTool === "hotspot";

  useEffect(() => {
    if (!id) return;
    const t = getTour(id);
    if (!t) {
      navigate("/dashboard");
      return;
    }
    setTour(t);
    setActiveIndex(0);
  }, [id]);

  function persist(updated: Tour) {
    setTour(updated);
    saveTour(updated);
  }

  function addStop() {
    if (!tour) return;
    const stop = newStop();
    const updated = { ...tour, stops: [...tour.stops, stop] };
    persist(updated);
    setActiveIndex(updated.stops.length - 1);
  }

  function updateStop(stopId: string, patch: Partial<Stop>) {
    if (!tour) return;
    const stops = tour.stops.map((s) => (s.id === stopId ? { ...s, ...patch } : s));
    persist({ ...tour, stops });
  }

  function removeStop(stopId: string) {
    if (!tour) return;
    const stops = tour.stops.filter((s) => s.id !== stopId);
    persist({ ...tour, stops });
    setActiveIndex((i) => Math.max(0, Math.min(i, stops.length - 1)));
  }

  function toggleStopSelection(stopId: string) {
    setSelectedStopIds((prev) => {
      const next = new Set(prev);
      if (next.has(stopId)) next.delete(stopId);
      else next.add(stopId);
      return next;
    });
  }

  function bulkDeleteSelected() {
    if (!tour || selectedStopIds.size === 0) return;
    const stops = tour.stops.filter((s) => !selectedStopIds.has(s.id));
    persist({ ...tour, stops });
    setSelectedStopIds(new Set());
    setActiveIndex((i) => Math.max(0, Math.min(i, stops.length - 1)));
  }

  function moveStop(index: number, dir: -1 | 1) {
    if (!tour) return;
    const stops = [...tour.stops];
    const target = index + dir;
    if (target < 0 || target >= stops.length) return;
    [stops[index], stops[target]] = [stops[target], stops[index]];
    persist({ ...tour, stops });
    setActiveIndex(target);
  }

  function runPanoramaPipeline(stopId: string, kind: "panorama" | "wide", startingDataUrl: string) {
    // Seam fix first (deterministic, structural continuity), then the AI
    // lighting/clarity pass — both silent, both fall back to whatever
    // came in if they fail, so this chain can never leave a stop broken.
    fixSeam(startingDataUrl).then((seamFixed) => {
      if (seamFixed !== startingDataUrl) {
        updateStop(stopId, { media: { kind, dataUrl: seamFixed } });
      }
      enhancePanorama(seamFixed, kind === "panorama" ? "sphere" : "cylinder").then((finalDataUrl) => {
        if (finalDataUrl !== seamFixed) {
          updateStop(stopId, { media: { kind, dataUrl: finalDataUrl } });
        }
      });
    });
  }

  /** Feature A/G: validates type + size BEFORE reading, then routes to
   *  cloud object storage when configured (full-res file in the cloud, small
   *  embedded preview for thumbs/AI) or the legacy embedded path otherwise
   *  — with real progress feedback either way.
   *  Returns a promise that resolves when the stop's media is set (or a
   *  validation error was shown) so batch flows can sequence uploads. */
  async function handleFile(file: File, stopId: string, kindOverride?: "image" | "panorama" | "wide") {
    const isVideo = file.type.startsWith("video/");
    const kind: "image" | "video" | "panorama" | "wide" = isVideo ? "video" : (kindOverride ?? uploadKind);
    setUploadError(null);

    // --- type validation ---
    if (!isVideo && !ACCEPTED_IMAGE_TYPES.includes(file.type)) {
      setUploadError(`Unsupported image type "${file.type || file.name.split(".").pop()}" — use JPEG, PNG or WebP.`);
      return;
    }
    if (isVideo && !ACCEPTED_VIDEO_TYPES.includes(file.type)) {
      setUploadError(`Unsupported video type "${file.type}" — use MP4, WebM or QuickTime.`);
      return;
    }

    // --- size validation (before any heavy work) ---
    const cloudAvailable = cloudStatus?.configured === true;
    if (!isVideo && file.size > MAX_RAW_IMAGE_BYTES) {
      setUploadError(`That image is ${(file.size / 1024 / 1024).toFixed(0)} MB — the limit is 30 MB. Resize it and try again.`);
      return;
    }
    if (isVideo && file.size > (cloudAvailable ? MAX_CLOUD_VIDEO_BYTES : MAX_EMBEDDED_VIDEO_BYTES)) {
      setUploadError(
        cloudAvailable
          ? `That video is ${(file.size / 1024 / 1024).toFixed(0)} MB — the cloud limit is 200 MB.`
          : `That video is ${(file.size / 1024 / 1024).toFixed(0)} MB — without cloud storage configured the limit is 15 MB (it gets embedded in the tour). Configure S3_* env vars for large videos.`
      );
      return;
    }

    const readDataUrl = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = () => reject(new Error("read failed"));
      reader.readAsDataURL(file);
    }).catch(() => null);
    if (readDataUrl === null) {
      setUploadError("Couldn't read that file — try again.");
      return;
    }
    try {
        if (cloudAvailable) {
          // --- cloud path: upload the ORIGINAL file, keep a small embedded
          //     preview so thumbs/AI checks keep working offline ---
          setUploadProgress({ stopId, pct: 0, label: `Uploading to cloud…` });
          const uploaded = await uploadToCloud(file, {
            onProgress: (pct) => setUploadProgress({ stopId, pct, label: "Uploading to cloud…" }),
          });
          let previewDataUrl = "";
          if (!isVideo) {
            previewDataUrl = await compressImage(readDataUrl, { maxDim: 1024, quality: 0.8, skipBelowBytes: 0 });
          }
          updateStop(stopId, {
            media: { kind, dataUrl: previewDataUrl, url: uploaded.url },
          });
          setUploadProgress(null);
          if (kind === "panorama" || kind === "wide") {
            // The silent enhance pipeline operates on dataUrls; for cloud
            // media the full-res original is already stored — skip it.
          }
          return;
        }

        // --- legacy embedded path: compress before it ever touches
        //     state/localStorage — a phone photo can be 10+ MB ---
        const rawDataUrl = isVideo
          ? readDataUrl
          : await compressImage(readDataUrl, {
              maxDim: UPLOAD_MAX_DIM[kind === "panorama" || kind === "wide" ? kind : "image"],
            });

        if (kind === "panorama") {
          try {
            const check = await checkEquirectangular(rawDataUrl);
            if (!check.isEquirectangular) {
              setPanoramaWarning({ stopId, dataUrl: rawDataUrl, check });
              return; // don't set media yet — wait for the person's choice below
            }
          } catch {
            // If dimension check itself fails, fall through and just show it —
            // no reason to block on a decode error unrelated to the shape check.
          }
        }

        try {
          updateStop(stopId, { media: { kind, dataUrl: rawDataUrl } });
        } catch (err) {
          if (err instanceof StorageFullError) {
            setStorageError(
              "Your browser's storage is full, so this photo couldn't be saved. Try removing an older scene or walkthrough first."
            );
            return;
          }
          throw err;
        }
        setBlurWarningStopId(null);

        if (kind === "panorama" || kind === "wide") {
          runPanoramaPipeline(stopId, kind, rawDataUrl);
        }

        // Best-effort blur heuristic — never blocks the upload, just warns.
        if (!isVideo) {
          checkBlurriness(rawDataUrl).then((result) => {
            if (result?.looksBlurry) setBlurWarningStopId(stopId);
          });
        }
      } catch (err: any) {
        setUploadProgress(null);
        // Honest failure — the stop keeps its previous media.
        setUploadError(err?.message ?? "Upload failed — try again.");
      }
  }

  /** Stage B1: applies the confirmed smart-upload batch — creates the stops
   *  with their edited titles/notes first, then runs each ORIGINAL file
   *  through the normal upload pipeline (compression / cloud routing /
   *  equirect checks) sequentially so progress and warnings stay accurate. */
  async function applySmartUpload(items: SmartUploadItem[]) {
    if (!tour || items.length === 0) return;
    let working = tour;
    const newIds: string[] = [];
    for (const item of items) {
      const stop = { ...newStop(), title: item.title, note: item.note };
      working = { ...working, stops: [...working.stops, stop] };
      newIds.push(stop.id);
    }
    persist(working);
    setSmartUploadOpen(false);
    setActiveIndex(Math.max(0, working.stops.length - items.length));
    for (let i = 0; i < items.length; i++) {
      // treatAs360 was only offered when the photo passed the equirect
      // dimension check, and the person confirmed it.
      await handleFile(items[i].file, newIds[i], items[i].treatAs360 ? "panorama" : "image");
    }
  }

  /** Shared engine for "auto-detect all" + "retry failed scenes": runs the
   *  resumable batch state machine, applies each success immediately (so a
   *  mid-run interruption keeps every completed scene), and surfaces a
   *  per-scene summary with retry-failed-only support. Systemic failures
   *  (expired session, daily quota, unconfigured AI) abort the run instead
   *  of masquerading as per-scene errors. */
  async function runAutoDetect(pass: BatchItem<SceneAnalysis>[], onlyIds?: string[]) {
    if (!tour || batchProgress) return;
    setBatchError(null);
    const summary0 = summarize(pass);
    setBatchProgress({ done: summary0.completed + summary0.skipped + summary0.failed, total: summary0.total });

    // Work on a local copy and persist after each result — calling
    // updateStop() in a loop would overwrite earlier results, since each
    // call closes over the same starting `tour`.
    let working = tour;

    const result = await runBatch<unknown, SceneAnalysis, { kind?: string }>({
      items: pass,
      onlyIds,
      processItem: async (item) => {
        const stop = working.stops.find((s) => s.id === item.id);
        if (!stop?.media || stop.media.kind === "video") {
          throw Object.assign(new Error("Scene has no analysable photo."), { friendlyMessage: "Scene has no analysable photo.", kind: "invalid" });
        }
        const otherTitles = working.stops.filter((s) => s.id !== stop.id).map((s) => s.title);
        const r = await analyzeScene(stop.media.dataUrl, otherTitles);
        if (!r.ok) {
          // The error kind decides systemic-vs-item in classifyError below.
          throw Object.assign(new Error(r.error), { friendlyMessage: r.error, kind: r.kind });
        }
        working = {
          ...working,
          stops: working.stops.map((s) =>
            s.id === stop.id ? { ...s, title: r.analysis.roomLabel, note: r.analysis.description || s.note } : s
          ),
        };
        persist(working);
        return r.analysis;
      },
      classifyError: (err: any) =>
        err?.kind === "auth" || err?.kind === "quota" || err?.kind === "provider-quota" || err?.kind === "not-configured"
          ? err.kind === "provider-quota" ? "quota" : err.kind
          : "item",
      onItemSettled: (items, summary) => {
        setBatchStates([...items]);
        setBatchProgress({ done: summary.completed + summary.skipped + summary.failed, total: summary.total });
      },
    });

    setBatchProgress(null);
    setBatchStates([...result.items]);
    if (result.aborted) {
      setBatchError(result.aborted.message);
    }
    return result;
  }

  async function handleAnalyzeAllScenes() {
    if (!tour || batchProgress) return;
    const targets = tour.stops.filter((s) => s.media && s.media.kind !== "video");
    if (targets.length === 0) return;
    // A fresh pass seeds every target as pending (an explicit new run is an
    // explicit request to re-analyse; "retry failed" keeps completed ones).
    await runAutoDetect(targets.map((s) => ({ id: s.id, state: "pending" as const })));
  }

  /** Retries ONLY the failed scenes from the last pass — completed and
   *  skipped scenes are never re-billed. */
  async function handleRetryFailedScenes() {
    if (!batchStates || batchProgress) return;
    const failedIds = batchStates.filter((i) => i.state === "failed").map((i) => i.id);
    if (failedIds.length === 0) return;
    const resumed = batchStates.map((i) => (i.state === "failed" ? { ...i, state: "pending" as const, reason: undefined } : i));
    await runAutoDetect(resumed, failedIds);
  }

  async function handleAnalyzeScene() {
    if (!activeStop?.media || activeStop.media.kind === "video" || !tour) return;
    setAnalyzingScene(true);
    setAnalyzeSceneError(null);
    const otherRoomTitles = tour.stops.filter((s) => s.id !== activeStop.id).map((s) => s.title);
    const result = await analyzeScene(activeStop.media.dataUrl, otherRoomTitles);
    setAnalyzingScene(false);
    if (!result.ok) {
      setAnalyzeSceneError(result.error);
      return;
    }
    setSuggestedStage(result.analysis.constructionStage);
    updateStop(activeStop.id, {
      title: result.analysis.roomLabel,
      note: result.analysis.description || activeStop.note,
    });
  }

  // Stage D (Phase 6): generate an illustrative interior concept for the
  // active scene's photo. The result is previewed and explicitly accepted or
  // discarded — never silently applied.
  async function handleInteriorConcept() {
    if (!activeStop?.media || activeStop.media.kind === "video") return;
    setInteriorBusy(true);
    setInteriorError(null);
    setInteriorPreview(null);
    const result = await generateInteriorConcept(activeStop.media.dataUrl, interiorStyle);
    setInteriorBusy(false);
    if (!result.ok) {
      setInteriorError(result.error);
      return;
    }
    setInteriorPreview(result.imageBase64);
    setInteriorPreviewMime(result.mimeType);
  }

  async function handleSuggestSequence() {
    if (!tour || tour.stops.length < 2) return;
    setSuggestingSequence(true);
    setSequenceError(null);
    const result = await suggestSequence(tour.stops.map((s) => ({ id: s.id, title: s.title, note: s.note })));
    setSuggestingSequence(false);
    if (result.ok) {
      setSequenceSuggestion(result.suggestion);
    } else {
      setSequenceError(result.error);
    }
  }

  /** Applies the AI-suggested scene order — explicit user action only. */
  function applySequenceSuggestion() {
    if (!tour || !sequenceSuggestion) return;
    const byId = new Map(tour.stops.map((s) => [s.id, s]));
    const reordered = sequenceSuggestion.orderedIds.map((sid) => byId.get(sid)).filter(Boolean) as Stop[];
    if (reordered.length === tour.stops.length) {
      persist({ ...tour, stops: reordered });
    }
    setSequenceSuggestion(null);
  }

  async function handleSuggestHotspots() {
    if (!tour || tour.stops.length < 2) return;
    setSuggestingHotspots(true);
    const suggestions = await suggestHotspots(
      tour.stops.map((s) => ({ id: s.id, title: s.title, note: s.note }))
    );
    setSuggestingHotspots(false);
    setHotspotSuggestions(suggestions);
  }

  function acceptHotspotSuggestion(s: HotspotSuggestion) {
    if (!tour) return;
    const fromStop = tour.stops.find((st) => st.id === s.fromId);
    if (!fromStop) return;
    const hotspot: Hotspot = {
      id: crypto.randomUUID(),
      targetStopId: s.toId,
      label: s.label,
      yaw: 0,
      pitch: 0,
      iconStyle: "chevron",
    };
    updateStop(fromStop.id, { hotspots: [...fromStop.hotspots, hotspot] });
    setHotspotSuggestions((list) => list.filter((x) => x !== s));
  }

  function dismissHotspotSuggestion(s: HotspotSuggestion) {
    setHotspotSuggestions((list) => list.filter((x) => x !== s));
  }

  function handleFloorPlanFile(file: File) {
    if (!activeStop) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const floorPlanDataUrl = reader.result as string;
      setRender3dError(null);
      setGenerating3D(true);
      const result = await generate3DRender(floorPlanDataUrl, render3dStyle);
      setGenerating3D(false);

      if (!result.ok) {
        setRender3dError(
          result.reason === "capped"
            ? "You've used all your free 3D renders for now."
            : `Couldn't generate a 3D render${result.detail ? ` — ${result.detail}` : " — try a clearer floor plan photo."}`
        );
        return;
      }

      updateStop(activeStop.id, {
        note: buildSyntheticNote(activeStop.note, SYNTHETIC_3D_MARKER),
        media: { kind: "image", dataUrl: result.dataUrl, synthetic: true },
      });
    };
    reader.readAsDataURL(file);
  }

  function addHotspot(stop: Stop, yaw: number, pitch: number) {
    if (!tour) return;
    const otherStops = tour.stops.filter((s) => s.id !== stop.id);
    const defaultTarget = otherStops[0];
    const hotspot: Hotspot = {
      id: crypto.randomUUID(),
      targetStopId: defaultTarget?.id ?? "",
      label: defaultTarget ? `Go to ${defaultTarget.title}` : "Untitled link",
      yaw,
      pitch,
      iconStyle: "chevron",
    };
    updateStop(stop.id, { hotspots: [...stop.hotspots, hotspot] });
    setActiveTool("select");
  }

  function updateHotspot(stop: Stop, hotspotId: string, patch: Partial<Hotspot>) {
    const hotspots = stop.hotspots.map((h) => (h.id === hotspotId ? { ...h, ...patch } : h));
    updateStop(stop.id, { hotspots });
  }

  function removeHotspot(stop: Stop, hotspotId: string) {
    updateStop(stop.id, { hotspots: stop.hotspots.filter((h) => h.id !== hotspotId) });
  }

  function acceptPanoramaAsRegularPhoto() {
    if (!panoramaWarning) return;
    updateStop(panoramaWarning.stopId, {
      media: { kind: "image", dataUrl: panoramaWarning.dataUrl },
    });
    setPanoramaWarning(null);
  }

  function acceptPanoramaAnyway() {
    if (!panoramaWarning) return;
    const { stopId, dataUrl } = panoramaWarning;
    updateStop(stopId, { media: { kind: "panorama", dataUrl } });
    setPanoramaWarning(null);
    runPanoramaPipeline(stopId, "panorama", dataUrl);
  }

  function dismissPanoramaWarning() {
    setPanoramaWarning(null);
  }

  async function acceptPanoramaAutoGenerate() {
    if (!panoramaWarning) return;
    const { stopId, dataUrl: sourcePhoto } = panoramaWarning;
    setPanoramaWarning(null);
    setGeneratingPanorama(true);

    const result = await generatePanoramaFromPhoto(sourcePhoto);
    setGeneratingPanorama(false);

    if (!result.ok) {
      // Fall back to the plain photo rather than leaving the stop empty —
      // the person can retry via "Replace media" if they want.
      setPanoramaGenError(
        `Couldn't auto-generate a 360° — used the plain photo instead.${result.detail ? ` (${result.detail})` : ""}`
      );
      updateStop(stopId, { media: { kind: "image", dataUrl: sourcePhoto } });
      return;
    }

    updateStop(stopId, {
      note: buildSyntheticNote(tour?.stops.find((s) => s.id === stopId)?.note),
      media: { kind: "panorama", dataUrl: result.dataUrl, synthetic: true },
    });
    runPanoramaPipeline(stopId, "panorama", result.dataUrl);
  }

  async function handlePublish() {
    if (!tour) return;
    setPublishState("publishing");
    setPublishError(null);
    const result = await publishTour(tour);
    if (result.ok) {
      // No auto-clipboard here any more: the SharePanel below shows the
      // tagged share link with an explicit copy button, so the agent
      // always copies the URL they meant to (and can pick QR / WhatsApp
      // / embed instead).
      setPublishState("done");
    } else {
      setPublishError(result.error);
      setPublishState("error");
    }
  }

  if (!tour) return null;

  const activeStop = tour.stops[activeIndex];
  const activeStopHasPanorama = activeStop?.media?.kind === "panorama" || activeStop?.media?.kind === "wide";

  function selectTool(tool: Tool) {
    if (COMING_SOON_TOOLS.includes(tool)) return;
    if (tool === "image") {
      fileInputRef.current?.click();
      return;
    }
    setActiveTool(tool);
  }

  return (
    <div className="flex h-[100dvh] flex-col overflow-hidden bg-bone text-charcoal">
      {panoramaWarning && (
        <PanoramaWarningModal
          check={panoramaWarning.check}
          onAutoGenerate={acceptPanoramaAutoGenerate}
          onUseAsPhoto={acceptPanoramaAsRegularPhoto}
          onChooseDifferent={dismissPanoramaWarning}
          onUseAnyway={acceptPanoramaAnyway}
        />
      )}
      {generatingPanorama && <GeneratingPanoramaModal />}
      {showMarketing && (
        <MarketingModal
          tour={tour}
          onClose={() => setShowMarketing(false)}
          onSaveDraft={(drafts) => persist({ ...tour, marketingDrafts: drafts })}
        />
      )}
      {planStudioOpen && (
        <React.Suspense
          fallback={
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/70">
              <Loader2 className="animate-spin text-bone" size={22} />
            </div>
          }
        >
          <PlanStudio
            tour={tour}
            onChangeTour={(updated) => persist(updated)}
            onClose={() => setPlanStudioOpen(false)}
            onOpenScene={(stopId) => {
              const idx = tour.stops.findIndex((s) => s.id === stopId);
              if (idx >= 0) setActiveIndex(idx);
            }}
          />
        </React.Suspense>
      )}
      {smartUploadOpen && (
        <SmartUploadPanel
          existingStops={tour.stops.map((s) => ({
            id: s.id,
            title: s.title,
            mediaDataUrl: s.media && s.media.kind !== "video" ? s.media.dataUrl : null,
          }))}
          onClose={() => setSmartUploadOpen(false)}
          onApply={applySmartUpload}
        />
      )}
      {floorPlanOpen && (
        <FloorPlanEditor
          tour={tour}
          activeStopId={activeStop?.id ?? null}
          onSelectStop={(stopId) => {
            const idx = tour.stops.findIndex((s) => s.id === stopId);
            if (idx >= 0) setActiveIndex(idx);
          }}
          onChange={(floorPlan) => persist({ ...tour, floorPlan })}
          onClose={() => setFloorPlanOpen(false)}
        />
      )}
      {constructionOpen && (
        <ConstructionPanel
          tour={tour}
          activeStopId={activeStop?.id ?? null}
          onChange={(updated) => persist(updated)}
          onClose={() => setConstructionOpen(false)}
          suggestedStage={suggestedStage}
        />
      )}
      {brandingOpen && (
        <BrandingPanel
          tour={tour}
          onChange={(branding) => persist({ ...tour, branding })}
          onClose={() => setBrandingOpen(false)}
        />
      )}

      {/* Top bar */}
      <header className="flex shrink-0 items-center gap-3 border-b border-charcoal/10 px-3 py-2.5 sm:px-5">
        <button
          onClick={() => navigate("/dashboard")}
          className="flex shrink-0 items-center gap-1.5 text-charcoal/60 hover:text-charcoal"
          aria-label="All walkthroughs"
        >
          <ArrowLeft size={16} />
          <MapPin className="text-brass" size={16} strokeWidth={2.5} />
          <span className="hidden font-display text-sm font-semibold tracking-tight sm:inline">Tourly</span>
        </button>

        <div className="mx-1 h-5 w-px shrink-0 bg-charcoal/10" />

        <div className="flex min-w-0 flex-1 items-center gap-2">
          <input
            value={tour.name}
            onChange={(e) => persist({ ...tour, name: e.target.value })}
            className="min-w-0 flex-1 truncate bg-transparent text-sm font-medium outline-none sm:flex-none sm:w-56"
            placeholder="Walkthrough name"
          />
          <span className="hidden shrink-0 text-xs text-charcoal/30 sm:inline">/ Edit</span>
        </div>

        <div className="flex shrink-0 items-center gap-1.5 text-xs text-emerald-600">
          <Check size={14} />
          <span className="hidden sm:inline">Saved</span>
        </div>

        <button
          onClick={handleAnalyzeAllScenes}
          disabled={!!batchProgress || tour.stops.length === 0}
          className="flex shrink-0 items-center gap-1.5 rounded-md border border-charcoal/15 px-2 py-1.5 text-xs font-medium text-charcoal/70 hover:border-charcoal/30 disabled:opacity-40 sm:px-3"
          title="AI: name and describe every scene that has a photo"
          aria-label="Auto-detect all scenes"
        >
          {batchProgress ? <Loader2 size={13} className="animate-spin" /> : <Wand2 size={13} />}
          {batchProgress ? <span>{`${batchProgress.done}/${batchProgress.total}`}</span> : <span className="hidden md:inline">Auto-detect all</span>}
        </button>
        <button
          onClick={() => setShowMarketing(true)}
          className="flex shrink-0 items-center gap-1.5 rounded-md border border-charcoal/15 px-2 py-1.5 text-xs font-medium text-charcoal/70 hover:border-charcoal/30 sm:px-3"
          title="AI: write listing copy from this tour"
          aria-label="Marketing copy"
        >
          <Megaphone size={13} /> <span className="hidden md:inline">Marketing</span>
        </button>
        <button
          onClick={() => navigate(`/tour/${tour.id}`)}
          disabled={tour.stops.length === 0}
          className="flex shrink-0 items-center gap-1.5 rounded-md border border-charcoal/15 px-3 py-1.5 text-xs font-medium text-charcoal/70 hover:border-charcoal/30 disabled:opacity-30"
        >
          Preview <ExternalLink size={13} />
        </button>
        <button
          onClick={handlePublish}
          disabled={tour.stops.length === 0 || publishState === "publishing"}
          className={`flex shrink-0 items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors disabled:opacity-30 ${
            publishState === "done"
              ? "bg-emerald-600 text-white"
              : publishState === "error"
              ? "bg-red-500 text-white"
              : "bg-sage text-white hover:opacity-90"
          }`}
        >
          {publishState === "publishing" ? (
            <Loader2 size={13} className="animate-spin" />
          ) : publishState === "done" ? (
            <Check size={13} />
          ) : (
            <Share2 size={13} />
          )}
          {publishState === "publishing" ? "Publishing…" : publishState === "done" ? "Published" : "Publish"}
        </button>
      </header>

      {publishState === "error" && publishError && (
        <div className="shrink-0 border-b border-red-200 bg-red-50 px-5 py-1.5 text-xs text-red-600">
          {publishError}
        </div>
      )}
      {publishState === "done" && (
        <div className="shrink-0 border-b border-emerald-200 bg-emerald-50/70 px-5 py-3">
          <p className="text-xs font-medium text-emerald-800">
            {tour.viewPassword?.trim() ? "Published with password protection — share it:" : "Published — anyone with the link can view it now."}
          </p>
          <div className="mt-2">
            <SharePanel
              tourId={tour.id}
              tourName={tour.name}
              passwordProtected={Boolean(tour.viewPassword?.trim())}
            />
          </div>
        </div>
      )}
      {blurWarningStopId === activeStop?.id && (
        <div className="flex shrink-0 items-center justify-between gap-3 border-b border-amber-200 bg-amber-50 px-5 py-1.5 text-xs text-amber-700">
          <span className="flex items-center gap-1.5">
            <AlertTriangle size={13} /> This photo looks a little blurry — consider retaking it for a sharper tour.
          </span>
          <button onClick={() => setBlurWarningStopId(null)} className="text-amber-600 hover:text-amber-800">
            <X size={13} />
          </button>
        </div>
      )}
      {batchError && (
        <div className="flex shrink-0 items-center justify-between gap-3 border-b border-red-200 bg-red-50 px-5 py-1.5 text-xs text-red-600">
          <span className="flex items-center gap-1.5">
            <AlertTriangle size={13} /> Auto-detect stopped: {batchError}
          </span>
          <span className="flex items-center gap-2">
            {!batchProgress && batchStates?.some((i) => i.state === "failed") && (
              <button
                onClick={handleRetryFailedScenes}
                className="rounded border border-red-300 px-2 py-0.5 font-medium text-red-700 hover:bg-red-100"
                title="Retry only the scenes that failed — completed ones are kept"
              >
                Retry failed ({batchStates.filter((i) => i.state === "failed").length})
              </button>
            )}
            <button onClick={() => setBatchError(null)} className="text-red-500 hover:text-red-700">
              <X size={13} />
            </button>
          </span>
        </div>
      )}
      {!batchError && !batchProgress && batchStates && (() => {
        const s = summarize(batchStates);
        if (s.total === 0 || (s.failed === 0 && s.skipped === 0)) return null;
        return (
          <div className="flex shrink-0 items-center justify-between gap-3 border-b border-emerald-200 bg-emerald-50 px-5 py-1.5 text-xs text-emerald-800">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 size={13} /> Auto-detect: {s.completed} done{s.skipped ? `, ${s.skipped} skipped` : ""}
              {s.failed ? `, ${s.failed} failed` : ""}. Successful scenes are saved.
            </span>
            {s.failed > 0 && (
              <button
                onClick={handleRetryFailedScenes}
                className="rounded border border-emerald-300 px-2 py-0.5 font-medium text-emerald-800 hover:bg-emerald-100"
                title="Retry only the failed scenes"
              >
                Retry failed ({s.failed})
              </button>
            )}
            <button onClick={() => setBatchStates(null)} className="text-emerald-600 hover:text-emerald-800">
              <X size={13} />
            </button>
          </div>
        );
      })()}
      {panoramaGenError && (
        <div className="flex shrink-0 items-center justify-between gap-3 border-b border-red-200 bg-red-50 px-5 py-1.5 text-xs text-red-600">
          <span className="flex items-center gap-1.5">
            <AlertTriangle size={13} /> {panoramaGenError}
          </span>
          <button onClick={() => setPanoramaGenError(null)} className="text-red-500 hover:text-red-700">
            <X size={13} />
          </button>
        </div>
      )}
      {storageError && (
        <div className="flex shrink-0 items-center justify-between gap-3 border-b border-red-200 bg-red-50 px-5 py-1.5 text-xs text-red-600">
          <span className="flex items-center gap-1.5">
            <AlertTriangle size={13} /> {storageError}
          </span>
          <button onClick={() => setStorageError(null)} className="text-red-500 hover:text-red-700">
            <X size={13} />
          </button>
        </div>
      )}

      {/* 3-panel body */}
      <div className="flex min-h-0 flex-1 flex-col overflow-y-auto lg:flex-row lg:overflow-hidden">
        {/* Left: Scenes */}
        <aside className="flex shrink-0 flex-col border-b border-charcoal/10 bg-white/60 lg:w-52 xl:w-56 lg:border-b-0 lg:border-r lg:overflow-y-auto">
          <div className="flex items-center justify-between px-3 py-2.5">
            <span className="font-mono text-[11px] uppercase tracking-wider text-charcoal/40">Scenes</span>
            {selectedStopIds.size > 0 ? (
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-charcoal/50">{selectedStopIds.size} selected</span>
                <button
                  onClick={bulkDeleteSelected}
                  className="flex items-center gap-1 text-xs font-medium text-red-500 hover:underline"
                >
                  <Trash2 size={11} /> Delete
                </button>
                <button
                  onClick={() => setSelectedStopIds(new Set())}
                  className="text-charcoal/30 hover:text-charcoal"
                >
                  <X size={12} />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2.5">
                <button
                  onClick={() => setSmartUploadOpen(true)}
                  className="flex items-center gap-1 rounded border border-brass/50 bg-brass/10 px-1.5 py-0.5 text-[10px] font-semibold text-brass hover:bg-brass/20"
                  title="Add many photos at once — duplicates and quality issues are flagged, AI suggests titles and order"
                >
                  <Wand2 size={10} /> Smart
                </button>
                <button
                  onClick={addStop}
                  className="flex items-center gap-1 text-xs font-medium text-brass hover:underline"
                >
                  <Plus size={12} /> Add
                </button>
              </div>
            )}
          </div>
          <div className="flex gap-2 overflow-x-auto px-2 pb-3 lg:flex-col lg:gap-1 lg:overflow-visible lg:pb-4">
            {tour.stops.map((stop, i) => {
              const isActive = i === activeIndex;
              const isSelected = selectedStopIds.has(stop.id);
              return (
                <div
                  key={stop.id}
                  onClick={() => setActiveIndex(i)}
                  className={`group flex w-32 shrink-0 cursor-pointer items-center gap-2 rounded-md border px-2 py-2 lg:w-auto ${
                    isActive ? "border-brass bg-brass/10" : "border-transparent hover:bg-charcoal/5"
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={isSelected}
                    onClick={(e) => e.stopPropagation()}
                    onChange={() => toggleStopSelection(stop.id)}
                    className="h-3.5 w-3.5 shrink-0 accent-brass"
                  />
                  <SceneThumb stop={stop} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-xs font-medium">{stop.title || `Stop ${i + 1}`}</p>
                  </div>
                  <div className="hidden shrink-0 items-center gap-0.5 sm:group-hover:flex">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        moveStop(i, -1);
                      }}
                      disabled={i === 0}
                      className="rounded p-0.5 text-charcoal/30 hover:text-charcoal disabled:opacity-20"
                    >
                      <ChevronUp size={12} />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        moveStop(i, 1);
                      }}
                      disabled={i === tour.stops.length - 1}
                      className="rounded p-0.5 text-charcoal/30 hover:text-charcoal disabled:opacity-20"
                    >
                      <ChevronDown size={12} />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        removeStop(stop.id);
                      }}
                      className="rounded p-0.5 text-charcoal/30 hover:text-red-500"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                </div>
              );
            })}
            {tour.stops.length === 0 && (
              <p className="px-2 py-4 text-xs text-charcoal/40">No scenes yet — add your first one.</p>
            )}
          </div>
        </aside>

        {/* Center: viewer */}
        <main className="flex flex-1 flex-col items-center justify-center overflow-y-auto bg-charcoal/[0.03] p-4 sm:p-8">
          {activeStop ? (
            <div className="w-full max-w-2xl">
              <div className="mb-3 flex items-center justify-center gap-2">
                <button
                  onClick={() => setActiveIndex((i) => Math.max(0, i - 1))}
                  disabled={activeIndex === 0}
                  className="rounded-full border border-charcoal/15 p-1.5 disabled:opacity-20"
                >
                  <ChevronLeft size={16} />
                </button>
                <span className="font-mono text-xs text-charcoal/40">
                  Stop {activeIndex + 1} of {tour.stops.length}
                </span>
                <button
                  onClick={() => setActiveIndex((i) => Math.min(tour.stops.length - 1, i + 1))}
                  disabled={activeIndex === tour.stops.length - 1}
                  className="rounded-full border border-charcoal/15 p-1.5 disabled:opacity-20"
                >
                  <ChevronRight size={16} />
                </button>
              </div>

              {activeStopHasPanorama ? (
                <div className="relative aspect-video w-full overflow-hidden rounded-lg border border-charcoal/15 bg-black">
                  <PanoramaViewer
                    imageUrl={activeStop.media!.dataUrl}
                    mode={activeStop.media!.kind === "wide" ? "cylinder" : "sphere"}
                    hotspots={activeStop.hotspots}
                    placementMode={placingHotspot}
                    onPlacePoint={(yaw, pitch) => addHotspot(activeStop, yaw, pitch)}
                    editable={!placingHotspot}
                    onRepositionHotspot={(hotspotId, yaw, pitch) =>
                      updateHotspot(activeStop, hotspotId, { yaw, pitch })
                    }
                  />
                  {placingHotspot && (
                    <span className="pointer-events-none absolute left-1/2 top-3 -translate-x-1/2 rounded-full bg-brass px-3 py-1 text-xs font-medium text-bone">
                      Click the panorama to place a hotspot
                    </span>
                  )}
                </div>
              ) : (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="relative flex aspect-video w-full cursor-pointer items-center justify-center overflow-hidden rounded-lg border-2 border-dashed border-charcoal/20 bg-white"
                >
                  {activeStop.media ? (
                    activeStop.media.kind === "image" ? (
                      <>
                        <img src={activeStop.media.dataUrl} alt="" className="h-full w-full object-cover" />
                        {activeStop.media.synthetic && (
                          <span className="pointer-events-none absolute bottom-2 left-2 flex items-center gap-1 rounded-full bg-ink/70 px-2.5 py-1 text-[10px] font-medium text-brass-soft backdrop-blur">
                            <Box size={10} /> AI-generated 3D render — not a real photo
                          </span>
                        )}
                      </>
                    ) : (
                      <video src={activeStop.media.dataUrl} className="h-full w-full object-cover" controls />
                    )
                  ) : (
                    <div className="flex flex-col items-center gap-2 text-charcoal/40">
                      <Upload size={22} />
                      <span className="text-sm font-medium text-charcoal/70">Is scene mein photo add karo</span>
                      <span className="max-w-xs text-center text-xs leading-relaxed">
                        1. Yahan tap karke 360° ya photo chuno · 2. ✨ Auto-detect se naam pao · 3. 2+ scenes hone par hotspots banao
                      </span>
                    </div>
                  )}
                </div>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept={uploadKind === "video" ? "video/*" : "image/*"}
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleFile(file, activeStop.id);
                  e.target.value = "";
                }}
              />
            </div>
          ) : (
            <div className="text-center">
              <p className="font-display text-lg text-charcoal/50">No scenes yet</p>
              <p className="mx-auto mt-1 max-w-xs text-xs text-charcoal/45">
                Pehle ek scene banao, phir usme photo upload karo. Tour ke har room ke liye ek scene.
              </p>
              <button
                onClick={addStop}
                className="mt-4 rounded-md bg-charcoal px-5 py-2.5 text-sm font-medium text-bone"
              >
                Add first scene
              </button>
            </div>
          )}
        </main>

        {/* Right: Scene settings */}
        <aside className="flex shrink-0 flex-col border-t border-charcoal/10 bg-white/60 lg:w-80 xl:w-96 lg:border-l lg:border-t-0 lg:overflow-y-auto">
          {activeStop ? (
            <div className="flex flex-col gap-5 px-4 py-4">
              <span className="font-mono text-[11px] uppercase tracking-wider text-charcoal/40">Scene settings</span>

              <div>
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-medium uppercase tracking-wide text-charcoal/40">Name</label>
                  <button
                    onClick={handleAnalyzeScene}
                    disabled={!activeStop.media || activeStop.media.kind === "video" || analyzingScene}
                    className="flex items-center gap-1 text-[11px] font-medium text-brass hover:underline disabled:opacity-30"
                    title="Ask AI to suggest a room name and description from the photo"
                  >
                    {analyzingScene ? <Loader2 size={11} className="animate-spin" /> : <Wand2 size={11} />}
                    Auto-detect
                  </button>
                </div>
                <input
                  value={activeStop.title}
                  onChange={(e) => updateStop(activeStop.id, { title: e.target.value })}
                  placeholder="e.g. Living Room"
                  className="mt-1.5 w-full rounded-md border border-charcoal/15 bg-white px-3 py-2 text-sm outline-none focus:border-brass"
                />
                {analyzeSceneError && (
                  <p className="mt-1 text-[10px] text-red-500">{analyzeSceneError}</p>
                )}
              </div>

              <div>
                <label className="text-[11px] font-medium uppercase tracking-wide text-charcoal/40">Media</label>
                <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                  {(["panorama", "image", "video"] as const).map((k) => (
                    <button
                      key={k}
                      onClick={() => setUploadKind(k)}
                      className={`rounded-full border px-2.5 py-1 text-[11px] font-medium transition-colors ${
                        uploadKind === k
                          ? "border-brass bg-brass/15 text-brass"
                          : "border-charcoal/15 text-charcoal/50 hover:border-charcoal/30"
                      }`}
                    >
                      {k === "panorama" ? "360°" : k === "image" ? "Photo" : "Video"}
                    </button>
                  ))}
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="ml-auto text-[11px] font-medium text-brass hover:underline"
                  >
                    {activeStop.media ? "Replace" : "Upload"}
                  </button>
                </div>
              </div>

              <div className="rounded-md border border-dashed border-charcoal/15 p-3">
                <label className="flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wide text-charcoal/40">
                  <Box size={12} /> 3D render from floor plan
                </label>
                <p className="mt-1 text-[10px] leading-relaxed text-charcoal/40">
                  Concept image banane ke 3 steps: (1) floor plan ki photo chuno · (2) style chuno · (3) Generate.
                  Ye real 3D model nahi hai aur scale par nahi hai. Result ek naya photo stop ban jata hai.
                </p>
                <div className="mt-2 flex flex-wrap items-center gap-1.5">
                  {(["modern", "minimal", "cozy", "luxury"] as const).map((s) => (
                    <button
                      key={s}
                      onClick={() => setRender3dStyle(s)}
                      className={`rounded-full border px-2.5 py-1 text-[11px] font-medium capitalize transition-colors ${
                        render3dStyle === s
                          ? "border-brass bg-brass/15 text-brass"
                          : "border-charcoal/15 text-charcoal/50 hover:border-charcoal/30"
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => floorPlanInputRef.current?.click()}
                  disabled={generating3D || remaining3DRenders() <= 0}
                  className="mt-2.5 flex w-full items-center justify-center gap-1.5 rounded-md bg-charcoal px-3 py-2 text-[11px] font-medium text-bone hover:bg-ink disabled:opacity-30"
                >
                  {generating3D ? (
                    <>
                      <Loader2 size={11} className="animate-spin" /> Generating…
                    </>
                  ) : remaining3DRenders() <= 0 ? (
                    "3D render limit reached for now"
                  ) : (
                    <>
                      <Box size={11} /> Upload floor plan & generate ({remaining3DRenders()} left)
                    </>
                  )}
                </button>
                {render3dError && <p className="mt-1.5 text-[10px] text-red-500">{render3dError}</p>}
                <input
                  ref={floorPlanInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleFloorPlanFile(file);
                    e.target.value = "";
                  }}
                />
              </div>

              {/* Stage D (Phase 6): optional AI interior concept from a photo */}
              <div className="rounded-md border border-dashed border-charcoal/15 p-3">
                <label className="flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wide text-charcoal/40">
                  <Sparkles size={12} /> Interior concept (AI)
                </label>
                <p className="mt-1 text-[10px] leading-relaxed text-charcoal/40">
                  Illustrative restyle of this scene's photo — an idea of what the room could look
                  like, NOT the property's actual condition.
                </p>
                <div className="mt-2 flex flex-wrap items-center gap-1.5">
                  {INTERIOR_STYLES.map((s) => (
                    <button
                      key={s.id}
                      onClick={() => setInteriorStyle(s.id)}
                      className={`rounded-full border px-2.5 py-1 text-[11px] font-medium transition-colors ${
                        interiorStyle === s.id
                          ? "border-brass bg-brass/15 text-brass"
                          : "border-charcoal/15 text-charcoal/50 hover:border-charcoal/30"
                      }`}
                    >
                      {s.label}
                    </button>
                  ))}
                  <button
                    onClick={handleInteriorConcept}
                    disabled={!activeStop.media || activeStop.media.kind === "video" || interiorBusy}
                    className="ml-auto flex items-center gap-1 text-[11px] font-medium text-brass hover:underline disabled:opacity-30"
                    title="Generate an illustrative interior concept from this scene's photo"
                  >
                    {interiorBusy ? <Loader2 size={11} className="animate-spin" /> : <Sparkles size={11} />}
                    {interiorBusy ? "Generating…" : "Generate"}
                  </button>
                </div>
                {interiorError && (
                  <p className="mt-1.5 text-[10px] text-red-500">{interiorError}</p>
                )}
                {interiorPreview && (
                  <div className="mt-2">
                    <img
                      src={`data:${interiorPreviewMime};base64,${interiorPreview}`}
                      alt="AI interior concept preview"
                      className="w-full rounded border border-brass/40 object-cover"
                    />
                    <p className="mt-1 text-[9px] leading-relaxed text-amber-700">
                      AI interior concept — illustrative only, not the actual property.
                    </p>
                    <div className="mt-1.5 flex gap-1.5">
                      <button
                        onClick={() => {
                          if (
                            window.confirm(
                              "Replace this scene's photo with the AI interior concept? The concept is illustrative — it will be marked as AI-generated."
                            )
                          ) {
                            updateStop(activeStop.id, {
                              media: {
                                kind: "image",
                                dataUrl: `data:${interiorPreviewMime};base64,${interiorPreview}`,
                                synthetic: true,
                              },
                            });
                            setInteriorPreview(null);
                          }
                        }}
                        className="flex-1 rounded bg-charcoal px-2 py-1.5 text-[10px] font-semibold text-bone"
                      >
                        Use as scene photo
                      </button>
                      <button
                        onClick={() => setInteriorPreview(null)}
                        className="flex-1 rounded border border-charcoal/15 px-2 py-1.5 text-[10px] font-medium text-charcoal/60"
                      >
                        Discard
                      </button>
                    </div>
                  </div>
                )}
              </div>

              <div>
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-medium uppercase tracking-wide text-charcoal/40">
                    Hotspots ({activeStop.hotspots.length})
                  </label>
                  <div className="flex items-center gap-2.5">
                    <button
                      onClick={handleSuggestHotspots}
                      disabled={tour.stops.length < 2 || suggestingHotspots}
                      className="flex items-center gap-1 text-[11px] font-medium text-charcoal/50 hover:text-charcoal disabled:opacity-30"
                      title="Ask AI to suggest which rooms should connect"
                    >
                      {suggestingHotspots ? <Loader2 size={11} className="animate-spin" /> : <Wand2 size={11} />}
                      Suggest
                    </button>
                    <button
                      onClick={() => setActiveTool(placingHotspot ? "select" : "hotspot")}
                      disabled={!activeStopHasPanorama || tour.stops.length < 2}
                      className={`flex items-center gap-1 text-[11px] font-medium disabled:opacity-30 ${
                        placingHotspot ? "text-brass" : "text-charcoal/50 hover:text-charcoal"
                      }`}
                    >
                      <Plus size={11} /> Add
                    </button>
                  </div>
                </div>
                {hotspotSuggestions.filter((s) => s.fromId === activeStop.id).length > 0 && (
                  <ul className="mt-2 space-y-1.5">
                    {hotspotSuggestions
                      .filter((s) => s.fromId === activeStop.id)
                      .map((s, i) => {
                        const target = tour.stops.find((st) => st.id === s.toId);
                        return (
                          <li
                            key={`${s.fromId}-${s.toId}-${i}`}
                            className="flex items-center justify-between gap-2 rounded-md border border-dashed border-brass/40 bg-brass/5 px-2.5 py-1.5"
                          >
                            <span className="text-xs text-charcoal/70">
                              <Wand2 size={10} className="mr-1 inline text-brass" />
                              {s.label} <span className="text-charcoal/40">({target?.title})</span>
                            </span>
                            <div className="flex items-center gap-1 shrink-0">
                              <button
                                onClick={() => acceptHotspotSuggestion(s)}
                                className="rounded px-1.5 py-0.5 text-[10px] font-medium text-brass hover:bg-brass/15"
                              >
                                Add
                              </button>
                              <button
                                onClick={() => dismissHotspotSuggestion(s)}
                                className="rounded p-0.5 text-charcoal/30 hover:text-red-500"
                              >
                                <X size={11} />
                              </button>
                            </div>
                          </li>
                        );
                      })}
                  </ul>
                )}
                {!activeStopHasPanorama ? (
                  <p className="mt-2 text-xs text-charcoal/40">Upload a 360° photo to add hotspots.</p>
                ) : tour.stops.length < 2 ? (
                  <p className="mt-2 text-xs text-charcoal/40">
                    Add another scene first — a hotspot needs somewhere to link to.
                  </p>
                ) : activeStop.hotspots.length === 0 ? (
                  <p className="mt-2 text-xs text-charcoal/40">
                    No links yet. Use the Hotspot tool below and click the panorama.
                  </p>
                ) : (
                  <ul className="mt-2 space-y-2.5">
                    {activeStop.hotspots.map((h) => (
                      <li key={h.id} className="rounded-md border border-charcoal/10 bg-bone/60 p-2.5">
                        <div className="flex items-center gap-1.5">
                          <select
                            value={h.targetStopId}
                            onChange={(e) => {
                              const target = tour.stops.find((s) => s.id === e.target.value);
                              updateHotspot(activeStop, h.id, {
                                targetStopId: e.target.value,
                                label: target ? `Go to ${target.title}` : h.label,
                              });
                            }}
                            className="flex-1 rounded-md border border-charcoal/15 bg-white px-2 py-1.5 text-xs"
                          >
                            {tour.stops
                              .filter((s) => s.id !== activeStop.id)
                              .map((s) => (
                                <option key={s.id} value={s.id}>
                                  {s.title}
                                </option>
                              ))}
                          </select>
                          <button
                            onClick={() => removeHotspot(activeStop, h.id)}
                            className="text-charcoal/30 hover:text-red-500"
                          >
                            <X size={13} />
                          </button>
                        </div>
                        <div className="mt-2 flex items-center gap-1.5">
                          <span className="mr-1 text-[10px] uppercase tracking-wide text-charcoal/35">Icon</span>
                          {(["chevron", "circle", "arrow"] as const).map((style) => (
                            <button
                              key={style}
                              onClick={() => updateHotspot(activeStop, h.id, { iconStyle: style })}
                              className={`flex h-6 w-6 items-center justify-center rounded-full border transition-colors ${
                                (h.iconStyle ?? "chevron") === style
                                  ? "border-brass bg-brass/15 text-brass"
                                  : "border-charcoal/15 text-charcoal/40 hover:border-charcoal/30"
                              }`}
                              title={style}
                            >
                              <HotspotIconPreview style={style} />
                            </button>
                          ))}
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              <div>
                <label className="text-[11px] font-medium uppercase tracking-wide text-charcoal/40">Notes</label>
                <textarea
                  value={activeStop.note}
                  onChange={(e) => updateStop(activeStop.id, { note: e.target.value })}
                  placeholder="Optional note visitors will see at this stop"
                  rows={3}
                  className="mt-1.5 w-full resize-none rounded-md border border-charcoal/15 bg-white px-3 py-2 text-sm outline-none focus:border-brass"
                />
              </div>

              <input
                value={tour.subtitle}
                onChange={(e) => persist({ ...tour, subtitle: e.target.value })}
                placeholder="Tour description (optional)"
                className="rounded-md border border-charcoal/15 bg-white px-3 py-2 text-xs text-charcoal/60 outline-none focus:border-brass"
              />

              <div>
                <label className="flex items-center gap-1 text-[11px] font-medium uppercase tracking-wide text-charcoal/40">
                  <MessageCircle size={11} /> WhatsApp enquiry
                </label>
                <input
                  value={tour.whatsappNumber ?? ""}
                  onChange={(e) => persist({ ...tour, whatsappNumber: e.target.value })}
                  placeholder="Country code + number, e.g. 919876543210"
                  className="mt-1.5 w-full rounded-md border border-charcoal/15 bg-white px-3 py-2 text-xs outline-none focus:border-brass"
                />
                <p className="mt-1 text-[10px] text-charcoal/35">
                  Shows a WhatsApp button on the public tour. Leave blank to hide it.
                </p>
              </div>

              <div>
                <label className="flex items-center gap-1 text-[11px] font-medium uppercase tracking-wide text-charcoal/40">
                  <Lock size={11} /> View password
                </label>
                <input
                  type="text"
                  value={tour.viewPassword ?? ""}
                  onChange={(e) => persist({ ...tour, viewPassword: e.target.value })}
                  placeholder="Leave blank for a public link"
                  className="mt-1.5 w-full rounded-md border border-charcoal/15 bg-white px-3 py-2 text-xs outline-none focus:border-brass"
                />
                <p className="mt-1 text-[10px] text-charcoal/35">
                  Applies on the next Publish — viewers must enter it to open the shared link. Clearing it and
                  republishing makes the link public again.
                </p>
              </div>

              <div>
                <label className="flex items-center gap-1 text-[11px] font-medium uppercase tracking-wide text-charcoal/40">
                  <Folder size={11} /> Folder
                </label>
                <input
                  value={tour.folder ?? ""}
                  onChange={(e) => persist({ ...tour, folder: e.target.value })}
                  placeholder="e.g. Gurgaon listings"
                  className="mt-1.5 w-full rounded-md border border-charcoal/15 bg-white px-3 py-2 text-xs outline-none focus:border-brass"
                />
              </div>
            </div>
          ) : (
            <div className="px-4 py-6 text-center text-xs text-charcoal/40">Add a scene to edit its settings.</div>
          )}

          {/* Tour-level tools (Features C/D/E) — available with or without
              scenes, so a floor plan or branding can be set up first. */}
          <div className="mt-auto border-t border-charcoal/10 px-4 py-4">
            <span className="font-mono text-[11px] uppercase tracking-wider text-charcoal/40">Tour tools</span>
            <div className="mt-2.5 flex flex-col gap-1.5">
              <button
                onClick={() => setFloorPlanOpen(true)}
                className="flex items-center gap-2 rounded-md border border-charcoal/10 bg-bone/60 px-2.5 py-2 text-xs font-medium text-charcoal/70 transition-colors hover:border-charcoal/30 hover:bg-white"
              >
                <MapPin size={12} className="shrink-0 text-brass" />
                <span className="flex-1 text-left">Floor plan & rooms</span>
                {tour.floorPlan && (
                  <span className="shrink-0 rounded-full bg-brass/15 px-1.5 py-0.5 font-mono text-[9px] text-brass">
                    {tour.floorPlan.markers.length} pin{tour.floorPlan.markers.length === 1 ? "" : "s"}
                  </span>
                )}
              </button>
              <button
                onClick={() => setPlanStudioOpen(true)}
                className="flex items-center gap-2 rounded-md border border-charcoal/10 bg-bone/60 px-2.5 py-2 text-xs font-medium text-charcoal/70 transition-colors hover:border-charcoal/30 hover:bg-white"
                title="Draw rooms, walls, doors and windows — then see the plan in 3D"
              >
                <Box size={12} className="shrink-0 text-brass" />
                <span className="flex-1 text-left">Plan studio (2D + 3D)</span>
                {(() => {
                  const rooms = tour.plan?.floors?.reduce((n, f) => n + (f.rooms?.length ?? 0), 0) ?? 0;
                  return rooms > 0 ? (
                    <span className="shrink-0 rounded-full bg-brass/15 px-1.5 py-0.5 font-mono text-[9px] text-brass">
                      {rooms} room{rooms === 1 ? "" : "s"}
                    </span>
                  ) : null;
                })()}
              </button>
              <button
                onClick={() => setConstructionOpen(true)}
                className="flex items-center gap-2 rounded-md border border-charcoal/10 bg-bone/60 px-2.5 py-2 text-xs font-medium text-charcoal/70 transition-colors hover:border-charcoal/30 hover:bg-white"
              >
                <History size={12} className="shrink-0 text-brass" />
                <span className="flex-1 text-left">Construction progress</span>
                {tour.snapshots?.length ? (
                  <span className="shrink-0 rounded-full bg-brass/15 px-1.5 py-0.5 font-mono text-[9px] text-brass">
                    {tour.snapshots.length}
                  </span>
                ) : null}
              </button>
              <button
                onClick={() => setBrandingOpen(true)}
                className="flex items-center gap-2 rounded-md border border-charcoal/10 bg-bone/60 px-2.5 py-2 text-xs font-medium text-charcoal/70 transition-colors hover:border-charcoal/30 hover:bg-white"
              >
                <Palette size={12} className="shrink-0 text-brass" />
                <span className="flex-1 text-left">Branding & white-label</span>
                {tour.branding?.agencyName ? (
                  <span className="max-w-[72px] shrink-0 truncate rounded-full bg-brass/15 px-1.5 py-0.5 font-mono text-[9px] text-brass">
                    {tour.branding.agencyName}
                  </span>
                ) : null}
              </button>
            </div>
          </div>
        </aside>
      </div>

      {/* Bottom toolbar */}
      <div className="flex shrink-0 items-center gap-1 overflow-x-auto border-t border-charcoal/10 bg-white px-2 py-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] md:justify-center md:px-3">
        <ToolButton icon={MousePointer2} label="Select" active={activeTool === "select"} onClick={() => selectTool("select")} />
        <ToolButton icon={Link2} label="Hotspot" active={activeTool === "hotspot"} onClick={() => selectTool("hotspot")} disabled={!activeStopHasPanorama || tour.stops.length < 2} />
        <ToolButton icon={MapPinned} label="Location" comingSoon onClick={() => selectTool("location")} />
        <ToolButton icon={Type} label="Text" comingSoon onClick={() => selectTool("text")} />
        <ToolButton icon={ImageIcon} label="Image" onClick={() => selectTool("image")} disabled={!activeStop} />
        <ToolButton icon={ZoomIn} label="Zoom" comingSoon onClick={() => selectTool("zoom")} />
      </div>
    </div>
  );
}

function ToolButton({
  icon: Icon,
  label,
  active,
  disabled,
  comingSoon,
  onClick,
}: {
  icon: typeof MousePointer2;
  label: string;
  active?: boolean;
  disabled?: boolean;
  comingSoon?: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled || comingSoon}
      title={comingSoon ? `${label} — coming soon` : label}
      className={`flex min-w-[56px] shrink-0 flex-col items-center gap-1 rounded-md px-2.5 py-1.5 text-[11px] font-medium transition-colors disabled:opacity-30 sm:min-w-[64px] sm:px-3 ${
        active ? "bg-brass/15 text-brass" : "text-charcoal/60 hover:bg-charcoal/5"
      }`}
    >
      <Icon size={16} strokeWidth={1.75} />
      {label}
    </button>
  );
}

function SceneThumb({ stop }: { stop: Stop }) {
  return (
    <div className="relative h-10 w-12 shrink-0 overflow-hidden rounded border border-charcoal/10 bg-charcoal/5">
      {stop.media ? (
        stop.media.kind === "video" ? (
          <video src={stop.media.dataUrl} className="h-full w-full object-cover" muted />
        ) : (
          <>
            <img src={stop.media.dataUrl} alt="" className="h-full w-full object-cover" />
            {stop.media.kind === "panorama" && stop.media.synthetic && (
              <span
                className="absolute bottom-0.5 right-0.5 rounded-full bg-ink/70 p-0.5 text-brass"
                title="AI-generated panorama — not a real capture"
              >
                <Sparkles size={8} />
              </span>
            )}
            {stop.media.kind === "image" && stop.media.synthetic && (
              <span
                className="absolute bottom-0.5 right-0.5 rounded-full bg-ink/70 p-0.5 text-brass"
                title="AI-generated 3D render — not a real photo"
              >
                <Box size={8} />
              </span>
            )}
            {stop.media.kind === "panorama" && !stop.media.synthetic && (
              <span className="absolute bottom-0.5 right-0.5 rounded-full bg-ink/70 p-0.5 text-brass">
                <RotateCw size={8} />
              </span>
            )}
            {stop.media.kind === "wide" && (
              <span className="absolute bottom-0.5 right-0.5 rounded-full bg-ink/70 p-0.5 text-brass">
                <PanelTop size={8} />
              </span>
            )}
          </>
        )
      ) : (
        <div className="flex h-full w-full items-center justify-center text-charcoal/25">
          <Circle size={12} />
        </div>
      )}
    </div>
  );
}

function HotspotIconPreview({ style }: { style: "chevron" | "circle" | "arrow" }) {
  if (style === "circle") return <Circle size={11} strokeWidth={2.5} />;
  if (style === "arrow") return <ArrowUpRight size={11} strokeWidth={2.5} />;
  return <ChevronUp size={11} strokeWidth={2.5} />;
}

const SYNTHETIC_MARKER = "AI-generated panorama — not a real capture.";
const SYNTHETIC_3D_MARKER = "AI-generated 3D concept render from a floor plan — not a real photo, not to scale.";
function buildSyntheticNote(existingNote?: string, marker: string = SYNTHETIC_MARKER): string {
  const trimmed = existingNote?.trim();
  if (!trimmed) return marker;
  if (trimmed.includes(marker)) return trimmed;
  return `${trimmed} (${marker})`;
}


function embedSnippet(tourId: string): string {
  // Tagged ?embed=1&src=embed so the embed shows up as its own source in
  // Analytics. Kept as a helper for tests/diagnostics; SharePanel builds
  // the same snippet for the UI.
  return `<iframe src="${window.location.origin}/tour/${tourId}?embed=1&src=embed" width="100%" height="520" style="border:0;border-radius:12px" allow="fullscreen; accelerometer; gyroscope" loading="lazy"></iframe>`;
}
