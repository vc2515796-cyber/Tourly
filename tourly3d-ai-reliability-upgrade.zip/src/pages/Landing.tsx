import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
  MapPin,
  ArrowRight,
  ArrowUpRight,
  Check,
  ChevronDown,
  Menu,
  X,
  Route,
  Link2,
  Sparkles,
  ShieldCheck,
  BarChart3,
  RotateCw,
  Smartphone,
  Wand2,
  ChevronUp,
  Images,
  Clapperboard,
  MessageCircleQuestion,
} from "lucide-react";
import { listTours } from "../lib/storage";
import { analyticsConfigured, OPEN_SETTINGS_EVENT } from "../lib/analytics";
import { Tour } from "../types";
import PanoramaViewer from "../components/PanoramaViewer";
import { usePageMeta } from "../lib/usePageMeta";

const PROBLEM_CARDS = [
  {
    icon: Images,
    title: "Photo galleries lose the flow",
    body: "Buyers see rooms one at a time, in no particular order. A guided route shows them how the property actually connects.",
  },
  {
    icon: Clapperboard,
    title: "Videos are hard to revisit",
    body: "A video moves at one pace. A walkthrough lets buyers explore at their own pace and return to the details they care about.",
  },
  {
    icon: MessageCircleQuestion,
    title: "Viewers need a next step",
    body: "Add a WhatsApp enquiry button or an \"ask about this tour\" chat directly to the experience, so interest turns into a conversation.",
  },
];

const FEATURE_BLOCKS = [
  {
    eyebrow: "One-link sharing",
    title: "Publish once. Share it everywhere.",
    body: "No app installs, no sign-up for the viewer. Send one link and buyers can drag, look around, and click through every room — on a phone or a laptop, in a listing, email, or social post.",
    icon: Link2,
    visual: "share" as const,
  },
  {
    eyebrow: "Guided routes & hotspots",
    title: "Give buyers the flow of the property.",
    body: "Place a hotspot in one room, point it at the next, and buyers click room to room in the order you choose — not a flat gallery of disconnected images.",
    icon: Route,
    visual: "hotspot" as const,
  },
  {
    eyebrow: "Built-in AI, always labeled",
    title: "Quiet AI help, never passed off as real.",
    body: "Room names, descriptions, and suggested connections are drafted for you — every suggestion stays editable, and anything AI-generated is clearly marked, never silently substituted for a real photo.",
    icon: Sparkles,
    visual: "ai" as const,
  },
];

const TRUST_ROW = [
  { icon: Smartphone, label: "No special camera required" },
  { icon: BarChart3, label: "Real, local view counts" },
  { icon: ShieldCheck, label: "Real captures stay real" },
];

const STEPS = [
  { n: "01", title: "Bring your media", body: "Upload photos, video, and 360° panoramas from the property." },
  { n: "02", title: "Shape the journey", body: "Arrange scenes and add the route you want buyers to follow." },
  { n: "03", title: "Send one link", body: "Publish a walkthrough and share it wherever buyers already look." },
];

type Plan = { name: string; tagline: string; price: number; features: string[]; highlighted?: boolean };
const PLANS: Plan[] = [
  { name: "Free", tagline: "Try it on your next listing", price: 0, features: ["2 active walkthroughs", "Core media upload", "Shareable link"] },
  { name: "Agent", tagline: "For agents who publish regularly", price: 9, features: ["Multiple walkthroughs", "Guided routes & hotspots", "Embed on your website"], highlighted: true },
  { name: "Team", tagline: "For agencies and brokerages", price: 29, features: ["Everything in Agent", "View analytics", "Priority processing"] },
];

const FAQS = [
  { q: "Do I need a Matterport camera?", a: "No — Tourly is built to work with the property media you already have, including ordinary photos, video, and 360° panoramas." },
  { q: "Is Tourly a replacement for professional photography?", a: "No. Tourly helps you get more value from the photography and video you already have by turning it into a guided, interactive experience." },
  { q: "Can buyers view a walkthrough without downloading an app?", a: "Yes — walkthroughs are shared through a link and open in any browser, on phone or desktop." },
  { q: "Can I embed a walkthrough on my website?", a: "Yes. Every published walkthrough comes with an embed snippet you can paste directly onto your listing page." },
  { q: "Does Tourly provide measurements or floor plans?", a: "Tourly can generate a stylized 3D concept image from an uploaded floor plan using AI — it's a visual concept, not a survey-grade measurement or CAD/BIM export." },
  { q: "Where is my data stored?", a: "Walkthroughs live in your browser by default. Publishing uploads the current state so anyone with the link can view it from any device." },
];

export default function Landing() {
  usePageMeta({
    title: "Tourly | Guided Property Walkthroughs from Your Listing Media",
    description:
      "Turn property photos, video, and 360° panoramas into a guided, branded walkthrough buyers can explore and share in one link.",
  });
  const [exampleTour, setExampleTour] = useState<Tour | null>(null);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const tours = listTours();
    const demoTour = tours.find((t) => t.name.startsWith("Demo —"));
    setExampleTour(demoTour ?? tours[0] ?? null);
  }, []);

  useEffect(() => {
    function onScroll() {
      setScrolled(window.scrollY > 12);
    }
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const heroStop = exampleTour?.stops[0];
  const heroIsPanorama = heroStop?.media?.kind === "panorama" || heroStop?.media?.kind === "wide";
  const secondStop = exampleTour?.stops[1] ?? exampleTour?.stops[0];
  const secondIsPanorama = secondStop?.media?.kind === "panorama" || secondStop?.media?.kind === "wide";

  return (
    <div className="min-h-full bg-bone text-charcoal">
      {/* Nav */}
      <header
        className={`sticky top-0 z-30 px-6 py-5 transition-all sm:px-10 ${
          scrolled ? "border-b border-charcoal/10 bg-bone/90 backdrop-blur-xl" : "border-b border-transparent"
        }`}
      >
        <div className="mx-auto flex max-w-6xl items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brass/15">
              <MapPin className="text-brass" size={17} strokeWidth={2.5} />
            </div>
            <span className="font-serif text-lg italic tracking-tight">Tourly</span>
          </div>

          <nav className="hidden items-center gap-8 text-sm text-charcoal/60 md:flex">
            <a href="#features" className="hover:text-charcoal">Features</a>
            <a href="#how-it-works" className="hover:text-charcoal">How it works</a>
            <a href="#pricing" className="hover:text-charcoal">Pricing</a>
            <a href="#faq" className="hover:text-charcoal">FAQ</a>
          </nav>

          <div className="hidden items-center gap-3 md:flex">
            <Link
              to="/login"
              className="rounded-full border border-charcoal/15 px-4 py-2 text-sm text-charcoal/70 hover:border-charcoal/30"
            >
              Sign in
            </Link>
            <Link
              to="/dashboard"
              className="flex items-center gap-1.5 rounded-full bg-brass px-4 py-2 text-sm font-medium text-bone hover:opacity-90"
            >
              Create a walkthrough
              <ArrowUpRight size={14} />
            </Link>
          </div>

          <button onClick={() => setMenuOpen((v) => !v)} className="md:hidden">
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>

        {menuOpen && (
          <div className="mx-auto mt-4 flex max-w-6xl flex-col gap-4 pb-2 text-sm md:hidden">
            <a href="#features" onClick={() => setMenuOpen(false)}>Features</a>
            <a href="#how-it-works" onClick={() => setMenuOpen(false)}>How it works</a>
            <a href="#pricing" onClick={() => setMenuOpen(false)}>Pricing</a>
            <a href="#faq" onClick={() => setMenuOpen(false)}>FAQ</a>
            <Link to="/login" onClick={() => setMenuOpen(false)}>Sign in</Link>
            <Link to="/dashboard" className="rounded-full bg-brass px-5 py-2.5 text-center font-medium text-bone">
              Create a walkthrough
            </Link>
          </div>
        )}
      </header>

      {/* Hero */}
      <section className="mx-auto max-w-6xl px-6 pb-20 pt-14 sm:px-10 sm:pt-20">
        <div className="grid items-center gap-14 lg:grid-cols-2">
          <div>
            <span className="text-xs font-semibold uppercase tracking-[0.15em] text-sage">
              Real-estate walkthroughs, without the specialized camera
            </span>
            <h1 className="mt-4 font-serif text-5xl leading-[1.08] tracking-tight sm:text-6xl">
              Turn your listing media into a{" "}
              <em className="text-brass-soft">walkthrough</em> buyers can actually explore.
            </h1>
            <p className="mt-6 max-w-md text-[15px] leading-relaxed text-charcoal/55">
              Upload your photos, video, or 360° panoramas. Tourly turns them into a guided,
              clickable property experience you can share from one link — so buyers understand
              the home before they book a viewing.
            </p>
            <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:items-center">
              <Link
                to="/dashboard"
                className="flex items-center justify-center gap-2 rounded-full bg-brass px-6 py-3.5 text-sm font-medium text-bone shadow-lg shadow-brass/20 hover:opacity-90"
              >
                Create a walkthrough
                <ArrowRight size={15} />
              </Link>
              {exampleTour && (
                <Link
                  to={`/tour/${exampleTour.id}`}
                  className="flex items-center justify-center gap-1.5 text-sm font-medium text-charcoal/70 hover:text-charcoal"
                >
                  See an example
                  <ArrowRight size={14} />
                </Link>
              )}
            </div>
            <p className="mt-6 text-xs text-charcoal/45">
              No special camera required. Start with the media you already have.
            </p>
          </div>

          <div className="relative overflow-hidden rounded-2xl border border-charcoal/10 bg-white p-2 shadow-2xl shadow-charcoal/10">
            <div className="relative flex aspect-[4/3] items-center justify-center overflow-hidden rounded-xl bg-gradient-to-br from-ink via-ink-soft to-ink">
              {heroStop?.media && heroIsPanorama ? (
                <PanoramaViewer
                  imageUrl={heroStop.media.dataUrl}
                  mode={heroStop.media.kind === "wide" ? "cylinder" : "sphere"}
                />
              ) : (
                <RotateCw className="text-bone/20" size={40} strokeWidth={1.5} />
              )}
              <span className="pointer-events-none absolute bottom-3 left-3 rounded-full bg-ink/60 px-3 py-1 text-[11px] text-bone/80 backdrop-blur">
                Drag to look around
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Trust row */}
      <section className="border-y border-charcoal/10 bg-bone-soft/60 px-6 py-6 sm:px-10">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-center gap-x-10 gap-y-3 text-sm text-charcoal/60">
          {TRUST_ROW.map((t) => (
            <span key={t.label} className="flex items-center gap-2">
              <t.icon size={15} className="text-sage" /> {t.label}
            </span>
          ))}
        </div>
      </section>

      {/* Problem */}
      <section className="mx-auto max-w-6xl px-6 py-24 sm:px-10">
        <p className="text-xs font-semibold uppercase tracking-[0.15em] text-sage">
          Listings are more than photo galleries
        </p>
        <h2 className="mt-3 max-w-xl font-serif text-4xl leading-tight tracking-tight sm:text-5xl">
          Give buyers the flow of the property — not just a stack of images.
        </h2>
        <p className="mt-4 max-w-lg text-[15px] leading-relaxed text-charcoal/55">
          Photos show individual rooms. A guided walkthrough helps buyers understand the whole
          property: where the rooms lead, what deserves a closer look, and why the space fits
          their life.
        </p>
        <div className="mt-10 grid gap-5 sm:grid-cols-3">
          {PROBLEM_CARDS.map((c) => (
            <div key={c.title} className="rounded-xl border border-charcoal/10 bg-white p-6">
              <c.icon size={20} className="text-brass" strokeWidth={1.75} />
              <h3 className="mt-3 text-sm font-semibold">{c.title}</h3>
              <p className="mt-1.5 text-xs leading-relaxed text-charcoal/55">{c.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Alternating feature blocks */}
      <section id="features" className="border-t border-charcoal/10 px-6 py-24 sm:px-10">
        <div className="mx-auto max-w-6xl">
          <p className="text-xs font-semibold uppercase tracking-[0.15em] text-sage">The details that move a buyer forward</p>
          <h2 className="mt-3 max-w-lg font-serif text-4xl tracking-tight sm:text-5xl">More than a tour. A guided path to enquiry.</h2>
        </div>
        <div className="mx-auto mt-14 flex max-w-6xl flex-col gap-24">
          {FEATURE_BLOCKS.map((f, i) => (
            <div
              key={f.title}
              className={`grid items-center gap-12 lg:grid-cols-2 ${i % 2 === 1 ? "lg:[&>*:first-child]:order-2" : ""}`}
            >
              <div className="relative aspect-[4/3] overflow-hidden rounded-2xl border border-charcoal/10 bg-white shadow-xl shadow-charcoal/5">
                {f.visual === "share" && heroStop?.media && heroIsPanorama && (
                  <>
                    <PanoramaViewer
                      imageUrl={heroStop.media.dataUrl}
                      mode={heroStop.media.kind === "wide" ? "cylinder" : "sphere"}
                    />
                    <span className="pointer-events-none absolute bottom-3 left-3 flex items-center gap-1.5 rounded-full bg-ink/70 px-3 py-1.5 text-[11px] text-bone/90 backdrop-blur">
                      <Link2 size={12} /> tourly.app/tour/{heroStop.id.slice(0, 6)}…
                    </span>
                  </>
                )}
                {f.visual === "hotspot" && secondStop?.media && secondIsPanorama && (
                  <>
                    <PanoramaViewer
                      imageUrl={secondStop.media.dataUrl}
                      mode={secondStop.media.kind === "wide" ? "cylinder" : "sphere"}
                      hotspots={secondStop.hotspots}
                    />
                    <span className="pointer-events-none absolute bottom-3 left-3 rounded-full bg-ink/70 px-3 py-1.5 text-[11px] text-bone/90 backdrop-blur">
                      {secondStop.hotspots[0]?.label ?? "Real hotspot from the demo tour"}
                    </span>
                  </>
                )}
                {f.visual === "ai" && (
                  <div className="flex h-full w-full flex-col justify-center gap-4 bg-bone-soft/40 p-6">
                    <div className="rounded-lg border border-charcoal/10 bg-white p-3.5 shadow-sm">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-medium uppercase tracking-wide text-charcoal/40">Name</span>
                        <span className="flex items-center gap-1 text-[10px] font-medium text-brass">
                          <Wand2 size={10} /> Auto-detect
                        </span>
                      </div>
                      <div className="mt-1.5 rounded-md border border-charcoal/15 bg-white px-2.5 py-1.5 text-xs text-charcoal/70">
                        {secondStop?.title ?? "Living Room"}
                      </div>
                    </div>
                    <div className="rounded-lg border border-dashed border-brass/40 bg-brass/5 px-3.5 py-2.5">
                      <span className="flex items-center gap-1.5 text-[11px] text-charcoal/70">
                        <Wand2 size={10} className="shrink-0 text-brass" />
                        Go to {heroStop?.title ?? "Second Room"}
                        <ChevronUp size={10} className="ml-auto shrink-0 text-charcoal/30" />
                      </span>
                    </div>
                    <p className="text-[10px] text-charcoal/35">
                      Real editor UI, shown as-is — every suggestion above is still just a draft
                      until you click Add.
                    </p>
                  </div>
                )}
                {((f.visual === "share" && !(heroStop?.media && heroIsPanorama)) ||
                  (f.visual === "hotspot" && !(secondStop?.media && secondIsPanorama))) && (
                  <div className="flex h-full w-full items-center justify-center">
                    <f.icon size={48} strokeWidth={1} className="text-brass/40" />
                  </div>
                )}
              </div>
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.15em] text-sage">{f.eyebrow}</p>
                <h3 className="mt-3 font-serif text-3xl leading-tight tracking-tight sm:text-4xl">{f.title}</h3>
                <p className="mt-4 max-w-md text-[15px] leading-relaxed text-charcoal/55">{f.body}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section id="how-it-works" className="border-t border-charcoal/10 bg-bone-soft/60 px-6 py-24 sm:px-10">
        <div className="mx-auto max-w-6xl">
          <p className="text-xs font-semibold uppercase tracking-[0.15em] text-sage">Simple process</p>
          <h2 className="mt-3 max-w-lg font-serif text-4xl tracking-tight">
            Publish a better property experience in three steps.
          </h2>
          <div className="mt-12 grid gap-10 sm:grid-cols-3">
            {STEPS.map((s) => (
              <div key={s.n}>
                <span className="font-serif text-4xl italic text-brass/50">{s.n}</span>
                <h3 className="mt-3 text-lg font-medium">{s.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-charcoal/55">{s.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="px-6 py-24 sm:px-10">
        <div className="mx-auto max-w-6xl">
          <div className="text-center">
            <p className="text-xs font-semibold uppercase tracking-[0.15em] text-sage">Pricing</p>
            <h2 className="mt-3 font-serif text-4xl tracking-tight">Simple, honest pricing.</h2>
            <p className="mt-2 text-xs text-charcoal/40">
              Paid plans aren't billed yet — everyone currently gets the Free tier while billing is built.
            </p>
          </div>
          <div className="mx-auto mt-12 grid max-w-3xl gap-5 sm:grid-cols-3">
            {PLANS.map((plan) => (
              <div
                key={plan.name}
                className={`rounded-2xl border p-6 ${
                  plan.highlighted ? "border-brass bg-white shadow-lg" : "border-charcoal/10 bg-white/60"
                }`}
              >
                <h3 className="font-medium">{plan.name}</h3>
                <p className="mt-1 text-xs text-charcoal/45">{plan.tagline}</p>
                <p className="mt-5 font-serif text-3xl">
                  ${plan.price}
                  <span className="text-sm font-sans font-normal text-charcoal/40">/mo</span>
                </p>
                <ul className="mt-5 space-y-2 text-sm text-charcoal/60">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2">
                      <Check size={13} className="mt-0.5 shrink-0 text-sage" /> {f}
                    </li>
                  ))}
                </ul>
                <Link
                  to="/dashboard"
                  className={`mt-6 block rounded-full px-4 py-2.5 text-center text-sm font-medium ${
                    plan.highlighted ? "bg-brass text-bone hover:opacity-90" : "border border-charcoal/15 text-charcoal/70 hover:border-charcoal/30"
                  }`}
                >
                  {plan.price === 0 ? "Start free" : "Get started (billing coming soon)"}
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="border-t border-charcoal/10 bg-bone-soft/60 px-6 py-24 sm:px-10">
        <div className="mx-auto max-w-2xl">
          <p className="text-xs font-semibold uppercase tracking-[0.15em] text-sage">FAQ</p>
          <h2 className="mt-3 font-serif text-4xl tracking-tight">Questions, answered.</h2>
          <div className="mt-8 flex flex-col gap-2">
            {FAQS.map((item, i) => {
              const open = openFaq === i;
              return (
                <div key={item.q} className="rounded-xl border border-charcoal/10 bg-white">
                  <button onClick={() => setOpenFaq(open ? null : i)} className="flex w-full items-center justify-between px-5 py-4 text-left">
                    <span className="text-sm font-medium">{item.q}</span>
                    <ChevronDown size={16} className={`shrink-0 text-charcoal/30 transition-transform ${open ? "rotate-180" : ""}`} />
                  </button>
                  {open && <p className="px-5 pb-4 text-sm leading-relaxed text-charcoal/55">{item.a}</p>}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="border-t border-charcoal/10 bg-ink px-6 py-24 text-bone sm:px-10">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="font-serif text-4xl leading-tight tracking-tight sm:text-5xl">
            Your next listing deserves more than a <em className="text-brass-soft">gallery</em>.
          </h2>
          <p className="mt-4 text-sm text-bone/50">
            Create a guided walkthrough from the media you already have and share it with buyers today.
          </p>
          <Link
            to="/dashboard"
            className="mt-8 inline-flex items-center gap-2 rounded-full bg-brass px-7 py-3.5 text-sm font-medium text-bone hover:opacity-90"
          >
            Create a walkthrough
            <ArrowRight size={15} />
          </Link>
          <p className="mt-3 text-xs text-bone/40">No special camera required · No credit card required</p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-ink px-6 py-10 text-bone/50 sm:px-10">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 sm:flex-row">
          <div className="flex items-center gap-2">
            <MapPin className="text-brass" size={16} strokeWidth={2.5} />
            <span className="font-serif italic text-bone/80">Tourly</span>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-xs">
            <Link to="/privacy" className="hover:text-bone">Privacy</Link>
            <Link to="/terms" className="hover:text-bone">Terms</Link>
            <Link to="/notices" className="hover:text-bone">Open-source notices</Link>
            {analyticsConfigured && (
              <button
                onClick={() => window.dispatchEvent(new Event(OPEN_SETTINGS_EVENT))}
                className="hover:text-bone"
              >
                Cookie settings
              </button>
            )}
          </div>
          <p className="text-xs">© 2026 Tourly. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
