import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, ShieldCheck, Activity, RefreshCw, Database, GaugeCircle, AlertTriangle, CheckCircle2, XCircle } from "lucide-react";
import {
  fetchDiagnostics,
  runDiagnosticsTest,
  type DiagnosticsSnapshot,
  type DiagnosticsTestResult,
} from "../lib/aiDiagnostics";

/**
 * Admin-only AI diagnostics (Phase 8). Everything shown here comes from the
 * server's SAFE snapshot — provider NAMES and model ids (not secrets),
 * aggregate counters, sanitized error kinds, quota config. The server
 * authorizes every request against ADMIN_EMAILS; this page being reachable
 * is never what makes someone an admin.
 *
 * Honesty rules in the UI:
 *  - "Last successful request" is history, never a live health claim.
 *  - The only live check is the explicit, rate-limited "Test connection".
 *  - Metrics are labelled best-effort (per-instance breakers, approximate
 *    counters under concurrency).
 */
export default function AiDiagnostics() {
  const navigate = useNavigate();
  const [snapshot, setSnapshot] = useState<DiagnosticsSnapshot | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<DiagnosticsTestResult | null>(null);
  const [testError, setTestError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    const outcome = await fetchDiagnostics();
    setLoading(false);
    if (outcome.ok) setSnapshot(outcome.snapshot);
    else setLoadError(outcome.error);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function handleTest() {
    setTesting(true);
    setTestError(null);
    setTestResult(null);
    const outcome = await runDiagnosticsTest();
    setTesting(false);
    if (outcome.ok) setTestResult(outcome.result);
    else setTestError(outcome.error);
  }

  const fmtTime = (ts: number | null) =>
    ts ? new Date(ts).toLocaleString() : "never (no recorded success)";

  return (
    <div className="min-h-screen bg-bone text-charcoal">
      <header className="border-b border-charcoal/10 bg-forest text-bone">
        <div className="mx-auto flex max-w-4xl items-center justify-between px-4 py-4 sm:px-6">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate(-1)}
              className="rounded-md p-1.5 hover:bg-bone/10"
              aria-label="Go back"
            >
              <ArrowLeft size={18} />
            </button>
            <div>
              <h1 className="flex items-center gap-2 text-lg font-semibold">
                <ShieldCheck size={18} /> AI Diagnostics
              </h1>
              <p className="text-xs text-bone/70">
                Admin-only operational status — no secrets, no customer data, ever.
              </p>
            </div>
          </div>
          <button
            onClick={() => void load()}
            disabled={loading}
            className="flex items-center gap-1.5 rounded-md border border-bone/30 px-3 py-1.5 text-xs font-medium hover:bg-bone/10 disabled:opacity-50"
          >
            <RefreshCw size={13} className={loading ? "animate-spin" : ""} /> Refresh
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-4xl space-y-6 px-4 py-6 sm:px-6">
        {loadError && (
          <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700">
            <p className="flex items-center gap-2 font-medium">
              <AlertTriangle size={15} /> {loadError}
            </p>
            <p className="mt-1 text-xs text-red-600">
              If you're the site owner: set ADMIN_EMAILS (Netlify env vars) to your signed-in
              account's email, and make sure FIREBASE_SERVICE_ACCOUNT_KEY is configured.
            </p>
          </div>
        )}

        {snapshot && (
          <>
            {/* Providers */}
            <section className="rounded-lg border border-charcoal/10 bg-white p-5 shadow-sm">
              <h2 className="flex items-center gap-2 text-sm font-semibold">
                <Activity size={15} className="text-forest" /> Providers
              </h2>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                {snapshot.providers.map((p) => {
                  const m = snapshot.metrics.providers[p.id];
                  return (
                    <div key={p.id} className="rounded-md border border-charcoal/10 bg-bone/50 p-3">
                      <div className="flex items-center justify-between">
                        <span className="font-medium capitalize">{p.id}</span>
                        <span
                          className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                            p.configured ? "bg-emerald-100 text-emerald-800" : "bg-charcoal/10 text-charcoal/60"
                          }`}
                        >
                          {p.configured ? "configured" : "not configured"}
                        </span>
                      </div>
                      <p className="mt-1 text-[11px] text-charcoal/60">
                        text models: {p.models.text?.join(", ") || "—"}
                        {p.models.image ? ` · image: ${p.models.image.join(", ")}` : ""}
                      </p>
                      {m && (
                        <p className="mt-1 text-[11px] text-charcoal/60">
                          {m.okCount} ok / {m.errCount} err · last ok {fmtTime(m.lastOkAt)}
                          {m.lastErrKind ? ` · last error kind: ${m.lastErrKind}` : ""}
                          {m.breakerTrips > 0 ? ` · ${m.breakerTrips} breaker trips` : ""}
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
              {snapshot.config.secondaryProvider && (
                <p className="mt-3 text-[11px] text-charcoal/55">
                  Secondary provider active: <strong>{snapshot.config.secondaryProvider}</strong> — used
                  only when Gemini fails rate limits, outages, timeouts or network errors (text
                  requests{snapshot.config.visionFallbackAllowed ? ", vision explicitly allowed" : " only — vision stays on Gemini"}).
                </p>
              )}
              {!snapshot.config.adminConfigured && (
                <p className="mt-3 text-[11px] text-amber-700">
                  ADMIN_EMAILS isn't set — nobody can view this page until it is.
                </p>
              )}
              <p className="mt-2 text-[11px] text-charcoal/50">{snapshot.note}</p>
            </section>

            {/* Cache + rate limits */}
            <section className="grid gap-4 sm:grid-cols-2">
              <div className="rounded-lg border border-charcoal/10 bg-white p-5 shadow-sm">
                <h2 className="flex items-center gap-2 text-sm font-semibold">
                  <Database size={15} className="text-forest" /> Result cache
                </h2>
                <p className="mt-2 text-2xl font-semibold">
                  {snapshot.metrics.cache.hits + snapshot.metrics.cache.misses > 0
                    ? `${Math.round(
                        (snapshot.metrics.cache.hits /
                          (snapshot.metrics.cache.hits + snapshot.metrics.cache.misses)) *
                          100
                      )}%`
                    : "—"}
                  <span className="ml-1 text-xs font-normal text-charcoal/50">hit rate</span>
                </p>
                <p className="mt-1 text-xs text-charcoal/60">
                  {snapshot.metrics.cache.hits} hits · {snapshot.metrics.cache.misses} misses
                </p>
              </div>
              <div className="rounded-lg border border-charcoal/10 bg-white p-5 shadow-sm">
                <h2 className="flex items-center gap-2 text-sm font-semibold">
                  <GaugeCircle size={15} className="text-forest" /> Rate-limit & quota events
                </h2>
                <p className="mt-2 text-2xl font-semibold">
                  {Object.values(snapshot.metrics.providers).reduce((n, p) => n + p.rateLimitEvents, 0)}
                  <span className="ml-1 text-xs font-normal text-charcoal/50">rate-limit events</span>
                </p>
                <p className="mt-1 text-xs text-charcoal/60">
                  {Object.values(snapshot.metrics.providers).reduce((n, p) => n + p.quotaEvents, 0)} provider
                  daily-quota events
                </p>
              </div>
            </section>

            {/* Feature quotas */}
            <section className="rounded-lg border border-charcoal/10 bg-white p-5 shadow-sm">
              <h2 className="text-sm font-semibold">Per-user daily quotas</h2>
              <div className="mt-3 grid gap-2 sm:grid-cols-2">
                {snapshot.features.map((f) => (
                  <div key={f.feature} className="flex items-center justify-between rounded-md bg-bone/50 px-3 py-1.5 text-xs">
                    <span className="text-charcoal/70">{f.feature}</span>
                    <span className="font-semibold">{f.dailyQuota}/day</span>
                  </div>
                ))}
              </div>
              <p className="mt-2 text-[11px] text-charcoal/50">
                Configurable via AI_DAILY_QUOTA_* env vars (per feature) or AI_DAILY_QUOTA_DEFAULT.
              </p>
            </section>

            {/* Live test */}
            <section className="rounded-lg border border-charcoal/10 bg-white p-5 shadow-sm">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <h2 className="text-sm font-semibold">Test connection (live)</h2>
                  <p className="text-[11px] text-charcoal/55">
                    Sends ONE minimal request per configured provider. Rate-limited to once per 30s.
                  </p>
                </div>
                <button
                  onClick={() => void handleTest()}
                  disabled={testing}
                  className="flex shrink-0 items-center gap-1.5 rounded-md bg-forest px-3 py-1.5 text-xs font-medium text-bone hover:opacity-90 disabled:opacity-50"
                >
                  <RefreshCw size={13} className={testing ? "animate-spin" : ""} />
                  {testing ? "Testing…" : "Test connection"}
                </button>
              </div>
              {testError && (
                <p className="mt-3 flex items-center gap-1.5 text-xs text-red-600">
                  <AlertTriangle size={13} /> {testError}
                </p>
              )}
              {testResult && (
                <div className="mt-3 space-y-2">
                  {testResult.results.map((r) => (
                    <div
                      key={r.provider}
                      className={`flex items-center justify-between rounded-md px-3 py-2 text-xs ${
                        r.ok ? "bg-emerald-50 text-emerald-800" : "bg-red-50 text-red-700"
                      }`}
                    >
                      <span className="flex items-center gap-1.5 font-medium">
                        {r.ok ? <CheckCircle2 size={13} /> : <XCircle size={13} />}
                        {r.provider} ({r.model})
                      </span>
                      <span>
                        {r.ok ? `responded in ${r.latencyMs}ms` : `failed — ${r.errorKind ?? "error"} (${r.latencyMs}ms)`}
                      </span>
                    </div>
                  ))}
                  <p className="text-[11px] text-charcoal/50">{testResult.note}</p>
                </div>
              )}
            </section>
          </>
        )}
      </main>
    </div>
  );
}
