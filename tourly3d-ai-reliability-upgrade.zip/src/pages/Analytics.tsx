import { useCallback, useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  MapPin,
  Eye,
  MousePointerClick,
  Layers,
  MessageCircle,
  CalendarCheck,
  TrendingUp,
  TrendingDown,
  RefreshCw,
  QrCode,
  Link2,
  MessageSquareShare,
  Code2,
  Globe,
  Loader2,
} from "lucide-react";
import { listTours, getViewSeries } from "../lib/storage";
import { useAuth } from "../lib/auth";
import { usePageMeta } from "../lib/usePageMeta";
import { auth } from "../lib/firebase";
import {
  fetchAnalyticsSummary,
  type AnalyticsSummary,
  type TourAnalyticsSummary,
} from "../lib/tourAnalytics";
import { formatDateIN } from "../lib/format";

/**
 * Stage C — buyer-engagement analytics. Two layers, honestly labelled:
 *
 *  1. SERVER data (default): real cross-device counts from the tour's
 *     public pages — tour views, scene views, hotspot clicks, enquiries,
 *     visit requests, and where opens came from (QR / WhatsApp / link /
 *     embed / direct). Ownership is enforced server-side; nothing from
 *     other agents' tours can appear here.
 *  2. LOCAL data (fallback when the server isn't configured yet): view
 *     counts recorded in THIS browser only — real, but obviously not
 *     visitor-wide. Kept so the page is still honest and useful before
 *     server setup, instead of showing nothing or pretending.
 *
 * Metric definitions are printed on the page itself (no black boxes):
 *  - Tour view  = one tracked open per visitor browser session
 *  - Unique visitors = distinct random browser tokens per day, summed per
 *    day (visitor-days) — an estimate of interest, not a headcount
 *  - Conversion = enquiries ÷ tour views. A view is NOT a buyer.
 */

type ServerState =
  | { kind: "loading" }
  | { kind: "ok"; data: AnalyticsSummary }
  | { kind: "error"; message: string; notConfigured?: boolean; needsAuth?: boolean };

const SOURCE_META: { key: "qr" | "wa" | "link" | "embed" | "direct"; label: string; icon: typeof QrCode }[] = [
  { key: "qr", label: "QR scans", icon: QrCode },
  { key: "wa", label: "WhatsApp", icon: MessageSquareShare },
  { key: "link", label: "Copied links", icon: Link2 },
  { key: "embed", label: "Embeds", icon: Code2 },
  { key: "direct", label: "Direct / other", icon: Globe },
];

export default function Analytics() {
  usePageMeta({ title: "Analytics — Tourly", noindex: true });
  const navigate = useNavigate();
  const { user, configured } = useAuth();
  const [server, setServer] = useState<ServerState>({ kind: "loading" });
  const [range, setRange] = useState<7 | 30 | 90>(7);

  /** Local tour ids — the server checks each against its own owner
   *  records, so sending drafts is harmless (they come back excluded). */
  const localTours = useMemo(() => listTours(), []);
  const tourIds = useMemo(() => localTours.slice(0, 15).map((t) => t.id), [localTours]);

  const load = useCallback(
    async (days: 7 | 30 | 90) => {
      setServer({ kind: "loading" });
      // Unconfigured deployment (local/preview): show the setup state, NOT
      // a sign-in redirect — ProtectedRoute already passes through with a
      // Local-mode banner, and shipping the user to /login here would just
      // bounce them back with no way forward.
      if (!configured) {
        setServer({
          kind: "error",
          message: "Analytics needs a configured deployment.",
          notConfigured: true,
        });
        return;
      }
      const token = await auth?.currentUser?.getIdToken().catch(() => null);
      if (!token) {
        setServer({ kind: "error", message: "Sign in to see your analytics.", needsAuth: true });
        if (!user) navigate("/login");
        return;
      }
      if (tourIds.length === 0) {
        setServer({ kind: "error", message: "No tours yet — create one and publish it to start collecting data." });
        return;
      }
      const result = await fetchAnalyticsSummary(tourIds, days, token);
      if (result.ok) {
        setServer({ kind: "ok", data: result.data });
      } else {
        setServer({ kind: "error", message: result.error, notConfigured: result.notConfigured, needsAuth: result.needsAuth });
      }
    },
    [tourIds, user, navigate, configured]
  );

  useEffect(() => {
    void load(range);
  }, [load, range]);

  // Scene titles live in the local drafts (server analytics only stores
  // scene ids) — map them for readable "top scenes" labels.
  const sceneTitles = useMemo(() => {
    const map = new Map<string, string>();
    for (const t of localTours) for (const s of t.stops) if (s.title) map.set(`${t.id}:${s.id}`, s.title);
    return map;
  }, [localTours]);

  return (
    <div className="min-h-full bg-bone text-charcoal">
      <header className="flex items-center justify-between border-b border-charcoal/10 px-6 py-4 sm:px-10">
        <Link to="/dashboard" className="flex items-center gap-1.5 text-sm text-charcoal/50 hover:text-charcoal">
          <ArrowLeft size={15} />
          Dashboard
        </Link>
        <div className="flex items-center gap-2">
          <MapPin className="text-brass" size={18} strokeWidth={2.5} />
          <span className="font-display text-sm font-semibold tracking-tight">Tourly</span>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-8 sm:px-10 sm:py-10">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="font-display text-2xl font-semibold tracking-tight sm:text-3xl">Analytics</h1>
            <p className="mt-1 max-w-xl text-sm text-charcoal/50">
              Real engagement from your published tours — views, scenes opened, hotspot clicks, enquiries and where
              visitors came from. Only your own tours; nobody else's numbers can appear here.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => void load(range)}
              className="flex items-center gap-1.5 rounded-md border border-charcoal/15 px-2.5 py-1.5 text-xs font-medium text-charcoal/70 hover:border-charcoal/30"
            >
              <RefreshCw size={12} /> Refresh
            </button>
            <div className="flex overflow-hidden rounded-md border border-charcoal/15">
              {([7, 30, 90] as const).map((r) => (
                <button
                  key={r}
                  onClick={() => setRange(r)}
                  className={`px-2.5 py-1.5 text-xs font-medium ${
                    range === r ? "bg-brass/15 text-brass" : "text-charcoal/50 hover:bg-charcoal/5"
                  }`}
                >
                  {r}d
                </button>
              ))}
            </div>
          </div>
        </div>

        {server.kind === "loading" && (
          <div className="flex items-center justify-center gap-2 py-16 text-charcoal/40">
            <Loader2 size={18} className="animate-spin" /> Loading your numbers…
          </div>
        )}

        {server.kind === "error" && (
          <ErrorState state={server} onRetry={() => void load(range)} />
        )}

        {server.kind === "ok" && <ServerDashboard data={server.data} sceneTitles={sceneTitles} />}

        {/* Local fallback — always shown, always labelled. This is the
            same real data the page showed before server analytics existed. */}
        <LocalViewsSection range={range} />
      </main>
    </div>
  );
}

function ErrorState({ state, onRetry }: { state: Extract<ServerState, { kind: "error" }>; onRetry: () => void }) {
  return (
    <div className="mt-6 rounded-lg border border-amber-200 bg-amber-50 px-4 py-4 text-sm text-amber-800">
      <p className="font-medium">{state.message}</p>
      {state.notConfigured && (
        <p className="mt-1 text-xs leading-relaxed text-amber-700">
          Engagement analytics needs server-side sign-in verification. Set FIREBASE_SERVICE_ACCOUNT_KEY on the
          deployment (see AUTH-SETUP.md §4) — publishing and leads use the same setup.
        </p>
      )}
      {!state.needsAuth && !state.notConfigured && (
        <button onClick={onRetry} className="mt-2 text-xs font-medium underline">
          Try again
        </button>
      )}
    </div>
  );
}

function ServerDashboard({ data, sceneTitles }: { data: AnalyticsSummary; sceneTitles: Map<string, string> }) {
  const { overall, tours, window: win } = data;
  const empty = overall.views === 0 && overall.enquiries === 0 && overall.sceneViews === 0;
  const viewDelta = overall.views - overall.prevViews;
  const showDelta = win.days === 7;

  if (empty) {
    return (
      <div className="mt-8 rounded-lg border border-dashed border-charcoal/20 bg-white/60 px-6 py-12 text-center">
        <Eye size={22} className="mx-auto text-charcoal/25" />
        <p className="mt-2 text-sm font-medium text-charcoal/55">No engagement recorded yet</p>
        <p className="mx-auto mt-1 max-w-md text-xs leading-relaxed text-charcoal/40">
          Zero is genuinely zero here — it means nobody has opened your published tours in this window (or they were
          opened before tracking shipped). Share a tour link or its QR code from the editor's share panel and numbers
          will start appearing.
        </p>
      </div>
    );
  }

  const maxSource = Math.max(1, ...Object.values(overall.sources).map((n) => n ?? 0));

  return (
    <>
      {/* weekly / window summary */}
      <div className="mt-8 rounded-lg border border-charcoal/10 bg-white/60 p-5 sm:p-6">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h2 className="font-display text-base font-semibold">
            {win.days === 7 ? "This week" : `Last ${win.days} days`}
          </h2>
          <p className="font-mono text-[11px] text-charcoal/40">
            {formatDateIN(Date.parse(win.from))} – {formatDateIN(Date.parse(win.to))}
          </p>
        </div>
        {showDelta && (overall.prevViews > 0 || overall.views > 0) && (
          <p className="mt-1 flex items-center gap-1.5 text-xs text-charcoal/50">
            {viewDelta > 0 ? <TrendingUp size={13} className="text-emerald-600" /> : viewDelta < 0 ? <TrendingDown size={13} className="text-red-500" /> : null}
            <span>
              {overall.views} view{overall.views === 1 ? "" : "s"}
              {viewDelta !== 0 && (
                <> — {viewDelta > 0 ? "+" : ""}{viewDelta} vs the previous week ({overall.prevViews})</>
              )}
            </span>
            <span className="text-charcoal/40">· {overall.enquiries} enquir{overall.enquiries === 1 ? "y" : "ies"} this week</span>
          </p>
        )}
        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          <Metric icon={Eye} label="Tour views" value={overall.views} />
          <Metric icon={MapPin} label="Unique visitors*" value={`${overall.uniques}${overall.uniquesCapped ? "+" : ""}`} />
          <Metric icon={Layers} label="Scene views" value={overall.sceneViews} />
          <Metric icon={MousePointerClick} label="Hotspot clicks" value={overall.hotspotClicks} />
          <Metric icon={MessageCircle} label="Enquiries" value={overall.enquiries} />
          <Metric icon={CalendarCheck} label="Visit requests" value={overall.visitRequests} />
        </div>
        <p className="mt-3 text-xs font-medium text-charcoal/60">
          Conversion (enquiries ÷ views):{" "}
          <span className="font-mono text-charcoal">{overall.conversionRate === null ? "—" : `${overall.conversionRate}%`}</span>
        </p>
      </div>

      {/* sources */}
      <div className="mt-6 rounded-lg border border-charcoal/10 bg-white/60 p-5 sm:p-6">
        <h2 className="font-display text-base font-semibold">Where opens came from</h2>
        <p className="mt-1 text-xs text-charcoal/45">
          Share links, QR codes, WhatsApp messages and embed snippets from the editor's share panel are each tagged —
          so you can see which channel actually brings buyers. Direct = typed or untagged.
        </p>
        <div className="mt-4 space-y-2.5">
          {SOURCE_META.map(({ key, label, icon: Icon }) => {
            const n = overall.sources[key] ?? 0;
            return (
              <div key={key} className="flex items-center gap-3">
                <Icon size={14} className="shrink-0 text-charcoal/35" />
                <span className="w-28 shrink-0 text-xs text-charcoal/60">{label}</span>
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-charcoal/5">
                  <div className="h-full rounded-full bg-brass/70" style={{ width: `${Math.max(n > 0 ? 3 : 0, (n / maxSource) * 100)}%` }} />
                </div>
                <span className="w-10 shrink-0 text-right font-mono text-xs text-charcoal/60">{n}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* per-tour */}
      <div className="mt-6">
        <h2 className="font-display text-base font-semibold">By property</h2>
        {tours.length === 0 ? (
          <p className="mt-2 text-xs text-charcoal/40">
            None of your tours are published yet — publish one and its numbers appear here.
          </p>
        ) : (
          <div className="mt-3 space-y-3">
            {tours.map((t) => (
              <TourRow key={t.id} tour={t} sceneTitles={sceneTitles} />
            ))}
          </div>
        )}
      </div>

      {/* metric definitions — printed, not hidden */}
      <div className="mt-8 rounded-lg border border-charcoal/10 bg-white/40 px-4 py-3 text-[11px] leading-relaxed text-charcoal/45">
        <p>
          * A unique visitor is a random per-browser token (no personal data), hashed and stored per day — summed
          across days it counts visitor-days, an estimate of interest, not people. A tour view is one tracked open per
          visitor session (refreshes don't double-count). Counts are aggregate and best-effort: a view is engagement,
          never a guarantee of a buyer. Google Analytics, if enabled, is separate and consent-gated.
        </p>
      </div>
    </>
  );
}

function Metric({ icon: Icon, label, value }: { icon: typeof Eye; label: string; value: number | string }) {
  return (
    <div className="rounded-md border border-charcoal/10 bg-white p-3">
      <div className="flex items-center gap-1.5 text-charcoal/40">
        <Icon size={13} />
        <span className="text-[10px] uppercase tracking-wide">{label}</span>
      </div>
      <p className="mt-1 font-display text-xl font-semibold">{value}</p>
    </div>
  );
}

function TourRow({ tour, sceneTitles }: { tour: TourAnalyticsSummary; sceneTitles: Map<string, string> }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-lg border border-charcoal/10 bg-white/60">
      <button onClick={() => setOpen((o) => !o)} className="flex w-full flex-wrap items-center justify-between gap-2 px-4 py-3 text-left">
        <span className="text-sm font-medium">{tour.name}</span>
        <span className="font-mono text-[11px] text-charcoal/50">
          {tour.views} views · {tour.uniques}{tour.uniquesCapped ? "+" : ""} uniques · {tour.sceneViews} scenes ·{" "}
          {tour.enquiries} enquir{tour.enquiries === 1 ? "y" : "ies"}
          {tour.conversionRate !== null && ` · ${tour.conversionRate}%`}
        </span>
      </button>
      {open && (
        <div className="border-t border-charcoal/10 px-4 py-3">
          <div className="grid grid-cols-2 gap-2 text-[11px] text-charcoal/60 sm:grid-cols-4">
            <span>Hotspot clicks: <b className="font-mono">{tour.hotspotClicks}</b></span>
            <span>Visit requests: <b className="font-mono">{tour.visitRequests}</b></span>
            <span>Enquiries: <b className="font-mono">{tour.enquiries}</b></span>
            <span>Conversion: <b className="font-mono">{tour.conversionRate === null ? "—" : `${tour.conversionRate}%`}</b></span>
          </div>
          {tour.topScenes.length > 0 && (
            <div className="mt-3">
              <p className="text-[10px] font-medium uppercase tracking-wide text-charcoal/40">Most-opened scenes</p>
              <ul className="mt-1 space-y-1">
                {tour.topScenes.map((s) => (
                  <li key={s.sceneId} className="flex items-center justify-between text-xs text-charcoal/60">
                    <span className="truncate">{sceneTitles.get(`${tour.id}:${s.sceneId}`) ?? s.sceneId}</span>
                    <span className="font-mono">{s.views}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/** Pre-server-analytics view data: real, but only from THIS browser. */
function LocalViewsSection({ range }: { range: 7 | 30 | 90 }) {
  const series = useMemo(() => getViewSeries(range), [range]);
  const maxDayViews = Math.max(1, ...series.days.map((d) => d.views));
  return (
    <div className="mt-10 rounded-lg border border-charcoal/10 bg-white/40 p-5 sm:p-6">
      <h2 className="font-display text-sm font-semibold">This browser only — local view log</h2>
      <p className="mt-1 text-xs text-charcoal/45">
        Every tour page you open in THIS browser (including your own previews). Useful for a quick sanity check; the
        numbers above come from all visitors via the server.
      </p>
      {series.total === 0 ? (
        <p className="mt-3 text-xs text-charcoal/35">Nothing recorded in this browser for the last {range} days.</p>
      ) : (
        <div className={`mt-4 flex items-end ${range === 7 ? "gap-3 sm:gap-5" : "gap-[2px]"}`}>
          {series.days.map((d, i) => (
            <div key={i} className="flex flex-1 flex-col items-center gap-1.5">
              <div className="flex h-20 w-full items-end justify-center">
                <div
                  className={`w-full rounded-t bg-charcoal/20 ${range === 7 ? "max-w-[28px]" : ""}`}
                  style={{ height: `${Math.max(3, (d.views / maxDayViews) * 100)}%` }}
                  title={`${d.date}: ${d.views}`}
                />
              </div>
              <span className="h-3 font-mono text-[9px] text-charcoal/35">
                {i % (range === 7 ? 1 : range === 30 ? 5 : 10) === 0 || i === series.days.length - 1 ? d.label : ""}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
