import LegalPage from "../components/LegalPage";

const NOTICES: { name: string; license: string; note?: string }[] = [
  { name: "React & React DOM", license: "MIT" },
  { name: "React Router", license: "MIT" },
  { name: "lucide-react", license: "ISC" },
  { name: "three.js", license: "MIT" },
  { name: "Firebase JS SDK", license: "Apache-2.0" },
  { name: "@netlify/blobs, @netlify/functions", license: "MIT" },
  { name: "jpeg-js", license: "MIT" },
  { name: "Tailwind CSS", license: "MIT" },
  { name: "Vite", license: "MIT" },
  { name: "TypeScript", license: "Apache-2.0" },
  { name: "Fraunces, Space Grotesk, Inter, JetBrains Mono (Google Fonts)", license: "SIL Open Font License 1.1" },
];

export default function Notices() {
  return (
    <LegalPage eyebrow="Legal" title="Open-Source Notices" updated="September 2026">
      <p className="rounded-md border border-brass/30 bg-brass/10 px-4 py-3 text-xs text-charcoal/70">
        Licenses listed here reflect each project's well-known, publicly documented license as of
        this writing — verify against each package's own LICENSE file (e.g. via <code>npm ls</code>{" "}
        and a license-checker tool) before publishing this page, since versions and licenses can
        change.
      </p>

      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="border-b border-charcoal/10 text-left text-xs uppercase tracking-wide text-charcoal/40">
            <th className="py-2 pr-4 font-medium">Package</th>
            <th className="py-2 font-medium">License</th>
          </tr>
        </thead>
        <tbody>
          {NOTICES.map((n) => (
            <tr key={n.name} className="border-b border-charcoal/5">
              <td className="py-2.5 pr-4">{n.name}</td>
              <td className="py-2.5 text-charcoal/60">{n.license}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <p className="text-xs text-charcoal/40">
        Demo panorama images shipped with this app are placeholders for development —{" "}
        <span className="rounded bg-charcoal/5 px-1">confirm their source/license</span> or
        replace them with your own captures before using this build publicly.
      </p>
    </LegalPage>
  );
}
