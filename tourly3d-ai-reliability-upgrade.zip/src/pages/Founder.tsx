import { Link } from "react-router-dom";
import { MapPin, ArrowLeft } from "lucide-react";
import { usePageMeta } from "../lib/usePageMeta";

export default function Founder() {
  usePageMeta({ title: "Founder — Tourly", description: "The story and principles behind Tourly." });
  return (
    <div className="flex min-h-full flex-col bg-ink text-bone">
      <header className="flex items-center justify-between px-6 py-4 sm:px-10">
        <Link to="/" className="flex items-center gap-2">
          <MapPin className="text-brass" size={18} strokeWidth={2.5} />
          <span className="font-display text-sm font-semibold tracking-tight">Tourly</span>
        </Link>
        <Link to="/" className="flex items-center gap-1.5 text-sm text-bone/50 hover:text-bone">
          <ArrowLeft size={15} />
          Back
        </Link>
      </header>

      <main className="flex flex-1 flex-col items-center justify-center px-6 py-16 text-center">
        <p className="font-mono text-[11px] uppercase tracking-widest text-brass">Founder</p>
        <h1 className="mt-3 font-display text-4xl font-semibold tracking-tight sm:text-5xl">
          Veer
        </h1>
        <p className="mt-4 max-w-md text-bone/60">
          Building Tourly solo — walkthroughs that don't need a 3D scanner to make.
        </p>
      </main>
    </div>
  );
}
