import { Link } from "react-router-dom";
import LegalPage from "../components/LegalPage";

export default function Privacy() {
  return (
    <LegalPage eyebrow="Legal" title="Privacy Policy" updated="October 2026">
      <p className="rounded-md border border-brass/30 bg-brass/10 px-4 py-3 text-xs text-charcoal/70">
        This page describes what the Tourly app itself actually does with data, based on how it's
        built. It is a plain-language starting point, not legal advice — have a lawyer review it
        before relying on it, especially for the account details in brackets below.
      </p>

      <section>
        <h2 className="font-medium text-charcoal">What we collect</h2>
        <ul className="mt-2 list-disc space-y-1.5 pl-5">
          <li><strong>Account info</strong> — if you sign in, your email address and authentication state are handled by Firebase Authentication (a Google service), not stored on our own servers.</li>
          <li><strong>Tour content</strong> — photos, video, panoramas, and notes you add stay in your own browser's local storage by default.</li>
          <li><strong>Published tours</strong> — clicking "Publish" uploads a copy of that tour to our hosting storage so the shareable link works from any device. Anyone with the link can view it.</li>
          <li><strong>Tour engagement counts (aggregate)</strong> — when someone opens a published tour, the server records anonymous aggregate counters for that tour: views, scenes opened, hotspot clicks, enquiries, and where the open came from (link / QR / WhatsApp / embed / direct). No IP address, no device fingerprint, and no personal identifier is stored with these counts. "Unique visitor" numbers come from a random token generated in each visitor's browser, which is stored only as a one-way hash — it is derived from nothing about the person and can't be traced back to one.</li>
          <li><strong>Local view log</strong> — each browser also keeps its own view history locally; that log never leaves the visitor's device.</li>
          <li><strong>Enquiries you send</strong> — if you use the enquiry form on a tour, your message and the contact details you choose to leave go to that tour's agent (and only that agent) so they can reply. The form asks for explicit consent before anything is stored.</li>
          <li><strong>AI feature input</strong> — text and images you submit to AI tools (auto-detect, marketing copy, hotspot suggestions, 3D render, the tour assistant) are sent to Google's Gemini API for processing. If the site operator has configured an additional AI provider (Groq or Mistral), requests may be sent to that provider instead when Gemini is temporarily unavailable — the same content is sent, for the same purpose. Buyer contact details from enquiries are deliberately excluded from AI prompts.</li>
        </ul>
      </section>

      <section>
        <h2 className="font-medium text-charcoal">What we don't do</h2>
        <ul className="mt-2 list-disc space-y-1.5 pl-5">
          <li>No advertising cookies, and no cross-site tracking of visitors.</li>
          <li>If Google Analytics is enabled on a deployment, it is separate, optional, and only runs after the visitor accepts the cookie banner — and never inside embedded tours.</li>
          <li>We don't sell personal data.</li>
          <li>
            AI providers process your requests to return a response; we don't control their retention — see the
            providers' own privacy terms for details:{" "}
            <a className="underline hover:text-forest" href="https://policies.google.com/privacy" target="_blank" rel="noreferrer">Google (Gemini)</a>
            {" · "}
            <a className="underline hover:text-forest" href="https://groq.com/privacy-policy" target="_blank" rel="noreferrer">Groq</a>
            {" · "}
            <a className="underline hover:text-forest" href="https://mistral.ai/privacy-policy" target="_blank" rel="noreferrer">Mistral</a>
            . Which providers are active on a deployment is shown to the site operator in the admin AI diagnostics.
          </li>
        </ul>
      </section>

      <section>
        <h2 className="font-medium text-charcoal">Your choices</h2>
        <ul className="mt-2 list-disc space-y-1.5 pl-5">
          <li>Clearing your browser's local storage removes tours that were never published, plus your local view log and random visitor token.</li>
          <li>To request deletion or correction of a published tour, its aggregate engagement counts, its enquiries, or your account, contact <span className="rounded bg-charcoal/5 px-1">[add your support email here]</span>.</li>
        </ul>
      </section>

      <section>
        <h2 className="font-medium text-charcoal">Children</h2>
        <p className="mt-2">
          Tourly isn't directed at children, and accounts require agreeing to the{" "}
          <Link to="/terms" className="text-brass hover:underline">Terms</Link>, which set a minimum age.
        </p>
      </section>

      <p className="text-xs text-charcoal/40">
        Questions about this policy: <span className="rounded bg-charcoal/5 px-1">[add your support email here]</span>.
      </p>
    </LegalPage>
  );
}
