import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Plus, MapPin, ExternalLink, Trash2, User, BarChart3, LogOut, Search, Folder, Lock, MailWarning, X, MessageCircle } from "lucide-react";
import { listTours, createTour, deleteTour } from "../lib/storage";
import { seedDemoToursIfEmpty } from "../lib/demo";
import { Tour } from "../types";
import { useAuth } from "../lib/auth";
import { usePageMeta } from "../lib/usePageMeta";
import MessagingPanel from "../components/MessagingPanel";

export default function Home() {
  usePageMeta({ title: "My walkthroughs — Tourly", noindex: true });
  const [tours, setTours] = useState<Tour[]>([]);
  const [name, setName] = useState("");
  const [query, setQuery] = useState("");
  const [folderFilter, setFolderFilter] = useState<string>("all");
  const navigate = useNavigate();
  const { user, signOut, configured, resendVerification } = useAuth();
  const [verifyBannerDismissed, setVerifyBannerDismissed] = useState(false);
  const [verifySent, setVerifySent] = useState(false);
  const [verifyBusy, setVerifyBusy] = useState(false);

  useEffect(() => {
    setTours(listTours());
  }, []);

  function handleCreate() {
    const tour = createTour(name.trim());
    navigate(`/editor/${tour.id}`);
  }

  function handleDelete(id: string) {
    const tour = tours.find((t) => t.id === id);
    if (!window.confirm(`Delete "${tour?.name || "this walkthrough"}"? This can't be undone.`)) return;
    deleteTour(id);
    setTours(listTours());
  }

  const folders = Array.from(new Set(tours.map((t) => (t.folder ?? "").trim()).filter(Boolean))).sort();
  const q = query.trim().toLowerCase();
  const filtered = tours.filter((t) => {
    const folder = (t.folder ?? "").trim();
    if (folderFilter === "__none" && folder) return false;
    if (folderFilter !== "all" && folderFilter !== "__none" && folder !== folderFilter) return false;
    if (!q) return true;
    return t.name.toLowerCase().includes(q) || folder.toLowerCase().includes(q) || t.subtitle.toLowerCase().includes(q);
  });

  // Group by folder only in the "all" view, and only if any folders exist.
  const groups: { label: string | null; items: Tour[] }[] =
    folderFilter === "all" && folders.length > 0
      ? [
          ...folders
            .map((f) => ({ label: f, items: filtered.filter((t) => (t.folder ?? "").trim() === f) }))
            .filter((g) => g.items.length > 0),
          { label: "No folder", items: filtered.filter((t) => !(t.folder ?? "").trim()) },
        ].filter((g) => g.items.length > 0)
      : [{ label: null, items: filtered }];

  function renderCard(tour: Tour) {
    return (
      <li
        key={tour.id}
        className="group flex flex-col justify-between rounded-lg border border-charcoal/10 bg-white/60 p-5 transition-shadow hover:shadow-md"
      >
        <div>
          <div className="flex items-start justify-between">
            <h3 className="font-display text-lg font-semibold">{tour.name}</h3>
            <button
              onClick={() => handleDelete(tour.id)}
              className="text-charcoal/30 opacity-0 transition-opacity hover:text-red-500 group-hover:opacity-100"
              aria-label="Delete walkthrough"
            >
              <Trash2 size={16} />
            </button>
          </div>
          <p className="mt-1 flex items-center gap-2 font-mono text-xs text-charcoal/40">
            <span>
              {tour.stops.length} {tour.stops.length === 1 ? "stop" : "stops"}
            </span>
            {tour.viewPassword?.trim() && (
              <span className="flex items-center gap-0.5" title="Password set for the published link">
                <Lock size={10} /> protected
              </span>
            )}
          </p>
        </div>
        <div className="mt-5 flex gap-2">
          <button
            onClick={() => navigate(`/editor/${tour.id}`)}
            className="flex-1 rounded-md border border-charcoal/15 px-3 py-2 text-sm font-medium transition-colors hover:border-charcoal/30"
          >
            Edit
          </button>
          <button
            onClick={() => navigate(`/tour/${tour.id}`)}
            disabled={tour.stops.length === 0}
            className="flex flex-1 items-center justify-center gap-1.5 rounded-md bg-sage px-3 py-2 text-sm font-medium text-white transition-opacity hover:opacity-90 disabled:opacity-30"
          >
            View <ExternalLink size={13} />
          </button>
        </div>
      </li>
    );
  }

  return (
    <div className="min-h-full bg-bone text-charcoal">
      <header className="border-b border-charcoal/10 px-6 py-6 sm:px-10">
        <div className="mx-auto flex max-w-5xl items-center justify-between">
          <div className="flex items-center gap-2">
            <MapPin className="text-brass" size={22} strokeWidth={2.5} />
            <span className="font-display text-lg font-semibold tracking-tight">Tourly</span>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/analytics")}
              className="flex items-center gap-1.5 text-xs text-charcoal/40 hover:text-charcoal/70"
            >
              <BarChart3 size={13} />
              Analytics
            </button>
            <button
              onClick={() => navigate("/leads")}
              className="flex items-center gap-1.5 text-xs text-charcoal/40 hover:text-charcoal/70"
              title="Enquiries from your published tours"
            >
              <MessageCircle size={13} />
              Leads
            </button>
            <button
              onClick={() => navigate("/founder")}
              className="flex items-center gap-1.5 text-xs text-charcoal/40 hover:text-charcoal/70"
            >
              <User size={13} />
              Founder
            </button>
            {configured && user && (
              <>
                <span className="hidden text-xs text-charcoal/30 sm:inline">{user.email}</span>
                <button
                  onClick={async () => {
                    await signOut();
                    navigate("/login");
                  }}
                  className="flex items-center gap-1.5 text-xs text-charcoal/40 hover:text-charcoal/70"
                >
                  <LogOut size={13} />
                  Sign out
                </button>
              </>
            )}
          </div>
        </div>
      </header>

      {configured && user && !user.emailVerified && !verifyBannerDismissed && (
        <div className="border-b border-amber-200 bg-amber-50 px-6 py-2.5 text-xs text-amber-800 sm:px-10">
          <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-2">
            <span className="flex items-center gap-1.5">
              <MailWarning size={13} />
              {verifySent
                ? "Verification email sent — check your inbox."
                : "Please verify your email address to secure your account."}
            </span>
            <div className="flex items-center gap-3">
              {!verifySent && (
                <button
                  onClick={async () => {
                    setVerifyBusy(true);
                    try {
                      await resendVerification();
                      setVerifySent(true);
                    } catch {
                      // Firebase rate-limits repeat sends — fail quietly, the
                      // banner just stays up so they can try again shortly.
                    } finally {
                      setVerifyBusy(false);
                    }
                  }}
                  disabled={verifyBusy}
                  className="font-medium underline hover:no-underline disabled:opacity-50"
                >
                  {verifyBusy ? "Sending…" : "Resend email"}
                </button>
              )}
              <button onClick={() => setVerifyBannerDismissed(true)} className="text-amber-700/60 hover:text-amber-900">
                <X size={13} />
              </button>
            </div>
          </div>
        </div>
      )}

      <main className="mx-auto max-w-5xl px-6 py-12 sm:px-10">
        <div className="mb-10">
          <h1 className="font-display text-3xl font-semibold tracking-tight sm:text-4xl">
            Every walkthrough starts with a first stop.
          </h1>
          <p className="mt-2 max-w-xl text-charcoal/60">
            Drop in photos and video, arrange them into a route, and share a link
            people can click through — stop by stop.
          </p>
        </div>

        <div className="mb-12 flex flex-col gap-3 rounded-lg border border-charcoal/10 bg-white/60 p-5 sm:flex-row sm:items-center">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleCreate()}
            placeholder="Name this walkthrough — e.g. Riverside 2BHK"
            className="flex-1 rounded-md border border-charcoal/15 bg-white px-4 py-2.5 text-sm outline-none placeholder:text-charcoal/35 focus:border-brass"
          />
          <button
            onClick={handleCreate}
            className="flex items-center justify-center gap-2 rounded-md bg-charcoal px-5 py-2.5 text-sm font-medium text-bone transition-colors hover:bg-ink"
          >
            <Plus size={16} />
            New walkthrough
          </button>
        </div>

        {tours.length === 0 ? (
          <div className="rounded-lg border border-dashed border-charcoal/15 px-6 py-16 text-center">
            <p className="font-display text-lg text-charcoal/50">Nothing built yet</p>
            <p className="mt-1 text-sm text-charcoal/40">
              Name a walkthrough above to lay down your first stop.
            </p>
            <button
              onClick={() => {
                seedDemoToursIfEmpty();
                setTours(listTours());
              }}
              className="mt-4 text-sm font-medium text-brass hover:underline"
            >
              Or add 2 demo walkthroughs to explore first
            </button>
          </div>
        ) : (
          <>
            <div className="mb-5 flex flex-col gap-3">
              <div className="relative">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-charcoal/30" />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search walkthroughs…"
                  className="w-full rounded-md border border-charcoal/15 bg-white py-2 pl-9 pr-3 text-sm outline-none focus:border-brass"
                />
              </div>
              {folders.length > 0 && (
                <div className="flex flex-wrap items-center gap-1.5">
                  <Folder size={13} className="text-charcoal/30" />
                  {[
                    { key: "all", label: "All" },
                    ...folders.map((f) => ({ key: f, label: f })),
                    { key: "__none", label: "No folder" },
                  ].map((f) => (
                    <button
                      key={f.key}
                      onClick={() => setFolderFilter(f.key)}
                      className={`rounded-full border px-2.5 py-1 text-[11px] font-medium transition-colors ${
                        folderFilter === f.key
                          ? "border-brass bg-brass/15 text-brass"
                          : "border-charcoal/15 text-charcoal/50 hover:border-charcoal/30"
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
            {filtered.length === 0 ? (
              <p className="py-10 text-center text-sm text-charcoal/40">No walkthroughs match your search.</p>
            ) : (
              <div className="flex flex-col gap-8">
                {groups.map((g) => (
                  <section key={g.label ?? "all"}>
                    {g.label && (
                      <h2 className="mb-3 flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-wider text-charcoal/40">
                        <Folder size={12} /> {g.label}
                      </h2>
                    )}
                    <ul className="grid gap-4 sm:grid-cols-2">{g.items.map(renderCard)}</ul>
                  </section>
                ))}
              </div>
            )}
          </>
        )}

        {/* Feature H — chat-to-tour linking (WhatsApp / Telegram). Rendered
            for everyone; the panel itself reports honestly whether the
            providers are configured on this deployment. */}
        <div className="mt-12">
          <MessagingPanel />
        </div>
      </main>
    </div>
  );
}
