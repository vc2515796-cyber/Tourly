/**
 * Client-side image compression. Photos straight off a phone are often 5–15 MB
 * — far too big for localStorage (~5 MB total), for publishing (Netlify
 * functions cap request bodies around 6 MB), and for fast page loads.
 * Everything here fails soft: on any error the original is returned untouched.
 */

function loadImage(dataUrl: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = dataUrl;
  });
}

export function dataUrlBytes(dataUrl: string): number {
  const comma = dataUrl.indexOf(",");
  return Math.floor(((dataUrl.length - comma - 1) * 3) / 4);
}

/** Longest-side caps used at upload time. 4096 keeps a 2:1 panorama sharp
 *  on large screens while staying WebGL-texture-safe on phones. */
export const UPLOAD_MAX_DIM = { image: 2560, panorama: 4096, wide: 6144 } as const;

export async function compressImage(
  dataUrl: string,
  { maxDim, quality = 0.85, skipBelowBytes = 500_000 }: { maxDim: number; quality?: number; skipBelowBytes?: number }
): Promise<string> {
  try {
    if (!dataUrl.startsWith("data:image/")) return dataUrl;
    const originalBytes = dataUrlBytes(dataUrl);
    const img = await loadImage(dataUrl);
    const scale = Math.min(1, maxDim / Math.max(img.width, img.height));

    // Already small enough in both pixels and bytes — don't re-encode
    // (re-encoding a fine JPEG only costs quality).
    if (scale === 1 && originalBytes <= skipBelowBytes) return dataUrl;

    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(img.width * scale));
    canvas.height = Math.max(1, Math.round(img.height * scale));
    const ctx = canvas.getContext("2d");
    if (!ctx) return dataUrl;
    // JPEG has no alpha — paint white first so transparent PNGs don't go black.
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

    const out = canvas.toDataURL("image/jpeg", quality);
    // Never make a same-size image bigger.
    if (scale === 1 && dataUrlBytes(out) >= originalBytes) return dataUrl;
    return out;
  } catch {
    return dataUrl;
  }
}

/** Center-cropped "cover" thumbnail for link previews (1200×630 is the
 *  standard Open Graph size). */
export async function makeCoverJpeg(dataUrl: string, width = 1200, height = 630, quality = 0.8): Promise<string | null> {
  try {
    const img = await loadImage(dataUrl);
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;
    const scale = Math.max(width / img.width, height / img.height);
    const dw = img.width * scale;
    const dh = img.height * scale;
    ctx.drawImage(img, (width - dw) / 2, (height - dh) / 2, dw, dh);
    return canvas.toDataURL("image/jpeg", quality);
  } catch {
    return null;
  }
}
