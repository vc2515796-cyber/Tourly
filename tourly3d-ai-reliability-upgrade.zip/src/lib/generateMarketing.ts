import type { SavedMarketingDraft } from "../types";
import { auth } from "./firebase";

export type MarketingCopy = {
  title: string;
  shortDescription: string;
  longDescription: string;
  instagramCaption: string;
  whatsappMessage: string;
  seoTitle: string;
  seoDescription: string;
  /** Stage B4 additions — optional so older responses still parse. */
  headline?: string;
  tourIntro?: string;
  /** Stage D (Phase 4) additions — optional, facts-grounded. */
  highlights?: string[];
  buyerSummary?: string;
  language?: string;
  missingFields?: string[];
  note?: string;
};

export type MarketingFactsInput = {
  propertyType?: string;
  location?: string;
  size?: string;
  price?: string;
  bedrooms?: string;
  bathrooms?: string;
  amenities?: string[];
  audience?: string;
  tone?: string;
  language?: "en" | "hi" | "hinglish";
  channel?: string;
  /** total m² from the CALIBRATED floor plan, when available */
  planAreaM2?: number;
};

export type MarketingResult = { ok: true; copy: MarketingCopy } | { ok: false; error: string; quotaExhausted?: boolean };

/**
 * Stage B4 — grounded listing copy. All fact fields are optional; whatever
 * the user supplies is sent, and the server is contracted to never invent
 * the rest (it reports them in `missingFields` instead).
 */
export async function generateMarketing(
  tourName: string,
  subtitle: string,
  stops: { title: string; note?: string }[],
  facts?: MarketingFactsInput
): Promise<MarketingResult> {
  try {
    // Signed-in agents get their per-account daily quota (instead of the
    // anonymous per-IP one); anonymous calls still work.
    const token = await auth?.currentUser?.getIdToken().catch(() => null);
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30_000);

    const response = await fetch("/api/generate-marketing", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      signal: controller.signal,
      body: JSON.stringify({ tourName, subtitle, stops, facts: facts ?? {} }),
    }).finally(() => clearTimeout(timeoutId));

    if (!response.ok) {
      const body = await response.json().catch(() => null);
      const error = body?.error ?? "Could not generate marketing copy right now.";
      return {
        ok: false,
        error: body?.detail ? `${error} — ${String(body.detail).slice(0, 200)}` : error,
        quotaExhausted: response.status === 429 || response.status === 503,
      };
    }
    const copy = await response.json();
    return { ok: true, copy };
  } catch (err: any) {
    if (err?.name === "AbortError") {
      return { ok: false, error: "Generation timed out — try again." };
    }
    return { ok: false, error: "Could not reach the marketing generator." };
  }
}

/** Persists a creator-approved draft into the tour (never auto-published). */
export function draftToSaved(fields: Record<string, string>, language: string, channel: string): SavedMarketingDraft {
  return {
    id: crypto.randomUUID(),
    createdAt: Date.now(),
    language,
    channel,
    fields,
  };
}
