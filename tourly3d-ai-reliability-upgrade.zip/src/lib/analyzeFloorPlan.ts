/**
 * Stage D (Phase 5A/5B of the AI upgrade) — client side of the AI Concept
 * Floor Plan: panorama selection + validation, client-rendered perspective
 * crops, and the call to /api/analyze-floorplan with the agent's auth token.
 *
 * Perspective crops are produced in the browser with a plain canvas — the
 * classic equirectangular→rectilinear resampling. Four straight-ahead views
 * (front / right / back / left) let the vision model see walls and furniture
 * without pincushion distortion, WITHOUT any new dependency or paid image
 * service. All crops are views of the SAME panorama and are labelled as
 * such in the request.
 */

import { auth } from "./firebase";
import type { ConceptAnalysis } from "./conceptPlan";

const MAX_SEND_DIMENSION = 1280; // panorama longest side sent to the server
const CROP_SIZE = 512; // per-crop resolution

export type AnalyzeFloorPlanResult =
  | { ok: true; analysis: ConceptAnalysis }
  | { ok: false; error: string; quotaExhausted?: boolean };

function loadImage(dataUrl: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = dataUrl;
  });
}

async function toCanvas(img: HTMLImageElement, maxDim: number): Promise<HTMLCanvasElement> {
  const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(img.width * scale));
  canvas.height = Math.max(1, Math.round(img.height * scale));
  const ctx = canvas.getContext("2d")!;
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  return canvas;
}

/** Validates the source image like the server will: real decodable image,
 *  JPEG/PNG, sane size. Returns the downscaled panorama dataUrl + base64. */
export async function preparePanorama(dataUrl: string): Promise<
  { ok: true; base64: string; mimeType: string; previewDataUrl: string; width: number; height: number } | { ok: false; error: string }
> {
  let img: HTMLImageElement;
  try {
    img = await loadImage(dataUrl);
  } catch {
    return { ok: false, error: "That file couldn't be decoded as an image." };
  }
  if (img.width < 256 || img.height < 128) {
    return { ok: false, error: "That panorama is too small to analyse (min 256×128 px)." };
  }
  const canvas = await toCanvas(img, MAX_SEND_DIMENSION);
  const out = canvas.toDataURL("image/jpeg", 0.85);
  return {
    ok: true,
    base64: out.split(",")[1] ?? "",
    mimeType: "image/jpeg",
    previewDataUrl: canvas.toDataURL("image/jpeg", 0.6),
    width: img.width,
    height: img.height,
  };
}

/**
 * Renders one straight-ahead rectilinear view from the equirectangular
 * canvas (inverse mapping per pixel — dependency-free and correct enough
 * to straighten walls for the vision model). yaw in degrees, 90° FOV.
 */
export function renderPerspectiveCrop(
  source: HTMLCanvasElement,
  yawDeg: number,
  size = CROP_SIZE
): string {
  const srcCtx = source.getContext("2d")!;
  const src = srcCtx.getImageData(0, 0, source.width, source.height);
  const sw = source.width;
  const sh = source.height;
  const sdata = src.data;

  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d")!;
  const out = ctx.createImageData(size, size);
  const odata = out.data;

  const yaw = (yawDeg * Math.PI) / 180;
  const halfFov = Math.PI / 4; // 90° FOV
  const focal = 1 / Math.tan(halfFov); // focal length in unit-crop space

  for (let y = 0; y < size; y++) {
    const v = ((y + 0.5) / size - 0.5) * 2 * Math.tan(halfFov); // -1..1 in camera units
    for (let x = 0; x < size; x++) {
      const u = ((x + 0.5) / size - 0.5) * 2 * Math.tan(halfFov);
      // Camera ray (x, y, z) with z forward — equirect inverse mapping:
      const theta = yaw + Math.atan2(u, focal);
      const phi = Math.atan2(v, Math.sqrt(u * u + focal * focal)); // ≈ pitch
      // Wrap longitude into [0, 1)
      let tx = theta / (Math.PI * 2);
      tx = tx - Math.floor(tx);
      const ty = 0.5 - phi / Math.PI; // 0 at top
      const sx = Math.min(sw - 1, Math.max(0, Math.floor(tx * sw)));
      const sy = Math.min(sh - 1, Math.max(0, Math.floor(ty * sh)));
      const si = (sy * sw + sx) * 4;
      const oi = (y * size + x) * 4;
      odata[oi] = sdata[si]!;
      odata[oi + 1] = sdata[si + 1]!;
      odata[oi + 2] = sdata[si + 2]!;
      odata[oi + 3] = 255;
    }
  }
  ctx.putImageData(out, 0, 0);
  return canvas.toDataURL("image/jpeg", 0.8);
}

/** The four straight-ahead views used as analysis aids. */
export async function renderAnalysisCrops(panoramaDataUrl: string): Promise<{ imageBase64: string; label: string }[]> {
  const img = await loadImage(panoramaDataUrl);
  const canvas = await toCanvas(img, MAX_SEND_DIMENSION);
  const labels = ["looking at the front wall", "looking right", "looking at the wall behind the camera", "looking left"];
  return [0, 90, 180, 270].map((yaw, i) => ({
    imageBase64: renderPerspectiveCrop(canvas, yaw).split(",")[1] ?? "",
    label: labels[i]!,
  }));
}

async function idToken(): Promise<string | null> {
  try {
    return (await auth?.currentUser?.getIdToken()) ?? null;
  } catch {
    return null;
  }
}

export async function analyzeFloorPlan(
  panoramaDataUrl: string
): Promise<AnalyzeFloorPlanResult> {
  const token = await idToken();
  if (!token) {
    return { ok: false, error: "Sign in to use AI floor-plan analysis." };
  }
  const prepared = await preparePanorama(panoramaDataUrl);
  if (!prepared.ok) return prepared;

  let crops: { imageBase64: string; label: string }[] = [];
  try {
    crops = await renderAnalysisCrops(panoramaDataUrl);
  } catch {
    crops = []; // crops are aids, never a requirement
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 60_000);
  try {
    const response = await fetch("/api/analyze-floorplan", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      signal: controller.signal,
      body: JSON.stringify({
        imageBase64: prepared.base64,
        mimeType: prepared.mimeType,
        crops,
      }),
    });
    const body = await response.json().catch(() => null);
    if (!response.ok) {
      return {
        ok: false,
        error: body?.error ?? `Analysis failed (${response.status}).`,
        quotaExhausted: response.status === 429,
      };
    }
    if (!body?.roomOutline || !Array.isArray(body.roomOutline)) {
      return { ok: false, error: "The analysis response was malformed." };
    }
    return { ok: true, analysis: body as ConceptAnalysis };
  } catch (err: any) {
    if (err?.name === "AbortError") {
      return { ok: false, error: "Analysis timed out — try again." };
    }
    return { ok: false, error: "Could not reach the floor-plan analysis endpoint." };
  } finally {
    clearTimeout(timeoutId);
  }
}
