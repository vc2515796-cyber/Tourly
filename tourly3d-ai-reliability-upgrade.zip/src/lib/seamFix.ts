/**
 * Silently fixes the left/right seam of a panorama photo before it's
 * stored — invisible to the user. Only works for JPEG (see
 * netlify/functions/fix-seam.mts for why). On any failure, non-JPEG
 * input, or missing backend, resolves with the ORIGINAL image unchanged.
 */

const MAX_SEND_DIMENSION = 3000;

function loadImage(dataUrl: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = dataUrl;
  });
}

function dataUrlToBase64(dataUrl: string): { base64: string; mimeType: string } {
  const [header, base64] = dataUrl.split(",");
  const mimeType = header.match(/data:(.*);base64/)?.[1] ?? "image/jpeg";
  return { base64, mimeType };
}

async function downscaleIfNeeded(dataUrl: string, maxDimension: number): Promise<string> {
  const img = await loadImage(dataUrl);
  if (Math.max(img.width, img.height) <= maxDimension) return dataUrl;

  const scale = maxDimension / Math.max(img.width, img.height);
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(img.width * scale);
  canvas.height = Math.round(img.height * scale);
  const ctx = canvas.getContext("2d");
  if (!ctx) return dataUrl;
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL("image/jpeg", 0.92);
}

export async function fixSeam(originalDataUrl: string): Promise<string> {
  try {
    const { mimeType: originalMime } = dataUrlToBase64(originalDataUrl);
    if (!/jpe?g/i.test(originalMime)) return originalDataUrl; // only JPEG supported today

    const sendDataUrl = await downscaleIfNeeded(originalDataUrl, MAX_SEND_DIMENSION);
    const { base64, mimeType } = dataUrlToBase64(sendDataUrl);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 20_000);

    const response = await fetch("/api/fix-seam", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      body: JSON.stringify({ imageBase64: base64, mimeType }),
    }).finally(() => clearTimeout(timeoutId));

    if (!response.ok) return originalDataUrl;

    const result = await response.json();
    if (!result?.imageBase64) return originalDataUrl;

    return `data:${result.mimeType ?? "image/jpeg"};base64,${result.imageBase64}`;
  } catch {
    return originalDataUrl;
  }
}
