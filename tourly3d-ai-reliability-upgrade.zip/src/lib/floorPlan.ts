import { FloorPlan, FloorPlanMarker, Tour } from "../types";

/**
 * Floor-plan HUD helpers (Feature C).
 *
 * HONEST LIMITATION (documented in README): marker positions are placed
 * MANUALLY by the creator. There is no automatic geometric mapping between
 * panorama pixels and blueprint coordinates — every marker's (x, y) is a
 * human judgement, and `northYaw` is a manual per-marker calibration of
 * which camera yaw points "up" on the blueprint. Nothing here claims
 * otherwise, and the UI never presents markers as survey-grade.
 */

export const FLOOR_PLAN_MAX_BYTES = 6_000_000; // before compression
export const FLOOR_PLAN_MAX_DIM = 3072;

export type FloorPlanBuildResult =
  | { ok: true; floorPlan: FloorPlan }
  | { ok: false; error: string };

function loadImage(dataUrl: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = dataUrl;
  });
}

/** Reads + validates a blueprint upload. Accepts normal photos/scans of
 *  plans as well as exported images; rejects non-images and files that are
 *  still huge after compression. */
export async function buildFloorPlanFromFile(
  file: File,
  compress: (dataUrl: string) => Promise<string>
): Promise<FloorPlanBuildResult> {
  if (!file.type.startsWith("image/")) {
    return { ok: false, error: "Floor plan must be an image (JPG, PNG or WebP)." };
  }
  if (file.size > FLOOR_PLAN_MAX_BYTES) {
    return { ok: false, error: "Floor plan image is too large — keep it under 6 MB." };
  }
  const readDataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error("read failed"));
    reader.readAsDataURL(file);
  }).catch(() => null);
  if (!readDataUrl) return { ok: false, error: "Couldn't read that file — try again." };

  const dataUrl = await compress(readDataUrl);
  let img: HTMLImageElement;
  try {
    img = await loadImage(dataUrl);
  } catch {
    return { ok: false, error: "That image couldn't be decoded — try a different file." };
  }
  return {
    ok: true,
    floorPlan: {
      dataUrl,
      width: img.width,
      height: img.height,
      markers: [],
    },
  };
}

/** One marker per stop — placing a marker for a stop that already has one
 *  moves it instead of duplicating. */
export function upsertMarker(
  floorPlan: FloorPlan,
  marker: FloorPlanMarker
): FloorPlan {
  const markers = floorPlan.markers.filter((m) => m.stopId !== marker.stopId);
  markers.push({ ...marker, x: clamp01(marker.x), y: clamp01(marker.y) });
  return { ...floorPlan, markers };
}

export function removeMarker(floorPlan: FloorPlan, stopId: string): FloorPlan {
  return { ...floorPlan, markers: floorPlan.markers.filter((m) => m.stopId !== stopId) };
}

export function markerForStop(tour: Tour, stopId: string): FloorPlanMarker | undefined {
  return tour.floorPlan?.markers.find((m) => m.stopId === stopId);
}

export function clamp01(v: number): number {
  return Math.max(0, Math.min(1, v));
}

/** Converts a click position inside a rendered blueprint element into
 *  normalized marker coordinates. This is what keeps markers aligned when
 *  the overlay is resized/re-cropped on any screen: we always divide by the
 *  element's CURRENT box, so the stored 0..1 value maps to the same
 *  relative spot at any scale or aspect ratio. */
export function eventToNormalized(
  el: HTMLElement,
  clientX: number,
  clientY: number
): { x: number; y: number } {
  const rect = el.getBoundingClientRect();
  return {
    x: clamp01((clientX - rect.left) / Math.max(rect.width, 1)),
    y: clamp01((clientY - rect.top) / Math.max(rect.height, 1)),
  };
}

/** The radar cone's rotation (CSS degrees, clockwise from up) given the
 *  live camera yaw and the marker's manual north calibration. Returns null
 *  when the marker was never calibrated — the HUD then hides the cone
 *  rather than showing a misleading orientation. */
export function radarRotationDeg(cameraYawDeg: number, northYawDeg: number | undefined): number | null {
  if (northYawDeg === undefined || northYawDeg === null || Number.isNaN(northYawDeg)) return null;
  // Camera yaw follows the equirect convention (counter-clockwise positive
  // around Y from +X). The cone points where the camera looks: rotation is
  // the signed difference between current yaw and the calibrated "up".
  let rel = cameraYawDeg - northYawDeg;
  rel = ((rel + 180) % 360 + 360) % 360 - 180; // wrap to -180..180
  return -rel;
}
