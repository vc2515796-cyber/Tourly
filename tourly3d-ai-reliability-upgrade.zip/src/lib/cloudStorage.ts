import { auth } from "./firebase";

/**
 * Cloud media storage client (Feature G).
 *
 * Talks to the /api/media-upload Netlify function, which issues SERVER-SIDE
 * S3 presigned PUT URLs (SigV4). No storage credentials ever reach the
 * browser — only short-lived (15 min) single-object upload URLs.
 *
 * HONEST BEHAVIOUR: when the deployment has no S3_* env vars configured,
 * `getCloudStorageStatus()` reports `{ configured: false }` and callers are
 * expected to fall back to the legacy embedded-dataUrl flow WITH A VISIBLE
 * NOTICE — never a silent fallback that pretends media is in the cloud.
 */

export type CloudStorageStatus = { configured: boolean; reason?: string };

export type CloudUpload = {
  /** Public (or CDN) URL the viewer loads the media from. */
  url: string;
  /** Object key, kept so the media can be deleted/replaced later. */
  key: string;
};

async function idToken(): Promise<string | null> {
  return auth?.currentUser?.getIdToken().catch(() => null) ?? null;
}

let cachedStatus: CloudStorageStatus | null = null;

/** Cheap GET check — safe to call once per editor session. */
export async function getCloudStorageStatus(force = false): Promise<CloudStorageStatus> {
  if (cachedStatus && !force) return cachedStatus;
  try {
    const response = await fetch("/api/media-upload");
    const body = await response.json().catch(() => null);
    cachedStatus = { configured: Boolean(body?.configured), reason: body?.reason };
  } catch {
    cachedStatus = { configured: false, reason: "unreachable" };
  }
  return cachedStatus;
}

async function callUploadApi(payload: Record<string, unknown>): Promise<Response> {
  const token = await idToken();
  if (!token) throw new Error("Sign in to upload media to cloud storage.");
  const response = await fetch("/api/media-upload", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify(payload),
  });
  if (response.status === 401) throw new Error("Your session has expired — sign in again and retry.");
  return response;
}

/** Uploads a file to S3-compatible storage via a presigned URL, with real
 *  upload progress (XHR — fetch() still has no portable upload progress). */
export function uploadToCloud(
  file: File,
  opts: { onProgress?: (fraction: number) => void; signal?: AbortSignal } = {}
): Promise<CloudUpload> {
  return (async () => {
    const signResponse = await callUploadApi({
      action: "sign",
      filename: file.name,
      contentType: file.type || "application/octet-stream",
      size: file.size,
    });
    if (!signResponse.ok) {
      const body = await signResponse.json().catch(() => null);
      throw new Error(body?.error ?? `Cloud upload isn't available (${signResponse.status}).`);
    }
    const signed = await signResponse.json();
    if (!signed?.uploadUrl || !signed?.publicUrl || !signed?.key) {
      throw new Error("Cloud storage returned an incomplete response.");
    }

    return new Promise<CloudUpload>((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open("PUT", signed.uploadUrl);
      // MUST match the Content-Type that was signed — S3 rejects otherwise.
      xhr.setRequestHeader("Content-Type", file.type || "application/octet-stream");
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable && opts.onProgress) opts.onProgress(e.loaded / e.total);
      };
      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          opts.onProgress?.(1);
          resolve({ url: signed.publicUrl, key: signed.key });
        } else {
          reject(new Error(`Cloud upload failed (${xhr.status}) — check the bucket's CORS settings.`));
        }
      };
      xhr.onerror = () => reject(new Error("Cloud upload failed — network error or bucket CORS misconfigured."));
      xhr.onabort = () => reject(new Error("Upload cancelled."));
      opts.signal?.addEventListener("abort", () => xhr.abort(), { once: true });
      xhr.send(file);
    });
  })();
}

/** Best-effort delete of a previously uploaded object. The server refuses
 *  keys outside the caller's own prefix, so this can't remove anyone else's
 *  media. Errors are surfaced, not swallowed. */
export async function deleteFromCloud(key: string): Promise<void> {
  const response = await callUploadApi({ action: "delete", key });
  if (!response.ok) {
    const body = await response.json().catch(() => null);
    throw new Error(body?.error ?? `Could not delete cloud media (${response.status}).`);
  }
}
