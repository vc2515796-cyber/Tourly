/**
 * Stage C — client side of buyer-engagement analytics.
 *
 * What this does NOT do: no cookies, no fingerprinting, no third-party
 * beacons. The "visitor token" is a random string generated once per
 * browser; the server only ever stores a truncated hash of it so unique
 * visitors can be estimated per day (see _analytics.mts for the model).
 *
 * Everything here is strictly best-effort: a tracking failure must NEVER
 * break or slow down the tour page.
 */

const TOKEN_KEY = "waypoint:visitor-token";
const SESSION_PREFIX = "waypoint:tracked:";

export type TrackKind = "tour-view" | "scene-view" | "hotspot";
export type ShareSource = "direct" | "link" | "qr" | "wa" | "embed";

/** Random per-browser token (no PII — derived from nothing). Returns ""
 *  when storage is blocked; the event still counts, just not as unique. */
export function getVisitorToken(): string {
  try {
    let token = localStorage.getItem(TOKEN_KEY);
    if (!token || !/^[A-Za-z0-9_-]{8,64}$/.test(token)) {
      const bytes = new Uint8Array(12);
      crypto.getRandomValues(bytes);
      token = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
      localStorage.setItem(TOKEN_KEY, token);
    }
    return token;
  } catch {
    return "";
  }
}

/** Where this open came from: ?src= tag first (qr/wa/link/embed), then
 *  iframe detection (embed), else direct. */
export function tourSourceFromLocation(): ShareSource {
  try {
    const src = new URLSearchParams(window.location.search).get("src");
    if (src === "qr" || src === "wa" || src === "link" || src === "embed") return src;
    if (window.self !== window.top) return "embed";
  } catch {
    // Cross-origin iframe access throws — that itself means embedded.
    return "embed";
  }
  return "direct";
}

/** True exactly once per visitor-session per tour — this is what stops a
 *  refresh from double-counting a tour view. */
export function markTourViewedSession(tourId: string): boolean {
  try {
    const key = `${SESSION_PREFIX}${tourId}`;
    if (sessionStorage.getItem(key)) return false;
    sessionStorage.setItem(key, "1");
    return true;
  } catch {
    // Storage blocked — count the view rather than silently lose it.
    return true;
  }
}

/** Fire-and-forget event POST. Never throws, never retries: analytics is
 *  not worth the visitor's battery. keepalive lets it survive navigation. */
export function trackTourEvent(tourId: string, kind: TrackKind, sceneId?: string): void {
  try {
    const body = JSON.stringify({
      tourId,
      kind,
      source: tourSourceFromLocation(),
      sceneId: sceneId ?? undefined,
      visitorId: getVisitorToken() || undefined,
    });
    void fetch("/api/track-event", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body,
      keepalive: true,
    }).catch(() => {
      // Offline / dev server without functions — fine, skip.
    });
  } catch {
    // Never let analytics break the page.
  }
}

/** Absolute share URL for a tour with a source tag, so the Analytics
 *  page can attribute visitors to QR codes / WhatsApp / links / embeds. */
export function buildShareUrl(tourId: string, source: "link" | "qr" | "wa"): string {
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  return `${origin}/tour/${tourId}?src=${source}`;
}

/** Embeds deliberately load the plain URL plus an embed marker: the
 *  iframe's src param wins over iframe detection. */
export function buildEmbedUrl(tourId: string): string {
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  return `${origin}/tour/${tourId}?embed=1&src=embed`;
}

// --- agent dashboard fetch -------------------------------------------------

export type TourAnalyticsSummary = {
  id: string;
  name: string;
  views: number;
  uniques: number;
  uniquesCapped: boolean;
  sceneViews: number;
  hotspotClicks: number;
  enquiries: number;
  visitRequests: number;
  conversionRate: number | null;
  sources: Partial<Record<ShareSource, number>>;
  topScenes: { sceneId: string; views: number }[];
};

export type AnalyticsSummary = {
  window: { days: number; from: string; to: string };
  tours: TourAnalyticsSummary[];
  overall: {
    views: number;
    uniques: number;
    uniquesCapped: boolean;
    sceneViews: number;
    hotspotClicks: number;
    enquiries: number;
    visitRequests: number;
    conversionRate: number | null;
    sources: Partial<Record<ShareSource, number>>;
    prevViews: number;
    prevEnquiries: number;
  };
  generatedAt: number;
};

export type AnalyticsSummaryResult =
  | { ok: true; data: AnalyticsSummary }
  | { ok: false; error: string; notConfigured?: boolean; needsAuth?: boolean };

/** Authenticated summary for the agent's OWN published tours — ownership
 *  is enforced server-side; tours without a server-side owner record for
 *  the caller simply don't come back. */
export async function fetchAnalyticsSummary(
  tourIds: string[],
  days: 7 | 30 | 90,
  idToken: string
): Promise<AnalyticsSummaryResult> {
  try {
    const response = await fetch(`/api/analytics-summary?ids=${encodeURIComponent(tourIds.join(","))}&days=${days}`, {
      headers: { Authorization: `Bearer ${idToken}` },
    });
    const body = await response.json().catch(() => null);
    if (response.status === 503) {
      return { ok: false, error: body?.error ?? "Analytics isn't configured on this deployment.", notConfigured: true };
    }
    if (response.status === 401) {
      return { ok: false, error: body?.error ?? "Your session expired — sign in again.", needsAuth: true };
    }
    if (!response.ok || !body?.ok || !Array.isArray(body.tours)) {
      return { ok: false, error: body?.error ?? "Couldn't load analytics right now." };
    }
    return { ok: true, data: body as AnalyticsSummary };
  } catch {
    return { ok: false, error: "Network problem — try again." };
  }
}
