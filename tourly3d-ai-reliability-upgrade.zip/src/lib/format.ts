/**
 * Indian-market formatting helpers.
 *
 * formatINR uses the en-IN locale, which groups digits the Indian way
 * (1,23,45,678) — the grouping buyers and agents actually read. Input is
 * a NUMBER only; free-text prices like "₹85 lakh" or "1.2 Cr" stay
 * free text wherever the agent typed them (never reformatted, never
 * invented).
 */
export function formatINR(value: number, opts?: { compact?: boolean }): string {
  if (!Number.isFinite(value)) return "—";
  try {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: value >= 1000 ? 0 : 2,
      ...(opts?.compact ? { notation: "compact" } : {}),
    }).format(value);
  } catch {
    return `₹${Math.round(value).toLocaleString("en-IN")}`;
  }
}

/** "12 Oct 2026" style dates used across the CRM and analytics pages. */
export function formatDateIN(epochMs: number): string {
  try {
    return new Date(epochMs).toLocaleDateString("en-IN", {
      day: "numeric",
      month: "short",
      year: "numeric",
    });
  } catch {
    return new Date(epochMs).toISOString().slice(0, 10);
  }
}
