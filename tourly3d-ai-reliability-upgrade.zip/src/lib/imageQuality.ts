/**
 * Local image-quality checks for the smart-upload flow (B1).
 *
 * Everything here runs on-device via the Canvas API — no bytes are uploaded
 * for quality analysis. The results are WARNINGS for a human to review,
 * never hard blocks: a dark photo of a cinema room can be exactly what the
 * creator wants. The pure-scoring core (works on ImageData-like objects)
 * is split out so it can be unit-tested in Node without a canvas.
 */

import type { ImageDataLike } from "./phash";

export type QualityFlags = {
  /** 0..100 — mean luma; very low means the photo is mostly dark. */
  brightness: number;
  /** Pixel dimensions actually checked (after decode, before compression). */
  width: number;
  height: number;
  blurry: boolean;
  tooDark: boolean;
  lowResolution: boolean;
};

// Thresholds are deliberately conservative: flag only clearly problematic
// photos so warnings stay trustworthy.
export const DARK_BRIGHTNESS_THRESHOLD = 18; // 0..100 mean luma
export const LOW_RES_MIN_EDGE = 720; // px on the shorter side

export type QualityScore = Omit<QualityFlags, "blurry" | "tooDark" | "lowResolution"> & {
  laplacianVariance: number | null;
};

/** Pure core: brightness + resolution scoring from raw RGBA pixels. */
export function scoreQualityCore(image: ImageDataLike): QualityScore {
  const { data, width, height } = image;
  let sum = 0;
  const n = width * height;
  for (let i = 0; i < n; i++) {
    const r = data[i * 4];
    const g = data[i * 4 + 1];
    const b = data[i * 4 + 2];
    sum += 0.299 * r + 0.587 * g + 0.114 * b;
  }
  const brightness = n ? Math.round((sum / n) / 255 * 100) : 0;
  return { brightness, width, height, laplacianVariance: null };
}

/** Pure core: Laplacian-edge variance (same heuristic as qualityCheck.ts,
 *  factored out so it can run on the SAME decoded pixels as brightness
 *  instead of decoding the image twice). */
export function laplacianVarianceCore(image: ImageDataLike): number | null {
  const { data, width, height } = image;
  if (width < 3 || height < 3) return null;
  const gray = new Float32Array(width * height);
  for (let i = 0; i < width * height; i++) {
    gray[i] = 0.299 * data[i * 4] + 0.587 * data[i * 4 + 1] + 0.114 * data[i * 4 + 2];
  }
  let sum = 0;
  let sumSq = 0;
  let count = 0;
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const idx = y * width + x;
      const v =
        4 * gray[idx] - gray[idx - 1] - gray[idx + 1] - gray[idx - width] - gray[idx + width];
      sum += v;
      sumSq += v * v;
      count++;
    }
  }
  if (!count) return null;
  const mean = sum / count;
  return sumSq / count - mean * mean;
}

export const BLUR_VARIANCE_THRESHOLD = 90; // matches qualityCheck.ts

/** Decodes a dataUrl ONCE and runs brightness + blur + resolution checks
 *  together. Returns null when the browser can't decode the image — the
 *  caller treats that as "no quality info" (never as a failure of the
 *  upload itself). */
export async function checkImageQuality(dataUrl: string): Promise<QualityFlags | null> {
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error("decode failed"));
      el.src = dataUrl;
    });
    const maxSide = Math.max(img.width, img.height);
    const scale = Math.min(1, 300 / maxSide);
    const w = Math.max(1, Math.round(img.width * scale));
    const h = Math.max(1, Math.round(img.height * scale));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    if (!ctx) return null;
    ctx.drawImage(img, 0, 0, w, h);
    const imageData = ctx.getImageData(0, 0, w, h);

    const base = scoreQualityCore(imageData);
    const lv = laplacianVarianceCore(imageData);
    return {
      brightness: base.brightness,
      width: img.width, // report the TRUE dimensions, not the sample
      height: img.height,
      blurry: lv !== null ? lv < BLUR_VARIANCE_THRESHOLD : false,
      tooDark: base.brightness < DARK_BRIGHTNESS_THRESHOLD,
      lowResolution: Math.min(img.width, img.height) < LOW_RES_MIN_EDGE,
    };
  } catch {
    return null;
  }
}

/** Human-readable summary of the warnings (empty string when clean). */
export function describeQualityWarnings(q: QualityFlags | null): string[] {
  if (!q) return [];
  const out: string[] = [];
  if (q.blurry) out.push("may be blurry");
  if (q.tooDark) out.push("very dark");
  if (q.lowResolution) out.push(`low resolution (${q.width}×${q.height})`);
  return out;
}
