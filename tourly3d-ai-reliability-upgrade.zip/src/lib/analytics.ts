/**
 * Optional, consent-gated Google Analytics 4.
 *
 * - Does nothing unless VITE_GA_MEASUREMENT_ID is set (a public id like G-XXXX).
 * - Loads nothing, and sets no cookies, until the visitor clicks "Accept".
 * - Never runs inside an embedded iframe (embedded tours stay tracker-free).
 * - Sends page paths with tour/editor ids masked, so unlisted tour links
 *   never reach a third party.
 * The app's own view counts (localStorage) are separate and always local.
 */
const GA_ID = import.meta.env.VITE_GA_MEASUREMENT_ID as string | undefined;

export const analyticsConfigured = Boolean(GA_ID && /^G-[A-Z0-9]+$/i.test(GA_ID));

const CONSENT_KEY = "waypoint:consent";
export const CONSENT_EVENT = "waypoint:consent-changed";
export const OPEN_SETTINGS_EVENT = "waypoint:open-cookie-settings";

export type Consent = "granted" | "denied" | null;

export function inIframe(): boolean {
  try {
    return window.self !== window.top;
  } catch {
    return true;
  }
}

export function getConsent(): Consent {
  try {
    const v = localStorage.getItem(CONSENT_KEY);
    return v === "granted" || v === "denied" ? v : null;
  } catch {
    return null;
  }
}

let loaded = false;

function gtag(...args: unknown[]) {
  const w = window as any;
  w.dataLayer = w.dataLayer || [];
  w.dataLayer.push(args);
}

function loadGa() {
  if (loaded || !analyticsConfigured || inIframe()) return;
  loaded = true;
  (window as any)[`ga-disable-${GA_ID}`] = false;
  gtag("js", new Date());
  gtag("config", GA_ID, { send_page_view: false, anonymize_ip: true });
  const s = document.createElement("script");
  s.async = true;
  s.src = `https://www.googletagmanager.com/gtag/js?id=${GA_ID}`;
  document.head.appendChild(s);
}

function clearGaCookies() {
  const host = window.location.hostname;
  document.cookie.split(";").forEach((c) => {
    const name = c.split("=")[0].trim();
    if (name.startsWith("_ga")) {
      for (const domain of ["", `;domain=${host}`, `;domain=.${host}`]) {
        document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/${domain}`;
      }
    }
  });
}

export function setConsent(value: "granted" | "denied") {
  try {
    localStorage.setItem(CONSENT_KEY, value);
  } catch {
    /* storage blocked — the choice just won't persist */
  }
  if (value === "granted") {
    loadGa();
    trackPageView(window.location.pathname);
  } else if (analyticsConfigured) {
    (window as any)[`ga-disable-${GA_ID}`] = true;
    clearGaCookies();
  }
  window.dispatchEvent(new Event(CONSENT_EVENT));
}

export function initAnalytics() {
  if (getConsent() === "granted") loadGa();
}

/** Mask ids in unlisted/private URLs before anything is sent to Google. */
export function sanitizePath(path: string): string {
  return path.replace(/^\/(tour|editor)\/[^/?#]+/, "/$1/[id]");
}

export function trackPageView(path: string) {
  if (!loaded || getConsent() !== "granted") return;
  gtag("event", "page_view", { page_path: sanitizePath(path), page_title: document.title });
}

export function track(event: string, params?: Record<string, string | number | boolean>) {
  if (!loaded || getConsent() !== "granted") return;
  gtag("event", event, params);
}
