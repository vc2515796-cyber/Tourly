import { ConstructionSnapshot, Tour, StopMedia } from "../types";

/**
 * Construction progress snapshots (Feature D).
 *
 * Snapshots are APPEND-ONLY — capturing never overwrites history — and are
 * persisted inside the tour JSON (localStorage draft + the published copy
 * in Netlify Blobs via the existing publish flow), so they survive reloads
 * and follow the tour across devices. Media is deduplicated: when the
 * scene's media is byte-identical to the previous snapshot, the new
 * snapshot stores a reference to it instead of a second copy of the same
 * (potentially multi-megabyte) dataUrl.
 */

export function snapshotsForStop(tour: Tour, stopId: string): ConstructionSnapshot[] {
  return (tour.snapshots ?? [])
    .filter((s) => s.stopId === stopId)
    .sort((a, b) => b.capturedAt - a.capturedAt);
}

export function allSnapshots(tour: Tour): ConstructionSnapshot[] {
  return [...(tour.snapshots ?? [])].sort((a, b) => b.capturedAt - a.capturedAt);
}

/** Resolves a snapshot's displayable media, following dedup references. */
export function resolveSnapshotMedia(tour: Tour, snapshot: ConstructionSnapshot): StopMedia | null {
  let current: ConstructionSnapshot | undefined = snapshot;
  const guard = new Set<string>();
  while (current) {
    if (guard.has(current.id)) return null; // cycle guard — corrupt data must not hang the UI
    guard.add(current.id);
    if (current.mediaDataUrl || current.mediaUrl) {
      return {
        kind: current.mediaKind ?? "image",
        dataUrl: current.mediaDataUrl ?? "",
        url: current.mediaUrl,
      };
    }
    if (!current.sameMediaAsSnapshotId) return null;
    current = (tour.snapshots ?? []).find((s) => s.id === current!.sameMediaAsSnapshotId);
  }
  return null;
}

export type SnapshotSaveResult =
  | { ok: true; snapshot: ConstructionSnapshot }
  | { ok: false; error: string };

/** Captures the scene's CURRENT media as a versioned snapshot. */
export function captureSnapshot(
  tour: Tour,
  stopId: string,
  stageLabel: string,
  capturedAt: number,
  note?: string
): SnapshotSaveResult {
  const stop = tour.stops.find((s) => s.id === stopId);
  if (!stop?.media) {
    return { ok: false, error: "This scene has no media to capture yet." };
  }
  const label = stageLabel.trim();
  if (!label) {
    return { ok: false, error: "Add a stage label first (e.g. \"Plaster stage\")." };
  }

  const previous = snapshotsForStop(tour, stopId)[0];
  const previousMedia = previous ? resolveSnapshotMedia(tour, previous) : null;

  // Dedup: same cloud object AND same embedded preview = same media —
  // reference the earlier snapshot instead of copying it again.
  const sameMedia =
    previousMedia !== null &&
    previousMedia.url === stop.media.url &&
    previousMedia.dataUrl === stop.media.dataUrl;

  const snapshot: ConstructionSnapshot = {
    id: crypto.randomUUID(),
    tourId: tour.id,
    stopId,
    capturedAt: Number.isFinite(capturedAt) ? capturedAt : Date.now(),
    stageLabel: label.slice(0, 80),
    note: note?.trim() ? note.trim().slice(0, 300) : undefined,
    stopTitle: stop.title || "Untitled scene",
    mediaKind: stop.media.kind,
    ...(sameMedia && previous
      ? { sameMediaAsSnapshotId: previous.id }
      : { mediaDataUrl: stop.media.dataUrl, mediaUrl: stop.media.url }),
  };

  return { ok: true, snapshot };
}

export function withSnapshotAdded(tour: Tour, snapshot: ConstructionSnapshot): Tour {
  return { ...tour, snapshots: [...(tour.snapshots ?? []), snapshot] };
}

export function withSnapshotDeleted(tour: Tour, snapshotId: string): Tour {
  // Snapshots that dedup-reference the deleted one are re-pointed to the
  // media they logically share — history stays intact.
  const snapshots = (tour.snapshots ?? []).filter((s) => s.id !== snapshotId);
  const deleted = (tour.snapshots ?? []).find((s) => s.id === snapshotId);
  const fixed = snapshots.map((s) =>
    s.sameMediaAsSnapshotId === snapshotId && deleted
      ? {
          ...s,
          sameMediaAsSnapshotId: deleted.sameMediaAsSnapshotId,
          mediaDataUrl: s.mediaDataUrl ?? deleted.mediaDataUrl,
          mediaUrl: s.mediaUrl ?? deleted.mediaUrl,
        }
      : s
  );
  return { ...tour, snapshots: fixed };
}

export function formatSnapshotDate(ts: number): string {
  return new Date(ts).toLocaleDateString(undefined, {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}
