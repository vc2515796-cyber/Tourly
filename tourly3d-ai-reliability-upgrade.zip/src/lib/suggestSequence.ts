/**
 * Asks Gemini to suggest a logical visiting ORDER for the tour's scenes
 * (entrance → living areas → bedrooms → outdoor). Returns a suggestion the
 * creator can review, reorder-per-move, or discard — it is NEVER applied
 * automatically, and scene connections/dimensions it infers are not treated
 * as verified facts.
 */

export type SequenceSuggestion = {
  /** Ordered stop ids. */
  orderedIds: string[];
  /** One-line rationale shown to the creator. */
  rationale: string;
};

export async function suggestSequence(
  stops: { id: string; title: string; note?: string }[]
): Promise<{ ok: true; suggestion: SequenceSuggestion } | { ok: false; error: string }> {
  if (stops.length < 2) return { ok: false, error: "Add at least two scenes first." };
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 25_000);

    const response = await fetch("/api/suggest-sequence", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      body: JSON.stringify({
        stops: stops.map((s) => ({ id: s.id, title: s.title, note: s.note ?? "" })),
      }),
    }).finally(() => clearTimeout(timeoutId));

    if (!response.ok) {
      const body = await response.json().catch(() => null);
      return { ok: false, error: body?.error ?? `Sequence suggestion failed (${response.status}).` };
    }
    const result = await response.json();
    if (!Array.isArray(result?.orderedIds) || typeof result?.rationale !== "string") {
      return { ok: false, error: "Gemini didn't return a usable sequence." };
    }
    return { ok: true, suggestion: { orderedIds: result.orderedIds, rationale: result.rationale } };
  } catch (err: any) {
    if (err?.name === "AbortError") return { ok: false, error: "Sequence suggestion timed out." };
    return { ok: false, error: "Could not reach the sequence endpoint." };
  }
}
