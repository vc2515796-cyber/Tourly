/**
 * Shared AI error normalization for the frontend (Phase 7 of the reliability
 * upgrade). Every AI client funnels its failure through `friendlyAiError` so
 * users always get the same honest, actionable message for the same failure
 * class — never a raw stack trace, provider response dump, or internal URL.
 *
 * Messages match the project's existing English tone (the mandated examples
 * were Hinglish; the app's UI language is English, so we keep English and
 * stay consistent).
 */

export type AiErrorKind =
  | "rate-limit" // temporary — retry after a short wait helps
  | "quota" // daily usage limit reached — retry tomorrow
  | "provider-quota" // the SERVER's provider daily quota is exhausted
  | "not-configured" // site owner hasn't set up AI
  | "auth" // user session expired
  | "network" // connection issue
  | "timeout" // request took too long
  | "server" // provider temporarily unavailable
  | "invalid" // the request itself was bad (our bug or bad input)
  | "partial" // batch: some scenes done, some failed
  | "unknown";

export type FriendlyAiError = {
  kind: AiErrorKind;
  message: string;
  /** Whether pressing "retry" shortly can realistically help. */
  canRetry: boolean;
};

/** Normalizes a fetch Response (or thrown error) into a friendly message. */
export async function friendlyAiError(
  response: Response | null,
  thrown?: unknown
): Promise<FriendlyAiError> {
  // Network-level failure (fetch rejected / aborted by our client timeout)
  if (!response) {
    const name = (thrown as any)?.name;
    if (name === "AbortError") {
      return {
        kind: "timeout",
        message: "The AI service took too long to respond. Your saved work is safe — please try again.",
        canRetry: true,
      };
    }
    return {
      kind: "network",
      message: "Connection issue. Please check your internet and try again — your saved work is safe.",
      canRetry: true,
    };
  }

  let body: any = null;
  try {
    body = await response.json();
  } catch {
    /* non-JSON error body */
  }
  const serverMessage: string = typeof body?.error === "string" ? body.error : "";

  switch (response.status) {
    case 429: {
      // Our own per-user daily limit vs the provider's own quota — both are
      // "come back later", but the wording differs.
      if (body?.quota) {
        return {
          kind: "quota",
          message: `You've reached today's AI limit for this feature (${body.quota.limit} per day). Your work is saved — you can keep editing manually and try again tomorrow.`,
          canRetry: false,
        };
      }
      if (/daily limit|quota is used up|daily quota/i.test(serverMessage)) {
        return {
          kind: "provider-quota",
          message: "The AI service's daily limit is used up. Your work is safe — please try again tomorrow.",
          canRetry: false,
        };
      }
      return {
        kind: "rate-limit",
        message: "The AI service is busy right now. Your work is saved — please wait a minute and try again.",
        canRetry: true,
      };
    }
    case 503:
      if (/configured|API key/i.test(serverMessage)) {
        return {
          kind: "not-configured",
          message: "The AI service isn't configured on this deployment yet. You can continue with the manual workflow.",
          canRetry: false,
        };
      }
      return {
        kind: "server",
        message: "The AI service is temporarily unavailable. Your work is saved — please try again in a moment.",
        canRetry: true,
      };
    case 504:
      return {
        kind: "timeout",
        message: "The AI service took too long to respond. Your work is saved — please try again.",
        canRetry: true,
      };
    case 401:
      return {
        kind: "auth",
        message: "Your session has expired — sign in again to use AI features. Your saved work is safe.",
        canRetry: false,
      };
    case 403:
      return {
        kind: "auth",
        message: "You don't have access to this feature on this account.",
        canRetry: false,
      };
    case 400:
    case 413:
    case 415:
      return {
        kind: "invalid",
        message: serverMessage || "That request couldn't be processed — check the input and try again.",
        canRetry: false,
      };
    default:
      if (response.ok) {
        return { kind: "unknown", message: "Something went wrong. Please try again.", canRetry: true };
      }
      return {
        kind: "server",
        message: serverMessage || "The AI service hit a problem. Your work is saved — please try again.",
        canRetry: true,
      };
  }
}

/** Summary copy for a partial multi-scene batch (some succeeded, some failed). */
export function partialBatchMessage(completed: number, failed: number, skipped: number): string {
  const parts = [
    `${completed} scene${completed === 1 ? "" : "s"} processed`,
    skipped > 0 ? `${skipped} skipped` : "",
    failed > 0 ? `${failed} failed` : "",
  ].filter(Boolean);
  return `${parts.join(", ")}. ${failed > 0 ? "You can retry just the failed scenes — successful ones are kept." : ""}`.trim();
}
