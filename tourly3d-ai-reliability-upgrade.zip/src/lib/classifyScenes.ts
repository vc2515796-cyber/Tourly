/**
 * Client for the batch scene-classification endpoint (Stage B1).
 *
 * Sends already-downscaled images to the server-side Gemini call and gets
 * back, per image: a room CATEGORY from a fixed list, a suggested readable
 * title, a short description, a confidence hint and a suggested tour order.
 *
 * Honesty rules baked in:
 * - The category is a SUGGESTION (the user can correct every field before
 *   applying); confidence is the model's self-report, not a verified fact.
 * - Room SIZE / dimensions are never requested or returned — they cannot be
 *   measured from an ordinary photo.
 * - Results are cached locally by perceptual hash, so re-running the
 *   suggestion flow (or re-adding the same photos) never re-sends an image
 *   whose result we already hold.
 */

export const ROOM_CATEGORIES = [
  "living-room",
  "bedroom",
  "kitchen",
  "bathroom",
  "balcony",
  "exterior",
  "dining-room",
  "hallway",
  "stairs",
  "parking",
  "amenity",
  "other",
  "unknown",
] as const;

export type RoomCategory = (typeof ROOM_CATEGORIES)[number];

export const CATEGORY_LABELS: Record<RoomCategory, string> = {
  "living-room": "Living room",
  bedroom: "Bedroom",
  kitchen: "Kitchen",
  bathroom: "Bathroom",
  balcony: "Balcony",
  exterior: "Exterior",
  "dining-room": "Dining room",
  hallway: "Hallway",
  stairs: "Stairs",
  parking: "Parking",
  amenity: "Amenity (pool/gym/garden…)",
  other: "Other room",
  unknown: "Unknown",
};

export type SceneClassification = {
  /** Client-supplied staging id — echoed back so results stay matched. */
  id: string;
  category: RoomCategory;
  title: string;
  description: string;
  /** 0..1 self-reported model confidence — a hint, never a verified fact. */
  confidence: number;
  /** Suggested position in the tour (1-based). Ties are fine; the user
   *  re-orders scenes freely afterwards. */
  order: number;
};

export type ClassifyResult =
  | { ok: true; results: SceneClassification[]; partial?: boolean; failedIds?: string[]; failureReason?: string }
  | { ok: false; error: string; quotaExhausted?: boolean };

export function isRoomCategory(v: unknown): v is RoomCategory {
  return typeof v === "string" && (ROOM_CATEGORIES as readonly string[]).includes(v);
}

// --- request shaping --------------------------------------------------------

const SEND_MAX_DIM = 640;
const MAX_IMAGES_PER_REQUEST = 12;

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("decode failed"));
    img.src = src;
  });
}

async function downscaleToJpegBase64(dataUrl: string, maxDim = SEND_MAX_DIM): Promise<{ base64: string; mimeType: string }> {
  const img = await loadImage(dataUrl);
  const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(img.width * scale));
  canvas.height = Math.max(1, Math.round(img.height * scale));
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("canvas unavailable");
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  const out = canvas.toDataURL("image/jpeg", 0.8);
  return { base64: out.split(",")[1] ?? "", mimeType: "image/jpeg" };
}

/** pHash-keyed cache: the same photo never goes to the AI twice in a page
 *  session. (A perceptual key is what makes this SAFE to reuse — a byte
 *  key would miss re-compressed copies and a naive reuse would wrongly
 *  serve a different photo's result.) */
const cache = new Map<string, SceneClassification>();

export function cachedClassification(phash: string): SceneClassification | undefined {
  return cache.get(phash);
}

export function rememberClassification(phash: string, result: SceneClassification) {
  cache.set(phash, result);
}

export type ClassifyRequestImage = { id: string; phash: string; dataUrl: string };

/**
 * Classifies staged images. Images whose pHash already has a cached result
 * are served locally and NOT sent; the rest are sent in batches of 12.
 *
 * Resumable partial behaviour (Phase 6): a recoverable BATCH failure marks
 * that batch's images failed and CONTINUES with the remaining batches —
 * successful results are returned alongside the failed ids so the caller
 * can show an honest partial summary and retry just the failures. A
 * SYSTEMIC failure (expired session, daily quota gone, AI not configured,
 * rate-limited into the ground) stops the whole run instead. An image that
 * can't be prepared (corrupt/undecodable) is skipped with an explanation,
 * never failing its whole batch.
 */
export async function classifyScenes(
  images: ClassifyRequestImage[],
  existingTitles: string[]
): Promise<ClassifyResult> {
  const pending = images.filter((img) => !cache.has(img.phash));
  const collected: SceneClassification[] = [];
  const failedIds: string[] = [];
  let lastBatchError = "";
  let anyBatchFailed = false;

  for (let i = 0; i < pending.length; i += MAX_IMAGES_PER_REQUEST) {
    const batch = pending.slice(i, i + MAX_IMAGES_PER_REQUEST);

    // Prepare each image independently — a corrupt file must not sink its
    // batch-mates (skip it with an explanation instead).
    const prepared: { id: string; imageBase64: string; mimeType: string; phash: string }[] = [];
    for (const img of batch) {
      try {
        const { base64, mimeType } = await downscaleToJpegBase64(img.dataUrl);
        prepared.push({ id: img.id, imageBase64: base64, mimeType, phash: img.phash });
      } catch {
        failedIds.push(img.id);
        anyBatchFailed = true;
        lastBatchError = "One photo couldn't be read (it may be corrupt) — it was skipped.";
      }
    }
    if (prepared.length === 0) continue;

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 45_000);
    let response: Response;
    try {
      response = await fetch("/api/classify-scenes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({ images: prepared.map(({ id, imageBase64, mimeType }) => ({ id, imageBase64, mimeType })), existingTitles }),
      });
    } catch (err: any) {
      clearTimeout(timeoutId);
      // Connection-level failure: mark this batch failed, keep going — the
      // next batch might land on a healthier moment.
      failedIds.push(...prepared.map((p) => p.id));
      anyBatchFailed = true;
      lastBatchError = err?.name === "AbortError" ? "AI analysis timed out." : "Could not reach the AI analysis endpoint.";
      continue;
    } finally {
      clearTimeout(timeoutId);
    }

    if (!response.ok) {
      const body = await response.json().catch(() => null);
      const error = body?.error ?? `AI analysis failed (${response.status})`;
      // Systemic failures stop the whole run — every remaining batch would
      // fail identically, so reporting per-photo errors would be dishonest.
      const systemic =
        response.status === 401 ||
        response.status === 403 ||
        (response.status === 429 && body?.quota) ||
        (response.status === 503 && /configured/i.test(String(body?.error ?? "")));
      if (systemic) {
        return {
          ok: false,
          error: body?.detail ? `${error} — ${String(body.detail).slice(0, 200)}` : error,
          quotaExhausted: response.status === 429 || response.status === 503,
        };
      }
      failedIds.push(...prepared.map((p) => p.id));
      anyBatchFailed = true;
      lastBatchError = body?.detail ? `${error} — ${String(body.detail).slice(0, 200)}` : error;
      continue; // recoverable → try the next batch
    }

    const body = await response.json().catch(() => null);
    const results: unknown = (body as any)?.results;
    if (!Array.isArray(results)) {
      failedIds.push(...prepared.map((p) => p.id));
      anyBatchFailed = true;
      lastBatchError = "The AI response was missing its results.";
      continue;
    }
    for (const item of results) {
      const r = normalizeResult(item, batch);
      if (!r) continue;
      collected.push(r);
      const src = batch.find((b) => b.id === r.id);
      if (src) cache.set(src.phash, r);
    }
  }

  return anyBatchFailed
    ? { ok: true, results: collected, partial: true, failedIds, failureReason: lastBatchError }
    : { ok: true, results: collected };
}

function normalizeResult(item: any, batch: ClassifyRequestImage[]): SceneClassification | null {
  const id = typeof item?.id === "string" ? item.id : null;
  if (!id || !batch.some((b) => b.id === id)) return null; // never trust unmatched ids
  const category = isRoomCategory(item?.category) ? item.category : "unknown";
  const title = typeof item?.title === "string" ? item.title.slice(0, 80).trim() : "";
  const description = typeof item?.description === "string" ? item.description.slice(0, 400).trim() : "";
  const confidence =
    typeof item?.confidence === "number" && item.confidence >= 0 && item.confidence <= 1 ? item.confidence : 0.5;
  const order = Number.isFinite(item?.order) ? Math.max(1, Math.round(item.order)) : 1;
  return { id, category, title, description, confidence, order };
}
