/**
 * Turns a 2D floor plan photo into a stylized isometric 3D room render
 * via Gemini image generation. This is a picture of what a space COULD
 * look like — not a real 3D model, not to scale, not interactive. Always
 * comes back with a clear "AI-generated" marker for the caller to keep
 * on the stop (see StopMedia.synthetic in src/types.ts).
 */

const MAX_SEND_DIMENSION = 1024;
const MAX_RENDERS = 8;
const USAGE_KEY = "waypoint:render3dGenCount";

export type RenderStyle = "modern" | "minimal" | "cozy" | "luxury";

export type Render3DResult =
  | { ok: true; dataUrl: string }
  | { ok: false; reason: "capped" | "failed"; detail?: string };

function getUsageCount(): number {
  return Number(localStorage.getItem(USAGE_KEY) ?? "0");
}

function incrementUsage(): void {
  localStorage.setItem(USAGE_KEY, String(getUsageCount() + 1));
}

export function remaining3DRenders(): number {
  return Math.max(0, MAX_RENDERS - getUsageCount());
}

function loadImage(dataUrl: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = dataUrl;
  });
}

async function downscale(dataUrl: string, maxDimension: number): Promise<string> {
  const img = await loadImage(dataUrl);
  const scale = Math.min(1, maxDimension / Math.max(img.width, img.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(img.width * scale);
  canvas.height = Math.round(img.height * scale);
  const ctx = canvas.getContext("2d");
  if (!ctx) return dataUrl;
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL("image/jpeg", 0.9);
}

function dataUrlToBase64(dataUrl: string): { base64: string; mimeType: string } {
  const [header, base64] = dataUrl.split(",");
  const mimeType = header.match(/data:(.*);base64/)?.[1] ?? "image/jpeg";
  return { base64, mimeType };
}

export async function generate3DRender(
  floorPlanDataUrl: string,
  style: RenderStyle
): Promise<Render3DResult> {
  if (getUsageCount() >= MAX_RENDERS) {
    return { ok: false, reason: "capped" };
  }

  try {
    const sendDataUrl = await downscale(floorPlanDataUrl, MAX_SEND_DIMENSION);
    const { base64, mimeType } = dataUrlToBase64(sendDataUrl);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 45_000);

    const response = await fetch("/api/generate-3d-render", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      body: JSON.stringify({ imageBase64: base64, mimeType, style }),
    }).finally(() => clearTimeout(timeoutId));

    if (!response.ok) {
      const body = await response.json().catch(() => null);
      return { ok: false, reason: "failed", detail: body?.detail ?? body?.error };
    }

    const result = await response.json();
    if (!result?.imageBase64) return { ok: false, reason: "failed" };

    incrementUsage();
    return {
      ok: true,
      dataUrl: `data:${result.mimeType ?? "image/jpeg"};base64,${result.imageBase64}`,
    };
  } catch {
    return { ok: false, reason: "failed" };
  }
}
