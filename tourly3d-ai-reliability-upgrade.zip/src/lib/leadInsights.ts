/**
 * Stage D (Phase 7 of the AI upgrade) — client for /api/lead-insights.
 * Returns an AI-generated enquiry summary, the buyer's STATED requirements
 * (never inferred), and suggested next actions for the lead's current stage.
 * Everything is explicitly marked AI-generated in the UI; nothing is sent
 * anywhere from here.
 */
import { auth } from "./firebase";

export type LeadInsights = {
  enquirySummary: string;
  buyerRequirements: string[];
  suggestedNextActions: string[];
  stage: string;
  aiGenerated: true;
  disclaimer: string;
};

export type LeadInsightsResult =
  | { ok: true; insights: LeadInsights }
  | { ok: false; error: string; quotaExhausted?: boolean };

export async function fetchLeadInsights(leadId: string): Promise<LeadInsightsResult> {
  const token = await auth?.currentUser?.getIdToken().catch(() => null);
  if (!token) return { ok: false, error: "Sign in to use AI lead insights." };
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 35_000);
    const response = await fetch("/api/lead-insights", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      signal: controller.signal,
      body: JSON.stringify({ leadId }),
    }).finally(() => clearTimeout(timeoutId));

    const body = await response.json().catch(() => null);
    if (!response.ok) {
      return {
        ok: false,
        error: body?.error ?? `Insights failed (${response.status}).`,
        quotaExhausted: response.status === 429,
      };
    }
    if (typeof body?.enquirySummary !== "string") {
      return { ok: false, error: "The insights response was malformed." };
    }
    return { ok: true, insights: body as LeadInsights };
  } catch (err: any) {
    if (err?.name === "AbortError") {
      return { ok: false, error: "Insights timed out — try again." };
    }
    return { ok: false, error: "Could not reach the lead-insights endpoint." };
  }
}
