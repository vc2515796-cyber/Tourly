/**
 * Asks Gemini to look at a stop's photo and suggest a room label, short
 * description, and — only when the visible evidence supports it — a
 * construction-stage label. Always returns an error on failure; callers
 * should treat this as a nice-to-have suggestion, never a required step,
 * and always let the person edit or reject the result (never auto-publish
 * it unreviewed). The confidence value is the MODEL's self-reported
 * estimate, shown as a hint — it is NOT a verified fact.
 */

import { friendlyAiError, type AiErrorKind } from "./aiErrors";

const MAX_SEND_DIMENSION = 1024;

function loadImage(dataUrl: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = dataUrl;
  });
}

async function downscale(dataUrl: string, maxDimension: number): Promise<string> {
  const img = await loadImage(dataUrl);
  const scale = Math.min(1, maxDimension / Math.max(img.width, img.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(img.width * scale);
  canvas.height = Math.round(img.height * scale);
  const ctx = canvas.getContext("2d");
  if (!ctx) return dataUrl;
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL("image/jpeg", 0.85);
}

function dataUrlToBase64(dataUrl: string): { base64: string; mimeType: string } {
  const [header, base64] = dataUrl.split(",");
  const mimeType = header.match(/data:(.*);base64/)?.[1] ?? "image/jpeg";
  return { base64, mimeType };
}

export type SceneAnalysis = {
  roomLabel: string;
  description: string;
  /** 0..1 self-reported confidence — a review hint, not a verified fact. */
  confidence: number;
  /** Present ONLY when the photo visibly shows an active construction site. */
  constructionStage?: string;
};
export type AnalyzeSceneResult =
  | { ok: true; analysis: SceneAnalysis }
  | { ok: false; error: string; kind: AiErrorKind; canRetry: boolean };

export async function analyzeScene(
  imageDataUrl: string,
  otherRoomTitles: string[]
): Promise<AnalyzeSceneResult> {
  try {
    const sendDataUrl = await downscale(imageDataUrl, MAX_SEND_DIMENSION);
    const { base64, mimeType } = dataUrlToBase64(sendDataUrl);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 25_000);

    const response = await fetch("/api/analyze-scene", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      body: JSON.stringify({ imageBase64: base64, mimeType, otherRoomTitles }),
    }).finally(() => clearTimeout(timeoutId));

    if (!response.ok) {
      const friendly = await friendlyAiError(response);
      return { ok: false, error: friendly.message, kind: friendly.kind, canRetry: friendly.canRetry };
    }
    const result = await response.json();
    if (!result?.roomLabel) {
      return { ok: false, error: "The AI didn't return a room label — try again or type it yourself.", kind: "invalid", canRetry: true };
    }
    return {
      ok: true,
      analysis: {
        roomLabel: result.roomLabel,
        description: result.description ?? "",
        confidence: typeof result.confidence === "number" ? result.confidence : 0.5,
        constructionStage:
          typeof result.constructionStage === "string" && result.constructionStage.trim()
            ? result.constructionStage.trim()
            : undefined,
      },
    };
  } catch (err: any) {
    const friendly = await friendlyAiError(null, err);
    return { ok: false, error: friendly.message, kind: friendly.kind, canRetry: friendly.canRetry };
  }
}
