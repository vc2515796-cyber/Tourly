export type AskResult = { ok: true; answer: string } | { ok: false; error: string };

export async function askTourAssistant(
  question: string,
  tour: { name: string; subtitle: string; whatsappNumber?: string; stops: { title: string; note?: string }[] },
  history: { role: "user" | "assistant"; text: string }[] = []
): Promise<AskResult> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 25_000);

    const response = await fetch("/api/tour-assistant", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      body: JSON.stringify({
        question,
        tourName: tour.name,
        subtitle: tour.subtitle,
        whatsappNumber: tour.whatsappNumber,
        stops: tour.stops,
        history,
      }),
    }).finally(() => clearTimeout(timeoutId));

    if (!response.ok) {
      const body = await response.json().catch(() => null);
      const error = body?.error ?? `This assistant isn't available right now (${response.status}).`;
      return { ok: false, error: body?.detail ? `${error} — ${body.detail}` : error };
    }
    const result = await response.json();
    if (!result?.answer) return { ok: false, error: "This assistant isn't available right now." };
    return { ok: true, answer: result.answer };
  } catch {
    return { ok: false, error: "Could not reach the assistant." };
  }
}
