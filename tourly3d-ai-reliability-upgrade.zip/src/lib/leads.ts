/**
 * Stage B5 — client API for the lead workflow: public enquiry capture on
 * tour pages, and the authenticated agent CRM (list / update / AI draft).
 *
 * All agent endpoints require the signed-in user's Firebase ID token; the
 * server derives ownership from the VERIFIED token, never from anything
 * this client sends.
 */

import { auth } from "./firebase";
import { Tour } from "../types";

export const LEAD_STAGES = [
  "new",
  "contacted",
  "qualified",
  "visit-requested",
  "visit-scheduled",
  "closed",
  "not-interested",
] as const;

export type LeadStage = (typeof LEAD_STAGES)[number];

export const STAGE_LABELS: Record<LeadStage, string> = {
  new: "New",
  contacted: "Contacted",
  qualified: "Qualified",
  "visit-requested": "Visit requested",
  "visit-scheduled": "Visit scheduled",
  closed: "Closed",
  "not-interested": "Not interested",
};

export type LeadSummary = {
  id: string;
  tourId: string;
  tourName: string;
  stopTitle?: string;
  name: string | null;
  phone: string | null;
  email: string | null;
  message: string;
  stage: LeadStage;
  visitRequested: boolean;
  createdAt: number;
  updatedAt: number;
  nextActionAt: number | null;
  activityCount: number;
};

export type LeadActivityClient =
  | { id: string; kind: "stage-change"; at: number; fromStage?: string; toStage: string }
  | { id: string; kind: "note" | "contact-logged"; at: number; text: string }
  | { id: string; kind: "draft"; at: number; text: string; channel: string; language: string };

async function idToken(): Promise<string | null> {
  return auth?.currentUser?.getIdToken().catch(() => null) ?? null;
}

// --- public enquiry capture -------------------------------------------------

export type CaptureLeadInput = {
  name: string;
  phone: string;
  email: string;
  message: string;
  consent: boolean;
  visitRequested?: boolean;
};

export async function captureLead(tour: Tour, stopTitle: string | null, input: CaptureLeadInput): Promise<{ ok: true; duplicate?: boolean } | { ok: false; error: string }> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15_000);
    const response = await fetch("/api/capture-lead", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      body: JSON.stringify({
        tourId: tour.id,
        stopTitle: stopTitle ?? undefined,
        name: input.name,
        phone: input.phone,
        email: input.email,
        message: input.message,
        consent: input.consent,
        visitRequested: input.visitRequested === true || undefined,
        company: "", // honeypot — real users never fill this
      }),
    }).finally(() => clearTimeout(timeoutId));
    const body = await response.json().catch(() => null);
    if (!response.ok || !body || body.ok !== true) {
      // A 200 that isn't our JSON (proxy/SPA fallback HTML) is a failure —
      // never report an enquiry as sent when it wasn't.
      return { ok: false, error: body?.error ?? "Couldn't send your enquiry — please try again." };
    }
    return { ok: true, duplicate: Boolean(body.duplicate) };
  } catch (err: any) {
    if (err?.name === "AbortError") return { ok: false, error: "Sending took too long — please try again." };
    return { ok: false, error: "Network problem — please try again." };
  }
}

// --- agent CRM ----------------------------------------------------------------

export type LeadsListResult =
  | { ok: true; leads: LeadSummary[] }
  | { ok: false; error: string; notConfigured?: boolean; needsAuth?: boolean };

export async function listLeads(): Promise<LeadsListResult> {
  const token = await idToken();
  if (!token) return { ok: false, error: "Sign in to see your leads.", needsAuth: true };
  try {
    const response = await fetch("/api/leads", {
      headers: { Authorization: `Bearer ${token}` },
    });
    const body = await response.json().catch(() => null);
    if (response.status === 503) {
      return { ok: false, error: body?.error ?? "Lead management isn't configured on this deployment.", notConfigured: true };
    }
    if (response.status === 401) {
      return { ok: false, error: body?.error ?? "Your session expired — sign in again.", needsAuth: true };
    }
    if (!response.ok || !Array.isArray(body?.leads)) {
      return { ok: false, error: body?.error ?? "Couldn't load your leads." };
    }
    return { ok: true, leads: body.leads };
  } catch {
    return { ok: false, error: "Network problem — please try again." };
  }
}

export type UpdateLeadInput = {
  stage?: LeadStage;
  note?: string;
  contactLog?: string;
  nextActionAt?: number | null;
};

export async function updateLead(leadId: string, expectedUpdatedAt: number, patch: UpdateLeadInput): Promise<{ ok: true; lead: { stage: LeadStage; nextActionAt: number | null; updatedAt: number; activities: LeadActivityClient[] } } | { ok: false; error: string; conflict?: boolean }> {
  const token = await idToken();
  if (!token) return { ok: false, error: "Sign in to manage your leads." };
  try {
    const response = await fetch("/api/lead-update", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({ leadId, expectedUpdatedAt, ...patch }),
    });
    const body = await response.json().catch(() => null);
    if (!response.ok) {
      return { ok: false, error: body?.error ?? "Couldn't update the lead.", conflict: Boolean(body?.conflict) };
    }
    return { ok: true, lead: body.lead };
  } catch {
    return { ok: false, error: "Network problem — please try again." };
  }
}

export async function draftFollowUp(
  leadId: string,
  channel: "whatsapp" | "email" | "sms",
  language: "en" | "hi" | "hinglish"
): Promise<{ ok: true; draft: string } | { ok: false; error: string; quotaExhausted?: boolean }> {
  const token = await idToken();
  if (!token) return { ok: false, error: "Sign in to draft follow-ups." };
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 35_000);
    const response = await fetch("/api/lead-draft", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      signal: controller.signal,
      body: JSON.stringify({ leadId, channel, language }),
    }).finally(() => clearTimeout(timeoutId));
    const body = await response.json().catch(() => null);
    if (!response.ok || typeof body?.draft !== "string" || !body.draft) {
      return {
        ok: false,
        error: body?.error ?? "Couldn't draft the follow-up.",
        quotaExhausted: response.status === 429 || response.status === 503,
      };
    }
    return { ok: true, draft: body.draft };
  } catch (err: any) {
    if (err?.name === "AbortError") return { ok: false, error: "Drafting timed out — try again." };
    return { ok: false, error: "Network problem — please try again." };
  }
}
