/**
 * Client for the admin-only AI diagnostics endpoint (Phase 8). The page is
 * a thin view over the server's SAFE snapshot — authorization (ADMIN_EMAILS
 * + verified token) happens server-side on every request; this client just
 * attaches the caller's token and renders what comes back. It never sees
 * (and can never show) API keys or other customers' data, because the
 * server doesn't send them.
 */
import { auth } from "./firebase";

export type DiagnosticsSnapshot = {
  ok: boolean;
  providers: { id: string; configured: boolean; models: { text?: string[]; image?: string[] } }[];
  metrics: {
    providers: Record<
      string,
      {
        okCount: number;
        errCount: number;
        lastOkAt: number | null;
        lastErrAt: number | null;
        lastErrKind: string | null;
        rateLimitEvents: number;
        quotaEvents: number;
        breakerTrips: number;
      }
    >;
    cache: { hits: number; misses: number };
    updatedAt: number | null;
  };
  features: { feature: string; dailyQuota: number }[];
  config: {
    geminiConfigured: boolean;
    secondaryProvider: string | null;
    secondaryDisabledByEnv: boolean;
    visionFallbackAllowed: boolean;
    adminConfigured: boolean;
  };
  note: string;
};

export type DiagnosticsTestResult = {
  ok: boolean;
  testedAt: string;
  totalMs: number;
  results: {
    provider: string;
    model: string;
    ok: boolean;
    httpStatus: number | null;
    latencyMs: number;
    errorKind: string | null;
  }[];
  note: string;
};

async function authHeaders(): Promise<Record<string, string> | null> {
  const token = await auth?.currentUser?.getIdToken().catch(() => null);
  return token ? { "Content-Type": "application/json", Authorization: `Bearer ${token}` } : null;
}

export type DiagnosticsOutcome =
  | { ok: true; snapshot: DiagnosticsSnapshot }
  | { ok: false; status: number; error: string };

export async function fetchDiagnostics(): Promise<DiagnosticsOutcome> {
  const headers = await authHeaders();
  if (!headers) return { ok: false, status: 401, error: "Sign in as an administrator first." };
  try {
    const res = await fetch("/api/ai-diagnostics", { method: "GET", headers });
    const body = await res.json().catch(() => null);
    if (!res.ok) {
      return { ok: false, status: res.status, error: body?.error ?? `Diagnostics failed (${res.status}).` };
    }
    return { ok: true, snapshot: body as DiagnosticsSnapshot };
  } catch {
    return { ok: false, status: 0, error: "Could not reach the diagnostics endpoint." };
  }
}

export type TestOutcome =
  | { ok: true; result: DiagnosticsTestResult }
  | { ok: false; status: number; error: string };

export async function runDiagnosticsTest(): Promise<TestOutcome> {
  const headers = await authHeaders();
  if (!headers) return { ok: false, status: 401, error: "Sign in as an administrator first." };
  try {
    const res = await fetch("/api/ai-diagnostics", {
      method: "POST",
      headers,
      body: JSON.stringify({ test: true }),
    });
    const body = await res.json().catch(() => null);
    if (!res.ok) {
      return { ok: false, status: res.status, error: body?.error ?? `Test failed (${res.status}).` };
    }
    return { ok: true, result: body as DiagnosticsTestResult };
  } catch {
    return { ok: false, status: 0, error: "Could not reach the diagnostics endpoint." };
  }
}
