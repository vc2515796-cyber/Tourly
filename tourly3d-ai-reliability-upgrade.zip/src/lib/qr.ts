/**
 * QR code generation for share links. Wraps the `qrcode` package (MIT,
 * battle-tested encoder — hand-rolling a QR encoder risks producing
 * codes that don't scan, which would be worse than a 40 KB lazy chunk).
 *
 * The dynamic import keeps it OUT of the editor bundle: the code is only
 * downloaded when an agent actually opens the share panel.
 */

export type QrResult = { ok: true; dataUrl: string } | { ok: false; error: string };

export async function generateShareQr(text: string): Promise<QrResult> {
  try {
    const QRCode = await import("qrcode");
    const dataUrl = await QRCode.toDataURL(text, {
      width: 512,
      margin: 2,
      errorCorrectionLevel: "M",
      color: { dark: "#1c1a17", light: "#ffffff" }, // charcoal on white
    });
    if (typeof dataUrl !== "string" || !dataUrl.startsWith("data:image/png")) {
      return { ok: false, error: "QR generation returned an unexpected result." };
    }
    return { ok: true, dataUrl };
  } catch {
    return { ok: false, error: "Couldn't generate the QR code — the share link still works." };
  }
}
