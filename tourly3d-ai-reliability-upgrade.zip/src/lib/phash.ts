/**
 * Perceptual hashing (dHash) for local duplicate-image detection.
 *
 * A cryptographic hash changes completely when a photo is re-saved with
 * different compression; a PERCEPTUAL hash stays close, which is what
 * "these two uploads look like the same photo" needs. This is 100% local
 * (Canvas API) — no bytes leave the browser for dedupe — and the result is
 * a suggestion to review, never an automatic deletion.
 *
 * Pure, Node-testable core (works on ImageData-like objects) + a thin
 * browser wrapper that decodes a dataUrl/file to ImageData first.
 */

export type ImageDataLike = { width: number; height: number; data: Uint8ClampedArray | Uint8Array };

/** 8x8 dHash → 64-bit value represented as 16 hex chars. */
export type Phash = string;

const HASH_SIZE = 8; // 8x8 gradient matrix → 64 comparison bits

/**
 * Core dHash: shrink to (size+1)x(size) grayscale, compare horizontally
 * adjacent pixels, set a bit when left > right.
 *
 * Accepts raw RGBA pixels (already decoded) so the algorithm itself can be
 * unit-tested in Node without a canvas.
 */
export function dhashCore(image: ImageDataLike, size = HASH_SIZE): Phash {
  // Downsample by area-averaging (box filter) into a (size+1) x size
  // grayscale buffer. This is deliberately simple + deterministic.
  const w = image.width;
  const h = image.height;
  if (w < 2 || h < 2) return "0".repeat(size * size / 4);
  const cols = size + 1;
  const rows = size;
  const gray = new Float64Array(cols * rows);
  const px = image.data;
  const cellW = w / cols;
  const cellH = h / rows;
  for (let r = 0; r < rows; r++) {
    const y0 = Math.floor(r * cellH);
    const y1 = Math.max(y0 + 1, Math.floor((r + 1) * cellH));
    for (let c = 0; c < cols; c++) {
      const x0 = Math.floor(c * cellW);
      const x1 = Math.max(x0 + 1, Math.floor((c + 1) * cellW));
      let sum = 0;
      let count = 0;
      for (let y = y0; y < y1 && y < h; y++) {
        for (let x = x0; x < x1 && x < w; x++) {
          const i = (y * w + x) * 4;
          // Rec.601 luma — same weighting everywhere is what matters here.
          sum += 0.299 * px[i] + 0.587 * px[i + 1] + 0.114 * px[i + 2];
          count++;
        }
      }
      gray[r * cols + c] = count ? sum / count : 0;
    }
  }
  let hex = "";
  for (let r = 0; r < rows; r++) {
    // One nibble per row (8 bits → 2 hex chars per 8 rows… we emit 2 hex
    // chars per row of 8 bits, giving 16 chars for 8 rows).
    let byte = 0;
    for (let c = 0; c < size; c++) {
      const bit = gray[r * cols + c] > gray[r * cols + c + 1] ? 1 : 0;
      byte = (byte << 1) | bit;
    }
    hex += byte.toString(16).padStart(2, "0");
  }
  return hex;
}

/** Number of differing bits between two hashes (0 = identical images). */
export function hammingDistance(a: Phash, b: Phash): number {
  if (a.length !== b.length) return Infinity;
  let dist = 0;
  for (let i = 0; i < a.length; i += 2) {
    const x = parseInt(a.slice(i, i + 2), 16) ^ parseInt(b.slice(i, i + 2), 16);
    // Brian Kernighan's bit count
    let v = x;
    while (v) {
      v &= v - 1;
      dist++;
    }
  }
  return dist;
}

/**
 * dHash distances for natural photos cluster low (0–10 ≈ same shot with
 * trivial edits); 12+ is usually a genuinely different frame. Conservative
 * default so we only flag near-certain duplicates for human review.
 */
export const DUPLICATE_HAMMING_THRESHOLD = 10;

export function areLikelyDuplicates(a: Phash, b: Phash, threshold = DUPLICATE_HAMMING_THRESHOLD): boolean {
  return hammingDistance(a, b) <= threshold;
}

/** Finds near-duplicate groups: for each index, the earlier index it
 *  duplicates. Null/undefined entries (photos that couldn't be hashed) are
 *  skipped — no hash means we honestly can't compare, never a false match.
 *  Returns a map idx → first-seen idx it matches. */
export function findDuplicateGroups(
  hashes: (Phash | null | undefined)[],
  threshold = DUPLICATE_HAMMING_THRESHOLD
): Map<number, number> {
  const dupes = new Map<number, number>();
  for (let i = 1; i < hashes.length; i++) {
    if (!hashes[i]) continue;
    for (let j = 0; j < i; j++) {
      if (!hashes[j]) continue;
      if (hammingDistance(hashes[i]!, hashes[j]!) <= threshold) {
        dupes.set(i, j);
        break;
      }
    }
  }
  return dupes;
}

// --- Browser wrappers ------------------------------------------------------

/** Decodes a dataUrl to a small ImageData for hashing. Downscales to a
 *  max dimension first — dHash only needs order-of-magnitude pixels and
 *  this keeps the work tiny for 12 MP phone photos. */
export async function phashFromDataUrl(dataUrl: string, maxDim = 64): Promise<Phash> {
  const img = await loadImageElement(dataUrl);
  return dhashCore(toImageData(img, maxDim));
}

export async function phashFromFile(file: File): Promise<Phash> {
  const dataUrl = await fileToDataUrl(file);
  return phashFromDataUrl(dataUrl);
}

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error("read failed"));
    reader.readAsDataURL(file);
  });
}

function loadImageElement(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("decode failed"));
    img.src = src;
  });
}

function toImageData(img: HTMLImageElement, maxDim: number): ImageDataLike {
  const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
  const w = Math.max(1, Math.round(img.width * scale));
  const h = Math.max(1, Math.round(img.height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) {
    // Canvas unavailable (extremely rare) — fall back to a constant hash so
    // the caller can still proceed; dedupe just won't flag anything.
    return { width: 2, height: 2, data: new Uint8ClampedArray(8) };
  }
  ctx.drawImage(img, 0, 0, w, h);
  return ctx.getImageData(0, 0, w, h);
}
