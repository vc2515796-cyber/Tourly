/**
 * Stage D (Phase 6 of the AI upgrade) — client for /api/interior-concept.
 * Optional feature: restyles one room photo into an illustrative interior
 * CONCEPT (modern / minimal / contemporary). The result is always labelled
 * "AI interior concept — illustrative only"; it never represents the actual
 * property condition, and replacing a scene's media with it is an explicit
 * user action.
 */
import { auth } from "./firebase";

export type InteriorStyle = "modern" | "minimal" | "contemporary";
export const INTERIOR_STYLES: { id: InteriorStyle; label: string }[] = [
  { id: "modern", label: "Modern" },
  { id: "minimal", label: "Minimal" },
  { id: "contemporary", label: "Contemporary" },
];

export type InteriorConceptResult =
  | { ok: true; imageBase64: string; mimeType: string; style: InteriorStyle; note: string }
  | { ok: false; error: string; quotaExhausted?: boolean };

function loadImage(dataUrl: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = dataUrl;
  });
}

export async function generateInteriorConcept(
  imageDataUrl: string,
  style: InteriorStyle
): Promise<InteriorConceptResult> {
  const token = await auth?.currentUser?.getIdToken().catch(() => null);
  if (!token) return { ok: false, error: "Sign in to use AI interior concepts." };

  // Downscale before sending — same policy as every other AI image feature.
  let base64 = "";
  let mimeType = "image/jpeg";
  try {
    const img = await loadImage(imageDataUrl);
    const scale = Math.min(1, 1024 / Math.max(img.width, img.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(img.width * scale));
    canvas.height = Math.max(1, Math.round(img.height * scale));
    canvas.getContext("2d")!.drawImage(img, 0, 0, canvas.width, canvas.height);
    const out = canvas.toDataURL("image/jpeg", 0.85);
    mimeType = "image/jpeg";
    base64 = out.split(",")[1] ?? "";
  } catch {
    return { ok: false, error: "That image couldn't be processed." };
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 60_000);
    const response = await fetch("/api/interior-concept", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      signal: controller.signal,
      body: JSON.stringify({ imageBase64: base64, mimeType, style }),
    }).finally(() => clearTimeout(timeoutId));

    const body = await response.json().catch(() => null);
    if (!response.ok) {
      return {
        ok: false,
        error: body?.error ?? `Concept generation failed (${response.status}).`,
        quotaExhausted: response.status === 429,
      };
    }
    if (typeof body?.imageBase64 !== "string") {
      return { ok: false, error: "The response was malformed." };
    }
    return {
      ok: true,
      imageBase64: body.imageBase64,
      mimeType: body.mimeType ?? "image/jpeg",
      style: body.style ?? style,
      note: body.note ?? "AI interior concept — illustrative only.",
    };
  } catch (err: any) {
    if (err?.name === "AbortError") {
      return { ok: false, error: "Concept generation timed out — try again." };
    }
    return { ok: false, error: "Could not reach the interior-concept endpoint." };
  }
}
