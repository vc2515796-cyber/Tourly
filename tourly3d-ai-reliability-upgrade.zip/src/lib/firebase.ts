import { initializeApp, getApps, FirebaseApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, Auth } from "firebase/auth";

// All values come from Netlify environment variables (must be prefixed
// VITE_ so Vite exposes them to client code — see AUTH-SETUP.md).
//
// authDomain can be omitted in the environment: every Firebase project
// always owns "<projectId>.firebaseapp.com", so it's derived from the
// project id. Without this, a deployment with all other vars set would
// count as "configured" yet initialize auth with authDomain undefined,
// which breaks Google sign-in popups with an opaque error.
const projectId = import.meta.env.VITE_FIREBASE_PROJECT_ID;
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || (projectId ? `${projectId}.firebaseapp.com` : undefined),
  projectId,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

export const firebaseConfigured = Boolean(
  firebaseConfig.apiKey && firebaseConfig.projectId && firebaseConfig.appId
);

// IMPORTANT: getAuth() can throw synchronously (e.g. "auth/invalid-api-key")
// when the config is missing/invalid, and this file is imported at app
// startup — an uncaught throw here would crash the entire React app before
// it even mounts (blank white page, no error the person can see). Only
// initialize when config actually looks present, and always wrap in
// try/catch so a bad value never takes down the whole site.
let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let googleProvider: GoogleAuthProvider | null = null;

if (firebaseConfigured) {
  try {
    app = getApps().length ? getApps()[0]! : initializeApp(firebaseConfig);
    auth = getAuth(app);
    googleProvider = new GoogleAuthProvider();
  } catch (err) {
    console.error("Firebase failed to initialize — auth will be unavailable:", err);
    app = null;
    auth = null;
    googleProvider = null;
  }
}

export { auth, googleProvider };
