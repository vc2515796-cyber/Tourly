/**
 * Turns a regular photo into a full panorama via AI generation — most of
 * the result is invented, not photographed. Two cost controls here since
 * this is meaningfully more expensive than the lighting-only enhancer:
 *   1. The input is downscaled hard (768px) before it's ever sent —
 *      Gemini image cost scales with image size, and this is just a
 *      reference seed for the model, not the final output resolution.
 *   2. A hard usage cap tracked in localStorage. This can't see your
 *      actual Gemini billing/credit balance — there's no API for that
 *      here — so treat MAX_GENERATIONS as a manually-tuned safety net,
 *      not a real "7% of credit" calculation. Adjust the constant below
 *      to match your actual budget once you know your real usage cost.
 */

const MAX_SEND_DIMENSION = 768;
const MAX_GENERATIONS = 12;
const USAGE_KEY = "waypoint:panoramaGenCount";

export type GenerateResult =
  | { ok: true; dataUrl: string }
  | { ok: false; reason: "capped" | "failed"; detail?: string };

function getUsageCount(): number {
  return Number(localStorage.getItem(USAGE_KEY) ?? "0");
}

function incrementUsage(): void {
  localStorage.setItem(USAGE_KEY, String(getUsageCount() + 1));
}

export function remainingGenerations(): number {
  return Math.max(0, MAX_GENERATIONS - getUsageCount());
}

function loadImage(dataUrl: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = dataUrl;
  });
}

async function downscale(dataUrl: string, maxDimension: number): Promise<string> {
  const img = await loadImage(dataUrl);
  const scale = Math.min(1, maxDimension / Math.max(img.width, img.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(img.width * scale);
  canvas.height = Math.round(img.height * scale);
  const ctx = canvas.getContext("2d");
  if (!ctx) return dataUrl;
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL("image/jpeg", 0.85);
}

function dataUrlToBase64(dataUrl: string): { base64: string; mimeType: string } {
  const [header, base64] = dataUrl.split(",");
  const mimeType = header.match(/data:(.*);base64/)?.[1] ?? "image/jpeg";
  return { base64, mimeType };
}

export async function generatePanoramaFromPhoto(originalDataUrl: string): Promise<GenerateResult> {
  if (getUsageCount() >= MAX_GENERATIONS) {
    return { ok: false, reason: "capped" };
  }

  try {
    const sendDataUrl = await downscale(originalDataUrl, MAX_SEND_DIMENSION);
    const { base64, mimeType } = dataUrlToBase64(sendDataUrl);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 45_000);

    const response = await fetch("/api/generate-panorama", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      body: JSON.stringify({ imageBase64: base64, mimeType }),
    }).finally(() => clearTimeout(timeoutId));

    if (!response.ok) {
      const body = await response.json().catch(() => null);
      return { ok: false, reason: "failed", detail: body?.detail ?? body?.error };
    }

    const result = await response.json();
    if (!result?.imageBase64) return { ok: false, reason: "failed" };

    incrementUsage(); // only count it once we know the call actually succeeded
    return {
      ok: true,
      dataUrl: `data:${result.mimeType ?? "image/jpeg"};base64,${result.imageBase64}`,
    };
  } catch {
    return { ok: false, reason: "failed" };
  }
}
