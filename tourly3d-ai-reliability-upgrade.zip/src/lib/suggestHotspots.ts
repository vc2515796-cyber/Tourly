export type HotspotSuggestion = { fromId: string; toId: string; label: string };

/** Asks for suggested room-to-room connections. Returns [] on any failure —
 *  this is always optional, never required to build or publish a tour. */
export async function suggestHotspots(
  stops: { id: string; title: string; note?: string }[]
): Promise<HotspotSuggestion[]> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 25_000);

    const response = await fetch("/api/suggest-hotspots", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      body: JSON.stringify({ stops }),
    }).finally(() => clearTimeout(timeoutId));

    if (!response.ok) return [];
    const result = await response.json();
    return Array.isArray(result?.suggestions) ? result.suggestions : [];
  } catch {
    return [];
  }
}
