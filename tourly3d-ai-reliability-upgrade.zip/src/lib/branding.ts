import { Branding } from "../types";
import { compressImage, dataUrlBytes } from "./imageCompress";

/**
 * White-label branding (Feature E). Everything here is validation-first:
 * colors must be real hex values, logos must be a compact image data-URL or
 * an https URL, and anything invalid is dropped rather than rendered — a
 * broken branding value must never break the public tour page.
 */

const HEX_RE = /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;

export function isValidHexColor(value: string | undefined): boolean {
  return typeof value === "string" && HEX_RE.test(value.trim());
}

/** Expands #abc → #aabbcc so it can be used in CSS rgba() derivations. */
export function normalizeHex(value: string): string {
  const v = value.trim();
  if (/^#[0-9a-fA-F]{6}$/.test(v)) return v.toLowerCase();
  if (/^#[0-9a-fA-F]{3}$/.test(v)) {
    return "#" + v[1] + v[1] + v[2] + v[2] + v[3] + v[3];
  }
  return "#c98a3e"; // brand default — never throws
}

/** Accepts only safe image sources for the public viewer: data:image URLs
 *  (what our own uploader produces) or https URLs. Blocks javascript:,
 *  http:, and anything else a creative visitor might inject. */
export function safeLogoSrc(url: string | undefined): string | null {
  if (!url) return null;
  const trimmed = url.trim();
  if (trimmed.startsWith("data:image/")) return trimmed;
  if (/^https:\/\/[^\s"'<>]+$/i.test(trimmed)) return trimmed;
  return null;
}

export const BRANDING_MAX_LOGO_BYTES = 300_000;
export const BRANDING_LOGO_MAX_DIM = 512;

export type LogoUploadResult =
  | { ok: true; dataUrl: string }
  | { ok: false; error: string };

/** Validates + compresses an uploaded logo file into a data URL that is
 *  safe to embed in the tour JSON (and small enough to publish). */
export async function prepareLogoFile(file: File): Promise<LogoUploadResult> {
  if (!file.type.startsWith("image/")) {
    return { ok: false, error: "Logo must be an image file (PNG, JPG, WebP or SVG export)." };
  }
  if (file.size > 5_000_000) {
    return { ok: false, error: "Logo file is too large — use an image under 5 MB." };
  }
  const readDataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error("read failed"));
    reader.readAsDataURL(file);
  }).catch(() => null);
  if (!readDataUrl) return { ok: false, error: "Couldn't read that file — try again." };

  // SVG has no dimensions to compress; embed as-is after the size check.
  if (file.type === "image/svg+xml") {
    if (dataUrlBytes(readDataUrl) > BRANDING_MAX_LOGO_BYTES) {
      return { ok: false, error: "SVG logo is too large — keep it under 300 KB." };
    }
    return { ok: true, dataUrl: readDataUrl };
  }

  const compressed = await compressImage(readDataUrl, {
    maxDim: BRANDING_LOGO_MAX_DIM,
    quality: 0.9,
    skipBelowBytes: 0,
  });
  if (dataUrlBytes(compressed) > BRANDING_MAX_LOGO_BYTES) {
    return { ok: false, error: "Logo is still too large after compression — use a simpler image." };
  }
  return { ok: true, dataUrl: compressed };
}

/** Strips invalid fields so we never persist junk. Returns undefined when
 *  nothing usable remains (keeps old tours byte-compatible). */
export function sanitizeBranding(branding: Branding | undefined): Branding | undefined {
  if (!branding) return undefined;
  const out: Branding = {};
  const name = branding.agencyName?.trim();
  if (name) out.agencyName = name.slice(0, 80);
  const logo = safeLogoSrc(branding.logoUrl);
  if (logo) out.logoUrl = logo;
  if (typeof branding.primaryColor === "string" && isValidHexColor(branding.primaryColor))
    out.primaryColor = normalizeHex(branding.primaryColor);
  if (typeof branding.accentColor === "string" && isValidHexColor(branding.accentColor))
    out.accentColor = normalizeHex(branding.accentColor);
  if (branding.splashEnabled !== undefined) out.splashEnabled = Boolean(branding.splashEnabled);
  return Object.keys(out).length > 0 ? out : undefined;
}

/** Best-effort runtime favicon swap on the public viewer. "Where technically
 *  appropriate" — quietly does nothing when no valid logo exists. */
export function applyBrandingFavicon(branding: Branding | undefined): void {
  try {
    const logo = safeLogoSrc(branding?.logoUrl);
    if (!logo) return;
    let link = document.querySelector<HTMLLinkElement>("link[rel~='icon'][data-brand-icon]");
    if (!link) {
      link = document.createElement("link");
      link.rel = "icon";
      link.dataset.brandIcon = "1";
      document.head.appendChild(link);
    }
    // SVG data URLs work as favicons in every modern browser; raster types
    // pass through unchanged.
    link.href = logo.startsWith("data:image/svg+xml")
      ? logo
      : logo;
  } catch {
    // Never let a cosmetic favicon swap break the page.
  }
}

/** Derives a translucent version of a hex color for glows/overlays. */
export function hexToRgba(hex: string, alpha: number): string {
  const h = normalizeHex(hex).slice(1);
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

export const DEFAULT_BRANDING = {
  primaryColor: "#c98a3e", // brass
  accentColor: "#f2ead8", // bone
};
