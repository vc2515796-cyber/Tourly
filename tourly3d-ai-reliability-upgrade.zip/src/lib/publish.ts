import { Tour } from "../types";
import { auth } from "./firebase";
import { compressImage, makeCoverJpeg, dataUrlBytes } from "./imageCompress";

export type PublishResult = { ok: true; protected: boolean; resized: boolean } | { ok: false; error: string };

// Netlify Functions reject request bodies above ~6 MB. Stay safely under it.
const MAX_BODY_BYTES = 5_500_000;
// If a tour is over the limit, the PUBLISHED copy (never the local original)
// is re-compressed through these steps until it fits.
const FIT_LEVELS = [
  { maxDim: 3072, quality: 0.78 },
  { maxDim: 2048, quality: 0.7 },
  { maxDim: 1536, quality: 0.62 },
];

function isCompressible(kind: string) {
  return kind === "image" || kind === "panorama" || kind === "wide";
}

async function fitTourToLimit(tour: Tour): Promise<{ tour: Tour; resized: boolean } | null> {
  const size = (t: Tour) => JSON.stringify(t).length;
  if (size(tour) <= MAX_BODY_BYTES) return { tour, resized: false };
  for (const level of FIT_LEVELS) {
    const stops = await Promise.all(
      tour.stops.map(async (stop) => {
        if (!stop.media || !isCompressible(stop.media.kind)) return stop;
        const dataUrl = await compressImage(stop.media.dataUrl, { ...level, skipBelowBytes: 0 });
        return { ...stop, media: { ...stop.media, dataUrl } };
      })
    );
    const candidate = { ...tour, stops };
    if (size(candidate) <= MAX_BODY_BYTES) return { tour: candidate, resized: true };
  }
  return null;
}

/** 1200×630 cover crop of the first image-like stop, used for WhatsApp /
 *  social link previews. Skipped for password-protected tours so a locked
 *  tour's photo is never exposed through its preview. */
async function buildPreviewImage(tour: Tour): Promise<string | undefined> {
  if (tour.viewPassword?.trim()) return undefined;
  const first = tour.stops.find((s) => s.media && isCompressible(s.media.kind));
  if (!first?.media) return undefined;
  const jpeg = await makeCoverJpeg(first.media.dataUrl);
  return jpeg && dataUrlBytes(jpeg) < 350_000 ? jpeg : undefined;
}

/**
 * Publishes the current state of a tour so its /tour/:id link works from
 * any device. This is an explicit action — errors are surfaced to the
 * caller rather than silently swallowed, since sharing is the whole
 * point of this feature and a silent failure would be misleading.
 */
export async function publishTour(tour: Tour): Promise<PublishResult> {
  try {
    const fitted = await fitTourToLimit(tour);
    if (!fitted) {
      const mb = (JSON.stringify(tour).length / 1_000_000).toFixed(1);
      return {
        ok: false,
        error: `This walkthrough is about ${mb} MB even after compression — too large to publish (limit ≈ 5.5 MB). Remove a scene or a video and try again.`,
      };
    }

    // The published copy is tied to whoever is signed in server-side (see
    // publish-tour.mts) — a Firebase ID token proves that, not a flag this
    // client could just lie about. Not signed in → nothing to attach, and
    // the server will (correctly) reject the request.
    const idToken = await auth?.currentUser?.getIdToken().catch(() => null);
    if (!idToken) {
      return { ok: false, error: "Sign in to publish a walkthrough." };
    }

    const previewImage = await buildPreviewImage(tour);
    const response = await fetch("/api/publish-tour", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${idToken}` },
      // The password travels separately from the tour so it's never part of
      // the shared tour JSON; the server hashes it.
      body: JSON.stringify({
        tour: { ...fitted.tour, viewPassword: undefined },
        password: tour.viewPassword?.trim() || undefined,
        previewImage,
      }),
    });

    if (!response.ok) {
      if (response.status === 404 || response.status === 405) {
        return {
          ok: false,
          error:
            "Sharing isn't available in this environment yet. Run `netlify dev` locally, or deploy this site, to enable it.",
        };
      }
      if (response.status === 401) {
        const body = await response.json().catch(() => null);
        return {
          ok: false,
          error:
            body?.error ??
            "Your session has expired — sign in again and retry.",
        };
      }
      if (response.status === 403) {
        return { ok: false, error: "This walkthrough was published by a different account." };
      }
      if (response.status === 429) {
        return { ok: false, error: "You're publishing too quickly — wait a minute and try again." };
      }
      if (response.status === 413) {
        return { ok: false, error: "This walkthrough is too large to publish. Remove a scene or a video and try again." };
      }
      if (response.status === 503) {
        const body = await response.json().catch(() => null);
        return { ok: false, error: body?.error ?? "Publishing isn't available yet — it needs server-side setup." };
      }
      const body = await response.json().catch(() => null);
      return { ok: false, error: body?.error ?? `Publish failed (${response.status})` };
    }

    return { ok: true, protected: Boolean(tour.viewPassword?.trim()), resized: fitted.resized };
  } catch {
    return {
      ok: false,
      error: "Couldn't reach the publish endpoint. Check your connection and try again.",
    };
  }
}

export type RemoteTourResult =
  | { status: "ok"; tour: Tour }
  | { status: "password-required"; wrong: boolean }
  | { status: "missing" };

/** Fetches a tour that was published from another device. */
export async function fetchRemoteTour(id: string, password?: string): Promise<RemoteTourResult> {
  try {
    const response = await fetch(`/api/tour?id=${encodeURIComponent(id)}`, {
      headers: password ? { "x-tour-password": password } : undefined,
    });
    if (response.status === 401) {
      const body = await response.json().catch(() => null);
      return { status: "password-required", wrong: Boolean(body?.wrong) };
    }
    if (!response.ok) return { status: "missing" };
    const body = await response.json();
    return body?.tour ? { status: "ok", tour: body.tour as Tour } : { status: "missing" };
  } catch {
    return { status: "missing" };
  }
}
