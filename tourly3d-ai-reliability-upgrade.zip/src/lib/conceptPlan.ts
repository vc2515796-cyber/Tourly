/**
 * Stage D (Phase 5D of the AI upgrade) — the conceptual geometry engine.
 *
 * Converts a VALIDATED AI ConceptAnalysis (normalized 0..1 top-down sketch
 * of one room, produced by /api/analyze-floorplan) into the EXISTING typed
 * floor-plan document (src/lib/plan/model.ts) so the whole Plan Studio
 * editor — drag, undo/redo, save, 3D preview — works on it unchanged.
 *
 * Honesty rules:
 * - The generated plan is UNCALIBRATED (scale.calibrated = false). World
 *   coordinates are NOMINAL plan units with no real-world meaning; the
 *   editor hides all computed measurements until the owner calibrates with
 *   a real measurement, and the plan is watermarked
 *   "CONCEPTUAL FLOOR PLAN — NOT TO SCALE" while it has concept origin.
 * - AI `certain:false` flags survive as `uncertain` markers on furniture
 *   and openings, rendered dashed for agent review.
 * - Nothing here fabricates geometry: if the analysis is empty the convert
 *   refuses (returns null) rather than inventing a room.
 */

import {
  createPlan,
  FURNITURE_DEFAULT_SIZES,
  PLAN_SCHEMA_VERSION,
  type FloorPlanDocument,
  type PlanFurniture,
  type PlanFurnitureKind,
  type PlanOpening,
  type PlanVertex,
  type PlanWall,
} from "./plan/model";
import { pointToSegment, type Pt } from "./plan/geometry";

export const CONCEPT_DISCLAIMER = "CONCEPTUAL FLOOR PLAN — NOT TO SCALE";

/** The normalized 0..1 analysis box maps onto this nominal world span. The
 *  number has NO real-world meaning — it only sizes the uncalibrated
 *  drawing canvas. Calibration (if ever done by the owner with real
 *  measurements) is what makes units true. */
const NOMINAL_SPAN = 8;

// --- client-side mirror of the server's validated response schema ------------
// (kept in sync with netlify/functions/analyze-floorplan.mts; the server
// validates BEFORE responding, so this is a typing aid, not the guard)

export type ConceptPoint = { x: number; y: number };

export type ConceptAnalysis = {
  schemaVersion: 1;
  roomType: string;
  confidence: number;
  roomOutline: ConceptPoint[];
  walls: { a: ConceptPoint; b: ConceptPoint; certain: boolean }[];
  openings: { kind: "door" | "window"; x: number; y: number; certain: boolean }[];
  furniture: {
    kind: PlanFurnitureKind;
    label?: string;
    x: number;
    y: number;
    w?: number;
    h?: number;
    rotation?: number;
    certain: boolean;
  }[];
  uncertaintyNotes: string[];
  model?: string;
  cached?: boolean;
  disclaimer?: string;
};

// --- conversion ----------------------------------------------------------------

/** Normalized (0..1) → nominal plan units. */
function toWorld(p: ConceptPoint): Pt {
  return { x: p.x * NOMINAL_SPAN, y: p.y * NOMINAL_SPAN };
}

/**
 * Endpoint-snap: analysis walls arrive as free segments; the plan model is a
 * vertex graph. Points closer than EPSILON (in world units) share a vertex,
 * which is how the AI's "roughly touching" corners become real corners.
 */
const SNAP_EPSILON = NOMINAL_SPAN * 0.04; // 4% of the canvas ≈ 0.32 units

export type ConversionResult =
  | { ok: true; plan: FloorPlanDocument }
  | { ok: false; error: string };

export function analysisToFloorPlan(
  analysis: ConceptAnalysis,
  tourId: string,
  source: { stopId: string; stopTitle?: string }
): ConversionResult {
  if (!analysis || !Array.isArray(analysis.roomOutline) || analysis.roomOutline.length < 3) {
    return { ok: false, error: "The analysis has no usable room outline." };
  }

  const plan = createPlan(tourId); // uncalibrated by construction
  const floor = plan.floors[0]!;

  // --- vertices + ring walls from the outline --------------------------------
  const vertices: PlanVertex[] = [];
  const snapVertex = (p: Pt): PlanVertex => {
    const existing = vertices.find(
      (v) => Math.abs(v.x - p.x) < SNAP_EPSILON && Math.abs(v.y - p.y) < SNAP_EPSILON
    );
    if (existing) return existing;
    const v: PlanVertex = { id: crypto.randomUUID(), x: p.x, y: p.y };
    vertices.push(v);
    return v;
  };

  const ringVertices = analysis.roomOutline.map((p) => snapVertex(toWorld(p)));
  // Degenerate ring (outline collapsed onto itself) → refuse, don't invent.
  const uniqueRing = new Set(ringVertices.map((v) => v.id));
  if (uniqueRing.size < 3) {
    return { ok: false, error: "The analyzed room outline is degenerate." };
  }

  const walls: PlanWall[] = [];
  const wallKey = (a: string, b: string) => (a < b ? `${a}|${b}` : `${b}|${a}`);
  const wallKeys = new Set<string>();
  const addWall = (a: PlanVertex, b: PlanVertex, certain: boolean) => {
    if (a.id === b.id) return;
    const key = wallKey(a.id, b.id);
    if (wallKeys.has(key)) return;
    wallKeys.add(key);
    walls.push({ id: crypto.randomUUID(), a: a.id, b: b.id, thickness: plan.defaultWallThickness * (certain ? 1 : 0.8) });
  };
  for (let i = 0; i < ringVertices.length; i++) {
    const a = ringVertices[i]!;
    const b = ringVertices[(i + 1) % ringVertices.length]!;
    addWall(a, b, true); // the outline ring is the room's own boundary
  }

  // --- extra (interior) wall segments from the analysis -----------------------
  if (Array.isArray(analysis.walls)) {
    for (const w of analysis.walls) {
      if (!w?.a || !w?.b) continue;
      addWall(snapVertex(toWorld(w.a)), snapVertex(toWorld(w.b)), w.certain !== false);
    }
  }

  // --- openings projected onto the nearest wall --------------------------------
  const openings: PlanOpening[] = [];
  const resolve = (id: string): Pt => {
    const v = vertices.find((x) => x.id === id);
    return v ? { x: v.x, y: v.y } : { x: 0, y: 0 };
  };
  if (Array.isArray(analysis.openings)) {
    for (const o of analysis.openings) {
      if (!o || (o.kind !== "door" && o.kind !== "window")) continue;
      const p = toWorld({ x: o.x, y: o.y });
      let best: { wallId: string; dist: number; t: number } | null = null;
      for (const wall of walls) {
        const a = resolve(wall.a);
        const b = resolve(wall.b);
        const { dist, t } = pointToSegment(p, a, b);
        if (!best || dist < best.dist) best = { wallId: wall.id, dist, t };
      }
      if (!best) continue;
      openings.push({
        id: crypto.randomUUID(),
        wallId: best.wallId,
        kind: o.kind,
        t: Math.min(0.95, Math.max(0.05, best.t)),
        width: o.kind === "door" ? 0.9 : 1.2, // nominal, NOT a measurement
        height: o.kind === "door" ? 2.1 : 1.5,
        sillHeight: o.kind === "door" ? 0 : 1.0,
        uncertain: o.certain === false,
      } as PlanOpening);
    }
  }

  // --- furniture ---------------------------------------------------------------
  const furniture: PlanFurniture[] = [];
  if (Array.isArray(analysis.furniture)) {
    for (const f of analysis.furniture) {
      if (!f || typeof f.x !== "number" || typeof f.y !== "number") continue;
      const defaults = FURNITURE_DEFAULT_SIZES[f.kind] ?? FURNITURE_DEFAULT_SIZES.other;
      const kind: PlanFurnitureKind = FURNITURE_DEFAULT_SIZES[f.kind] ? f.kind : "other";
      const w = typeof f.w === "number" ? Math.min(4, Math.max(0.2, f.w * NOMINAL_SPAN)) : defaults.w;
      const h = typeof f.h === "number" ? Math.min(4, Math.max(0.2, f.h * NOMINAL_SPAN)) : defaults.h;
      furniture.push({
        id: crypto.randomUUID(),
        kind,
        label: f.label,
        x: f.x * NOMINAL_SPAN,
        y: f.y * NOMINAL_SPAN,
        w,
        h,
        rotation: typeof f.rotation === "number" ? ((f.rotation % 360) + 360) % 360 : 0,
        uncertain: f.certain === true ? false : true,
      });
    }
  }

  floor.vertices = vertices;
  floor.walls = walls;
  floor.openings = openings;
  floor.furniture = furniture;
  floor.rooms = [
    {
      id: crypto.randomUUID(),
      name: analysis.roomType?.slice(0, 60) || "Room",
      polygon: ringVertices.map((v) => v.id),
      createdAt: Date.now(),
      updatedAt: Date.now(),
    },
  ];

  plan.concept = {
    generatedBy: "ai-concept-v1",
    sourceStopId: source.stopId,
    sourceStopTitle: source.stopTitle,
    generatedAt: Date.now(),
    model: analysis.model,
    uncertaintyNotes: Array.isArray(analysis.uncertaintyNotes)
      ? analysis.uncertaintyNotes.slice(0, 6)
      : [],
    // generatedSnapshot is attached by the UI after conversion (it stores a
    // copy of this pristine document for "reset to generated layout").
  };

  return { ok: true, plan };
}

/** The pristine snapshot for reset: the converted document itself, with its
 *  own (empty) snapshot field to avoid unbounded nesting. */
export function snapshotOfConceptPlan(plan: FloorPlanDocument): FloorPlanDocument {
  return { ...plan, concept: plan.concept ? { ...plan.concept, generatedSnapshot: undefined } : undefined };
}

/** Whether the NOT-TO-SCALE watermark must be shown for this plan. */
export function needsConceptWatermark(plan: FloorPlanDocument | null): boolean {
  return Boolean(plan?.concept);
}

export { PLAN_SCHEMA_VERSION };
