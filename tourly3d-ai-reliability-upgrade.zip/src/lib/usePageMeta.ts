import { useEffect } from "react";

type PageMeta = {
  title: string;
  description?: string;
  /** Keep private/app pages (dashboard, editor, shared tours) out of search. */
  noindex?: boolean;
};

function setMeta(attr: "name" | "property", key: string, value: string) {
  let el = document.head.querySelector<HTMLMetaElement>(`meta[${attr}="${key}"]`);
  if (!el) {
    el = document.createElement("meta");
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute("content", value);
}

/** Per-route <title>, description, Open Graph and robots tags for the SPA.
 *  (Link-preview crawlers don't run JS — per-tour previews are injected at the
 *  edge instead, see netlify/edge-functions/tour-meta.ts.) */
export function usePageMeta({ title, description, noindex = false }: PageMeta) {
  useEffect(() => {
    document.title = title;
    setMeta("property", "og:title", title);
    setMeta("name", "twitter:title", title);
    if (description) {
      setMeta("name", "description", description);
      setMeta("property", "og:description", description);
      setMeta("name", "twitter:description", description);
    }
    setMeta("name", "robots", noindex ? "noindex, nofollow" : "index, follow");

    const canonical = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (canonical && !noindex) {
      canonical.href = `${window.location.origin}${window.location.pathname}`;
      setMeta("property", "og:url", canonical.href);
    }

    return () => {
      // The next page sets its own; make sure a noindex never leaks forward.
      setMeta("name", "robots", "index, follow");
    };
  }, [title, description, noindex]);
}
