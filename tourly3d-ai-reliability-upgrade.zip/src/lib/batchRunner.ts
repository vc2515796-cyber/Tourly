/**
 * Resumable multi-scene batch runner (Phase 6 of the reliability upgrade).
 *
 * A PURE state machine — no DOM, no fetch — so the resume semantics are
 * unit-testable and reusable by both the "auto-detect all scenes" flow and
 * any future per-scene AI pass:
 *
 *   - each item moves through pending → processing → completed | skipped | failed
 *   - a recoverable ITEM failure is recorded and the batch CONTINUES
 *   - a SYSTEMIC failure (auth expired, daily quota gone, service not
 *     configured, rate-limit-everything) aborts the batch — it is never
 *     misreported as "one bad scene"
 *   - completed items are never reprocessed on resume; `retryIds` re-runs
 *     ONLY failed (or explicitly selected) items
 *   - the caller persists state after every item (see Editor's usage), so
 *     progress survives the batch being interrupted
 *
 * Why client-side: the staged images live in the browser (localStorage
 * drafts), so the server can't resume a job it can't see — and Netlify
 * Functions must stay short-lived. The resumable unit is the item, and the
 * client already owns the item data.
 */

export type BatchItemState = "pending" | "processing" | "completed" | "skipped" | "failed";

export type BatchItem<S> = {
  /** Stable id (scene/stop id). */
  id: string;
  state: BatchItemState;
  /** Human-readable explanation for skipped/failed items. */
  reason?: string;
  /** Result payload for completed items (caller-defined). */
  result?: S;
};

export type BatchSummary = {
  total: number;
  completed: number;
  skipped: number;
  failed: number;
  pending: number;
};

export type SystemicErrorClassifier<E> = (error: E) => "auth" | "quota" | "not-configured" | "systemic" | "item";

export type RunBatchOptions<T, S, E> = {
  /** Items to process (state carried across resumes). */
  items: BatchItem<S>[];
  /** Runs ONE item. Resolves with its result; throws/rejects on failure. */
  processItem: (item: BatchItem<S>) => Promise<S>;
  /** Returns "skipped" + reason for items that shouldn't run at all. */
  shouldSkip?: (item: BatchItem<S>) => { skip: boolean; reason?: string } | null;
  /**
   * Classifies a thrown error: is it THIS item's problem, or a systemic one
   * that will fail every remaining item too? Systemic errors abort the run.
   */
  classifyError: SystemicErrorClassifier<E>;
  /** Called after EVERY item settles (persist your state here). */
  onItemSettled?: (items: BatchItem<S>[], summary: BatchSummary) => void;
  /** Abort the whole run after N consecutive item failures (default 3). */
  maxConsecutiveFailures?: number;
  /**
   * If set, only these ids run (a retry-failed pass); everything else keeps
   * its state untouched. Completed ids inside this list are still skipped —
   * reprocessing needs an explicit opt-in via forceIds.
   */
  onlyIds?: string[];
  /** Explicitly re-run these ids even if previously completed. */
  forceIds?: string[];
};

export type BatchRunResult<S> = {
  /** The final item states (same array, mutated — callers persist this). */
  items: BatchItem<S>[];
  summary: BatchSummary;
  /** Set when the run aborted early on a systemic error. */
  aborted?: { kind: string; message: string };
};

export function summarize<S>(items: BatchItem<S>[]): BatchSummary {
  const summary: BatchSummary = { total: items.length, completed: 0, skipped: 0, failed: 0, pending: 0 };
  for (const item of items) {
    if (item.state === "completed") summary.completed++;
    else if (item.state === "skipped") summary.skipped++;
    else if (item.state === "failed") summary.failed++;
    else summary.pending++; // pending | processing (interrupted runs reset processing → pending on resume)
  }
  return summary;
}

/** Normalizes states left behind by an interrupted run: processing → pending. */
export function normalizeForResume<S>(items: BatchItem<S>[]): BatchItem<S>[] {
  return items.map((i) => (i.state === "processing" ? { ...i, state: "pending" } : i));
}

export async function runBatch<T, S, E = unknown>(
  opts: RunBatchOptions<T, S, E>
): Promise<BatchRunResult<S>> {
  const {
    items,
    processItem,
    shouldSkip,
    classifyError,
    onItemSettled,
    maxConsecutiveFailures = 3,
    onlyIds,
    forceIds,
  } = opts;

  const only = onlyIds ? new Set(onlyIds) : null;
  const force = new Set(forceIds ?? []);
  let consecutiveFailures = 0;
  let aborted: BatchRunResult<S>["aborted"];

  for (const item of items) {
    if (aborted) break;
    if (only && !only.has(item.id)) continue; // not part of this pass
    if (item.state === "completed" && !force.has(item.id)) continue; // never redo completed
    if (item.state === "skipped" && !force.has(item.id)) continue; // skip reasons don't change on retry
    if (item.state === "processing") item.state = "pending"; // interrupted earlier

    // Pre-flight skip check (invalid input etc.)
    const skipCheck = shouldSkip?.(item) ?? null;
    if (skipCheck?.skip) {
      item.state = "skipped";
      item.reason = skipCheck.reason ?? "skipped";
      onItemSettled?.(items, summarize(items));
      continue;
    }

    item.state = "processing";
    item.reason = undefined;
    try {
      const result = await processItem(item);
      item.state = "completed";
      item.result = result;
      item.reason = undefined;
      consecutiveFailures = 0;
    } catch (err: any) {
      const kind = classifyError(err as E);
      if (kind === "auth" || kind === "quota" || kind === "not-configured" || kind === "systemic") {
        // A systemic failure is NOT this scene's fault — every remaining
        // scene would fail identically. Stop the run honestly.
        item.state = "failed";
        item.reason = err?.friendlyMessage ?? String(err?.message ?? kind);
        aborted = {
          kind,
          message:
            kind === "auth"
              ? "Your session expired — sign in again. Completed scenes are kept."
              : kind === "quota"
              ? "Today's AI limit was reached — completed scenes are kept, and you can retry the rest tomorrow."
              : kind === "not-configured"
              ? "The AI service isn't configured on this deployment — completed scenes are kept."
              : "The AI service stopped responding — completed scenes are kept, and you can retry the rest.",
        };
        onItemSettled?.(items, summarize(items));
        break;
      }
      // Item-level failure: record it, keep going with the rest.
      item.state = "failed";
      item.reason = err?.friendlyMessage ?? String(err?.message ?? "failed");
      consecutiveFailures++;
      if (consecutiveFailures >= maxConsecutiveFailures) {
        // A wall of consecutive failures looks systemic even if each error
        // was item-shaped — stop instead of burning the quota on doom.
        aborted = {
          kind: "consecutive-failures",
          message: "Several scenes failed in a row — the AI service looks unhealthy. Completed scenes are kept; retry the rest later.",
        };
        onItemSettled?.(items, summarize(items));
        break;
      }
    }
    onItemSettled?.(items, summarize(items));
  }

  // Anything left pending after an abort stays pending (resumable).
  return { items, summary: summarize(items), aborted };
}
