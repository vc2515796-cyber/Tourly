/**
 * Checks whether an image is close enough to a standard 2:1 equirectangular
 * panorama ratio (e.g. 4096x2048, 2048x1024) to be treated as real 360°
 * media. This doesn't fix distortion — nothing can, if the source photo
 * isn't a real panorama capture — it just catches the mismatch BEFORE the
 * photo gets silently wrapped onto a sphere and looks warped.
 */

const EXPECTED_RATIO = 2;
const TOLERANCE = 0.12; // ~12% — forgiving enough for slightly cropped exports

export type PanoramaCheck = {
  isEquirectangular: boolean;
  width: number;
  height: number;
  ratio: number;
};

export function checkEquirectangular(dataUrl: string): Promise<PanoramaCheck> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const ratio = img.width / img.height;
      resolve({
        isEquirectangular: Math.abs(ratio - EXPECTED_RATIO) / EXPECTED_RATIO <= TOLERANCE,
        width: img.width,
        height: img.height,
        ratio,
      });
    };
    img.onerror = reject;
    img.src = dataUrl;
  });
}
