import { Tour, Stop, Hotspot } from "../types";
import { saveTour } from "./storage";

/**
 * Adds a polished sample walkthrough so the landing page and new accounts
 * have something meaningful to explore. The included 2:1 panorama assets
 * are bundled locally, so the demo does not depend on an external CDN.
 * Keep sample content clearly labelled as a demo; never imply it is a real
 * customer listing or a measured/verified property scan.
 */

const DEMO_PANORAMAS: [title: string, src: string, note: string][] = [
  [
    "Grand Living & Lounge",
    "/demo-panorama.jpg",
    "Explore the open-plan lounge, statement lighting, floor-to-ceiling glazing and dining area. Sample showcase imagery — not a verified property listing.",
  ],
  [
    "Bright Everyday Living",
    "/demo-panorama-2.jpg",
    "Look around the bright family lounge and follow the room-to-room navigation to experience a second layout. Sample showcase imagery — not a measured scan.",
  ],
];

function makePanoramaStop(title: string, src: string, note: string): Stop {
  return {
    id: crypto.randomUUID(),
    title,
    note,
    media: { kind: "panorama", dataUrl: src },
    hotspots: [],
  };
}

function linkSequentially(stops: Stop[]): void {
  if (stops.length < 2) return;
  for (let i = 0; i < stops.length; i++) {
    const next = stops[(i + 1) % stops.length];
    const hotspot: Hotspot = {
      id: crypto.randomUUID(),
      targetStopId: next.id,
      label: `Go to ${next.title}`,
      yaw: 20,
      pitch: 0,
      iconStyle: "chevron",
    };
    stops[i].hotspots.push(hotspot);
  }
}

function buildTour(name: string, subtitle: string, stops: Stop[]): Tour {
  linkSequentially(stops);
  const now = Date.now();
  return {
    id: crypto.randomUUID(),
    name,
    subtitle,
    createdAt: now,
    updatedAt: now,
    stops,
  };
}

// Versioned seed lets existing installations receive the improved showcase
// without overwriting or deleting any tours a user has already created.
const SEEDED_FLAG_KEY = "tourly:signatureDemoSeededV2";
// Older builds seeded the demo tour under a different flag key. A browser
// that already has any of these must NOT receive a second demo tour when
// it upgrades to this build (duplicate-demo bug). When only a legacy key is
// found, backfill the current key so future loads take the fast path.
const LEGACY_SEEDED_FLAG_KEYS = ["waypoint:demoSeededOnce"];

export function seedDemoToursIfEmpty(): void {
  // Seed exactly once, ever — a dedicated flag (not "does a demo tour
  // currently exist") so deleting the demo tour on purpose doesn't
  // bring it back on next load. Installations upgraded from older builds
  // count as already seeded, whichever flag key they carry.
  if (localStorage.getItem(SEEDED_FLAG_KEY)) return;
  if (LEGACY_SEEDED_FLAG_KEYS.some((key) => localStorage.getItem(key))) {
    localStorage.setItem(SEEDED_FLAG_KEY, "1");
    return;
  }

  const sample = buildTour(
    "Demo — Signature Residence",
    "Explore a premium property walkthrough · sample imagery",
    DEMO_PANORAMAS.map(([title, src, note]) => makePanoramaStop(title, src, note))
  );

  saveTour(sample);
  localStorage.setItem(SEEDED_FLAG_KEY, "1");
}
