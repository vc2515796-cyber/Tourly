import { Tour, Stop } from "../types";

const KEY = "waypoint:tours";

function readAll(): Tour[] {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Tour[]) : [];
  } catch {
    return [];
  }
}

/** Thrown when the browser's ~5 MB localStorage quota is exhausted. */
export class StorageFullError extends Error {
  constructor() {
    super("Browser storage is full");
    this.name = "StorageFullError";
  }
}

function isQuotaError(e: any): boolean {
  return (
    e?.name === "QuotaExceededError" ||
    e?.name === "NS_ERROR_DOM_QUOTA_REACHED" ||
    e?.code === 22 ||
    e?.code === 1014
  );
}

function writeAll(tours: Tour[]) {
  try {
    localStorage.setItem(KEY, JSON.stringify(tours));
  } catch (e) {
    if (isQuotaError(e)) throw new StorageFullError();
    throw e;
  }
}

export function listTours(): Tour[] {
  return readAll().sort((a, b) => b.updatedAt - a.updatedAt);
}

export function getTour(id: string): Tour | undefined {
  return readAll().find((t) => t.id === id);
}

export function createTour(name: string): Tour {
  const now = Date.now();
  const tour: Tour = {
    id: crypto.randomUUID(),
    name: name || "Untitled walkthrough",
    subtitle: "",
    createdAt: now,
    updatedAt: now,
    stops: [],
  };
  const all = readAll();
  all.push(tour);
  writeAll(all);
  return tour;
}

export function saveTour(tour: Tour) {
  const all = readAll();
  const idx = all.findIndex((t) => t.id === tour.id);
  const updated = { ...tour, updatedAt: Date.now() };
  if (idx === -1) {
    all.push(updated);
  } else {
    all[idx] = updated;
  }
  writeAll(all);
}

export function deleteTour(id: string) {
  writeAll(readAll().filter((t) => t.id !== id));
}

export function newStop(): Stop {
  return {
    id: crypto.randomUUID(),
    title: "New stop",
    note: "",
    media: null,
    hotspots: [],
  };
}

// --- Analytics (real, local-only view tracking) ---------------------------
// Records a view every time a public /tour/:id page is loaded in THIS
// browser. This is genuine data, not a fabricated number — but it only
// reflects views from devices that hit this browser's localStorage, not
// cross-device visitors. A real analytics backend would be needed for that.

const VIEWS_KEY = "waypoint:views";

type ViewEvent = { tourId: string; timestamp: number };

function readViews(): ViewEvent[] {
  try {
    const raw = localStorage.getItem(VIEWS_KEY);
    return raw ? (JSON.parse(raw) as ViewEvent[]) : [];
  } catch {
    return [];
  }
}

export function recordView(tourId: string) {
  const views = readViews();
  views.push({ tourId, timestamp: Date.now() });
  const trimmed = views.slice(-2000);
  try {
    localStorage.setItem(VIEWS_KEY, JSON.stringify(trimmed));
  } catch {
    // A full quota must never break viewing a tour just because a view
    // couldn't be counted.
  }
}

export type TourAnalytics = {
  id: string;
  name: string;
  stops: number;
  views: number;
  /** Timestamp of the most recent recorded view in this browser, if any. */
  lastViewed: number | null;
};

export type ViewSeries = {
  days: { label: string; date: string; views: number }[];
  total: number;
  /** Views in the equally long period right before this one, for comparison. */
  previousTotal: number;
  busiest: { date: string; views: number } | null;
};

/** Per-day view counts for the last `days` days (optionally for one tour),
 *  computed from the same real, local view events as everything else. */
export function getViewSeries(days: number, tourId?: string): ViewSeries {
  const views = readViews().filter((v) => !tourId || v.tourId === tourId);
  const DAY = 24 * 60 * 60 * 1000;
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const firstStart = todayStart - (days - 1) * DAY;

  const series = Array.from({ length: days }).map((_, i) => {
    const start = firstStart + i * DAY;
    const d = new Date(start);
    const count = views.filter((v) => v.timestamp >= start && v.timestamp < start + DAY).length;
    return {
      label: days <= 7 ? d.toLocaleDateString(undefined, { weekday: "short" }) : String(d.getDate()),
      date: d.toLocaleDateString(undefined, { day: "numeric", month: "short" }),
      views: count,
    };
  });

  const total = series.reduce((sum, d) => sum + d.views, 0);
  const prevStart = firstStart - days * DAY;
  const previousTotal = views.filter((v) => v.timestamp >= prevStart && v.timestamp < firstStart).length;
  const top = series.reduce((best, d) => (d.views > best.views ? d : best), series[0]);

  return {
    days: series,
    total,
    previousTotal,
    busiest: top && top.views > 0 ? { date: top.date, views: top.views } : null,
  };
}

export function getAnalytics(): {
  totalViews: number;
  totalTours: number;
  totalStops: number;
  perTour: TourAnalytics[];
  last7Days: { label: string; views: number }[];
} {
  const tours = listTours();
  const views = readViews();

  const viewCountByTour = new Map<string, number>();
  for (const v of views) {
    viewCountByTour.set(v.tourId, (viewCountByTour.get(v.tourId) ?? 0) + 1);
  }

  const lastViewedByTour = new Map<string, number>();
  for (const v of views) {
    if (v.timestamp > (lastViewedByTour.get(v.tourId) ?? 0)) lastViewedByTour.set(v.tourId, v.timestamp);
  }

  const perTour: TourAnalytics[] = tours
    .map((t) => ({
      id: t.id,
      name: t.name,
      stops: t.stops.length,
      views: viewCountByTour.get(t.id) ?? 0,
      lastViewed: lastViewedByTour.get(t.id) ?? null,
    }))
    .sort((a, b) => b.views - a.views);

  const now = new Date();
  const last7Days = Array.from({ length: 7 }).map((_, i) => {
    const day = new Date(now);
    day.setDate(now.getDate() - (6 - i));
    const dayStart = new Date(day.getFullYear(), day.getMonth(), day.getDate()).getTime();
    const dayEnd = dayStart + 24 * 60 * 60 * 1000;
    const count = views.filter((v) => v.timestamp >= dayStart && v.timestamp < dayEnd).length;
    return { label: day.toLocaleDateString(undefined, { weekday: "short" }), views: count };
  });

  return {
    totalViews: views.length,
    totalTours: tours.length,
    totalStops: tours.reduce((sum, t) => sum + t.stops.length, 0),
    perTour,
    last7Days,
  };
}
