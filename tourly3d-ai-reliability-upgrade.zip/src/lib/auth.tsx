import {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode,
} from "react";
import {
  User,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  signOut as firebaseSignOut,
  sendPasswordResetEmail,
  sendEmailVerification,
  updateProfile,
} from "firebase/auth";
import { auth, googleProvider, firebaseConfigured } from "./firebase";

interface AuthContextValue {
  user: User | null;
  loading: boolean;
  configured: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string) => Promise<void>;
  signInWithGoogle: () => Promise<void>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  resendVerification: () => Promise<void>;
  updateDisplayName: (name: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

// Thrown when the deployment has no usable Firebase client config. Carries
// a stable `code` so the login page can show exactly WHAT is missing rather
// than a generic "something went wrong" — the old message hid the actual
// cause (missing VITE_FIREBASE_* build-time env vars) behind a dead end.
function notConfiguredError(): Error {
  const err = new Error(
    "Firebase authentication isn't configured on this deployment — the site owner must set the VITE_FIREBASE_* environment variables and redeploy (see AUTH-SETUP.md)."
  );
  (err as Error & { code?: string }).code = "app/firebase-not-configured";
  return err;
}

// True only when firebase.ts's own initialization actually succeeded —
// distinct from firebaseConfigured, which just means env vars were
// present (init can still fail on a bad/invalid value).
const authReady = firebaseConfigured && auth !== null && googleProvider !== null;

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  // If Firebase isn't usable (env vars missing, or init failed), don't
  // hang on a loading spinner forever — treat as signed out.
  const [loading, setLoading] = useState(authReady);

  useEffect(() => {
    if (!authReady || !auth) return;
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
    return unsub;
  }, []);

  const value: AuthContextValue = {
    user,
    loading,
    configured: authReady,
    signIn: async (email, password) => {
      if (!auth) throw notConfiguredError();
      await signInWithEmailAndPassword(auth, email, password);
    },
    signUp: async (email, password) => {
      if (!auth) throw notConfiguredError();
      const credential = await createUserWithEmailAndPassword(auth, email, password);
      // Best-effort — a slow verification email shouldn't block account
      // creation; the "verify your email" banner covers the resend case.
      sendEmailVerification(credential.user).catch(() => {});
    },
    signInWithGoogle: async () => {
      if (!auth || !googleProvider) throw notConfiguredError();
      await signInWithPopup(auth, googleProvider);
    },
    signOut: async () => {
      if (!auth) return;
      await firebaseSignOut(auth);
    },
    resetPassword: async (email) => {
      if (!auth) throw notConfiguredError();
      await sendPasswordResetEmail(auth, email);
    },
    resendVerification: async () => {
      if (!auth?.currentUser) throw notConfiguredError();
      await sendEmailVerification(auth.currentUser);
    },
    updateDisplayName: async (name) => {
      if (!auth?.currentUser) throw notConfiguredError();
      await updateProfile(auth.currentUser, { displayName: name });
      // updateProfile doesn't trigger onAuthStateChanged — force our own
      // state to reflect the new name immediately instead of waiting for
      // the next natural auth event (e.g. a refresh).
      setUser({ ...auth.currentUser });
    },
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
