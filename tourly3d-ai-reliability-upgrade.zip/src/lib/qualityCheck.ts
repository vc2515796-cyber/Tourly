/**
 * Rough client-side blur check — downsamples the image, converts to
 * grayscale, and measures the variance of a simple Laplacian (edge)
 * filter. Sharp, detailed photos have high edge variance; blurry ones
 * are smooth and score low. This is a heuristic, not a real computer-
 * vision quality model — it's meant to catch obviously blurry uploads,
 * not to be authoritative. Never blocks the upload; only warns.
 */

const SAMPLE_SIZE = 300;
// Tuned empirically against a handful of sharp vs. blurry test photos —
// treat as a rough cutoff, not a precise threshold.
const BLUR_VARIANCE_THRESHOLD = 90;

function loadImage(dataUrl: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = dataUrl;
  });
}

export async function checkBlurriness(dataUrl: string): Promise<{ looksBlurry: boolean } | null> {
  try {
    const img = await loadImage(dataUrl);
    const scale = Math.min(1, SAMPLE_SIZE / Math.max(img.width, img.height));
    const w = Math.max(1, Math.round(img.width * scale));
    const h = Math.max(1, Math.round(img.height * scale));

    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    if (!ctx) return null;
    ctx.drawImage(img, 0, 0, w, h);

    const { data } = ctx.getImageData(0, 0, w, h);
    const gray = new Float32Array(w * h);
    for (let i = 0; i < w * h; i++) {
      const r = data[i * 4];
      const g = data[i * 4 + 1];
      const b = data[i * 4 + 2];
      gray[i] = 0.299 * r + 0.587 * g + 0.114 * b;
    }

    // Simple discrete Laplacian at each interior pixel.
    const laplacian: number[] = [];
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const idx = y * w + x;
        const value =
          4 * gray[idx] - gray[idx - 1] - gray[idx + 1] - gray[idx - w] - gray[idx + w];
        laplacian.push(value);
      }
    }
    if (laplacian.length === 0) return null;

    const mean = laplacian.reduce((a, b) => a + b, 0) / laplacian.length;
    const variance = laplacian.reduce((a, b) => a + (b - mean) ** 2, 0) / laplacian.length;

    return { looksBlurry: variance < BLUR_VARIANCE_THRESHOLD };
  } catch {
    return null;
  }
}
