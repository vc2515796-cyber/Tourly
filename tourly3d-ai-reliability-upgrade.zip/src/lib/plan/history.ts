/**
 * Stage B2 — undo/redo history for the floor-plan document.
 *
 * Snapshots are whole-document (the doc is small: vertices/walls/rooms —
 * background images are shared string references, not copies), which makes
 * undo trivially correct even across floors. The stack is capped so a long
 * editing session can't grow without bound.
 */

import type { FloorPlanDocument } from "./model";

const MAX_HISTORY = 60;

export class PlanHistory {
  private past: FloorPlanDocument[] = [];
  private future: FloorPlanDocument[] = [];
  private lastCommitted: FloorPlanDocument;

  constructor(initial: FloorPlanDocument) {
    this.lastCommitted = initial;
  }

  /** True when the working doc differs from the last committed snapshot. */
  isDirty(current: FloorPlanDocument): boolean {
    // updatedAt is excluded from equality — a restamp alone isn't an edit.
    return JSON.stringify(stripStamp(current)) !== JSON.stringify(stripStamp(this.lastCommitted));
  }

  /** Records a completed edit (call AFTER the mutation, with its result). */
  commit(doc: FloorPlanDocument) {
    if (this.isDirty(doc)) {
      this.past.push(this.lastCommitted);
      if (this.past.length > MAX_HISTORY) this.past.shift();
      this.lastCommitted = doc;
      this.future = []; // a new edit invalidates the redo branch
    }
  }

  canUndo(): boolean {
    return this.past.length > 0;
  }

  canRedo(): boolean {
    return this.future.length > 0;
  }

  /** Returns the doc to restore, or null when nothing to undo. */
  undo(current: FloorPlanDocument): FloorPlanDocument | null {
    if (!this.past.length) return null;
    this.future.push(this.lastCommitted);
    const restored = this.past.pop()!;
    this.lastCommitted = restored;
    // If the caller had uncommitted tweaks, they're discarded by design —
    // undo is a committed-state operation.
    void current;
    return restored;
  }

  redo(): FloorPlanDocument | null {
    if (!this.future.length) return null;
    this.past.push(this.lastCommitted);
    const restored = this.future.pop()!;
    this.lastCommitted = restored;
    return restored;
  }
}

function stripStamp(doc: FloorPlanDocument): Omit<FloorPlanDocument, "updatedAt"> {
  const { updatedAt: _ignored, ...rest } = doc;
  return rest;
}
