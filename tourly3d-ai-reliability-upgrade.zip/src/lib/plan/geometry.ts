/**
 * Stage B2/B3 — pure floor-plan geometry.
 *
 * Every function here is side-effect-free and Node-testable: the 2D editor,
 * the 3D dollhouse, the validation UI and the unit tests all call the SAME
 * code, so what you draw is literally what gets extruded into 3D.
 *
 * Honesty: all computed lengths/areas are only meaningful after the user
 * calibrates the plan scale; callers must hide (never fake) measurements
 * while `scale.calibrated === false`.
 */

import type { PlanFloor, PlanOpening, PlanRoom, PlanVertex, PlanWall } from "./model";

export type Pt = { x: number; y: number };

// --- basic polygon math --------------------------------------------------------

/** Shoelace area (absolute). */
export function polygonArea(points: Pt[]): number {
  let sum = 0;
  for (let i = 0; i < points.length; i++) {
    const a = points[i]!;
    const b = points[(i + 1) % points.length]!;
    sum += a.x * b.y - b.x * a.y;
  }
  return Math.abs(sum) / 2;
}

/** Perimeter of the closed ring. */
export function polygonPerimeter(points: Pt[]): number {
  let sum = 0;
  for (let i = 0; i < points.length; i++) {
    const a = points[i]!;
    const b = points[(i + 1) % points.length]!;
    sum += Math.hypot(b.x - a.x, b.y - a.y);
  }
  return sum;
}

/** Area centroid — the natural label anchor for a room. */
export function polygonCentroid(points: Pt[]): Pt {
  if (points.length === 0) return { x: 0, y: 0 };
  if (points.length < 3) {
    return {
      x: points.reduce((s, p) => s + p.x, 0) / points.length,
      y: points.reduce((s, p) => s + p.y, 0) / points.length,
    };
  }
  let cx = 0;
  let cy = 0;
  let area2 = 0; // signed double area
  for (let i = 0; i < points.length; i++) {
    const a = points[i]!;
    const b = points[(i + 1) % points.length]!;
    const cross = a.x * b.y - b.x * a.y;
    area2 += cross;
    cx += (a.x + b.x) * cross;
    cy += (a.y + b.y) * cross;
  }
  if (Math.abs(area2) < 1e-9) {
    return { x: points[0]!.x, y: points[0]!.y };
  }
  return { x: cx / (3 * area2), y: cy / (3 * area2) };
}

/** Winding sign of the ring (+1 counter-clockwise, -1 clockwise). */
export function polygonWinding(points: Pt[]): number {
  let sum = 0;
  for (let i = 0; i < points.length; i++) {
    const a = points[i]!;
    const b = points[(i + 1) % points.length]!;
    sum += a.x * b.y - b.x * a.y;
  }
  return sum >= 0 ? 1 : -1;
}

export function pointInPolygon(pt: Pt, points: Pt[]): boolean {
  let inside = false;
  for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
    const a = points[i]!;
    const b = points[j]!;
    if (a.y > pt.y !== b.y > pt.y && pt.x < ((b.x - a.x) * (pt.y - a.y)) / (b.y - a.y) + a.x) {
      inside = !inside;
    }
  }
  return inside;
}

// --- simplicity (self-intersection) -------------------------------------------

function segmentsProperlyIntersect(p1: Pt, p2: Pt, p3: Pt, p4: Pt): boolean {
  const d1 = cross(p3, p4, p1);
  const d2 = cross(p3, p4, p2);
  const d3 = cross(p1, p2, p3);
  const d4 = cross(p1, p2, p4);
  if (((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) && ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0))) {
    return true;
  }
  return false;
}

function cross(a: Pt, b: Pt, c: Pt): number {
  return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
}

/** True when the closed ring has no self-intersections and no repeated
 *  vertices — the minimum geometric sanity for a "room". */
export function isSimplePolygon(points: Pt[]): boolean {
  const n = points.length;
  if (n < 3) return false;
  // Repeated vertices (excluding the implicit closure) make the ring degenerate.
  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      if (Math.hypot(points[i]!.x - points[j]!.x, points[i]!.y - points[j]!.y) < 1e-6) return false;
    }
  }
  // Every non-adjacent edge pair must not properly intersect. Adjacent
  // edges share an endpoint by design.
  for (let i = 0; i < n; i++) {
    const a1 = points[i]!;
    const a2 = points[(i + 1) % n]!;
    for (let j = i + 1; j < n; j++) {
      const b1 = points[j]!;
      const b2 = points[(j + 1) % n]!;
      const adjacent = j === i || (j + 1) % n === i || (i + 1) % n === j;
      if (adjacent) continue;
      if (segmentsProperlyIntersect(a1, a2, b1, b2)) return false;
    }
  }
  return true;
}

export type RoomValidationIssue = { roomId: string; level: "error" | "warning"; message: string };

/**
 * Full validation for one room ring. Errors make the room invalid (it is
 * excluded from the 3D build and marked in red); warnings are cosmetic.
 */
export function validateRoomRing(roomId: string, points: Pt[]): RoomValidationIssue[] {
  const issues: RoomValidationIssue[] = [];
  if (points.length < 3) {
    issues.push({ roomId, level: "error", message: "A room needs at least 3 corners." });
    return issues;
  }
  if (points.length === 3) {
    const area = polygonArea(points);
    if (area < 0.01) {
      issues.push({ roomId, level: "error", message: "This room's corners are (nearly) collinear — it has no area." });
    }
  }
  if (!isSimplePolygon(points)) {
    issues.push({ roomId, level: "error", message: "The room outline crosses itself — edges must not intersect." });
  }
  const perimeter = polygonPerimeter(points);
  if (perimeter > 0 && polygonArea(points) / perimeter < 0.01) {
    issues.push({ roomId, level: "warning", message: "This room is extremely thin — check for accidental corners." });
  }
  return issues;
}

/** Validates every room on a floor (plus shared checks). */
export function validateFloor(floor: PlanFloor, resolve: (id: string) => Pt): RoomValidationIssue[] {
  const issues: RoomValidationIssue[] = [];
  for (const room of floor.rooms) {
    issues.push(...validateRoomRing(room.id, room.polygon.map(resolve)));
  }
  return issues;
}

// --- room/world helpers ---------------------------------------------------------

export function vertexById(vertices: PlanVertex[]): (id: string) => Pt {
  const map = new Map(vertices.map((v) => [v.id, { x: v.x, y: v.y }]));
  return (id) => map.get(id) ?? { x: 0, y: 0 };
}

export function roomPoints(room: PlanRoom, resolve: (id: string) => Pt): Pt[] {
  return room.polygon.map(resolve);
}

/** Distance from a point to a segment, plus the clamped projection t (0..1). */
export function pointToSegment(pt: Pt, a: Pt, b: Pt): { dist: number; t: number; closest: Pt } {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const len2 = dx * dx + dy * dy;
  if (len2 < 1e-12) {
    return { dist: Math.hypot(pt.x - a.x, pt.y - a.y), t: 0, closest: a };
  }
  let t = ((pt.x - a.x) * dx + (pt.y - a.y) * dy) / len2;
  t = Math.max(0, Math.min(1, t));
  const closest = { x: a.x + t * dx, y: a.y + t * dy };
  return { dist: Math.hypot(pt.x - closest.x, pt.y - closest.y), t, closest };
}

// --- walls + openings (the 2D/3D shared core) ----------------------------------

export type WallSegment = {
  wall: PlanWall;
  a: Pt;
  b: Pt;
  length: number;
  angle: number; // radians, a→b
};

export function wallSegment(wall: PlanWall, resolve: (id: string) => Pt): WallSegment {
  const a = resolve(wall.a);
  const b = resolve(wall.b);
  return {
    wall,
    a,
    b,
    length: Math.hypot(b.x - a.x, b.y - a.y),
    angle: Math.atan2(b.y - a.y, b.x - a.x),
  };
}

export type OpeningPlacement = {
  opening: PlanOpening;
  /** world-space center of the opening */
  center: Pt;
  /** angle of the host wall (radians) */
  angle: number;
  /** effective width after clamping to the wall length (plan units) */
  width: number;
  /** t after clamping so the opening fits inside the wall */
  t: number;
};

/** Resolves an opening onto its wall with clamping — an opening can never
 *  extend past the wall it belongs to (3D depends on this). */
export function placeOpening(
  opening: PlanOpening,
  segment: WallSegment
): OpeningPlacement {
  const maxT = Math.min(0.999, Math.max(0.001, opening.width / 2 / Math.max(segment.length, 1e-9)));
  const t = Math.max(maxT, Math.min(1 - maxT, opening.t));
  const width = Math.min(opening.width, segment.length * 0.98);
  return {
    opening,
    center: {
      x: segment.a.x + (segment.b.x - segment.a.x) * t,
      y: segment.a.y + (segment.b.y - segment.a.y) * t,
    },
    angle: segment.angle,
    width,
    t,
  };
}

export type WallPiece = {
  /** kind of piece: solid wall, or a gap cut by an opening */
  kind: "wall" | "door-gap" | "window-gap";
  /** world-space start of the piece along the wall axis */
  start: Pt;
  end: Pt;
};

/**
 * Splits a wall into solid pieces and opening gaps along its axis — the
 * exact geometry the 2D editor renders AND the 3D viewer extrudes. Both
 * views are built from this one function, which is what guarantees they
 * never disagree.
 */
export function wallPieces(segment: WallSegment, openings: PlanOpening[]): WallPiece[] {
  const usable = openings
    .map((o) => placeOpening(o, segment))
    .filter((p) => p.opening.width > 0)
    .sort((p, q) => p.t - q.t);

  const pieces: WallPiece[] = [];
  let cursor = 0; // distance along wall from a
  const dir = { x: Math.cos(segment.angle), y: Math.sin(segment.angle) };
  const at = (d: number): Pt => ({
    x: segment.a.x + dir.x * d,
    y: segment.a.y + dir.y * d,
  });

  for (const p of usable) {
    const gapStart = Math.max(0, p.t * segment.length - p.width / 2);
    const gapEnd = Math.min(segment.length, p.t * segment.length + p.width / 2);
    if (gapStart > cursor + 1e-9) {
      pieces.push({ kind: "wall", start: at(cursor), end: at(gapStart) });
    }
    pieces.push({
      kind: p.opening.kind === "door" ? "door-gap" : "window-gap",
      start: at(Math.max(cursor, gapStart)),
      end: at(Math.min(segment.length, gapEnd)),
    });
    cursor = Math.max(cursor, gapEnd);
  }
  if (cursor < segment.length - 1e-9) {
    pieces.push({ kind: "wall", start: at(cursor), end: at(segment.length) });
  }
  return pieces;
}

/** Solid pieces only (for 3D wall boxes), plus the openings' placements. */
export function solidWallPieces(segment: WallSegment, openings: PlanOpening[]) {
  return wallPieces(segment, openings).filter((p) => p.kind === "wall");
}

/** Bounds of all geometry on a floor (for fit-to-view). */
export function floorBounds(floor: PlanFloor): { minX: number; minY: number; maxX: number; maxY: number } | null {
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  const consider = (x: number, y: number) => {
    minX = Math.min(minX, x);
    minY = Math.min(minY, y);
    maxX = Math.max(maxX, x);
    maxY = Math.max(maxY, y);
  };
  for (const v of floor.vertices) consider(v.x, v.y);
  if (floor.background) {
    consider(floor.background.x, floor.background.y);
    consider(floor.background.x + floor.background.w, floor.background.y + floor.background.h);
  }
  if (minX === Infinity) return null;
  return { minX, minY, maxX, maxY };
}
