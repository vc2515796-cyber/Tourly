/**
 * Stage B2 — pure floor-plan document operations.
 *
 * All structural mutations (create/delete rooms, walls, openings; rescale
 * for calibration) live here as pure functions on the document, so the
 * canvas component stays thin and the operations are unit-testable.
 */

import type {
  FloorPlanDocument,
  PlanFloor,
  PlanOpening,
  PlanOpeningKind,
  PlanRoom,
  PlanVertex,
  PlanWall,
} from "./model";
import { polygonCentroid, type Pt } from "./geometry";

export function floorOf(plan: FloorPlanDocument): PlanFloor {
  return plan.floors.find((f) => f.id === plan.activeFloorId) ?? plan.floors[0]!;
}

function updateFloor(plan: FloorPlanDocument, floorId: string, fn: (floor: PlanFloor) => PlanFloor): FloorPlanDocument {
  return {
    ...plan,
    floors: plan.floors.map((f) => (f.id === floorId ? { ...fn(f), updatedAt: Date.now() } : f)),
    updatedAt: Date.now(),
  };
}

// --- vertices -------------------------------------------------------------------

export function addVertex(plan: FloorPlanDocument, p: Pt, snapTolerance = 0): { plan: FloorPlanDocument; vertexId: string } {
  const floor = floorOf(plan);
  // Snap to an existing vertex when one is close — shared corners are how
  // adjacent rooms connect.
  if (snapTolerance > 0) {
    const near = floor.vertices.find((v) => Math.hypot(v.x - p.x, v.y - p.y) <= snapTolerance);
    if (near) return { plan, vertexId: near.id };
  }
  const vertex: PlanVertex = { id: crypto.randomUUID(), x: round2(p.x), y: round2(p.y) };
  return {
    plan: updateFloor(plan, floor.id, (f) => ({ ...f, vertices: [...f.vertices, vertex] })),
    vertexId: vertex.id,
  };
}

export function moveVertex(plan: FloorPlanDocument, vertexId: string, to: Pt): FloorPlanDocument {
  const floor = floorOf(plan);
  return updateFloor(plan, floor.id, (f) => ({
    ...f,
    vertices: f.vertices.map((v) => (v.id === vertexId ? { ...v, x: round2(to.x), y: round2(to.y) } : v)),
  }));
}

/** Translates a set of vertices (a whole-room drag). Vertices shared with
 *  other rooms move too — adjacent rooms stay connected by design. */
export function translateVertices(plan: FloorPlanDocument, vertexIds: string[], dx: number, dy: number): FloorPlanDocument {
  const set = new Set(vertexIds);
  const floor = floorOf(plan);
  return updateFloor(plan, floor.id, (f) => ({
    ...f,
    vertices: f.vertices.map((v) => (set.has(v.id) ? { ...v, x: round2(v.x + dx), y: round2(v.y + dy) } : v)),
  }));
}

// --- walls ------------------------------------------------------------------------

/** Finds an existing wall between two vertices (either direction). */
export function wallBetween(floor: PlanFloor, a: string, b: string): PlanWall | undefined {
  return floor.walls.find((w) => (w.a === a && w.b === b) || (w.a === b && w.b === a));
}

export function addWall(plan: FloorPlanDocument, aId: string, bId: string, thickness: number): { plan: FloorPlanDocument; wall: PlanWall | null } {
  const floor = floorOf(plan);
  if (aId === bId) return { plan, wall: null };
  const existing = wallBetween(floor, aId, bId);
  if (existing) return { plan, wall: existing };
  const wall: PlanWall = { id: crypto.randomUUID(), a: aId, b: bId, thickness };
  const next = updateFloor(plan, floor.id, (f) => ({ ...f, walls: [...f.walls, wall] }));
  return { plan: next, wall };
}

// --- rooms --------------------------------------------------------------------------

export type CreateRoomInput = {
  name?: string;
  /** ordered vertex ids forming the ring */
  polygon: string[];
};

/** Creates a room from a ring of EXISTING vertex ids, plus a wall for every
 *  edge that doesn't already have one (shared edges between adjacent rooms
 *  reuse the same wall — no duplicates). */
export function createRoom(plan: FloorPlanDocument, input: CreateRoomInput): { plan: FloorPlanDocument; room: PlanRoom | null } {
  const floor = floorOf(plan);
  const polygon = input.polygon;
  if (polygon.length < 3) return { plan, room: null };

  let next = plan;
  for (let i = 0; i < polygon.length; i++) {
    const a = polygon[i]!;
    const b = polygon[(i + 1) % polygon.length]!;
    next = addWall(next, a, b, next.defaultWallThickness).plan;
  }
  const room: PlanRoom = {
    id: crypto.randomUUID(),
    name: input.name?.trim() || `Room ${floorOf(next).rooms.length + 1}`,
    polygon: [...polygon],
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  const floorNow = floorOf(next);
  next = updateFloor(next, floorNow.id, (f) => ({ ...f, rooms: [...f.rooms, room] }));
  return { plan: next, room };
}

export function updateRoom(plan: FloorPlanDocument, roomId: string, patch: Partial<Pick<PlanRoom, "name" | "sceneStopId" | "manualArea" | "manualDimensions">>): FloorPlanDocument {
  const floor = floorOf(plan);
  return updateFloor(plan, floor.id, (f) => ({
    ...f,
    rooms: f.rooms.map((r) => (r.id === roomId ? { ...r, ...patch, updatedAt: Date.now() } : r)),
  }));
}

/** Deletes a room. Walls that no other room uses are removed together with
 *  their openings; vertices nothing references anymore are cleaned up. */
export function deleteRoom(plan: FloorPlanDocument, roomId: string): FloorPlanDocument {
  const floor = floorOf(plan);
  const room = floor.rooms.find((r) => r.id === roomId);
  if (!room) return plan;

  const otherRooms = floor.rooms.filter((r) => r.id !== roomId);
  const usedByOthers = new Set(otherRooms.flatMap((r) => r.polygon));
  const wallsToRemove = new Set<string>();
  for (let i = 0; i < room.polygon.length; i++) {
    const a = room.polygon[i]!;
    const b = room.polygon[(i + 1) % room.polygon.length]!;
    const w = wallBetween(floor, a, b);
    if (!w) continue;
    const edgeUsedByOther = otherRooms.some((r) => {
      for (let j = 0; j < r.polygon.length; j++) {
        const c = r.polygon[j]!;
        const d = r.polygon[(j + 1) % r.polygon.length]!;
        if ((c === a && d === b) || (c === b && d === a)) return true;
      }
      return false;
    });
    if (!edgeUsedByOther) wallsToRemove.add(w.id);
  }
  const verticesToCheck = new Set(room.polygon.filter((v) => !usedByOthers.has(v)));
  const orphanedVertices = new Set(
    [...verticesToCheck].filter(
      (vid) => !floor.walls.some((w) => !wallsToRemove.has(w.id) && (w.a === vid || w.b === vid))
    )
  );

  return updateFloor(plan, floor.id, (f) => ({
    ...f,
    rooms: f.rooms.filter((r) => r.id !== roomId),
    walls: f.walls.filter((w) => !wallsToRemove.has(w.id)),
    openings: f.openings.filter((o) => !wallsToRemove.has(o.wallId)),
    vertices: f.vertices.filter((v) => !orphanedVertices.has(v.id)),
  }));
}

/** Deletes a standalone wall (not part of any room ring) + its openings. */
export function deleteWall(plan: FloorPlanDocument, wallId: string): FloorPlanDocument {
  const floor = floorOf(plan);
  const usedByRoom = floor.rooms.some((r) => {
    for (let i = 0; i < r.polygon.length; i++) {
      const a = r.polygon[i]!;
      const b = r.polygon[(i + 1) % r.polygon.length]!;
      const w = wallBetween(floor, a, b);
      if (w?.id === wallId) return true;
    }
    return false;
  });
  if (usedByRoom) return plan; // walls of room rings are deleted with the room
  const wall = floor.walls.find((w) => w.id === wallId);
  if (!wall) return plan;
  return updateFloor(plan, floor.id, (f) => ({
    ...f,
    walls: f.walls.filter((w) => w.id !== wallId),
    openings: f.openings.filter((o) => o.wallId !== wallId),
    vertices: f.vertices.filter((v) => v.id !== wall.a && v.id !== wall.b),
  }));
}

// --- openings ---------------------------------------------------------------------

export function addOpening(plan: FloorPlanDocument, wallId: string, kind: PlanOpeningKind, t: number): FloorPlanDocument {
  const floor = floorOf(plan);
  const wall = floor.walls.find((w) => w.id === wallId);
  if (!wall) return plan;
  const opening: PlanOpening = {
    id: crypto.randomUUID(),
    wallId,
    kind,
    t: Math.max(0, Math.min(1, t)),
    width: kind === "door" ? 0.9 : 1.2,
    height: kind === "door" ? 2.1 : 1.2,
    sillHeight: kind === "door" ? 0 : 0.9,
  };
  return updateFloor(plan, floor.id, (f) => ({ ...f, openings: [...f.openings, opening] }));
}

export function updateOpening(plan: FloorPlanDocument, openingId: string, patch: Partial<Pick<PlanOpening, "t" | "width" | "height" | "sillHeight">>): FloorPlanDocument {
  const floor = floorOf(plan);
  return updateFloor(plan, floor.id, (f) => ({
    ...f,
    openings: f.openings.map((o) => (o.id === openingId ? { ...o, ...patch } : o)),
  }));
}

export function deleteOpening(plan: FloorPlanDocument, openingId: string): FloorPlanDocument {
  const floor = floorOf(plan);
  return updateFloor(plan, floor.id, (f) => ({ ...f, openings: f.openings.filter((o) => o.id !== openingId) }));
}

/** Removes vertices referenced by no wall and no room ring — leftover
 *  draft corners from a cancelled drawing. Safe to run any time. */
export function cleanupOrphanVertices(plan: FloorPlanDocument): FloorPlanDocument {
  const floor = floorOf(plan);
  const used = new Set<string>();
  for (const w of floor.walls) {
    used.add(w.a);
    used.add(w.b);
  }
  for (const r of floor.rooms) {
    for (const v of r.polygon) used.add(v);
  }
  if (floor.vertices.every((v) => used.has(v.id))) return plan;
  return updateFloor(plan, floor.id, (f) => ({ ...f, vertices: f.vertices.filter((v) => used.has(v.id)) }));
}

// --- scale calibration ----------------------------------------------------------------

/**
 * Rescales the ENTIRE plan (all floors: vertices + background placements)
 * by `factor` and marks the scale calibrated with its provenance. Called
 * after the user points at a known segment and enters its real length:
 * factor = realLength / drawnLength.
 *
 * Everything scales together, so already-drawn geometry stays aligned with
 * the blueprint underlay — and computed measurements become real.
 */
export function applyCalibration(
  plan: FloorPlanDocument,
  factor: number,
  referenceLength: number,
  drawnLength: number
): FloorPlanDocument {
  if (!Number.isFinite(factor) || factor <= 0) return plan;
  const scaled: FloorPlanDocument = {
    ...plan,
    scale: {
      ...plan.scale,
      calibrated: true,
      referenceLength,
      drawnLength,
      calibratedAt: Date.now(),
    },
    floors: plan.floors.map((f) => ({
      ...f,
      vertices: f.vertices.map((v) => ({ ...v, x: round2(v.x * factor), y: round2(v.y * factor) })),
      background: f.background
        ? { ...f.background, x: round2(f.background.x * factor), y: round2(f.background.y * factor), w: round2(f.background.w * factor), h: round2(f.background.h * factor) }
        : undefined,
      updatedAt: Date.now(),
    })),
    updatedAt: Date.now(),
  };
  return scaled;
}

/** Centroid of a room ring (label anchor). */
export function roomCentroid(floor: PlanFloor, room: PlanRoom): Pt {
  const resolve = (id: string) => {
    const v = floor.vertices.find((x) => x.id === id);
    return v ? { x: v.x, y: v.y } : { x: 0, y: 0 };
  };
  return polygonCentroid(room.polygon.map(resolve));
}

function round2(n: number): number {
  return Math.round(n * 1000) / 1000; // mm precision is plenty for floor plans
}

// --- Stage D: furniture operations (AI concept floor plan) ---------------------

import type { PlanFurniture, PlanFurnitureKind } from "./model";
import { FURNITURE_DEFAULT_SIZES } from "./model";

function withFurniture(
  plan: FloorPlanDocument,
  floorId: string,
  fn: (items: PlanFurniture[]) => PlanFurniture[]
): FloorPlanDocument {
  return updateFloor(plan, floorId, (floor) => ({ ...floor, furniture: fn(floor.furniture ?? []) }));
}

export function addFurniture(
  plan: FloorPlanDocument,
  floorId: string,
  kind: PlanFurnitureKind,
  at: Pt
): { plan: FloorPlanDocument; item: PlanFurniture } {
  const size = FURNITURE_DEFAULT_SIZES[kind];
  const item: PlanFurniture = {
    id: crypto.randomUUID(),
    kind,
    x: round2(at.x),
    y: round2(at.y),
    w: size.w,
    h: size.h,
    rotation: 0,
    // Items the USER places are verified by definition — no uncertainty flag.
  };
  return { plan: withFurniture(plan, floorId, (items) => [...items, item]), item };
}

export function updateFurniture(
  plan: FloorPlanDocument,
  floorId: string,
  itemId: string,
  patch: Partial<Pick<PlanFurniture, "kind" | "label" | "x" | "y" | "w" | "h" | "rotation" | "uncertain">>
): FloorPlanDocument {
  return withFurniture(plan, floorId, (items) =>
    items.map((f) => (f.id === itemId ? { ...f, ...patch } : f))
  );
}

export function moveFurniture(
  plan: FloorPlanDocument,
  floorId: string,
  itemId: string,
  to: Pt
): FloorPlanDocument {
  return withFurniture(plan, floorId, (items) =>
    items.map((f) => (f.id === itemId ? { ...f, x: round2(to.x), y: round2(to.y) } : f))
  );
}

export function deleteFurniture(plan: FloorPlanDocument, floorId: string, itemId: string): FloorPlanDocument {
  return withFurniture(plan, floorId, (items) => items.filter((f) => f.id !== itemId));
}
