/**
 * Stage B2 — typed, versioned floor-plan document.
 *
 * This is the SINGLE source of truth consumed by BOTH the 2D editor and the
 * 3D dollhouse viewer: the 3D model is generated from this geometry and
 * nothing else, so "the same saved geometry appears in 2D and 3D" holds by
 * construction.
 *
 * Design notes:
 * - Coordinates are WORLD units ("plan units" = metres or feet per
 *   `scale.units`), not pixels. Pixel-only plans can't carry honest
 *   measurements; world units can, once the user calibrates the scale.
 * - Every object has a stable id (crypto.randomUUID) so edits, undo/redo,
 *   and scene links survive reordering.
 * - schemaVersion gates migrations: loading an unknown NEWER version never
 *   destroys data (the loader keeps it read-only-safe and flags it).
 * - Ownership travels with the tour the plan belongs to (tourId); there is
 *   no separate property entity in this app — the tour IS the property
 *   record (see SCHEMA.md).
 */

export type PlanUnits = "m" | "ft";

export type PlanVertex = {
  id: string;
  x: number;
  y: number;
};

export type PlanWall = {
  id: string;
  /** endpoint vertex ids */
  a: string;
  b: string;
  /** thickness in plan units */
  thickness: number;
};

export type PlanOpeningKind = "door" | "window";

export type PlanOpening = {
  id: string;
  wallId: string;
  kind: PlanOpeningKind;
  /** center position along the wall, 0..1 */
  t: number;
  /** opening width in plan units */
  width: number;
  /** opening height in metres (used by the 3D viewer) */
  height: number;
  /** floor-to-opening-bottom height in metres (window sill; 0 for doors) */
  sillHeight: number;
  /** Concept-origin flag (AI-placed, not yet user-verified) — rendered
   *  dashed in the editor. User-placed openings never set this. */
  uncertain?: boolean;
};

export type PlanRoom = {
  id: string;
  name: string;
  /** ordered ring of vertex ids; implicitly closed (last → first) */
  polygon: string[];
  /** optional link to a tour scene (stop id) */
  sceneStopId?: string;
  /** manually entered area (user-typed) — always shown as "manual", never mixed with computed values */
  manualArea?: number;
  /** manually entered dimension note, e.g. "4.2 × 3.1 m" */
  manualDimensions?: string;
  createdAt: number;
  updatedAt: number;
};

export type PlanFloorBackground = {
  dataUrl: string;
  /** natural pixel size of the image */
  width: number;
  height: number;
  /** 0..1 display opacity of the underlay layer */
  opacity: number;
  /** placement in world units: top-left corner + size */
  x: number;
  y: number;
  w: number;
  h: number;
};

export type PlanFloor = {
  id: string;
  name: string;
  /** elevation above ground in metres (ground floor = 0) */
  elevation: number;
  vertices: PlanVertex[];
  walls: PlanWall[];
  openings: PlanOpening[];
  rooms: PlanRoom[];
  /** optional blueprint underlay on its own adjustable layer */
  background?: PlanFloorBackground;
  /** Stage D (AI concept floor plan): furniture items, optional so every
   *  pre-existing plan document stays valid. Positions are CENTER points in
   *  plan units; sizes are APPROXIMATE — on concept plans they are nominal
   *  defaults, never measured dimensions. */
  furniture?: PlanFurniture[];
  createdAt: number;
  updatedAt: number;
};

export type PlanFurnitureKind =
  | "bed" | "sofa" | "table" | "chair" | "tv" | "wardrobe"
  | "counter" | "fridge" | "stove" | "toilet" | "sink" | "bathtub"
  | "plant" | "rug" | "stairs" | "other";

export const PLAN_FURNITURE_KINDS: PlanFurnitureKind[] = [
  "bed", "sofa", "table", "chair", "tv", "wardrobe",
  "counter", "fridge", "stove", "toilet", "sink", "bathtub",
  "plant", "rug", "stairs", "other",
];

export type PlanFurniture = {
  id: string;
  kind: PlanFurnitureKind;
  /** optional custom label (defaults to a readable name for the kind) */
  label?: string;
  /** center position in plan units */
  x: number;
  y: number;
  /** approximate size in plan units (nominal for concept items) */
  w: number;
  h: number;
  /** degrees, clockwise */
  rotation: number;
  /** Concept-origin flag: placed by the AI (not yet user-verified). The
   *  editor renders uncertain items with a dashed outline so the agent
   *  reviews them first. User-created items never set this. */
  uncertain?: boolean;
};

export const FURNITURE_DEFAULT_SIZES: Record<PlanFurnitureKind, { w: number; h: number }> = {
  bed: { w: 1.6, h: 2.0 },
  sofa: { w: 2.0, h: 0.9 },
  table: { w: 1.2, h: 0.8 },
  chair: { w: 0.5, h: 0.5 },
  tv: { w: 1.2, h: 0.15 },
  wardrobe: { w: 1.8, h: 0.6 },
  counter: { w: 2.0, h: 0.6 },
  fridge: { w: 0.7, h: 0.7 },
  stove: { w: 0.6, h: 0.6 },
  toilet: { w: 0.45, h: 0.7 },
  sink: { w: 0.6, h: 0.5 },
  bathtub: { w: 1.7, h: 0.75 },
  plant: { w: 0.5, h: 0.5 },
  rug: { w: 2.0, h: 1.5 },
  stairs: { w: 1.0, h: 2.5 },
  other: { w: 0.8, h: 0.8 },
};

export function furnitureLabel(kind: PlanFurnitureKind): string {
  const names: Record<PlanFurnitureKind, string> = {
    bed: "Bed", sofa: "Sofa", table: "Table", chair: "Chair", tv: "TV",
    wardrobe: "Wardrobe", counter: "Counter", fridge: "Fridge", stove: "Stove",
    toilet: "Toilet", sink: "Sink", bathtub: "Bathtub", plant: "Plant",
    rug: "Rug", stairs: "Stairs", other: "Object",
  };
  return names[kind];
}

export type PlanScale = {
  units: PlanUnits;
  /**
   * What calibration actually records is the KNOWN REFERENCE the user
   * measured, which proves the drawing is to scale. `calibrated` is false
   * until the user completes calibration — before that, computed
   * areas/lengths are hidden rather than shown as fake numbers.
   */
  calibrated: boolean;
  /** the real-world length the user entered (in units) */
  referenceLength?: number;
  /** the drawn length it corresponded to (world units) */
  drawnLength?: number;
  calibratedAt?: number;
};

export const PLAN_SCHEMA_VERSION = 1;

/** Stage D (AI concept floor plan): provenance metadata for a plan whose
 *  geometry originated from an AI analysis of one panorama. The presence of
 *  `concept` is what drives the "CONCEPTUAL FLOOR PLAN — NOT TO SCALE"
 *  watermark and the reset-to-generated affordance. Optional — hand-drawn
 *  plans never set it. schemaVersion stays 1: these fields are additive and
 *  every pre-existing plan document remains valid. */
export type PlanConceptMeta = {
  generatedBy: "ai-concept-v1";
  /** the panorama stop the analysis came from */
  sourceStopId: string;
  sourceStopTitle?: string;
  generatedAt: number;
  /** model that produced the analysis (provenance only) */
  model?: string;
  /** what the AI flagged as uncertain, shown to the agent for review */
  uncertaintyNotes: string[];
  /** the pristine converted document, enabling "reset to generated layout".
   *  Kept inside the tour record — the snapshot is small plan JSON. */
  generatedSnapshot?: FloorPlanDocument;
};

export type FloorPlanDocument = {
  schemaVersion: typeof PLAN_SCHEMA_VERSION;
  id: string;
  /** the tour (property record) this plan belongs to */
  tourId: string;
  scale: PlanScale;
  /** assumed wall height for the 3D viewer — always labelled as an assumption */
  defaultWallHeight: number;
  defaultWallThickness: number;
  floors: PlanFloor[];
  activeFloorId: string;
  /** AI-concept provenance (see PlanConceptMeta) — optional. */
  concept?: PlanConceptMeta;
  createdAt: number;
  updatedAt: number;
};

// --- factories ---------------------------------------------------------------

export function createFloor(name: string, elevation = 0): PlanFloor {
  const now = Date.now();
  return {
    id: crypto.randomUUID(),
    name,
    elevation,
    vertices: [],
    walls: [],
    openings: [],
    rooms: [],
    createdAt: now,
    updatedAt: now,
  };
}

export function createPlan(tourId: string, units: PlanUnits = "m"): FloorPlanDocument {
  const ground = createFloor("Ground floor", 0);
  const now = Date.now();
  return {
    schemaVersion: PLAN_SCHEMA_VERSION,
    id: crypto.randomUUID(),
    tourId,
    scale: { units, calibrated: false },
    defaultWallHeight: 2.7,
    defaultWallThickness: 0.12,
    floors: [ground],
    activeFloorId: ground.id,
    createdAt: now,
    updatedAt: now,
  };
}

// --- loading + safe migration -------------------------------------------------

export type PlanLoadResult =
  | { ok: true; plan: FloorPlanDocument; warnings: string[] }
  | { ok: false; error: string };

/**
 * Validates a persisted plan before the editor touches it. Unknown schema
 * versions and structurally-broken documents are rejected (the editor then
 * offers to start fresh while KEEPING the old blob inside the tour record —
 * nothing is silently overwritten). Recoverable oddities become warnings.
 */
export function loadPlan(raw: unknown, tourId: string): PlanLoadResult {
  if (!raw || typeof raw !== "object") {
    return { ok: false, error: "Floor plan data is not an object." };
  }
  const doc = raw as Partial<FloorPlanDocument>;
  if (doc.schemaVersion !== PLAN_SCHEMA_VERSION) {
    return {
      ok: false,
      error: `Floor plan schema version ${String(doc.schemaVersion)} isn't supported by this app version (expected ${PLAN_SCHEMA_VERSION}). The saved data is preserved untouched.`,
    };
  }
  if (!Array.isArray(doc.floors) || doc.floors.length === 0) {
    return { ok: false, error: "Floor plan has no floors." };
  }
  const warnings: string[] = [];
  for (const floor of doc.floors) {
    if (!floor || !Array.isArray(floor.vertices) || !Array.isArray(floor.walls) || !Array.isArray(floor.rooms)) {
      return { ok: false, error: `Floor "${floor?.name ?? "?"}" is structurally incomplete.` };
    }
    // Dangling references are dropped with a warning rather than crashing
    // the editor — recovery over strictness for user data.
    const vertexIds = new Set(floor.vertices.map((v) => v.id));
    const wallBefore = floor.walls.length;
    floor.walls = floor.walls.filter((w) => vertexIds.has(w.a) && vertexIds.has(w.b));
    if (floor.walls.length < wallBefore) {
      warnings.push(`Removed ${wallBefore - floor.walls.length} wall(s) with missing endpoints on "${floor.name}".`);
    }
    const wallIds = new Set(floor.walls.map((w) => w.id));
    const openings = Array.isArray(floor.openings) ? floor.openings : [];
    const openingBefore = openings.length;
    floor.openings = openings.filter((o) => wallIds.has(o.wallId));
    if (floor.openings.length < openingBefore) {
      warnings.push(`Removed ${openingBefore - floor.openings.length} opening(s) from missing walls on "${floor.name}".`);
    }
    const roomBefore = floor.rooms.length;
    floor.rooms = floor.rooms.filter(
      (r) => Array.isArray(r.polygon) && r.polygon.length >= 3 && r.polygon.every((id) => vertexIds.has(id))
    );
    if (floor.rooms.length < roomBefore) {
      warnings.push(`Removed ${roomBefore - floor.rooms.length} invalid room(s) on "${floor.name}".`);
    }
    // Stage D: furniture items are self-contained (no vertex references), so
    // only structural sanity is needed — broken items are dropped, not fatal.
    if (Array.isArray(floor.furniture) && floor.furniture.length) {
      const before = floor.furniture.length;
      floor.furniture = floor.furniture.filter(
        (f) =>
          f &&
          typeof f.id === "string" &&
          typeof f.x === "number" &&
          Number.isFinite(f.x) &&
          typeof f.y === "number" &&
          Number.isFinite(f.y) &&
          PLAN_FURNITURE_KINDS.includes(f.kind)
      );
      if (floor.furniture.length < before) {
        warnings.push(`Removed ${before - floor.furniture.length} invalid furniture item(s) on "${floor.name}".`);
      }
    }
  }
  if (doc.tourId !== tourId) {
    warnings.push("Plan tourId doesn't match this tour — check for copied data.");
  }
  if (!doc.floors.some((f) => f.id === doc.activeFloorId)) {
    doc.activeFloorId = doc.floors[0]!.id;
  }
  return { ok: true, plan: doc as FloorPlanDocument, warnings };
}

/** Stamps a mutation with a fresh updatedAt. */
export function touchPlan(plan: FloorPlanDocument): FloorPlanDocument {
  return { ...plan, updatedAt: Date.now() };
}

// --- units ---------------------------------------------------------------------

export function formatLength(units: PlanUnits, value: number): string {
  return units === "ft" ? `${(value * 3.28084).toFixed(1)} ft` : `${value.toFixed(2)} m`;
}

export function formatArea(units: PlanUnits, value: number): string {
  return units === "ft"
    ? `${(value * 10.7639).toFixed(0)} sq ft`
    : `${value.toFixed(1)} m²`;
}
