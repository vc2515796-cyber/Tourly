/**
 * Silently improves a panorama photo's lighting/sharpness before it's
 * stored — invisible to the user. On any failure, mismatch, or if the
 * Netlify Function isn't reachable (e.g. plain `npm run dev` without
 * `netlify dev`), this resolves with the ORIGINAL image unchanged.
 * Callers never need to handle an error case.
 */

const MAX_SEND_DIMENSION = 2048;
const ASPECT_RATIO_TOLERANCE = 0.08;

function loadImage(dataUrl: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = dataUrl;
  });
}

async function downscale(dataUrl: string, maxDimension: number): Promise<{ dataUrl: string; width: number; height: number }> {
  const img = await loadImage(dataUrl);
  const scale = Math.min(1, maxDimension / Math.max(img.width, img.height));
  const width = Math.round(img.width * scale);
  const height = Math.round(img.height * scale);

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas context unavailable");
  ctx.drawImage(img, 0, 0, width, height);

  return { dataUrl: canvas.toDataURL("image/jpeg", 0.92), width, height };
}

function dataUrlToBase64(dataUrl: string): { base64: string; mimeType: string } {
  const [header, base64] = dataUrl.split(",");
  const mimeType = header.match(/data:(.*);base64/)?.[1] ?? "image/jpeg";
  return { base64, mimeType };
}

export async function enhancePanorama(
  originalDataUrl: string,
  kind: "sphere" | "cylinder"
): Promise<string> {
  try {
    const original = await loadImage(originalDataUrl);
    const originalAspect = original.width / original.height;

    const { dataUrl: sendDataUrl } = await downscale(originalDataUrl, MAX_SEND_DIMENSION);
    const { base64, mimeType } = dataUrlToBase64(sendDataUrl);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 28_000);

    const response = await fetch("/api/enhance-panorama", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      body: JSON.stringify({
        imageBase64: base64,
        mimeType,
        kind: kind === "sphere" ? "sphere" : "cylinder",
      }),
    }).finally(() => clearTimeout(timeoutId));

    if (!response.ok) return originalDataUrl;

    const result = await response.json();
    if (!result?.imageBase64) return originalDataUrl;

    const enhancedDataUrl = `data:${result.mimeType ?? mimeType};base64,${result.imageBase64}`;
    const enhancedImg = await loadImage(enhancedDataUrl).catch(() => null);
    if (!enhancedImg) return originalDataUrl;

    const enhancedAspect = enhancedImg.width / enhancedImg.height;
    const aspectDrift = Math.abs(enhancedAspect - originalAspect) / originalAspect;
    if (aspectDrift > ASPECT_RATIO_TOLERANCE) {
      return originalDataUrl;
    }

    return enhancedDataUrl;
  } catch {
    return originalDataUrl;
  }
}
