import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css";
import { seedDemoToursIfEmpty } from "./lib/demo";
import { initAnalytics } from "./lib/analytics";

// The static, crawlable content in index.html (#seo-fallback) exists only
// for fetchers that don't run JavaScript. The moment this script runs, hide
// it — a real browser with JS always gets the live React app, never the
// duplicate static copy.
document.getElementById("seo-fallback")?.setAttribute("style", "display:none");

// Seed before any component mounts, so every page (including Landing's
// first read of localStorage) sees the demo tours immediately — doing
// this inside a React effect would race with child-component effects
// that read the same storage on their own mount.
try {
  seedDemoToursIfEmpty();
} catch {
  // Storage blocked or full — the app still works without demo tours.
}

// Belt-and-braces HTTPS: Netlify already redirects http → https, and HSTS is
// set in netlify.toml; this only matters if the app is ever served elsewhere.
const isLocalHost = /^(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(location.hostname);
if (location.protocol === "http:" && !isLocalHost) {
  location.replace(location.href.replace(/^http:/, "https:"));
}

// Loads Google Analytics only if it's configured AND the visitor already
// accepted it on a previous visit (see CookieConsent).
initAnalytics();

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
