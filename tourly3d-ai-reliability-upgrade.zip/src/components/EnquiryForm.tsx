import { useState } from "react";
import { Loader2, CheckCircle2, AlertTriangle, CalendarCheck, MessageCircle, ChevronDown, ChevronUp, ShieldCheck } from "lucide-react";
import type { Tour } from "../types";
import { captureLead } from "../lib/leads";

/**
 * Stage B5 — the public enquiry form on a tour page. Privacy-first:
 *  - every field except the message and one contact channel is optional
 *  - explicit consent is required before anything is stored
 *  - the honeypot field is invisible to humans
 *  - submission is validated server-side too (this UI is convenience, not
 *    the security boundary)
 */

export default function EnquiryForm({ tour, stopTitle }: { tour: Tour; stopTitle: string | null }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [consent, setConsent] = useState(false);
  const [visitRequested, setVisitRequested] = useState(false);
  const [company, setCompany] = useState(""); // honeypot
  const [state, setState] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (state === "sending") return;
    setError(null);

    if (message.trim().length < 5) {
      setError("Please write a short message.");
      return;
    }
    if (!consent) {
      setError("Please tick the consent box so the agent can reply.");
      return;
    }
    if (!phone.trim() && !email.trim()) {
      setError("Leave a phone number or an email so the agent can get back to you.");
      return;
    }

    setState("sending");
    const result = await captureLead(tour, stopTitle, { name, phone, email, message, consent, visitRequested });
    if (result.ok) {
      setState("sent");
    } else {
      setState("error");
      setError(result.error);
    }
  }

  if (state === "sent") {
    return (
      <div className="flex items-start gap-2.5 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
        <CheckCircle2 size={16} className="mt-0.5 shrink-0" />
        <div>
          <p className="font-medium">Enquiry sent — thank you.</p>
          <p className="mt-0.5 text-xs text-emerald-700">
            The agent will get back to you on the contact details you left. This page can be closed safely.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-lg border border-charcoal/10 bg-white/80">
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center justify-between gap-2 px-4 py-3 text-left"
        aria-expanded={open}
      >
        <span className="flex items-center gap-2 text-sm font-medium text-charcoal">
          <MessageCircle size={15} className="text-brass" />
          Enquire about this property
        </span>
        {open ? <ChevronUp size={15} className="text-charcoal/40" /> : <ChevronDown size={15} className="text-charcoal/40" />}
      </button>

      {open && (
        <form onSubmit={submit} className="border-t border-charcoal/10 px-4 py-3">
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
            <label className="block">
              <span className="text-[10px] font-medium uppercase tracking-wide text-charcoal/40">Your name (optional)</span>
              <input
                value={name}
                onChange={(e) => setName(e.target.value.slice(0, 80))}
                className="mt-1 w-full rounded-md border border-charcoal/15 bg-bone/40 px-2.5 py-2 text-sm outline-none focus:border-brass"
                autoComplete="name"
              />
            </label>
            <label className="block">
              <span className="text-[10px] font-medium uppercase tracking-wide text-charcoal/40">Phone (or email below)</span>
              <input
                value={phone}
                onChange={(e) => setPhone(e.target.value.slice(0, 20))}
                className="mt-1 w-full rounded-md border border-charcoal/15 bg-bone/40 px-2.5 py-2 text-sm outline-none focus:border-brass"
                inputMode="tel"
                autoComplete="tel"
              />
            </label>
            <label className="block sm:col-span-2">
              <span className="text-[10px] font-medium uppercase tracking-wide text-charcoal/40">Email (or phone above)</span>
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value.slice(0, 120))}
                className="mt-1 w-full rounded-md border border-charcoal/15 bg-bone/40 px-2.5 py-2 text-sm outline-none focus:border-brass"
                inputMode="email"
                autoComplete="email"
              />
            </label>
          </div>

          <label className="mt-2.5 block">
            <span className="text-[10px] font-medium uppercase tracking-wide text-charcoal/40">Message *</span>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value.slice(0, 2000))}
              rows={3}
              placeholder="e.g. Is this still available? Can I visit this weekend?"
              className="mt-1 w-full resize-y rounded-md border border-charcoal/15 bg-bone/40 px-2.5 py-2 text-sm outline-none focus:border-brass"
            />
          </label>

          {/* honeypot — hidden from humans, tempting for bots */}
          <input
            type="text"
            value={company}
            onChange={(e) => setCompany(e.target.value)}
            name="company"
            tabIndex={-1}
            autoComplete="off"
            aria-hidden="true"
            className="absolute -left-[9999px] h-0 w-0 opacity-0"
          />

          {/* Optional site-visit request — ticks into the lead AND the
              tour's analytics (visit-request), both server-side. */}
          <label className="mt-2.5 flex cursor-pointer items-center gap-2 rounded-md border border-charcoal/10 bg-bone/30 px-3 py-2 text-xs text-charcoal/70">
            <input
              type="checkbox"
              checked={visitRequested}
              onChange={(e) => setVisitRequested(e.target.checked)}
              className="h-3.5 w-3.5 shrink-0 accent-sage"
            />
            <span className="flex items-center gap-1.5">
              <CalendarCheck size={13} className="shrink-0 text-sage" />
              I'd like to request a site visit
            </span>
          </label>

          <label className="mt-2.5 flex cursor-pointer items-start gap-2 text-[11px] leading-relaxed text-charcoal/60">
            <input
              type="checkbox"
              checked={consent}
              onChange={(e) => setConsent(e.target.checked)}
              className="mt-0.5 h-3.5 w-3.5 shrink-0 accent-brass"
            />
            <span className="flex items-start gap-1">
              <ShieldCheck size={13} className="mt-0.5 shrink-0 text-sage" />
              I agree that my details and message go to this tour's agent so they can reply to me. That's the only use.
            </span>
          </label>

          {error && (
            <p className="mt-2 flex items-center gap-1.5 text-xs text-red-600">
              <AlertTriangle size={12} /> {error}
            </p>
          )}

          <button
            type="submit"
            disabled={state === "sending"}
            className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-md bg-sage px-3 py-2 text-sm font-semibold text-white disabled:opacity-50"
          >
            {state === "sending" ? <Loader2 size={14} className="animate-spin" /> : <MessageCircle size={14} />}
            {state === "sending" ? "Sending…" : "Send enquiry"}
          </button>
          <p className="mt-1.5 text-center text-[10px] text-charcoal/35">
            No account needed. Your details are only shared with this tour's agent.
          </p>
        </form>
      )}
    </div>
  );
}
