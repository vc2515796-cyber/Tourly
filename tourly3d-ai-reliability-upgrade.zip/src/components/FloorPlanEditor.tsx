import { useRef, useState } from "react";
import {
  X,
  Upload,
  Trash2,
  MapPin,
  Loader2,
  Compass,
  Crosshair,
  Info,
} from "lucide-react";
import { Tour, FloorPlan } from "../types";
import {
  buildFloorPlanFromFile,
  upsertMarker,
  removeMarker,
  eventToNormalized,
} from "../lib/floorPlan";

type Props = {
  tour: Tour;
  activeStopId: string | null;
  onSelectStop: (stopId: string) => void;
  onChange: (floorPlan: FloorPlan | undefined) => void;
  onClose: () => void;
};

/**
 * Floor-plan editor (Feature C). Manual marker placement on an uploaded
 * blueprint — there is deliberately NO automatic geometric mapping between
 * panorama pixels and blueprint coordinates (documented limitation); the
 * creator places each room marker by clicking, drags to fine-tune, and can
 * calibrate each marker's compass (which camera yaw = blueprint "up") so
 * the public viewer shows an honest radar cone.
 */
export default function FloorPlanEditor({ tour, activeStopId, onSelectStop, onChange, onClose }: Props) {
  const [placingStopId, setPlacingStopId] = useState<string | null>(null);
  const [dragging, setDragging] = useState<{ stopId: string } | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [calibrating, setCalibrating] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const imgWrapRef = useRef<HTMLDivElement>(null);

  const floorPlan = tour.floorPlan;

  async function handleFile(file: File) {
    setUploadError(null);
    setUploading(true);
    const { compressImage } = await import("../lib/imageCompress");
    const result = await buildFloorPlanFromFile(file, (dataUrl) =>
      compressImage(dataUrl, { maxDim: 3072, quality: 0.85 })
    );
    setUploading(false);
    if (!result.ok) {
      setUploadError(result.error);
      return;
    }
    // Keep existing markers when the blueprint is replaced — room positions
    // usually stay roughly right and can be nudged rather than redone.
    onChange({ ...result.floorPlan, markers: floorPlan?.markers ?? [] });
  }

  function placeAt(clientX: number, clientY: number) {
    if (!floorPlan) return;
    if (placingStopId && imgWrapRef.current) {
      const pos = eventToNormalized(imgWrapRef.current, clientX, clientY);
      onChange(upsertMarker(floorPlan, { stopId: placingStopId, x: pos.x, y: pos.y }));
      setPlacingStopId(null);
    }
  }

  function dragTo(clientX: number, clientY: number) {
    if (!floorPlan || !dragging || !imgWrapRef.current) return;
    const pos = eventToNormalized(imgWrapRef.current, clientX, clientY);
    const marker = floorPlan.markers.find((m) => m.stopId === dragging.stopId);
    if (marker) {
      onChange(upsertMarker(floorPlan, { ...marker, x: pos.x, y: pos.y }));
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/70 p-4 backdrop-blur-sm">
      <div className="flex h-full max-h-[90vh] w-full max-w-5xl flex-col overflow-hidden rounded-xl bg-bone shadow-2xl">
        <div className="flex shrink-0 items-center justify-between border-b border-charcoal/10 px-5 py-3">
          <div className="flex items-center gap-2">
            <MapPin className="text-brass" size={16} />
            <h2 className="font-display text-sm font-semibold">Floor plan & room navigation</h2>
          </div>
          <div className="flex items-center gap-2">
            {floorPlan && (
              <>
                <button
                  onClick={() => fileRef.current?.click()}
                  className="rounded-md border border-charcoal/15 px-2.5 py-1.5 text-xs font-medium text-charcoal/70 hover:border-charcoal/30"
                >
                  Replace plan
                </button>
                <button
                  onClick={() => {
                    if (window.confirm("Remove the floor plan and all its markers? Scenes are not affected.")) {
                      onChange(undefined);
                    }
                  }}
                  className="flex items-center gap-1 rounded-md border border-charcoal/15 px-2.5 py-1.5 text-xs font-medium text-red-500 hover:border-red-300"
                >
                  <Trash2 size={12} /> Remove
                </button>
              </>
            )}
            <button onClick={onClose} className="rounded p-1 text-charcoal/40 hover:text-charcoal" aria-label="Close">
              <X size={18} />
            </button>
          </div>
        </div>

        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) handleFile(file);
            e.target.value = "";
          }}
        />

        {uploadError && (
          <div className="border-b border-red-200 bg-red-50 px-5 py-2 text-xs text-red-600">{uploadError}</div>
        )}

        <div className="flex min-h-0 flex-1 flex-col overflow-y-auto lg:flex-row">
          {/* Blueprint canvas */}
          <div className="flex min-h-[300px] flex-1 items-center justify-center bg-charcoal/[0.04] p-4">
            {!floorPlan ? (
              <button
                onClick={() => fileRef.current?.click()}
                disabled={uploading}
                className="flex aspect-video w-full max-w-lg flex-col items-center justify-center gap-3 rounded-lg border-2 border-dashed border-charcoal/20 bg-white transition-colors hover:border-brass"
              >
                {uploading ? (
                  <Loader2 size={24} className="animate-spin text-charcoal/40" />
                ) : (
                  <>
                    <Upload size={24} className="text-charcoal/35" />
                    <span className="text-sm font-medium text-charcoal/60">Upload a floor plan</span>
                    <span className="max-w-xs text-center text-xs text-charcoal/40">
                      A photo, scan or export of the blueprint (JPG/PNG/WebP, up to 6 MB). Markers are placed manually —
                      nothing is auto-mapped.
                    </span>
                  </>
                )}
              </button>
            ) : (
              <div
                ref={imgWrapRef}
                onClick={(e) => placeAt(e.clientX, e.clientY)}
                onPointerMove={(e) => {
                  if (dragging && e.buttons === 1) dragTo(e.clientX, e.clientY);
                }}
                onPointerUp={() => setDragging(null)}
                className={`relative max-h-full w-full max-w-3xl select-none overflow-hidden rounded-lg border border-charcoal/15 bg-white ${
                  placingStopId ? "cursor-crosshair" : ""
                }`}
                style={{ aspectRatio: `${floorPlan.width} / ${floorPlan.height}` }}
              >
                <img
                  src={floorPlan.url && floorPlan.url.startsWith("https://") ? floorPlan.url : floorPlan.dataUrl}
                  alt="Floor plan"
                  className="pointer-events-none h-full w-full object-contain"
                  draggable={false}
                />
                {floorPlan.markers.map((m) => {
                  const stop = tour.stops.find((s) => s.id === m.stopId);
                  if (!stop) return null;
                  const isActive = m.stopId === activeStopId;
                  const isPlacing = placingStopId === m.stopId;
                  return (
                    <div
                      key={m.stopId}
                      style={{ left: `${m.x * 100}%`, top: `${m.y * 100}%` }}
                      className="group absolute -translate-x-1/2 -translate-y-1/2"
                    >
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectStop(m.stopId);
                        }}
                        onPointerDown={(e) => {
                          e.stopPropagation();
                          setDragging({ stopId: m.stopId });
                        }}
                        title={`${stop.title} — click to open, drag to move`}
                        className={`flex h-7 w-7 items-center justify-center rounded-full border-2 shadow-md transition-transform hover:scale-110 ${
                          isActive
                            ? "border-white bg-brass text-white"
                            : "border-white bg-charcoal/80 text-white"
                        }`}
                        style={{ animation: isActive || isPlacing ? "fp-pulse 2s ease-in-out infinite" : undefined }}
                      >
                        <MapPin size={13} />
                      </button>
                      <span className="pointer-events-none absolute left-1/2 top-full mt-1 -translate-x-1/2 whitespace-nowrap rounded bg-ink/85 px-1.5 py-0.5 text-[10px] font-medium text-bone">
                        {stop.title || "Untitled"}
                      </span>
                      {m.northYaw !== undefined && (
                        <span
                          className="pointer-events-none absolute right-full top-1/2 mr-1 -translate-y-1/2 text-brass"
                          title={`Compass calibrated (${Math.round(m.northYaw)}°)`}
                        >
                          <Compass size={11} />
                        </span>
                      )}
                    </div>
                  );
                })}
                {placingStopId && (
                  <div className="pointer-events-none absolute left-1/2 top-3 -translate-x-1/2 rounded-full bg-brass px-3 py-1 text-xs font-medium text-white shadow">
                    Click on the plan to place “{tour.stops.find((s) => s.id === placingStopId)?.title ?? "scene"}”
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Scene list / marker management */}
          <div className="shrink-0 border-t border-charcoal/10 bg-white/60 p-4 lg:w-72 lg:border-l lg:border-t-0">
            <p className="font-mono text-[11px] uppercase tracking-wider text-charcoal/40">Rooms</p>
            <p className="mt-1.5 text-[11px] leading-relaxed text-charcoal/45">
              Place a marker for each scene, then visitors can tap rooms on the plan to jump straight to them.
            </p>
            <ul className="mt-3 space-y-1.5">
              {tour.stops.map((stop, i) => {
                const marker = floorPlan?.markers.find((m) => m.stopId === stop.id);
                const isActive = stop.id === activeStopId;
                return (
                  <li
                    key={stop.id}
                    className={`rounded-md border px-2.5 py-2 ${
                      isActive ? "border-brass bg-brass/10" : "border-charcoal/10 bg-bone/60"
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <button
                        onClick={() => onSelectStop(stop.id)}
                        className="min-w-0 flex-1 truncate text-left text-xs font-medium"
                      >
                        {i + 1}. {stop.title || "Untitled"}
                      </button>
                      {marker ? (
                        <div className="flex shrink-0 items-center gap-1">
                          <button
                            onClick={() => setCalibrating(calibrating === stop.id ? null : stop.id)}
                            className={`rounded p-1 ${marker.northYaw !== undefined ? "text-brass" : "text-charcoal/30 hover:text-charcoal"}`}
                            title="Calibrate compass (radar direction)"
                          >
                            <Compass size={12} />
                          </button>
                          <button
                            onClick={() => floorPlan && onChange(removeMarker(floorPlan, stop.id))}
                            className="rounded p-1 text-charcoal/30 hover:text-red-500"
                            title="Remove marker"
                          >
                            <X size={12} />
                          </button>
                        </div>
                      ) : (
                        <span className="shrink-0 text-[10px] text-charcoal/30">no marker</span>
                      )}
                    </div>
                    {calibrating === stop.id && marker && (
                      <div className="mt-2 rounded border border-dashed border-brass/40 bg-brass/5 p-2">
                        <label className="flex items-center gap-1.5 text-[10px] text-charcoal/60">
                          <Compass size={10} /> Camera yaw that points “up” on this plan:
                        </label>
                        <div className="mt-1.5 flex items-center gap-2">
                          <input
                            type="range"
                            min={-180}
                            max={180}
                            step={5}
                            value={marker.northYaw ?? 0}
                            onChange={(e) => {
                              if (!floorPlan) return;
                              onChange(
                                upsertMarker(floorPlan, {
                                  ...marker,
                                  northYaw: Number(e.target.value),
                                })
                              );
                            }}
                            className="flex-1 accent-brass"
                          />
                          <span className="w-10 shrink-0 text-right font-mono text-[10px] text-charcoal/60">
                            {Math.round(marker.northYaw ?? 0)}°
                          </span>
                        </div>
                        <p className="mt-1 text-[9px] leading-relaxed text-charcoal/40">
                          Open the tour, look toward the plan's “up”, read the yaw shown in the viewer, and enter it
                          here. The radar cone then tracks the camera honestly.
                        </p>
                      </div>
                    )}
                    {!marker && (
                      <button
                        onClick={() => setPlacingStopId(stop.id)}
                        className={`mt-1.5 flex w-full items-center justify-center gap-1 rounded border px-2 py-1 text-[10px] font-medium ${
                          placingStopId === stop.id
                            ? "border-brass bg-brass text-white"
                            : "border-charcoal/20 text-charcoal/60 hover:border-charcoal/40"
                        }`}
                      >
                        <Crosshair size={10} />
                        {placingStopId === stop.id ? "Click the plan…" : "Place on plan"}
                      </button>
                    )}
                  </li>
                );
              })}
              {tour.stops.length === 0 && (
                <li className="py-3 text-center text-xs text-charcoal/40">Add scenes first.</li>
              )}
            </ul>
            <div className="mt-4 flex items-start gap-1.5 rounded-md bg-charcoal/5 p-2.5 text-[10px] leading-relaxed text-charcoal/50">
              <Info size={11} className="mt-0.5 shrink-0" />
              <span>
                Marker positions are saved relative to the plan (0–100%), so they stay aligned at any size. Placement
                is manual — Tourly doesn't infer room positions from photos.
              </span>
            </div>
          </div>
        </div>
      </div>
      <style>{`
        @keyframes fp-pulse {
          0%, 100% { box-shadow: 0 0 0 0 rgba(201,138,62,0.55); }
          50% { box-shadow: 0 0 0 7px rgba(201,138,62,0); }
        }
      `}</style>
    </div>
  );
}
