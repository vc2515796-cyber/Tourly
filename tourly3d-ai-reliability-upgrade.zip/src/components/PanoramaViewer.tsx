import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { Hotspot } from "../types";
import { ChevronUp, Smartphone, Circle, ArrowUpRight, Loader2, RotateCw, Compass } from "lucide-react";

const RADIUS = 490;
/** Panoramas are downscaled to this longest side before becoming a WebGL
 *  texture — safe for every phone GPU (max texture size is ≥ 4096 pretty
 *  much everywhere) while staying sharp on large screens. */
const MAX_TEXTURE_DIM = 4096;

function yawPitchToVector(yawDeg: number, pitchDeg: number, radius = RADIUS): THREE.Vector3 {
  const phi = THREE.MathUtils.degToRad(90 - pitchDeg);
  const theta = THREE.MathUtils.degToRad(yawDeg);
  return new THREE.Vector3(
    radius * Math.sin(phi) * Math.cos(theta),
    radius * Math.cos(phi),
    radius * Math.sin(phi) * Math.sin(theta)
  );
}

function vectorToYawPitch(v: THREE.Vector3): { yaw: number; pitch: number } {
  const radius = v.length();
  const phi = Math.acos(THREE.MathUtils.clamp(v.y / radius, -1, 1));
  const theta = Math.atan2(v.z, v.x);
  return {
    pitch: 90 - THREE.MathUtils.radToDeg(phi),
    yaw: THREE.MathUtils.radToDeg(theta),
  };
}

/** Loads an image (data URL or https) and downscales it on a canvas when it
 *  exceeds MAX_TEXTURE_DIM — a 12K panorama would otherwise either fail or
 *  stutter on mobile GPUs. */
function loadPanoramaTexture(src: string, maxDim: number): Promise<THREE.Texture> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    if (/^https?:/i.test(src)) img.crossOrigin = "anonymous";
    img.onload = () => {
      try {
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
        if (scale < 1) {
          const canvas = document.createElement("canvas");
          canvas.width = Math.max(1, Math.round(img.width * scale));
          canvas.height = Math.max(1, Math.round(img.height * scale));
          const ctx = canvas.getContext("2d");
          if (!ctx) {
            resolve(new THREE.Texture(img));
            return;
          }
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          const texture = new THREE.CanvasTexture(canvas);
          resolve(texture);
        } else {
          const texture = new THREE.Texture(img);
          texture.needsUpdate = true;
          resolve(texture);
        }
      } catch (err) {
        reject(err);
      }
    };
    img.onerror = () => reject(new Error("Couldn't load the panorama image"));
    img.src = src;
  });
}

type Props = {
  imageUrl: string;
  hotspots?: Hotspot[];
  onHotspotClick?: (hotspot: Hotspot) => void;
  placementMode?: boolean;
  onPlacePoint?: (yaw: number, pitch: number) => void;
  mode?: "sphere" | "cylinder";
  /** When true, existing hotspot pins can be dragged to a new position. */
  editable?: boolean;
  onRepositionHotspot?: (hotspotId: string, yaw: number, pitch: number) => void;
  /** Live camera orientation (degrees), throttled to changes > 0.4° — used
   *  by the floor-plan HUD to rotate the radar cone honestly. */
  onCameraMove?: (yaw: number, pitch: number) => void;
  /** Show a small yaw readout (editor calibration helper). */
  showYaw?: boolean;
};

export default function PanoramaViewer({
  imageUrl,
  hotspots = [],
  onHotspotClick,
  placementMode = false,
  onPlacePoint,
  mode = "sphere",
  editable = false,
  onRepositionHotspot,
  onCameraMove,
  showYaw = false,
}: Props) {
  const mountRef = useRef<HTMLDivElement>(null);
  const [screenPins, setScreenPins] = useState<{ hotspot: Hotspot; x: number; y: number; visible: boolean }[]>([]);
  const [motionEnabled, setMotionEnabled] = useState(false);
  const [motionAvailable, setMotionAvailable] = useState(true);
  const [draggingPin, setDraggingPin] = useState<{ id: string; x: number; y: number } | null>(null);
  const [loadState, setLoadState] = useState<"loading" | "ready" | "error">("loading");
  const [loadAttempt, setLoadAttempt] = useState(0);
  const [yawReadout, setYawReadout] = useState(0);
  const [xrAvailable, setXrAvailable] = useState(false);
  const [xrActive, setXrActive] = useState(false);
  const hotspotsRef = useRef(hotspots);
  hotspotsRef.current = hotspots;
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const sphereRef = useRef<THREE.Mesh | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const onCameraMoveRef = useRef(onCameraMove);
  onCameraMoveRef.current = onCameraMove;

  // Capability-DETECTED WebXR (Feature F): the VR button only appears when
  // the browser actually supports immersive-vr, and any failure quietly
  // hides it again — browsers without WebXR are completely unaffected.
  useEffect(() => {
    const xr = (navigator as any).xr;
    if (!xr?.isSessionSupported) return;
    let cancelled = false;
    xr
      .isSessionSupported("immersive-vr")
      .then((ok: boolean) => {
        if (!cancelled) setXrAvailable(Boolean(ok));
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, []);

  async function toggleXR() {
    const renderer = rendererRef.current;
    const xr = (navigator as any).xr;
    if (!renderer || !xr) return;
    try {
      if (xrActive) {
        const session = renderer.xr.getSession();
        await session?.end?.();
        return;
      }
      const session = await xr.requestSession("immersive-vr", { optionalFeatures: ["local-floor"] });
      renderer.xr.enabled = true;
      await renderer.xr.setSession(session);
      setXrActive(true);
      session.addEventListener("end", () => {
        renderer.xr.enabled = false;
        setXrActive(false);
      });
    } catch {
      setXrAvailable(false); // request refused — stop offering the button
    }
  }

  async function enableMotion() {
    const DOE = (window as any).DeviceOrientationEvent;
    if (DOE && typeof DOE.requestPermission === "function") {
      try {
        const result = await DOE.requestPermission();
        if (result === "granted") {
          setMotionEnabled(true);
        } else {
          setMotionAvailable(false);
        }
      } catch {
        setMotionAvailable(false);
      }
    } else {
      setMotionEnabled(true);
    }
  }

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    let width = mount.clientWidth;
    let height = mount.clientHeight;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(80, width / height, 1, 1100);
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    mount.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    const geometry =
      mode === "cylinder"
        ? new THREE.CylinderGeometry(500, 500, 340, 60, 1, true)
        : new THREE.SphereGeometry(500, 60, 40);
    geometry.scale(-1, 1, 1);
    const material = new THREE.MeshBasicMaterial({ map: null, side: THREE.FrontSide, color: 0x1a1a1a });
    const sphere = new THREE.Mesh(geometry, material);
    scene.add(sphere);
    cameraRef.current = camera;
    sphereRef.current = sphere;

    // --- texture loading with visible loading + error states ---
    let disposed = false;
    let liveTexture: THREE.Texture | null = null;
    setLoadState("loading");
    const maxDim = Math.min(MAX_TEXTURE_DIM, renderer.capabilities.maxTextureSize || MAX_TEXTURE_DIM);
    loadPanoramaTexture(imageUrl, maxDim)
      .then((texture) => {
        if (disposed) {
          texture.dispose();
          return;
        }
        texture.colorSpace = THREE.SRGBColorSpace;
        if (mode === "cylinder") texture.wrapS = THREE.RepeatWrapping;
        liveTexture = texture;
        material.map = texture;
        material.color.set(0xffffff);
        material.needsUpdate = true;
        setLoadState("ready");
      })
      .catch(() => {
        if (!disposed) setLoadState("error");
      });

    const latLimit = mode === "cylinder" ? 28 : 85;

    let lon = 0;
    let lat = 0;
    let velocityLon = 0;
    let velocityLat = 0;
    let isDragging = false;
    let startX = 0;
    let startY = 0;
    let moved = 0;
    let orientationOffset: number | null = null;
    let lastEmittedYaw: number | null = null;

    const activePointers = new Map<number, { x: number; y: number }>();
    let pinchStartDist: number | null = null;
    let pinchStartFov = 80;
    let fov = 80;
    const MIN_FOV = 35;
    const MAX_FOV = 95;

    function applyFov(newFov: number) {
      fov = THREE.MathUtils.clamp(newFov, MIN_FOV, MAX_FOV);
      camera.fov = fov;
      camera.updateProjectionMatrix();
    }

    function onDeviceOrientation(e: DeviceOrientationEvent) {
      if (e.alpha == null || e.beta == null) return;
      if (orientationOffset === null) orientationOffset = e.alpha;
      const relativeAlpha = e.alpha - orientationOffset;
      lon = -relativeAlpha;
      lat = THREE.MathUtils.clamp(e.beta - 90, -latLimit, latLimit);
    }
    if (motionEnabled) {
      window.addEventListener("deviceorientation", onDeviceOrientation);
    }

    function onWheel(e: WheelEvent) {
      e.preventDefault();
      applyFov(fov + e.deltaY * 0.05);
    }

    function onPointerDown(e: PointerEvent) {
      if (motionEnabled) return;
      activePointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (activePointers.size === 2) {
        isDragging = false;
        const pts = Array.from(activePointers.values());
        pinchStartDist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
        pinchStartFov = fov;
      } else if (activePointers.size === 1) {
        isDragging = true;
        startX = e.clientX;
        startY = e.clientY;
        moved = 0;
        velocityLon = 0;
        velocityLat = 0;
      }
    }
    function onPointerMove(e: PointerEvent) {
      if (motionEnabled) return;
      if (activePointers.has(e.pointerId)) {
        activePointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      }
      if (activePointers.size === 2 && pinchStartDist) {
        const pts = Array.from(activePointers.values());
        const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
        applyFov(pinchStartFov * (pinchStartDist / Math.max(dist, 1)));
        return;
      }
      if (!isDragging) return;
      const dx = e.movementX || 0;
      const dy = e.movementY || 0;
      moved += Math.abs(dx) + Math.abs(dy);
      const dLon = -dx * 0.18;
      const dLat = dy * 0.18;
      lon += dLon;
      lat = THREE.MathUtils.clamp(lat + dLat, -latLimit, latLimit);
      velocityLon = dLon;
      velocityLat = dLat;
    }
    function onPointerUp(e: PointerEvent) {
      const wasSingleDrag = isDragging && activePointers.size === 1;
      activePointers.delete(e.pointerId);
      if (activePointers.size < 2) pinchStartDist = null;
      isDragging = activePointers.size === 1;

      if (wasSingleDrag && placementMode && moved < 12 && onPlacePoint) {
        const rect = mount!.getBoundingClientRect();
        const ndcX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
        const ndcY = -((e.clientY - rect.top) / rect.height) * 2 + 1;
        const raycaster = new THREE.Raycaster();
        raycaster.setFromCamera(new THREE.Vector2(ndcX, ndcY), camera);
        const hit = raycaster.intersectObject(sphere)[0];
        if (hit) {
          const { yaw, pitch } = vectorToYawPitch(hit.point);
          onPlacePoint(yaw, pitch);
        }
      }
    }

    renderer.domElement.style.touchAction = "none";
    renderer.domElement.style.cursor = placementMode ? "crosshair" : "grab";
    renderer.domElement.addEventListener("pointerdown", onPointerDown);
    renderer.domElement.addEventListener("wheel", onWheel, { passive: false });
    window.addEventListener("pointermove", onPointerMove);
    window.addEventListener("pointerup", onPointerUp);

    function onResize() {
      if (!mount) return;
      width = mount.clientWidth;
      height = mount.clientHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    }
    const resizeObserver = new ResizeObserver(onResize);
    resizeObserver.observe(mount);

    let rafId: number;
    function animate() {
      rafId = requestAnimationFrame(animate);

      // Inertia: keep drifting briefly after a drag release, matching the
      // "smooth damping" feel of OrbitControls, without pulling in the
      // full OrbitControls module for a single-axis look control.
      if (!isDragging && (Math.abs(velocityLon) > 0.002 || Math.abs(velocityLat) > 0.002)) {
        lon += velocityLon;
        lat = THREE.MathUtils.clamp(lat + velocityLat, -latLimit, latLimit);
        velocityLon *= 0.92;
        velocityLat *= 0.92;
      }

      const target = yawPitchToVector(lon, lat, 500);
      camera.lookAt(target);

      // Stream orientation to the floor-plan HUD (throttled: only when it
      // actually moved enough to matter — avoids a React storm per frame).
      const wrappedYaw = ((lon + 180) % 360 + 360) % 360 - 180;
      if (lastEmittedYaw === null || Math.abs(wrappedYaw - lastEmittedYaw) > 0.4) {
        lastEmittedYaw = wrappedYaw;
        onCameraMoveRef.current?.(wrappedYaw, lat);
        setYawReadout(Math.round(wrappedYaw));
      }

      const pins = hotspotsRef.current.map((h) => {
        const pos = yawPitchToVector(h.yaw, h.pitch, RADIUS);
        const projected = pos.clone().project(camera);
        const dir = pos.clone().normalize();
        const camDir = new THREE.Vector3();
        camera.getWorldDirection(camDir);
        // A pin is on screen when the hotspot is IN FRONT of the camera
        // (dir and view direction roughly aligned). The previous
        // comparison (dot < -0.15) demanded the hotspot be BEHIND the
        // camera while projected.z < 1 demanded it in front — mutually
        // exclusive, so pins never rendered at any orientation
        // (browser-verified: full 360° sweep, zero pins). Sign corrected
        // here; 0.15 keeps pins fading slightly before the very edge.
        const facing = dir.dot(camDir) > 0.15;
        return {
          hotspot: h,
          x: ((projected.x + 1) / 2) * width,
          y: ((1 - projected.y) / 2) * height,
          visible: facing && projected.z < 1,
        };
      });
      setScreenPins(pins);

      renderer.render(scene, camera);
    }
    animate();

    return () => {
      disposed = true;
      cancelAnimationFrame(rafId);
      resizeObserver.disconnect();
      renderer.domElement.removeEventListener("pointerdown", onPointerDown);
      renderer.domElement.removeEventListener("wheel", onWheel);
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", onPointerUp);
      window.removeEventListener("deviceorientation", onDeviceOrientation);
      try {
        if (renderer.xr.enabled) renderer.xr.getSession()?.end?.().catch(() => {});
      } catch {
        /* leaving XR must never break unmount */
      }
      renderer.dispose();
      liveTexture?.dispose();
      geometry.dispose();
      material.dispose();
      if (mount.contains(renderer.domElement)) mount.removeChild(renderer.domElement);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [imageUrl, placementMode, motionEnabled, mode, loadAttempt]);

  return (
    <div
      ref={mountRef}
      className="relative h-full w-full overflow-hidden"
      onPointerMove={(e) => {
        if (!draggingPin || !mountRef.current) return;
        const rect = mountRef.current.getBoundingClientRect();
        setDraggingPin({ ...draggingPin, x: e.clientX - rect.left, y: e.clientY - rect.top });
      }}
      onPointerUp={(e) => {
        if (!draggingPin) return;
        const camera = cameraRef.current;
        const sphere = sphereRef.current;
        const mount = mountRef.current;
        if (camera && sphere && mount) {
          const rect = mount.getBoundingClientRect();
          const ndcX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
          const ndcY = -((e.clientY - rect.top) / rect.height) * 2 + 1;
          const raycaster = new THREE.Raycaster();
          raycaster.setFromCamera(new THREE.Vector2(ndcX, ndcY), camera);
          const hit = raycaster.intersectObject(sphere)[0];
          if (hit) {
            const { yaw, pitch } = vectorToYawPitch(hit.point);
            onRepositionHotspot?.(draggingPin.id, yaw, pitch);
          }
        }
        setDraggingPin(null);
      }}
    >
      {onHotspotClick && !placementMode && (
        <button
          onClick={() => (motionEnabled ? setMotionEnabled(false) : enableMotion())}
          className={`absolute right-3 top-3 z-20 flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium backdrop-blur transition-colors ${
            motionEnabled ? "bg-brass text-bone" : "bg-ink/60 text-bone hover:bg-ink/80"
          }`}
        >
          <Smartphone size={13} />
          {motionEnabled ? "Motion on" : "Look with phone"}
        </button>
      )}
      {!motionAvailable && (
        <div className="pointer-events-none absolute right-3 top-12 z-20 max-w-[180px] rounded bg-ink/80 px-2.5 py-1.5 text-[11px] text-bone/70 backdrop-blur">
          Motion permission denied — enable it in browser site settings to look around by tilting.
        </div>
      )}

      {/* Optional, capability-detected VR entry point (hidden unless WebXR
          immersive-vr is actually available on this browser). */}
      {xrAvailable && onHotspotClick && !placementMode && (
        <button
          onClick={toggleXR}
          className={`absolute left-3 top-3 z-20 flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium backdrop-blur transition-colors ${
            xrActive ? "bg-brass text-bone" : "bg-ink/60 text-bone hover:bg-ink/80"
          }`}
        >
          <Compass size={13} /> {xrActive ? "Exit VR" : "View in VR"}
        </button>
      )}

      {/* Loading state — a panorama over a slow connection takes seconds;
          a spinner is the difference between "loading" and "broken". */}
      {loadState === "loading" && (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-2 bg-black/45">
          <Loader2 size={26} className="animate-spin text-bone/80" />
          <span className="font-mono text-[11px] text-bone/60">Loading panorama…</span>
        </div>
      )}

      {/* Failure state — honest error + a retry, instead of a black box. */}
      {loadState === "error" && (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-3 bg-black/70 px-6 text-center">
          <span className="font-mono text-xs text-red-300">Couldn't load this panorama.</span>
          <span className="max-w-xs text-[11px] leading-relaxed text-bone/50">
            The image may have been deleted from storage, or your connection dropped. Check your connection and try
            again.
          </span>
          <button
            onClick={() => setLoadAttempt((n) => n + 1)}
            className="flex items-center gap-1.5 rounded-md bg-bone px-3.5 py-2 text-xs font-medium text-ink"
          >
            <RotateCw size={12} /> Retry
          </button>
        </div>
      )}

      {/* Yaw readout (editor only) — the number creators enter into the
          floor-plan compass calibration. */}
      {showYaw && loadState === "ready" && (
        <div className="pointer-events-none absolute bottom-3 left-3 z-20 rounded bg-ink/70 px-2.5 py-1 font-mono text-[10px] text-bone/80 backdrop-blur">
          yaw {yawReadout}°
        </div>
      )}

      {screenPins.map(({ hotspot, x, y, visible }) => {
        const drag = draggingPin && draggingPin.id === hotspot.id ? draggingPin : null;
        const isDragging = drag !== null;
        if (!visible && !drag) return null;
        const px = drag ? drag.x : x;
        const py = drag ? drag.y : y;
        return (
          <button
            key={hotspot.id}
            onClick={() => !editable && onHotspotClick?.(hotspot)}
            onPointerDown={(e) => {
              if (!editable) return;
              e.stopPropagation();
              const rect = mountRef.current?.getBoundingClientRect();
              if (!rect) return;
              setDraggingPin({ id: hotspot.id, x: e.clientX - rect.left, y: e.clientY - rect.top });
            }}
            style={{ left: px, top: py }}
            className={`group pointer-events-auto absolute z-10 flex -translate-x-1/2 -translate-y-1/2 flex-col items-center ${
              editable ? "cursor-grab active:cursor-grabbing" : ""
            }`}
          >
            <span
              className={`flex h-11 w-11 items-center justify-center rounded-full border-2 border-white/90 bg-brass/85 text-bone shadow-[0_0_18px_rgba(0,0,0,0.4)] backdrop-blur transition-transform duration-150 group-hover:scale-110 group-active:scale-95 ${
                isDragging ? "scale-110 ring-4 ring-brass/40" : ""
              }`}
              style={{ animation: isDragging ? undefined : "wp-pulse 2.4s ease-in-out infinite" }}
            >
              <HotspotGlyph style={hotspot.iconStyle} />
            </span>
            <span className="mt-1.5 whitespace-nowrap rounded-full bg-ink/80 px-2.5 py-0.5 text-[11px] font-medium text-bone opacity-0 backdrop-blur transition-opacity duration-150 group-hover:opacity-100">
              {hotspot.label}
            </span>
          </button>
        );
      })}
      <style>{`
        @keyframes wp-pulse {
          0%, 100% { box-shadow: 0 0 0 0 rgba(201,138,62,0.5); }
          50% { box-shadow: 0 0 0 8px rgba(201,138,62,0); }
        }
      `}</style>
      {placementMode && (
        <div className="pointer-events-none absolute left-1/2 top-3 -translate-x-1/2 rounded-full bg-brass px-3 py-1 text-xs font-medium text-bone">
          Click anywhere on the panorama to drop a hotspot
        </div>
      )}
      {editable && !placementMode && hotspots.length > 0 && (
        <div className="pointer-events-none absolute left-1/2 top-3 -translate-x-1/2 rounded-full bg-ink/60 px-3 py-1 text-[11px] text-bone/80 backdrop-blur">
          Drag a pin to reposition it
        </div>
      )}
    </div>
  );
}

function HotspotGlyph({ style }: { style?: Hotspot["iconStyle"] }) {
  if (style === "circle") return <Circle size={16} strokeWidth={3} />;
  if (style === "arrow") return <ArrowUpRight size={20} strokeWidth={3} />;
  return <ChevronUp size={22} strokeWidth={3} />;
}
