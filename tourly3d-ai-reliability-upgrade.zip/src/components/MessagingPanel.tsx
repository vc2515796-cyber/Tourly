import { useEffect, useState } from "react";
import { MessageCircle, Send, Copy, Loader2, RefreshCw, Check } from "lucide-react";
import { auth } from "../lib/firebase";

type ProviderStatus = { whatsappConfigured: boolean; telegramConfigured: boolean };

/**
 * Dashboard messaging panel (Feature H). Shows which chat providers are
 * actually configured on the deployment (honest status, not assumptions),
 * generates the single-use link code that connects a WhatsApp number or
 * Telegram chat to the signed-in account, and documents the exact bot
 * commands. The webhook URLs are copyable for provider setup.
 */
export default function MessagingPanel() {
  const [status, setStatus] = useState<ProviderStatus | null>(null);
  const [checking, setChecking] = useState(true);
  const [code, setCode] = useState<string | null>(null);
  const [codeBusy, setCodeBusy] = useState(false);
  const [codeError, setCodeError] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  async function refresh() {
    setChecking(true);
    try {
      const response = await fetch("/api/messaging-link");
      const body = await response.json();
      setStatus({ whatsappConfigured: Boolean(body?.whatsappConfigured), telegramConfigured: Boolean(body?.telegramConfigured) });
    } catch {
      setStatus({ whatsappConfigured: false, telegramConfigured: false });
    }
    setChecking(false);
  }

  useEffect(() => {
    refresh();
  }, []);

  async function generateCode() {
    setCodeError(null);
    setCodeBusy(true);
    try {
      const token = await auth?.currentUser?.getIdToken();
      if (!token) {
        setCodeError("Sign in first.");
        return;
      }
      const response = await fetch("/api/messaging-link", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ action: "create-code" }),
      });
      const body = await response.json();
      if (!response.ok) {
        setCodeError(body?.error ?? `Couldn't create a code (${response.status}).`);
        return;
      }
      setCode(body.code);
    } catch {
      setCodeError("Couldn't reach the messaging service — check your connection.");
    } finally {
      setCodeBusy(false);
    }
  }

  async function copy(text: string, key: string) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(key);
      setTimeout(() => setCopied((c) => (c === key ? null : c)), 1500);
    } catch {
      /* clipboard blocked — the text is selectable anyway */
    }
  }

  const origin = typeof window !== "undefined" ? window.location.origin : "https://your-site.netlify.app";

  return (
    <section className="rounded-lg border border-charcoal/10 bg-white/60 p-5">
      <div className="flex items-center justify-between">
        <h2 className="flex items-center gap-2 font-display text-lg font-semibold">
          <MessageCircle className="text-brass" size={18} /> Build tours over chat
        </h2>
        <button
          onClick={refresh}
          className="flex items-center gap-1 text-xs text-charcoal/40 hover:text-charcoal/70"
          title="Re-check provider configuration"
        >
          {checking ? <Loader2 size={12} className="animate-spin" /> : <RefreshCw size={12} />} Status
        </button>
      </div>
      <p className="mt-2 max-w-2xl text-sm leading-relaxed text-charcoal/60">
        Link your WhatsApp number or Telegram chat, then send photos straight to the bot — each one becomes a scene in
        a tour, labelled by AI, and you get the public link back in the chat.
      </p>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {(
          [
            { key: "whatsapp", label: "WhatsApp", configured: status?.whatsappConfigured },
            { key: "telegram", label: "Telegram", configured: status?.telegramConfigured },
          ] as const
        ).map((p) => (
          <div
            key={p.key}
            className={`rounded-md border p-3 ${
              p.configured === true ? "border-emerald-300 bg-emerald-50/60" : "border-charcoal/15 bg-bone/60"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold">{p.label}</span>
              <span
                className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${
                  p.configured === true
                    ? "bg-emerald-200/70 text-emerald-800"
                    : p.configured === false
                    ? "bg-charcoal/10 text-charcoal/50"
                    : "bg-charcoal/5 text-charcoal/40"
                }`}
              >
                {p.configured === true ? "Live" : p.configured === false ? "Not configured" : "Checking…"}
              </span>
            </div>
            <p className="mt-1.5 text-[10px] leading-relaxed text-charcoal/50">
              {p.configured === true
                ? `Connected. Send “start CODE” to the bot from your ${p.label} account.`
                : `Needs ${p.key === "whatsapp" ? "WHATSAPP_*" : "TELEGRAM_*"} env vars on the deployment (see DEPLOY.md).`}
            </p>
            <button
              onClick={() =>
                copy(
                  p.key === "whatsapp" ? `${origin}/api/whatsapp-webhook` : `${origin}/api/telegram-webhook`,
                  p.key
                )
              }
              className="mt-2 flex items-center gap-1 font-mono text-[10px] text-brass hover:underline"
            >
              {copied === p.key ? <Check size={10} /> : <Copy size={10} />}
              {copied === p.key ? "Copied webhook URL" : `Copy ${p.key} webhook URL`}
            </button>
          </div>
        ))}
      </div>

      <div className="mt-4 rounded-md border border-dashed border-charcoal/20 p-4">
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={generateCode}
            disabled={codeBusy}
            className="flex items-center gap-1.5 rounded-md bg-charcoal px-3.5 py-2 text-xs font-medium text-bone hover:bg-ink disabled:opacity-40"
          >
            {codeBusy ? <Loader2 size={12} className="animate-spin" /> : <Send size={12} />}
            Generate connect code
          </button>
          {code && (
            <div className="flex items-center gap-2">
              <code className="rounded bg-brass/15 px-3 py-2 font-mono text-base font-bold tracking-[0.25em] text-brass">
                {code}
              </code>
              <button onClick={() => copy(`start ${code}`, "cmd")} className="text-xs text-brass hover:underline">
                {copied === "cmd" ? "Copied" : "Copy command"}
              </button>
            </div>
          )}
        </div>
        {codeError && <p className="mt-2 text-xs text-red-500">{codeError}</p>}
        <p className="mt-2.5 text-[10px] leading-relaxed text-charcoal/45">
          Codes are single-use and expire in 24 hours. Send <code className="rounded bg-charcoal/5 px-1">start CODE</code>{" "}
          to the bot, then just send photos or videos — send{" "}
          <code className="rounded bg-charcoal/5 px-1">new</code> to start a fresh tour,{" "}
          <code className="rounded bg-charcoal/5 px-1">link</code> to get your tour URL again.
        </p>
      </div>
    </section>
  );
}
