import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  X,
  MousePointer2,
  Square,
  Minus,
  DoorOpen,
  AppWindow,
  Ruler,
  Hand,
  Undo2,
  Redo2,
  Save,
  Loader2,
  AlertTriangle,
  CheckCircle2,
  Grid3x3,
  Box,
  PencilRuler,
  Wand2,
  Download,
  FileJson,
  Share2,
} from "lucide-react";
import type { Tour } from "../../types";
import { compressImage } from "../../lib/imageCompress";
import {
  createFloor,
  createPlan,
  loadPlan,
  type FloorPlanDocument,
} from "../../lib/plan/model";
import { floorBounds } from "../../lib/plan/geometry";
import { PlanHistory } from "../../lib/plan/history";
import PlanCanvas2D, { type PlanSelection, type PlanTool } from "./PlanCanvas2D";
import PlanInspector from "./PlanInspector";
import ConceptGenerator from "./ConceptGenerator";
import { analysisToFloorPlan, snapshotOfConceptPlan, type ConceptAnalysis } from "../../lib/conceptPlan";
const Dollhouse3D = React.lazy(() => import("./Dollhouse3D"));

/**
 * Stage B2/B3 — the Plan Studio shell: toolbar (2D), 3D tab, inspector,
 * undo/redo, autosave with visible saved/saving/error states, and an
 * unsaved-changes guard on close. The plan document lives inside the tour
 * (`tour.plan`), so it persists and publishes through the EXISTING storage
 * pipeline — no second database.
 */

type Props = {
  tour: Tour;
  onChangeTour: (tour: Tour) => void; // studio saves via the tour (autosave)
  onClose: () => void;
  onOpenScene?: (stopId: string) => void;
};

type SaveState = "saved" | "saving" | "error" | "dirty";

const TOOLS: { id: PlanTool; label: string; icon: typeof MousePointer2; hint: string }[] = [
  { id: "select", label: "Select", icon: MousePointer2, hint: "Click rooms, walls, doors or windows to edit; drag to move" },
  { id: "room", label: "Room", icon: Square, hint: "Click to place corners; click the first corner (or double-click) to close" },
  { id: "wall", label: "Wall", icon: Minus, hint: "Click start, then end" },
  { id: "door", label: "Door", icon: DoorOpen, hint: "Click on a wall to place a door" },
  { id: "window", label: "Window", icon: AppWindow, hint: "Click on a wall to place a window" },
  { id: "calibrate", label: "Calibrate", icon: Ruler, hint: "Click two points with a known real distance" },
  { id: "pan", label: "Pan", icon: Hand, hint: "Drag to move the view (or use two fingers)" },
];

export default function PlanStudio({ tour, onChangeTour, onClose, onOpenScene }: Props) {
  const [plan, setPlan] = useState<FloorPlanDocument | null>(() => {
    if (!tour.plan) return null;
    const result = loadPlan(tour.plan, tour.id);
    return result.ok ? result.plan : null;
  });
  const [loadWarning, setLoadWarning] = useState<string | null>(() => {
    if (!tour.plan) return null;
    const result = loadPlan(tour.plan, tour.id);
    return result.ok ? (result.warnings.length ? result.warnings.join(" ") : null) : result.error;
  });
  const [tool, setTool] = useState<PlanTool>("select");
  const [selection, setSelection] = useState<PlanSelection>(null);
  const [tab, setTab] = useState<"2d" | "3d">("2d");
  const [gridSnap, setGridSnap] = useState(true);
  const [calibPoints, setCalibPoints] = useState<{ x: number; y: number }[] | null>(null);
  const [saveState, setSaveState] = useState<SaveState>(() => (tour.plan ? "saved" : "dirty"));
  const [saveError, setSaveError] = useState<string | null>(null);
  const [confirmClose, setConfirmClose] = useState(false);
  const historyRef = useRef<PlanHistory | null>(null);
  const [historyTick, setHistoryTick] = useState(0);
  const saveTimer = useRef<number | null>(null);
  // Stage D: AI concept generator + PNG/JSON export
  const [conceptOpen, setConceptOpen] = useState(false);
  const konvaStageRef = useRef<any>(null);
  const [exportBusy, setExportBusy] = useState(false);

  // --- init / create ---------------------------------------------------------
  useEffect(() => {
    if (!plan && !tour.plan) {
      setPlan(createPlan(tour.id));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (plan && !historyRef.current) {
      historyRef.current = new PlanHistory(plan);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [plan !== null]);

  // --- doc changes + autosave ---------------------------------------------------
  const applyDoc = useCallback(
    (next: FloorPlanDocument, commit: boolean) => {
      setPlan(next);
      setSaveState((s) => (s === "saving" ? s : "dirty"));
      if (commit && historyRef.current) {
        historyRef.current.commit(next);
        setHistoryTick((t) => t + 1);
      }
    },
    []
  );

  // Debounced autosave through the EXISTING tour persistence.
  useEffect(() => {
    if (!plan) return;
    if (saveState === "saved") return;
    if (saveTimer.current) window.clearTimeout(saveTimer.current);
    saveTimer.current = window.setTimeout(async () => {
      setSaveState("saving");
      setSaveError(null);
      try {
        onChangeTour({ ...tour, plan });
        setSaveState("saved");
      } catch (err: any) {
        setSaveState("error");
        setSaveError(err?.message ?? "Couldn't save the plan — your edits stay on screen, try again.");
      }
    }, 800);
    return () => {
      if (saveTimer.current) window.clearTimeout(saveTimer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [plan, saveState === "saved"]);

  // beforeunload guard while unsaved.
  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      if (saveState === "dirty" || saveState === "error") {
        e.preventDefault();
      }
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [saveState]);

  // --- undo / redo ------------------------------------------------------------------
  const undo = useCallback(() => {
    if (!plan || !historyRef.current) return;
    const restored = historyRef.current.undo(plan);
    if (restored) {
      setPlan(restored);
      setSelection(null);
      setHistoryTick((t) => t + 1);
      // A restore is a doc change like any other — mark it dirty so the
      // autosave persists the REVERTED state (otherwise an undo would be
      // silently lost on refresh).
      setSaveState("dirty");
    }
  }, [plan]);

  const redo = useCallback(() => {
    if (!historyRef.current) return;
    const restored = historyRef.current.redo();
    if (restored) {
      setPlan(restored);
      setSelection(null);
      setHistoryTick((t) => t + 1);
      setSaveState("dirty");
    }
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT") return;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") {
        e.preventDefault();
        if (e.shiftKey) redo();
        else undo();
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "y") {
        e.preventDefault();
        redo();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [undo, redo]);

  // --- floor management ----------------------------------------------------------------
  const activeFloor = useMemo(
    () => plan?.floors.find((f) => f.id === plan.activeFloorId) ?? plan?.floors[0],
    [plan]
  );

  const addFloor = useCallback(() => {
    if (!plan) return;
    const floor = createFloor(`Floor ${plan.floors.length + 1}`, plan.floors.length * 3);
    applyDoc({ ...plan, floors: [...plan.floors, floor], activeFloorId: floor.id }, true);
  }, [plan, applyDoc]);

  const deleteFloor = useCallback(
    (floorId: string) => {
      if (!plan || plan.floors.length <= 1) return;
      if (!window.confirm("Delete this floor with all its rooms? This can be undone with Ctrl+Z.")) return;
      const floors = plan.floors.filter((f) => f.id !== floorId);
      applyDoc(
        { ...plan, floors, activeFloorId: plan.activeFloorId === floorId ? floors[0]!.id : plan.activeFloorId },
        true
      );
    },
    [plan, applyDoc]
  );

  const uploadBackground = useCallback(
    async (file: File) => {
      if (!plan || !activeFloor) return;
      if (!file.type.startsWith("image/")) return;
      if (file.size > 6_000_000) {
        setLoadWarning("Blueprint image is too large — keep it under 6 MB.");
        return;
      }
      const readDataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = () => reject(new Error("read failed"));
        reader.readAsDataURL(file);
      }).catch(() => null);
      if (!readDataUrl) return;
      const dataUrl = await compressImage(readDataUrl, { maxDim: 2048, quality: 0.8 });
      const img = await new Promise<HTMLImageElement>((resolve, reject) => {
        const el = new Image();
        el.onload = () => resolve(el);
        el.onerror = reject;
        el.src = dataUrl;
      }).catch(() => null);
      if (!img) return;

      // Place the underlay to cover the current geometry bounds (or a
      // default 10×8 region for an empty plan), aspect-correct.
      const b = floorBounds(activeFloor);
      const spanX = b ? Math.max(b.maxX - b.minX, 4) : 10;
      const spanY = b ? Math.max(b.maxY - b.minY, 4) : 10;
      const aspect = img.width / img.height;
      let w = spanX * 1.2;
      let h = w / aspect;
      if (h < spanY * 1.2) {
        h = spanY * 1.2;
        w = h * aspect;
      }
      const cx = b ? (b.minX + b.maxX) / 2 : 0;
      const cy = b ? (b.minY + b.maxY) / 2 : 0;
      applyDoc(
        {
          ...plan,
          floors: plan.floors.map((f) =>
            f.id === activeFloor.id
              ? {
                  ...f,
                  background: {
                    dataUrl,
                    width: img.width,
                    height: img.height,
                    opacity: 0.45,
                    x: cx - w / 2,
                    y: cy - h / 2,
                    w,
                    h,
                  },
                }
              : f
          ),
        },
        true
      );
    },
    [plan, activeFloor, applyDoc]
  );

  // --- Stage D: AI concept floor plan ---------------------------------------
  const planHasContent = useMemo(() => {
    if (!plan) return false;
    return plan.floors.some(
      (f) => f.vertices.length > 0 || f.walls.length > 0 || (f.furniture ?? []).length > 0 || f.rooms.length > 0
    );
  }, [plan]);

  const applyConcept = useCallback(
    (analysis: ConceptAnalysis, source: { stopId: string; stopTitle?: string }) => {
      const conversion = analysisToFloorPlan(analysis, tour.id, source);
      if (!conversion.ok) {
        setLoadWarning(conversion.error);
        return;
      }
      // Keep a pristine copy for "reset to generated layout" — the snapshot
      // is stored INSIDE the document, so it persists and publishes with it.
      const snapshot = snapshotOfConceptPlan(conversion.plan);
      applyDoc(
        { ...conversion.plan, concept: { ...conversion.plan.concept!, generatedSnapshot: snapshot } },
        true
      );
      setSelection(null);
      setConceptOpen(false);
    },
    [applyDoc, tour.id]
  );

  const resetToGenerated = useCallback(() => {
    const snapshot = plan?.concept?.generatedSnapshot;
    if (!snapshot) return;
    applyDoc({ ...snapshot, updatedAt: Date.now() }, true);
    setSelection(null);
  }, [applyDoc, plan]);

  const exportPng = useCallback(() => {
    const stage = konvaStageRef.current;
    if (!stage) return;
    const url = stage.toDataURL({ pixelRatio: 2 });
    const a = document.createElement("a");
    a.href = url;
    a.download = "floor-plan.png";
    a.click();
  }, []);

  const exportJson = useCallback(() => {
    if (!plan) return;
    const blob = new Blob([JSON.stringify(plan, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "floor-plan.json";
    a.click();
    URL.revokeObjectURL(url);
  }, [plan]);

  /** Renders the plan as an image and attaches it to the PUBLIC tour as the
   *  Feature-C blueprint (shown in the viewer's floor-plan HUD). Replacing
   *  the blueprint clears placed markers — their normalized positions are
   *  tied to the old image — and the agent is told so, explicitly. */
  const useInPublicTour = useCallback(async () => {
    const stage = konvaStageRef.current;
    if (!stage || !plan) return;
    const hadMarkers = (tour.floorPlan?.markers?.length ?? 0) > 0;
    const ok = window.confirm(
      hadMarkers
        ? "Use this plan image as the public tour's floor plan? The current blueprint and its placed scene markers will be REPLACED — you'll re-place the markers on the new image."
        : "Use this plan image as the public tour's floor plan? Visitors will see it in the viewer's floor-plan mini-map (add scene markers in the editor afterwards)."
    );
    if (!ok) return;
    setExportBusy(true);
    try {
      const png = stage.toDataURL({ pixelRatio: 2 });
      const w = stage.width() * 2;
      const h = stage.height() * 2;
      const compressed = await compressImage(png, { maxDim: 1600, quality: 0.85 });
      onChangeTour({
        ...tour,
        plan,
        floorPlan: { dataUrl: compressed, width: w, height: h, markers: [] },
      });
    } finally {
      setExportBusy(false);
    }
  }, [onChangeTour, plan, tour]);

  if (!plan || !activeFloor) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/70 p-4">
        <div className="max-w-md rounded-xl bg-bone p-6 text-center shadow-2xl">
          <AlertTriangle size={20} className="mx-auto text-amber-600" />
          <p className="mt-2 text-sm text-charcoal/70">{loadWarning ?? "The floor plan couldn't be opened."}</p>
          <div className="mt-4 flex justify-center gap-2">
            {tour.plan && (
              <button
                onClick={() => {
                  // Start fresh but KEEP the old blob — never silently overwrite.
                  const fresh = createPlan(tour.id);
                  const old = tour.plan;
                  setPlan(fresh);
                  historyRef.current = new PlanHistory(fresh);
                  setLoadWarning(
                    `Previous plan data preserved in the tour record (${Math.round(JSON.stringify(old).length / 1024)} KB). It will be replaced only when this new plan saves.`
                  );
                }}
                className="rounded-md bg-sage px-3 py-1.5 text-xs font-semibold text-white"
              >
                Start a new plan
              </button>
            )}
            <button onClick={onClose} className="rounded-md border border-charcoal/15 px-3 py-1.5 text-xs font-medium text-charcoal/70">
              Close
            </button>
          </div>
        </div>
      </div>
    );
  }

  const dirty = saveState === "dirty" || saveState === "error";

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-bone">
      {/* header */}
      <div className="flex shrink-0 items-center justify-between gap-2 border-b border-charcoal/10 bg-white/70 px-3 py-2 sm:px-4">
        <div className="flex min-w-0 items-center gap-2">
          <PencilRuler className="shrink-0 text-brass" size={16} />
          <h2 className="truncate font-display text-sm font-semibold">Plan studio</h2>
          {/* save state — always visible, always honest */}
          <span
            className={`flex shrink-0 items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-medium ${
              saveState === "saved"
                ? "bg-emerald-50 text-emerald-700"
                : saveState === "saving"
                ? "bg-amber-50 text-amber-700"
                : saveState === "error"
                ? "bg-red-50 text-red-600"
                : "bg-charcoal/5 text-charcoal/50"
            }`}
            role="status"
          >
            {saveState === "saving" ? <Loader2 size={10} className="animate-spin" /> : saveState === "saved" ? <CheckCircle2 size={10} /> : saveState === "error" ? <AlertTriangle size={10} /> : <Save size={10} />}
            {saveState === "saving" ? "Saving…" : saveState === "saved" ? "Saved" : saveState === "error" ? "Save failed" : "Unsaved"}
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          {/* Stage D: AI concept floor plan + exports */}
          <button
            onClick={() => setConceptOpen(true)}
            title="Generate an editable concept floor plan from a 360° panorama (AI)"
            className="flex items-center gap-1 rounded-md border border-brass/50 bg-brass/10 px-2.5 py-1.5 text-[11px] font-semibold text-charcoal hover:bg-brass/20"
          >
            <Wand2 size={12} className="text-brass" /> AI concept
          </button>
          {planHasContent && (
            <>
              <button
                onClick={exportPng}
                title="Download the plan as a high-resolution PNG"
                className="flex items-center gap-1 rounded-md border border-charcoal/15 px-2.5 py-1.5 text-[11px] font-medium text-charcoal/70 hover:border-charcoal/30"
              >
                <Download size={12} /> PNG
              </button>
              <button
                onClick={exportJson}
                title="Download the editable plan geometry as JSON"
                className="flex items-center gap-1 rounded-md border border-charcoal/15 px-2.5 py-1.5 text-[11px] font-medium text-charcoal/70 hover:border-charcoal/30"
              >
                <FileJson size={12} /> JSON
              </button>
              <button
                onClick={() => void useInPublicTour()}
                disabled={exportBusy}
                title="Attach this plan image to the public tour (viewer floor-plan mini-map)"
                className="flex items-center gap-1 rounded-md border border-charcoal/15 px-2.5 py-1.5 text-[11px] font-medium text-charcoal/70 hover:border-charcoal/30 disabled:opacity-40"
              >
                {exportBusy ? <Loader2 size={12} className="animate-spin" /> : <Share2 size={12} />} Use in tour
              </button>
            </>
          )}
          {/* 2D / 3D switch */}
          <div className="flex rounded-md border border-charcoal/15 p-0.5">
            <button
              onClick={() => setTab("2d")}
              className={`rounded px-2.5 py-1 text-[11px] font-medium ${tab === "2d" ? "bg-charcoal text-bone" : "text-charcoal/60"}`}
            >
              2D edit
            </button>
            <button
              onClick={() => setTab("3d")}
              className={`flex items-center gap-1 rounded px-2.5 py-1 text-[11px] font-medium ${tab === "3d" ? "bg-charcoal text-bone" : "text-charcoal/60"}`}
            >
              <Box size={11} /> 3D
            </button>
          </div>
          <button onClick={() => setConfirmClose(true)} className="rounded p-1 text-charcoal/40 hover:text-charcoal" aria-label="Close plan studio">
            <X size={18} />
          </button>
        </div>
      </div>

      {loadWarning && (
        <div className="flex items-start gap-2 border-b border-amber-200 bg-amber-50 px-4 py-1.5 text-[11px] text-amber-800">
          <AlertTriangle size={12} className="mt-0.5 shrink-0" />
          <span className="flex-1">{loadWarning}</span>
          <button onClick={() => setLoadWarning(null)} className="shrink-0 text-amber-700 hover:underline">
            dismiss
          </button>
        </div>
      )}

      {saveError && (
        <div className="border-b border-red-200 bg-red-50 px-4 py-1.5 text-[11px] text-red-600">{saveError}</div>
      )}

      <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
        {/* left: toolbar + canvas/3D */}
        <div className="flex min-h-0 flex-1 flex-col gap-2 p-2 sm:p-3">
          {tab === "2d" ? (
            <>
              <div className="flex flex-wrap items-center gap-1">
                {TOOLS.map((t) => {
                  const Icon = t.icon;
                  const active = tool === t.id;
                  return (
                    <button
                      key={t.id}
                      onClick={() => setTool(t.id)}
                      title={t.hint}
                      className={`flex items-center gap-1 rounded-md border px-2 py-1.5 text-[11px] font-medium ${
                        active ? "border-brass bg-brass/15 text-charcoal" : "border-charcoal/10 text-charcoal/60 hover:border-charcoal/30"
                      }`}
                    >
                      <Icon size={12} /> <span className="hidden sm:inline">{t.label}</span>
                    </button>
                  );
                })}
                <div className="mx-1 h-5 w-px bg-charcoal/10" />
                <button
                  onClick={() => setGridSnap((g) => !g)}
                  title="Snap to grid (0.25 units)"
                  className={`flex items-center gap-1 rounded-md border px-2 py-1.5 text-[11px] font-medium ${
                    gridSnap ? "border-brass bg-brass/15 text-charcoal" : "border-charcoal/10 text-charcoal/60"
                  }`}
                >
                  <Grid3x3 size={12} /> <span className="hidden sm:inline">Snap</span>
                </button>
                <div className="mx-1 h-5 w-px bg-charcoal/10" />
                <button
                  onClick={undo}
                  disabled={!historyRef.current?.canUndo()}
                  title="Undo (Ctrl+Z)"
                  className="rounded-md border border-charcoal/10 p-1.5 text-charcoal/60 hover:border-charcoal/30 disabled:opacity-30"
                >
                  <Undo2 size={13} />
                </button>
                <button
                  onClick={redo}
                  disabled={!historyRef.current?.canRedo()}
                  title="Redo (Ctrl+Shift+Z)"
                  className="rounded-md border border-charcoal/10 p-1.5 text-charcoal/60 hover:border-charcoal/30 disabled:opacity-30"
                >
                  <Redo2 size={13} />
                </button>
                <span className="hidden font-mono text-[10px] text-charcoal/35 md:inline" key={historyTick}>
                  {historyRef.current ? `${historyRef.current.canUndo() ? "history" : "start"}` : ""}
                </span>
              </div>
              <PlanCanvas2D
                plan={plan}
                floor={activeFloor}
                tool={tool}
                selection={selection}
                onSelection={setSelection}
                onDocChange={applyDoc}
                onCalibratePoints={(a, b) => setCalibPoints([a, b])}
                gridSnap={gridSnap}
                onStageReady={(stage) => (konvaStageRef.current = stage)}
              />
            </>
          ) : (
            <React.Suspense
              fallback={
                <div className="flex min-h-0 flex-1 items-center justify-center rounded-lg border border-charcoal/15 bg-white">
                  <p className="font-mono text-xs text-charcoal/50">Loading 3D viewer…</p>
                </div>
              }
            >
              <Dollhouse3D
                plan={plan}
                selectedRoomId={selection?.kind === "room" ? selection.id : null}
                onSelectRoom={(roomId) => setSelection(roomId ? { kind: "room", id: roomId } : null)}
                onOpenScene={onOpenScene}
              />
            </React.Suspense>
          )}
        </div>

        {/* right: inspector */}
        <PlanInspector
          plan={plan}
          selection={selection}
          onSelection={setSelection}
          onDocChange={applyDoc}
          stops={tour.stops.map((s) => ({ id: s.id, title: s.title }))}
          calibPoints={calibPoints}
          onClearCalibPoints={() => setCalibPoints(null)}
          onUploadBackground={uploadBackground}
          onAddFloor={addFloor}
          onSelectFloor={(floorId) => applyDoc({ ...plan, activeFloorId: floorId }, false)}
          onDeleteFloor={deleteFloor}
          onRenameFloor={(floorId, name) =>
            applyDoc(
              { ...plan, floors: plan.floors.map((f) => (f.id === floorId ? { ...f, name } : f)) },
              false
            )
          }
          onResetToGenerated={resetToGenerated}
        />
      </div>

      {/* Stage D: AI concept generator */}
      {conceptOpen && (
        <ConceptGenerator
          tour={tour}
          planHasContent={planHasContent}
          onGenerated={applyConcept}
          onClose={() => setConceptOpen(false)}
        />
      )}

      {/* close confirmation — never discard unsaved edits silently */}
      {confirmClose && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-ink/70 p-4">
          <div className="max-w-sm rounded-xl bg-bone p-5 shadow-2xl">
            <p className="font-display text-sm font-semibold">
              {dirty ? "Unsaved changes" : "Close plan studio?"}
            </p>
            <p className="mt-1.5 text-xs leading-relaxed text-charcoal/60">
              {dirty
                ? "The plan has changes that haven't finished saving. Closing now keeps your last saved version — recent edits could be lost."
                : "All changes are saved."}
            </p>
            <div className="mt-4 flex justify-end gap-2">
              <button onClick={() => setConfirmClose(false)} className="rounded-md border border-charcoal/15 px-3 py-1.5 text-xs font-medium text-charcoal/70">
                Stay
              </button>
              <button
                onClick={onClose}
                className={`rounded-md px-3 py-1.5 text-xs font-semibold text-white ${dirty ? "bg-red-500" : "bg-sage"}`}
              >
                {dirty ? "Close and lose unsaved edits" : "Close"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
