import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { RotateCcw, Box, AlertTriangle, Layers } from "lucide-react";
import type { FloorPlanDocument, PlanFloor } from "../../lib/plan/model";
import {
  polygonArea,
  polygonWinding,
  roomPoints,
  solidWallPieces,
  validateRoomRing,
  vertexById,
  wallSegment,
} from "../../lib/plan/geometry";

/**
 * Stage B3 — the 3D dollhouse viewer.
 *
 * Built ONLY from the saved FloorPlanDocument geometry: floors are
 * triangulated room rings, walls are the SAME wallPieces() the 2D editor
 * renders, extruded with real door/window gaps. Nothing here is an AI
 * image — it is the actual plan, and it cannot disagree with the 2D view
 * because both consume one geometry source.
 *
 * Honesty rules shown in-UI: wall height is an assumption (from the plan
 * settings); measurements only appear when the scale is calibrated;
 * invalid rooms are excluded and reported, never silently drawn wrong.
 */

type Props = {
  plan: FloorPlanDocument;
  selectedRoomId: string | null;
  onSelectRoom: (roomId: string | null) => void;
  onOpenScene?: (stopId: string) => void;
};

const ROOM_COLORS = [0xc98a3e, 0x8aa67c, 0x5c8ab8, 0xb87c5c, 0x7c6ab8, 0x4c9c94, 0xa8905c];

export default function Dollhouse3D({ plan, selectedRoomId, onSelectRoom, onOpenScene }: Props) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [visibleFloors, setVisibleFloors] = useState<string[]>(plan.floors.map((f) => f.id));
  const [excludedRooms, setExcludedRooms] = useState<{ floor: string; room: string; reason: string }[]>([]);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const raycasterRef = useRef(new THREE.Raycaster());
  const roomMeshesRef = useRef<Map<string, THREE.Mesh>>(new Map());
  const frameRef = useRef<number>(0);
  const planRef = useRef(plan);
  planRef.current = plan;

  // Build (or rebuild) the scene whenever the plan or visible floors change.
  const buildKey = useMemo(
    () => JSON.stringify({ plan, visibleFloors }),
    [plan, visibleFloors]
  );

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    let disposed = false;

    try {
      if (!rendererRef.current) {
        const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        renderer.setSize(el.clientWidth, el.clientHeight);
        el.appendChild(renderer.domElement);
        rendererRef.current = renderer;
      }
      const renderer = rendererRef.current!;

      if (!sceneRef.current) {
        sceneRef.current = new THREE.Scene();
        sceneRef.current.background = new THREE.Color(0xf7f4ee);
        // Soft lights — a dollhouse look, not photorealism (and we don't claim it).
        const hemi = new THREE.HemisphereLight(0xffffff, 0xcfc8ba, 1.0);
        sceneRef.current.add(hemi);
        const dir = new THREE.DirectionalLight(0xffffff, 0.7);
        dir.position.set(8, 14, 6);
        sceneRef.current.add(dir);
      }
      const scene = sceneRef.current!;

      if (!cameraRef.current) {
        cameraRef.current = new THREE.PerspectiveCamera(50, el.clientWidth / Math.max(1, el.clientHeight), 0.1, 500);
        cameraRef.current.position.set(12, 10, 12);
        cameraRef.current.lookAt(0, 0, 0);
      }
      const camera = cameraRef.current!;

      if (!controlsRef.current) {
        controlsRef.current = new OrbitControls(camera, renderer.domElement);
        controlsRef.current.enableDamping = true;
        controlsRef.current.dampingFactor = 0.12;
        controlsRef.current.maxPolarAngle = Math.PI / 2 - 0.02; // don't go under the floor
        controlsRef.current.minDistance = 2;
        controlsRef.current.maxDistance = 120;
      }
      const controls = controlsRef.current!;

      // ---- (re)build geometry from the document ------------------------------
      const content = new THREE.Group();
      const excluded: { floor: string; room: string; reason: string }[] = [];
      const meshes = new Map<string, THREE.Mesh>();

      plan.floors.forEach((floor: PlanFloor, floorIdx) => {
        if (!visibleFloors.includes(floor.id)) return;
        const resolve = vertexById(floor.vertices);
        const z0 = floor.elevation;

        // Floor slabs: one triangulated mesh per VALID room ring.
        floor.rooms.forEach((room, roomIdx) => {
          const pts = roomPoints(room, resolve);
          const issues = validateRoomRing(room.id, pts);
          if (issues.some((i) => i.level === "error")) {
            excluded.push({ floor: floor.name, room: room.name, reason: issues.find((i) => i.level === "error")!.message });
            return;
          }
          try {
            // THREE.Shape triangulates concave rings correctly.
            const shape = new THREE.Shape(pts.map((p) => new THREE.Vector2(p.x, -p.y)));
            const geom = new THREE.ShapeGeometry(shape);
            geom.rotateX(Math.PI / 2);
            const mat = new THREE.MeshLambertMaterial({
              color: ROOM_COLORS[(floorIdx * 3 + roomIdx) % ROOM_COLORS.length],
              transparent: true,
              opacity: room.id === selectedRoomId ? 0.95 : 0.55,
              side: THREE.DoubleSide,
            });
            const mesh = new THREE.Mesh(geom, mat);
            mesh.position.set(0, z0 + 0.01, 0);
            mesh.userData = { roomId: room.id };
            content.add(mesh);
            meshes.set(room.id, mesh);
          } catch {
            excluded.push({ floor: floor.name, room: room.name, reason: "couldn't triangulate this room's shape" });
          }
        });

        // Walls: solid pieces from the SHARED wallPieces core, extruded.
        floor.walls.forEach((wall) => {
          const segment = wallSegment(wall, resolve);
          if (segment.length < 1e-6) return;
          const pieces = solidWallPieces(segment, floor.openings);
          for (const piece of pieces) {
            const len = Math.hypot(piece.end.x - piece.start.x, piece.end.y - piece.start.y);
            if (len < 1e-6) continue;
            const geom = new THREE.BoxGeometry(len, plan.defaultWallHeight, Math.max(wall.thickness, 0.05));
            const mat = new THREE.MeshLambertMaterial({ color: 0xefe9dd });
            const mesh = new THREE.Mesh(geom, mat);
            const cx = (piece.start.x + piece.end.x) / 2;
            const cz = (piece.start.y + piece.end.y) / 2;
            const angle = Math.atan2(piece.end.y - piece.start.y, piece.end.x - piece.start.x);
            mesh.position.set(cx, z0 + plan.defaultWallHeight / 2, cz);
            mesh.rotation.y = -angle;
            content.add(mesh);
          }

          // Window openings: translucent panes where the glass sits, so the
          // "gap" in the wall reads as a window rather than a hole.
          for (const opening of floor.openings.filter((o) => o.wallId === wall.id && o.kind === "window")) {
            const t = Math.max(0, Math.min(1, opening.t));
            const center = {
              x: segment.a.x + (segment.b.x - segment.a.x) * t,
              y: segment.a.y + (segment.b.y - segment.a.y) * t,
            };
            const w = Math.min(opening.width, segment.length * 0.98);
            const pane = new THREE.Mesh(
              new THREE.BoxGeometry(w, opening.height, 0.02),
              new THREE.MeshLambertMaterial({ color: 0xbfe0f5, transparent: true, opacity: 0.55 })
            );
            pane.position.set(center.x, z0 + opening.sillHeight + opening.height / 2, center.y);
            pane.rotation.y = -segment.angle;
            content.add(pane);
          }
        });
      });

      // Room labels as sprites (name + calibrated area, honestly labelled).
      plan.floors.forEach((floor) => {
        if (!visibleFloors.includes(floor.id)) return;
        const resolve = vertexById(floor.vertices);
        floor.rooms.forEach((room) => {
          const mesh = meshes.get(room.id);
          if (!mesh) return;
          const pts = roomPoints(room, resolve);
          const areaTxt = plan.scale.calibrated
            ? ` · ${polygonArea(pts).toFixed(1)} ${plan.scale.units === "ft" ? "sq ft" : "m²"}`
            : "";
          const label = makeLabelSprite(`${room.name}${areaTxt}`, room.id === selectedRoomId);
          const cx = pts.reduce((s, p) => s + p.x, 0) / pts.length;
          const cz = pts.reduce((s, p) => s + p.y, 0) / pts.length;
          label.position.set(cx, floor.elevation + plan.defaultWallHeight + 0.45, cz);
          label.userData = { roomId: room.id, isLabel: true };
          content.add(label);
        });
      });

      // Swap in the fresh content group.
      const prev = scene.getObjectByName("plan-content");
      if (prev) {
        disposeGroup(prev as THREE.Group);
        scene.remove(prev);
      }
      content.name = "plan-content";
      scene.add(content);
      roomMeshesRef.current = meshes;
      setExcludedRooms(excluded);
      setError(null);
      setReady(true);
      void polygonWinding; // (kept imported for parity; winding handled by Shape)

      // ---- animation loop -----------------------------------------------------
      const animate = () => {
        if (disposed) return;
        frameRef.current = requestAnimationFrame(animate);
        controls.update();
        renderer.render(scene, camera);
      };
      cancelAnimationFrame(frameRef.current);
      animate();

      const onResize = () => {
        if (!wrapRef.current) return;
        const w = wrapRef.current.clientWidth;
        const h = Math.max(1, wrapRef.current.clientHeight);
        renderer.setSize(w, h);
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
      };
      const ro = new ResizeObserver(onResize);
      ro.observe(el);

      // Room picking: a plain CLICK (not an orbit drag) selects the room;
      // a room linked to a tour scene opens that scene on double-click.
      let downAt: { x: number; y: number; t: number } | null = null;
      let lastClickAt = 0;
      const dom = renderer.domElement;
      const onPointerDown = (ev: PointerEvent) => {
        downAt = { x: ev.clientX, y: ev.clientY, t: performance.now() };
      };
      const onPointerUp = (ev: PointerEvent) => {
        if (!downAt) return;
        const moved = Math.hypot(ev.clientX - downAt.x, ev.clientY - downAt.y);
        downAt = null;
        if (moved > 6) return; // it was an orbit drag, not a click
        const isDouble = performance.now() - lastClickAt < 350;
        lastClickAt = performance.now();
        const rect = dom.getBoundingClientRect();
        const ndc = new THREE.Vector2(
          ((ev.clientX - rect.left) / rect.width) * 2 - 1,
          -((ev.clientY - rect.top) / rect.height) * 2 + 1
        );
        raycasterRef.current.setFromCamera(ndc, camera);
        const hits = raycasterRef.current.intersectObjects(content.children, true);
        const hit = hits.find((h) => h.object.userData?.roomId);
        if (hit) {
          const roomId = hit.object.userData.roomId as string;
          onSelectRoom(roomId);
          if (isDouble) {
            const floor = planRef.current.floors.find((f) => f.rooms.some((r) => r.id === roomId));
            const room = floor?.rooms.find((r) => r.id === roomId);
            if (room?.sceneStopId && onOpenScene) onOpenScene(room.sceneStopId);
          }
        } else {
          onSelectRoom(null);
        }
      };
      dom.addEventListener("pointerdown", onPointerDown);
      dom.addEventListener("pointerup", onPointerUp);

      return () => {
        disposed = true;
        cancelAnimationFrame(frameRef.current);
        ro.disconnect();
        dom.removeEventListener("pointerdown", onPointerDown);
        dom.removeEventListener("pointerup", onPointerUp);
      };
    } catch (err: any) {
      setError(err?.message ?? "The 3D view couldn't be initialised on this device.");
      setReady(false);
      return;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [buildKey, selectedRoomId]);

  const resetCamera = useCallback(() => {
    const camera = cameraRef.current;
    const controls = controlsRef.current;
    if (!camera || !controls) return;
    camera.position.set(12, 10, 12);
    controls.target.set(0, 0, 0);
    controls.update();
  }, []);

  useEffect(() => {
    return () => {
      // Unmount: free GPU resources.
      if (rendererRef.current) {
        rendererRef.current.dispose();
        rendererRef.current = null;
      }
      if (sceneRef.current) {
        disposeGroup(sceneRef.current);
        sceneRef.current = null;
      }
    };
  }, []);

  return (
    <div className="relative min-h-0 flex-1 overflow-hidden rounded-lg border border-charcoal/15 bg-[#f7f4ee]">
      <div ref={wrapRef} className="h-full w-full touch-none" />

      {/* controls */}
      <div className="absolute bottom-3 right-3 flex flex-col gap-1 rounded-lg border border-charcoal/10 bg-white/90 p-1 shadow-sm">
        <button onClick={resetCamera} className="rounded p-1.5 text-charcoal/60 hover:bg-charcoal/5" title="Reset camera" aria-label="Reset camera">
          <RotateCcw size={14} />
        </button>
      </div>

      {/* floor visibility */}
      {plan.floors.length > 1 && (
        <div className="absolute left-3 top-3 flex flex-col gap-1 rounded-lg border border-charcoal/10 bg-white/90 p-1.5 shadow-sm">
          <p className="flex items-center gap-1 px-0.5 font-mono text-[9px] uppercase tracking-wider text-charcoal/45">
            <Layers size={9} /> Floors
          </p>
          {plan.floors.map((f) => (
            <label key={f.id} className="flex cursor-pointer items-center gap-1.5 text-[10px] text-charcoal/65">
              <input
                type="checkbox"
                checked={visibleFloors.includes(f.id)}
                onChange={(e) => {
                  setVisibleFloors((prev) =>
                    e.target.checked ? [...prev, f.id] : prev.filter((id) => id !== f.id)
                  );
                }}
                className="h-3 w-3 accent-brass"
              />
              {f.name}
            </label>
          ))}
        </div>
      )}

      {/* honesty note */}
      <div className="pointer-events-none absolute right-3 top-3 rounded-md bg-white/85 px-2 py-1 font-mono text-[9px] text-charcoal/55">
        <Box size={9} className="mr-1 inline" />
        wall height {plan.defaultWallHeight} m — assumption{plan.scale.calibrated ? " · scale calibrated" : " · uncalibrated"}
      </div>

      {!ready && !error && (
        <div className="absolute inset-0 flex items-center justify-center bg-white/60">
          <p className="font-mono text-xs text-charcoal/50">Building 3D from plan geometry…</p>
        </div>
      )}
      {error && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-white/85 p-6 text-center">
          <AlertTriangle size={20} className="text-amber-600" />
          <p className="max-w-xs text-xs leading-relaxed text-charcoal/60">
            3D rendering failed on this device: {error}. The 2D plan keeps working — nothing is lost.
          </p>
        </div>
      )}
      {excludedRooms.length > 0 && (
        <div className="absolute bottom-3 left-3 max-w-56 rounded-md border border-amber-200 bg-amber-50/95 px-2.5 py-1.5 text-[10px] leading-relaxed text-amber-800">
          <p className="font-semibold">Excluded from 3D ({excludedRooms.length}):</p>
          {excludedRooms.slice(0, 3).map((x, i) => (
            <p key={i}>
              {x.room} ({x.floor}) — {x.reason}
            </p>
          ))}
          {excludedRooms.length > 3 && <p>+{excludedRooms.length - 3} more…</p>}
        </div>
      )}
    </div>
  );
}

/** Canvas-texture sprite with the room name (crisp at any zoom). */
function makeLabelSprite(text: string, selected: boolean): THREE.Sprite {
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d")!;
  const fontSize = 44;
  ctx.font = `600 ${fontSize}px "Noto Sans", system-ui, sans-serif`;
  const w = Math.max(120, ctx.measureText(text).width + 40);
  canvas.width = Math.ceil(w);
  canvas.height = fontSize + 28;
  const c2 = canvas.getContext("2d")!;
  c2.font = `600 ${fontSize}px "Noto Sans", system-ui, sans-serif`;
  c2.fillStyle = selected ? "rgba(201,138,62,0.95)" : "rgba(40,33,22,0.82)";
  // roundRect exists in all modern browsers; fillRect is the safe fallback.
  if (typeof c2.roundRect === "function") {
    c2.beginPath();
    c2.roundRect(0, 0, canvas.width, canvas.height, 14);
    c2.fill();
  } else {
    c2.fillRect(0, 0, canvas.width, canvas.height);
  }
  c2.fillStyle = "#fffaf2";
  c2.textAlign = "center";
  c2.textBaseline = "middle";
  c2.fillText(text, canvas.width / 2, canvas.height / 2 + 2);
  const texture = new THREE.CanvasTexture(canvas);
  texture.needsUpdate = true;
  const sprite = new THREE.Sprite(
    new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: false })
  );
  const scale = 0.006;
  sprite.scale.set(canvas.width * scale, canvas.height * scale, 1);
  return sprite;
}

/** Recursively frees geometries/materials/textures in a group. */
function disposeGroup(group: THREE.Object3D) {
  group.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (mesh.geometry) mesh.geometry.dispose();
    const mat = (mesh as any).material;
    if (Array.isArray(mat)) {
      mat.forEach((m: THREE.Material) => {
        if ((m as any).map) (m as any).map.dispose();
        m.dispose();
      });
    } else if (mat) {
      if ((mat as any).map) (mat as any).map.dispose();
      mat.dispose();
    }
  });
}
