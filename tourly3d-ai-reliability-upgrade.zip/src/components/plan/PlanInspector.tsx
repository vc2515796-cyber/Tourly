import { useMemo, useState } from "react";
import {
  Trash2,
  Upload,
  AlertTriangle,
  Ruler,
  Layers,
  Box,
  Eye,
  Info,
  DoorOpen,
  AppWindow,
  Armchair,
  RotateCcw,
} from "lucide-react";
import type { FloorPlanDocument, PlanFurnitureKind, PlanUnits } from "../../lib/plan/model";
import { formatArea, formatLength, furnitureLabel, PLAN_FURNITURE_KINDS } from "../../lib/plan/model";
import { floorBounds, polygonArea, polygonPerimeter, roomPoints, validateFloor, vertexById, wallSegment } from "../../lib/plan/geometry";
import { addFurniture, addOpening, applyCalibration, deleteFurniture, deleteOpening, deleteRoom, deleteWall, updateFurniture, updateOpening, updateRoom } from "../../lib/plan/ops";
import { CONCEPT_DISCLAIMER } from "../../lib/conceptPlan";
import type { PlanSelection } from "./PlanCanvas2D";
import type { Pt } from "../../lib/plan/geometry";

/**
 * Stage B2 — the inspector side panel: properties of the current selection,
 * scale calibration, floor management, honest measurement display and
 * validation feedback. All heavy lifting happens in lib/plan/ops.ts.
 */

type Props = {
  plan: FloorPlanDocument;
  selection: PlanSelection;
  onSelection: (sel: PlanSelection) => void;
  onDocChange: (next: FloorPlanDocument, commit: boolean) => void;
  stops: { id: string; title: string }[];
  calibPoints: Pt[] | null;
  onClearCalibPoints: () => void;
  onUploadBackground: (file: File) => void;
  onAddFloor: () => void;
  onSelectFloor: (floorId: string) => void;
  onDeleteFloor: (floorId: string) => void;
  onRenameFloor: (floorId: string, name: string) => void;
  /** Stage D: reset to the pristine AI-generated layout (concept plans). */
  onResetToGenerated?: () => void;
};

export default function PlanInspector({
  plan,
  selection,
  onSelection,
  onDocChange,
  stops,
  calibPoints,
  onClearCalibPoints,
  onUploadBackground,
  onAddFloor,
  onSelectFloor,
  onDeleteFloor,
  onRenameFloor,
  onResetToGenerated,
}: Props) {
  const floor = plan.floors.find((f) => f.id === plan.activeFloorId) ?? plan.floors[0]!;
  const resolve = useMemo(() => vertexById(floor.vertices), [floor.vertices]);
  const issues = useMemo(() => validateFloor(floor, resolve), [floor, resolve]);
  const [realLengthInput, setRealLengthInput] = useState("");
  const [unitsChoice, setUnitsChoice] = useState<PlanUnits>(plan.scale.units);

  const drawnLength =
    calibPoints && calibPoints.length >= 2
      ? Math.hypot(calibPoints[1]!.x - calibPoints[0]!.x, calibPoints[1]!.y - calibPoints[0]!.y)
      : null;

  function applyCalibrationFromInput() {
    if (drawnLength === null || !realLengthInput) return;
    const real = Number(realLengthInput);
    if (!Number.isFinite(real) || real <= 0 || drawnLength <= 0) return;
    onDocChange(applyCalibration(plan, real / drawnLength, real, drawnLength), true);
    setRealLengthInput("");
    onClearCalibPoints();
  }

  const room = selection?.kind === "room" ? floor.rooms.find((r) => r.id === selection.id) : undefined;
  const wall = selection?.kind === "wall" ? floor.walls.find((w) => w.id === selection.id) : undefined;
  const opening = selection?.kind === "opening" ? floor.openings.find((o) => o.id === selection.id) : undefined;
  const furnitureItem =
    selection?.kind === "furniture" ? (floor.furniture ?? []).find((f) => f.id === selection.id) : undefined;
  const [newFurnitureKind, setNewFurnitureKind] = useState<PlanFurnitureKind>("bed");

  return (
    <div className="flex w-full shrink-0 flex-col gap-4 overflow-y-auto border-t border-charcoal/10 bg-white/70 p-3 lg:w-80 lg:border-l lg:border-t-0">
      {/* selection properties */}
      <section>
        <p className="font-mono text-[11px] uppercase tracking-wider text-charcoal/40">Selection</p>
        {!selection && <p className="mt-1.5 text-[11px] text-charcoal/45">Click a room, wall, door, window or furniture item to edit it.</p>}

        {room && (
          <div className="mt-2 space-y-2 rounded-md border border-charcoal/10 bg-bone/60 p-2.5">
            <label className="block text-[10px] font-medium uppercase tracking-wide text-charcoal/40">Room name</label>
            <input
              value={room.name}
              onChange={(e) => onDocChange(updateRoom(plan, room.id, { name: e.target.value.slice(0, 60) }), false)}
              onBlur={() => onDocChange(plan, true)}
              className="w-full rounded border border-charcoal/15 bg-white px-2 py-1.5 text-xs outline-none focus:border-brass"
            />
            <label className="block text-[10px] font-medium uppercase tracking-wide text-charcoal/40">Linked tour scene</label>
            <select
              value={room.sceneStopId ?? ""}
              onChange={(e) =>
                onDocChange(updateRoom(plan, room.id, { sceneStopId: e.target.value || undefined }), true)
              }
              className="w-full rounded border border-charcoal/15 bg-white px-2 py-1.5 text-xs outline-none focus:border-brass"
            >
              <option value="">— none —</option>
              {stops.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.title || "Untitled scene"}
                </option>
              ))}
            </select>
            <div className="rounded bg-charcoal/5 p-2 text-[10px] leading-relaxed text-charcoal/55">
              <p className="flex items-center gap-1 font-medium text-charcoal/70">
                <Ruler size={10} /> Measurements
              </p>
              {plan.scale.calibrated ? (
                <p className="mt-1">
                  Computed (calibrated): {formatArea(plan.scale.units, polygonArea(roomPoints(room, resolve)))} ·{" "}
                  {formatLength(plan.scale.units, polygonPerimeter(roomPoints(room, resolve)))} perimeter
                </p>
              ) : (
                <p className="mt-1 text-amber-700">
                  Uncalibrated plan — computed sizes are hidden until you calibrate the scale (below). They would be
                  guesses otherwise.
                </p>
              )}
              <div className="mt-1.5 flex items-center gap-1">
                <input
                  value={room.manualDimensions ?? ""}
                  onChange={(e) =>
                    onDocChange(updateRoom(plan, room.id, { manualDimensions: e.target.value.slice(0, 40) || undefined }), false)
                  }
                  onBlur={() => onDocChange(plan, true)}
                  placeholder="e.g. 4.2 × 3.1 m (manual)"
                  className="min-w-0 flex-1 rounded border border-charcoal/15 bg-white px-1.5 py-1 text-[10px] outline-none focus:border-brass"
                />
              </div>
              <p className="mt-0.5 text-charcoal/40">Manual entries are always labelled “manual”, never shown as computed.</p>
            </div>
            <button
              onClick={() => {
                onDocChange(deleteRoom(plan, room.id), true);
                onSelection(null);
              }}
              className="flex w-full items-center justify-center gap-1.5 rounded border border-red-200 bg-red-50 px-2 py-1.5 text-[11px] font-medium text-red-600 hover:border-red-300"
            >
              <Trash2 size={11} /> Delete room (and its exclusive walls)
            </button>
          </div>
        )}

        {wall && (
          <div className="mt-2 space-y-2 rounded-md border border-charcoal/10 bg-bone/60 p-2.5">
            <p className="text-[11px] font-medium text-charcoal/70">Wall</p>
            <p className="text-[10px] text-charcoal/50">
              {plan.scale.calibrated
                ? `Length: ${formatLength(plan.scale.units, wallSegment(wall, resolve).length)} · thickness ${formatLength(plan.scale.units, wall.thickness)}`
                : `Drawn length: ${wallSegment(wall, resolve).length.toFixed(2)} units (calibrate to see real sizes)`}
            </p>
            <div className="flex gap-1.5">
              <button
                onClick={() => onDocChange(addOpening(plan, wall.id, "door", 0.5), true)}
                className="flex flex-1 items-center justify-center gap-1 rounded border border-charcoal/15 px-2 py-1.5 text-[10px] font-medium text-charcoal/65 hover:border-charcoal/30"
              >
                <DoorOpen size={11} /> Door
              </button>
              <button
                onClick={() => onDocChange(addOpening(plan, wall.id, "window", 0.5), true)}
                className="flex flex-1 items-center justify-center gap-1 rounded border border-charcoal/15 px-2 py-1.5 text-[10px] font-medium text-charcoal/65 hover:border-charcoal/30"
              >
                <AppWindow size={11} /> Window
              </button>
            </div>
            <button
              onClick={() => {
                onDocChange(deleteWall(plan, wall.id), true);
                onSelection(null);
              }}
              className="flex w-full items-center justify-center gap-1.5 rounded border border-red-200 bg-red-50 px-2 py-1.5 text-[11px] font-medium text-red-600 hover:border-red-300"
            >
              <Trash2 size={11} /> Delete wall
            </button>
          </div>
        )}

        {opening && (
          <div className="mt-2 space-y-2 rounded-md border border-charcoal/10 bg-bone/60 p-2.5">
            <p className="text-[11px] font-medium text-charcoal/70 capitalize">{opening.kind}</p>
            <div className="grid grid-cols-2 gap-2 text-[10px] text-charcoal/60">
              <label className="space-y-1">
                <span>Width ({plan.scale.units})</span>
                <input
                  type="number"
                  min={0.1}
                  step={0.1}
                  value={opening.width}
                  onChange={(e) => {
                    const w = Number(e.target.value);
                    if (w > 0) onDocChange(updateOpening(plan, opening.id, { width: w }), false);
                  }}
                  onBlur={() => onDocChange(plan, true)}
                  className="w-full rounded border border-charcoal/15 bg-white px-1.5 py-1 text-[10px]"
                />
              </label>
              <label className="space-y-1">
                <span>Height (m)</span>
                <input
                  type="number"
                  min={0.1}
                  step={0.1}
                  value={opening.height}
                  onChange={(e) => {
                    const h = Number(e.target.value);
                    if (h > 0) onDocChange(updateOpening(plan, opening.id, { height: h }), false);
                  }}
                  onBlur={() => onDocChange(plan, true)}
                  className="w-full rounded border border-charcoal/15 bg-white px-1.5 py-1 text-[10px]"
                />
              </label>
            </div>
            <button
              onClick={() => {
                onDocChange(deleteOpening(plan, opening.id), true);
                onSelection(null);
              }}
              className="flex w-full items-center justify-center gap-1.5 rounded border border-red-200 bg-red-50 px-2 py-1.5 text-[11px] font-medium text-red-600 hover:border-red-300"
            >
              <Trash2 size={11} /> Delete {opening.kind}
            </button>
          </div>
        )}

        {furnitureItem && (
          <div className="mt-2 space-y-2 rounded-md border border-charcoal/10 bg-bone/60 p-2.5">
            <p className="flex items-center gap-1 text-[11px] font-medium text-charcoal/70">
              <Armchair size={11} /> {furnitureLabel(furnitureItem.kind)}
              {furnitureItem.uncertain && (
                <span className="rounded bg-amber-100 px-1.5 py-0.5 text-[9px] font-medium text-amber-800">
                  AI-placed — review
                </span>
              )}
            </p>
            <label className="block text-[10px] font-medium uppercase tracking-wide text-charcoal/40">Kind</label>
            <select
              value={furnitureItem.kind}
              onChange={(e) =>
                onDocChange(
                  updateFurniture(plan, floor.id, furnitureItem.id, { kind: e.target.value as PlanFurnitureKind, uncertain: false }),
                  true
                )
              }
              className="w-full rounded border border-charcoal/15 bg-white px-2 py-1.5 text-xs outline-none focus:border-brass"
            >
              {PLAN_FURNITURE_KINDS.map((k) => (
                <option key={k} value={k}>
                  {furnitureLabel(k)}
                </option>
              ))}
            </select>
            <label className="block text-[10px] font-medium uppercase tracking-wide text-charcoal/40">Label (optional)</label>
            <input
              value={furnitureItem.label ?? ""}
              placeholder={furnitureLabel(furnitureItem.kind)}
              onChange={(e) =>
                onDocChange(
                  updateFurniture(plan, floor.id, furnitureItem.id, { label: e.target.value.slice(0, 40) || undefined }),
                  false
                )
              }
              onBlur={() => onDocChange(plan, true)}
              className="w-full rounded border border-charcoal/15 bg-white px-2 py-1.5 text-xs outline-none focus:border-brass"
            />
            <label className="flex items-center justify-between text-[10px] text-charcoal/60">
              Rotation {Math.round(furnitureItem.rotation)}°
              <input
                type="range"
                min={0}
                max={355}
                step={5}
                value={furnitureItem.rotation}
                onChange={(e) =>
                  onDocChange(updateFurniture(plan, floor.id, furnitureItem.id, { rotation: Number(e.target.value) }), false)
                }
                onMouseUp={() => onDocChange(plan, true)}
                onTouchEnd={() => onDocChange(plan, true)}
                className="ml-2 w-28 accent-brass"
              />
            </label>
            <div className="grid grid-cols-2 gap-2 text-[10px] text-charcoal/60">
              <label className="space-y-1">
                <span>Width (units)</span>
                <input
                  type="number"
                  min={0.1}
                  step={0.1}
                  value={furnitureItem.w}
                  onChange={(e) => {
                    const w = Number(e.target.value);
                    if (w > 0) onDocChange(updateFurniture(plan, floor.id, furnitureItem.id, { w, uncertain: false }), false);
                  }}
                  onBlur={() => onDocChange(plan, true)}
                  className="w-full rounded border border-charcoal/15 bg-white px-1.5 py-1 text-[10px]"
                />
              </label>
              <label className="space-y-1">
                <span>Depth (units)</span>
                <input
                  type="number"
                  min={0.1}
                  step={0.1}
                  value={furnitureItem.h}
                  onChange={(e) => {
                    const h = Number(e.target.value);
                    if (h > 0) onDocChange(updateFurniture(plan, floor.id, furnitureItem.id, { h, uncertain: false }), false);
                  }}
                  onBlur={() => onDocChange(plan, true)}
                  className="w-full rounded border border-charcoal/15 bg-white px-1.5 py-1 text-[10px]"
                />
              </label>
            </div>
            {!plan.scale.calibrated && (
              <p className="text-[9px] leading-relaxed text-amber-700">
                Sizes are nominal until the plan is calibrated — they are not measurements.
              </p>
            )}
            <button
              onClick={() => {
                onDocChange(deleteFurniture(plan, floor.id, furnitureItem.id), true);
                onSelection(null);
              }}
              className="flex w-full items-center justify-center gap-1.5 rounded border border-red-200 bg-red-50 px-2 py-1.5 text-[11px] font-medium text-red-600 hover:border-red-300"
            >
              <Trash2 size={11} /> Remove object
            </button>
          </div>
        )}

        {selection?.kind === "background" && floor.background && (
          <div className="mt-2 space-y-2 rounded-md border border-charcoal/10 bg-bone/60 p-2.5">
            <p className="flex items-center gap-1 text-[11px] font-medium text-charcoal/70">
              <Layers size={11} /> Blueprint underlay
            </p>
            <label className="flex items-center justify-between text-[10px] text-charcoal/60">
              Opacity
              <span className="font-mono">{Math.round(floor.background.opacity * 100)}%</span>
            </label>
            <input
              type="range"
              min={5}
              max={100}
              value={Math.round(floor.background.opacity * 100)}
              onChange={(e) =>
                onDocChange(
                  {
                    ...plan,
                    floors: plan.floors.map((f) =>
                      f.id === floor.id && f.background
                        ? { ...f, background: { ...f.background, opacity: Number(e.target.value) / 100 } }
                        : f
                    ),
                  },
                  false
                )
              }
              onMouseUp={() => onDocChange(plan, true)}
              onTouchEnd={() => onDocChange(plan, true)}
              className="w-full accent-brass"
            />
            <p className="text-[10px] leading-relaxed text-charcoal/45">
              Drag the image on the canvas to reposition it. It stays on its own layer — drawings are never baked into
              the picture.
            </p>
          </div>
        )}
      </section>

      {/* calibration */}
      <section className="rounded-md border border-dashed border-brass/40 bg-brass/5 p-2.5">
        <p className="flex items-center gap-1 font-mono text-[11px] uppercase tracking-wider text-charcoal/50">
          <Ruler size={11} className="text-brass" /> Scale calibration
        </p>
        {plan.scale.calibrated ? (
          <div className="mt-1.5 text-[10px] leading-relaxed text-charcoal/55">
            <p className="font-medium text-emerald-700">Calibrated ✓</p>
            <p>
              Reference: {formatLength(plan.scale.units, plan.scale.referenceLength ?? 0)} entered against{" "}
              {(plan.scale.drawnLength ?? 0).toFixed(2)} drawn units. Computed measurements are now shown.
            </p>
          </div>
        ) : (
          <div className="mt-1.5 space-y-2 text-[10px] leading-relaxed text-charcoal/55">
            <p>
              Pick the <b>Calibrate</b> tool and click two points whose real distance you know (e.g. a wall or a door).
            </p>
            {calibPoints && calibPoints.length >= 2 && drawnLength !== null && (
              <div className="space-y-1.5 rounded bg-white p-2">
                <p>
                  Drawn distance: <b>{drawnLength.toFixed(2)} units</b>
                </p>
                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    min={0.1}
                    step={0.1}
                    value={realLengthInput}
                    onChange={(e) => setRealLengthInput(e.target.value)}
                    placeholder="Real length"
                    className="min-w-0 flex-1 rounded border border-charcoal/15 px-1.5 py-1 text-[10px]"
                  />
                  <select
                    value={unitsChoice}
                    onChange={(e) => setUnitsChoice(e.target.value as PlanUnits)}
                    className="rounded border border-charcoal/15 px-1 py-1 text-[10px]"
                    aria-label="Units"
                  >
                    <option value="m">m</option>
                    <option value="ft">ft</option>
                  </select>
                  <button
                    onClick={applyCalibrationFromInput}
                    disabled={!realLengthInput}
                    className="rounded bg-brass px-2 py-1 font-semibold text-white disabled:opacity-40"
                  >
                    Apply
                  </button>
                </div>
                <p className="text-charcoal/40">The whole plan rescales proportionally — nothing is lost.</p>
              </div>
            )}
          </div>
        )}
      </section>

      {/* floors */}
      <section>
        <div className="flex items-center justify-between">
          <p className="font-mono text-[11px] uppercase tracking-wider text-charcoal/40">Floors</p>
          <button
            onClick={onAddFloor}
            className="flex items-center gap-1 text-[11px] font-medium text-brass hover:underline"
          >
            <Layers size={11} /> Add floor
          </button>
        </div>
        <ul className="mt-2 space-y-1.5">
          {plan.floors.map((f) => (
            <li
              key={f.id}
              className={`rounded-md border px-2 py-1.5 ${f.id === floor.id ? "border-brass bg-brass/10" : "border-charcoal/10 bg-bone/60"}`}
            >
              <div className="flex items-center gap-1.5">
                <button onClick={() => onSelectFloor(f.id)} className="min-w-0 flex-1 truncate text-left text-xs font-medium">
                  {f.name} · {f.rooms.length} room{f.rooms.length === 1 ? "" : "s"}
                </button>
                {plan.floors.length > 1 && (
                  <button
                    onClick={() => onDeleteFloor(f.id)}
                    className="rounded p-1 text-charcoal/30 hover:text-red-500"
                    title="Delete this floor"
                  >
                    <Trash2 size={11} />
                  </button>
                )}
              </div>
              {f.id === floor.id && (
                <input
                  value={f.name}
                  onChange={(e) => onRenameFloor(f.id, e.target.value.slice(0, 40))}
                  className="mt-1 w-full rounded border border-charcoal/15 bg-white px-1.5 py-1 text-[10px] outline-none focus:border-brass"
                  aria-label="Floor name"
                />
              )}
            </li>
          ))}
        </ul>
        <div className="mt-1.5 flex items-center gap-1.5">
          <label className="text-[10px] text-charcoal/50">3D wall height</label>
          <input
            type="number"
            min={1.5}
            max={6}
            step={0.1}
            value={plan.defaultWallHeight}
            onChange={(e) => {
              const h = Number(e.target.value);
              if (h >= 1.5 && h <= 6) onDocChange({ ...plan, defaultWallHeight: h }, false);
            }}
            onBlur={() => onDocChange(plan, true)}
            className="w-16 rounded border border-charcoal/15 bg-white px-1.5 py-1 text-[10px]"
          />
          <span className="text-[10px] text-charcoal/40">m (assumed — labelled in 3D)</span>
        </div>
      </section>

      {/* Stage D: add furniture */}
      <section>
        <p className="font-mono text-[11px] uppercase tracking-wider text-charcoal/40">Objects</p>
        <div className="mt-1.5 flex items-center gap-1.5">
          <select
            value={newFurnitureKind}
            onChange={(e) => setNewFurnitureKind(e.target.value as PlanFurnitureKind)}
            className="min-w-0 flex-1 rounded border border-charcoal/15 bg-white px-2 py-1.5 text-xs outline-none focus:border-brass"
            aria-label="Object kind"
          >
            {PLAN_FURNITURE_KINDS.map((k) => (
              <option key={k} value={k}>
                {furnitureLabel(k)}
              </option>
            ))}
          </select>
          <button
            onClick={() => {
              // Place at the middle of the current geometry (or a sensible
              // default for an empty floor) — the agent drags it from there.
              const b = floorBounds(floor);
              const at: Pt = b
                ? { x: (b.minX + b.maxX) / 2, y: (b.minY + b.maxY) / 2 }
                : { x: 2, y: 2 };
              const { plan: next, item } = addFurniture(plan, floor.id, newFurnitureKind, at);
              onDocChange(next, true);
              onSelection({ kind: "furniture", id: item.id });
            }}
            className="flex shrink-0 items-center gap-1 rounded-md bg-sage px-2.5 py-1.5 text-[11px] font-semibold text-white"
          >
            <Armchair size={11} /> Add
          </button>
        </div>
        <p className="mt-1 text-[10px] text-charcoal/45">
          Drag items on the canvas to arrange them. {(floor.furniture ?? []).length} item{(floor.furniture ?? []).length === 1 ? "" : "s"} on this floor.
        </p>
      </section>

      {/* Stage D: AI concept provenance + reset */}
      {plan.concept && (
        <section className="rounded-md border border-brass/40 bg-brass/5 p-2.5">
          <p className="font-mono text-[11px] uppercase tracking-wider text-charcoal/50">AI concept plan</p>
          <p className="mt-1.5 text-[10px] leading-relaxed text-charcoal/60">
            Generated from {plan.concept.sourceStopTitle ? `“${plan.concept.sourceStopTitle}”` : "a panorama"}
            {plan.concept.model ? ` (${plan.concept.model})` : ""} on{" "}
            {new Date(plan.concept.generatedAt).toLocaleDateString()}. Marked “{CONCEPT_DISCLAIMER}”.
          </p>
          {plan.concept.uncertaintyNotes.length > 0 && (
            <ul className="mt-1.5 space-y-1">
              {plan.concept.uncertaintyNotes.map((note, i) => (
                <li key={i} className="flex items-start gap-1 text-[10px] leading-relaxed text-amber-800">
                  <Info size={10} className="mt-0.5 shrink-0" /> {note}
                </li>
              ))}
            </ul>
          )}
          <p className="mt-1 text-[9px] leading-relaxed text-charcoal/45">
            Dashed items are AI-placed and unverified — review them, then edit or remove. Calibrate the scale only if
            you measure a real length.
          </p>
          {onResetToGenerated && plan.concept.generatedSnapshot && (
            <button
              onClick={() => {
                if (window.confirm("Reset to the AI-generated layout? Your edits to the plan will be reverted (undo works until save).")) {
                  onResetToGenerated();
                }
              }}
              className="mt-2 flex w-full items-center justify-center gap-1.5 rounded border border-charcoal/15 bg-white px-2 py-1.5 text-[11px] font-medium text-charcoal/70 hover:border-charcoal/30"
            >
              <RotateCcw size={11} /> Reset to generated layout
            </button>
          )}
        </section>
      )}

      {/* background upload */}
      <section>
        <p className="font-mono text-[11px] uppercase tracking-wider text-charcoal/40">Reference blueprint</p>
        <label className="mt-1.5 flex cursor-pointer items-center justify-center gap-1.5 rounded-md border border-charcoal/15 px-3 py-2 text-[11px] font-medium text-charcoal/60 hover:border-charcoal/30">
          <Upload size={11} /> {floor.background ? "Replace image" : "Upload image"}
          <input
            type="file"
            accept="image/jpeg,image/png,image/webp"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) onUploadBackground(file);
              e.target.value = "";
            }}
          />
        </label>
        {floor.background && (
          <p className="mt-1 flex items-center gap-1 text-[10px] text-charcoal/45">
            <Eye size={10} /> Underlay active — trace over it, then calibrate the scale from a known length.
            <button onClick={() => onSelection({ kind: "background" })} className="text-brass hover:underline">
              adjust
            </button>
          </p>
        )}
      </section>

      {/* validation */}
      {issues.length > 0 && (
        <section className="rounded-md border border-amber-200 bg-amber-50 p-2.5">
          <p className="flex items-center gap-1 text-[11px] font-semibold text-amber-800">
            <AlertTriangle size={12} /> Validation ({issues.filter((i) => i.level === "error").length} errors)
          </p>
          <ul className="mt-1.5 space-y-1">
            {issues.slice(0, 8).map((issue, i) => (
              <li key={i} className="flex items-start gap-1 text-[10px] leading-relaxed text-amber-800">
                {issue.level === "error" ? <AlertTriangle size={10} className="mt-0.5 shrink-0" /> : <Info size={10} className="mt-0.5 shrink-0" />}
                <span>
                  {floor.rooms.find((r) => r.id === issue.roomId)?.name ?? "Room"}: {issue.message}
                </span>
              </li>
            ))}
          </ul>
          <p className="mt-1 text-[9px] text-amber-700">
            Rooms with errors are drawn red and excluded from the 3D model until fixed.
          </p>
        </section>
      )}

      <div className="rounded-md bg-charcoal/5 p-2.5 text-[10px] leading-relaxed text-charcoal/50">
        <p className="flex items-start gap-1.5">
          <Box size={11} className="mt-0.5 shrink-0" />
          <span>
            The 3D view is generated from this exact geometry. Wall height is an assumption you set — Tourly never
            presents it as measured architecture.
          </span>
        </p>
      </div>
    </div>
  );
}
