import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Stage, Layer, Group, Line, Circle, Rect, Text as KText, Image as KonvaImage } from "react-konva";
import { Maximize2, ZoomIn, ZoomOut, Crosshair } from "lucide-react";
import type { FloorPlanDocument, PlanFloor, PlanFurniture, PlanOpening } from "../../lib/plan/model";
import { furnitureLabel } from "../../lib/plan/model";
import { CONCEPT_DISCLAIMER } from "../../lib/conceptPlan";
import {
  floorBounds,
  pointToSegment,
  polygonArea,
  polygonCentroid,
  roomPoints,
  validateRoomRing,
  vertexById,
  wallPieces,
  wallSegment,
  type Pt,
} from "../../lib/plan/geometry";
import {
  addOpening,
  addVertex,
  addWall,
  cleanupOrphanVertices,
  createRoom,
  moveFurniture,
  moveVertex,
  translateVertices,
} from "../../lib/plan/ops";

/**
 * Stage B2 — the interactive 2D floor-plan canvas (Konva).
 *
 * Everything drawn here is a projection of the FloorPlanDocument; every
 * mutation goes through the pure ops in lib/plan/ops.ts. Walls render from
 * the SAME wallPieces() the 3D dollhouse extrudes, so the two views cannot
 * disagree. Measurement labels appear only when the plan scale is
 * calibrated — never fabricated.
 */

export type PlanTool = "select" | "room" | "wall" | "door" | "window" | "calibrate" | "pan";

export type PlanSelection =
  | { kind: "room"; id: string }
  | { kind: "wall"; id: string }
  | { kind: "opening"; id: string }
  | { kind: "furniture"; id: string }
  | { kind: "background" }
  | null;

type Props = {
  plan: FloorPlanDocument;
  floor: PlanFloor;
  tool: PlanTool;
  selection: PlanSelection;
  onSelection: (sel: PlanSelection) => void;
  /** commit=true → push to undo history (end of a gesture); false = live preview */
  onDocChange: (next: FloorPlanDocument, commit: boolean) => void;
  onCalibratePoints: (a: Pt, b: Pt) => void;
  gridSnap: boolean;
  /** Stage D: exposes the Konva stage so PlanStudio can export a PNG. */
  onStageReady?: (stage: any | null) => void;
};

const GRID_UNIT = 1; // world units between major grid lines
const SNAP_GRID = 0.25; // snap resolution when enabled
const VERTEX_SNAP_PX = 10; // snap to a nearby corner within this many screen px
const WALL_CLICK_PX = 12; // clicking "on a wall" tolerance in screen px

export default function PlanCanvas2D({
  plan,
  floor,
  tool,
  selection,
  onSelection,
  onDocChange,
  onCalibratePoints,
  gridSnap,
  onStageReady,
}: Props) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const stageRef = useRef<any>(null);
  useEffect(() => {
    onStageReady?.(stageRef.current);
    return () => onStageReady?.(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const [size, setSize] = useState({ w: 800, h: 600 });
  const [view, setView] = useState({ x: 400, y: 300, scale: 60 }); // px per world unit
  const [bgImage, setBgImage] = useState<HTMLImageElement | null>(null);
  const [preview, setPreview] = useState<Pt | null>(null); // pointer while drawing
  const [draft, setDraft] = useState<{ points: { id: string; p: Pt }[] } | null>(null); // room being drawn
  const [wallDraft, setWallDraft] = useState<Pt | null>(null); // first click of wall tool
  const [calib, setCalib] = useState<Pt[]>([]); // calibration clicks
  /** Last two pointer-downs (used to reject SPURIOUS dblclicks: Konva/the
   *  browser can synthesize a dblclick from two fast clicks on the same
   *  TARGET even hundreds of px apart — which would close an in-progress
   *  ring early. A genuine double-click = two downs at nearly the same spot.) */
  const downsRef = useRef<{ x: number; y: number; t: number }[]>([]);
  const dragRef = useRef<
    | { mode: "vertex"; id: string }
    | { mode: "room"; id: string; last: Pt }
    | { mode: "background"; last: Pt }
    | { mode: "pan"; startClient: Pt; startView: { x: number; y: number } }
    | null
  >(null);

  // --- viewport sizing -------------------------------------------------------
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => {
      setSize({ w: el.clientWidth, h: el.clientHeight });
    });
    ro.observe(el);
    setSize({ w: el.clientWidth, h: el.clientHeight });
    return () => ro.disconnect();
  }, []);

  const fitToView = useCallback(() => {
    const b = floorBounds(floor);
    if (!b || size.w < 40) {
      setView({ x: size.w / 2, y: size.h / 2, scale: 60 });
      return;
    }
    const pad = 60;
    const sx = (size.w - pad * 2) / Math.max(b.maxX - b.minX, 0.001);
    const sy = (size.h - pad * 2) / Math.max(b.maxY - b.minY, 0.001);
    const scale = Math.max(5, Math.min(400, Math.min(sx, sy)));
    const cx = (b.minX + b.maxX) / 2;
    const cy = (b.minY + b.maxY) / 2;
    setView({ x: size.w / 2 - cx * scale, y: size.h / 2 - cy * scale, scale });
  }, [floor, size.w, size.h]);

  const didInitialFit = useRef(false);
  useEffect(() => {
    if (!didInitialFit.current && size.w > 100) {
      didInitialFit.current = true;
      fitToView();
    }
  }, [size.w, fitToView]);

  // --- background image ------------------------------------------------------
  useEffect(() => {
    if (!floor.background?.dataUrl) {
      setBgImage(null);
      return;
    }
    const img = new Image();
    img.onload = () => setBgImage(img);
    img.src = floor.background.dataUrl;
    return () => {
      img.onload = null;
    };
  }, [floor.background?.dataUrl]);

  // --- coordinate transforms ---------------------------------------------------
  const toWorld = useCallback(
    (clientX: number, clientY: number): Pt => {
      const stage = stageRef.current;
      if (!stage) return { x: 0, y: 0 };
      const rect = stage.container().getBoundingClientRect();
      const sx = clientX - rect.left;
      const sy = clientY - rect.top;
      return { x: (sx - view.x) / view.scale, y: (sy - view.y) / view.scale };
    },
    [view]
  );

  const snap = useCallback(
    (p: Pt): Pt => {
      if (!gridSnap) return p;
      return { x: Math.round(p.x / SNAP_GRID) * SNAP_GRID, y: Math.round(p.y / SNAP_GRID) * SNAP_GRID };
    },
    [gridSnap]
  );

  const snapToVertices = useCallback(
    (p: Pt): Pt | null => {
      const tol = VERTEX_SNAP_PX / view.scale;
      let best: Pt | null = null;
      let bestD = tol;
      for (const v of floor.vertices) {
        const d = Math.hypot(v.x - p.x, v.y - p.y);
        if (d < bestD) {
          bestD = d;
          best = { x: v.x, y: v.y };
        }
      }
      return best;
    },
    [floor.vertices, view.scale]
  );

  // --- derived geometry ---------------------------------------------------------
  const resolve = useMemo(() => vertexById(floor.vertices), [floor.vertices]);
  const roomsData = useMemo(
    () =>
      floor.rooms.map((room) => {
        const pts = roomPoints(room, resolve);
        const centroid = polygonCentroid(pts);
        const issues = validateRoomRing(room.id, pts);
        const area = polygonArea(pts);
        return { room, pts, centroid, issues, area };
      }),
    [floor.rooms, resolve]
  );
  const invalidRoomIds = useMemo(
    () => new Set(roomsData.filter((r) => r.issues.some((i) => i.level === "error")).map((r) => r.room.id)),
    [roomsData]
  );

  const wallsData = useMemo(
    () =>
      floor.walls.map((wall) => {
        const segment = wallSegment(wall, resolve);
        return { wall, segment, pieces: wallPieces(segment, floor.openings) };
      }),
    [floor.walls, floor.openings, resolve]
  );

  // --- zoom ---------------------------------------------------------------------
  const zoomAt = useCallback(
    (factor: number, anchor?: Pt) => {
      setView((v) => {
        const scale = Math.max(4, Math.min(500, v.scale * factor));
        const ax = anchor ? anchor.x : size.w / 2;
        const ay = anchor ? anchor.y : size.h / 2;
        const wx = (ax - v.x) / v.scale;
        const wy = (ay - v.y) / v.scale;
        return { scale, x: ax - wx * scale, y: ay - wy * scale };
      });
    },
    [size.w, size.h]
  );

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const rect = el.getBoundingClientRect();
      zoomAt(e.deltaY < 0 ? 1.12 : 1 / 1.12, { x: e.clientX - rect.left, y: e.clientY - rect.top });
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, [zoomAt]);

  // --- keyboard -------------------------------------------------------------------
  const cancelDraft = useCallback(() => {
    if (draft) {
      // Draft vertices were registered in the document as they were placed;
      // cancelling must not leave them behind as invisible orphans.
      onDocChange(cleanupOrphanVertices(plan), true);
    }
    setDraft(null);
    setWallDraft(null);
    setCalib([]);
    dragRef.current = null;
  }, [draft, plan, onDocChange]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        cancelDraft();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [cancelDraft]);

  // Changing tools abandons any in-progress drawing (with cleanup).
  useEffect(() => {
    cancelDraft();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tool]);

  // --- room ring completion (shared by first-point click and double-click) ------
  const closeDraft = useCallback(
    (vertexIds: string[]) => {
      if (vertexIds.length >= 3) {
        const { plan: withRoom } = createRoom(plan, { polygon: vertexIds });
        onDocChange(withRoom, true);
      } else if (vertexIds.length > 0) {
        onDocChange(cleanupOrphanVertices(plan), true);
      }
      setDraft(null);
    },
    [plan, onDocChange]
  );

  // --- pointer logic ---------------------------------------------------------------

  // Calibration: when the second point lands, hand the pair to the inspector
  // (which shows the drawn length + the real-length input).
  useEffect(() => {
    if (calib.length >= 2) {
      onCalibratePoints(calib[0]!, calib[1]!);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [calib.length]);

  const hitWallAt = useCallback(
    (p: Pt): { wallId: string; t: number } | null => {
      const tol = WALL_CLICK_PX / view.scale;
      let best: { wallId: string; t: number } | null = null;
      let bestD = tol;
      for (const { wall, segment } of wallsData) {
        const { dist, t } = pointToSegment(p, segment.a, segment.b);
        if (dist < bestD) {
          bestD = dist;
          best = { wallId: wall.id, t };
        }
      }
      return best;
    },
    [wallsData, view.scale]
  );

  const handleStageDown = useCallback(
    (clientX: number, clientY: number, button: number) => {
      const world = toWorld(clientX, clientY);
      downsRef.current = [...downsRef.current.slice(-1), { x: clientX, y: clientY, t: performance.now() }];

      if (tool === "pan" || button === 1) {
        dragRef.current = { mode: "pan", startClient: { x: clientX, y: clientY }, startView: { x: view.x, y: view.y } };
        return;
      }

      if (tool === "calibrate") {
        const snapped = snapToVertices(world) ?? snap(world);
        setCalib((prev) => (prev.length >= 2 ? [snapped] : [...prev, snapped]));
        return;
      }

      if (tool === "room") {
        const snappedRaw = snapToVertices(world) ?? snap(world);
        // Close the ring when clicking near the first point (or its vertex).
        if (draft && draft.points.length >= 3) {
          const first = draft.points[0]!;
          if (Math.hypot(first.p.x - snappedRaw.x, first.p.y - snappedRaw.y) < VERTEX_SNAP_PX / view.scale) {
            closeDraft(draft.points.map((d) => d.id));
            return;
          }
        }
        // Ignore a click that lands on the just-placed corner (dbl-click close).
        const last = draft?.points[draft.points.length - 1];
        if (last && Math.hypot(last.p.x - snappedRaw.x, last.p.y - snappedRaw.y) < 1e-9) return;
        const { plan: nextPlan, vertexId } = addVertex(plan, snappedRaw, VERTEX_SNAP_PX / view.scale);
        setDraft((prev) => ({
          points: prev ? [...prev.points, { id: vertexId, p: snappedRaw }] : [{ id: vertexId, p: snappedRaw }],
        }));
        onDocChange(nextPlan, false);
        return;
      }

      if (tool === "wall") {
        const snapped = snapToVertices(world) ?? snap(world);
        if (!wallDraft) {
          setWallDraft(snapped);
        } else {
          const { plan: p1, vertexId: aId } = addVertex(plan, wallDraft, VERTEX_SNAP_PX / view.scale);
          const { plan: p2, vertexId: bId } = addVertex(p1, snapped, VERTEX_SNAP_PX / view.scale);
          const { plan: withWall } = addWall(p2, aId, bId, plan.defaultWallThickness);
          onDocChange(withWall, true);
          setWallDraft(null);
        }
        return;
      }

      if (tool === "door" || tool === "window") {
        const hit = hitWallAt(world);
        if (hit) {
          onDocChange(addOpening(plan, hit.wallId, tool, hit.t), true);
        }
        return;
      }

      // select tool: hit tests happen on the shapes themselves (below);
      // clicking empty space clears the selection.
      onSelection(null);
    },
    [tool, draft, wallDraft, plan, snap, snapToVertices, toWorld, view.scale, hitWallAt, onDocChange, onSelection]
  );

  const handleStageMove = useCallback(
    (clientX: number, clientY: number) => {
      const world = toWorld(clientX, clientY);
      setPreview(tool === "room" || tool === "wall" || tool === "calibrate" ? world : null);

      const drag = dragRef.current;
      if (!drag) return;
      if (drag.mode === "pan") {
        const dx = clientX - drag.startClient.x;
        const dy = clientY - drag.startClient.y;
        setView((v) => ({ ...v, x: drag.startView.x + dx, y: drag.startView.y + dy }));
        return;
      }
      if (drag.mode === "vertex") {
        const target = snapToVertices(world) ?? snap(world);
        // Don't snap the dragged vertex onto itself.
        const current = floor.vertices.find((v) => v.id === drag.id);
        const snapped =
          current && target && Math.hypot(current.x - target.x, current.y - target.y) < 1e-9 ? snap(world) : target;
        onDocChange(moveVertex(plan, drag.id, snapped), false);
        return;
      }
      if (drag.mode === "room") {
        const d = { x: world.x - drag.last.x, y: world.y - drag.last.y };
        const room = floor.rooms.find((r) => r.id === drag.id);
        if (room && (Math.abs(d.x) > 1e-9 || Math.abs(d.y) > 1e-9)) {
          onDocChange(translateVertices(plan, room.polygon, d.x, d.y), false);
          dragRef.current = { ...drag, last: world };
        }
        return;
      }
      if (drag.mode === "background" && floor.background) {
        const d = { x: world.x - drag.last.x, y: world.y - drag.last.y };
        onDocChange(
          {
            ...plan,
            floors: plan.floors.map((f) =>
              f.id === floor.id && f.background
                ? { ...f, background: { ...f.background, x: f.background.x + d.x, y: f.background.y + d.y } }
                : f
            ),
          },
          false
        );
        dragRef.current = { ...drag, last: world };
      }
    },
    [tool, toWorld, plan, floor, snap, snapToVertices, onDocChange]
  );

  const handleStageUp = useCallback(() => {
    const drag = dragRef.current;
    dragRef.current = null;
    if (drag && drag.mode !== "pan") {
      onDocChange(plan, true); // commit the finished gesture to history
    }
  }, [plan, onDocChange]);

  const bindPointing = {
    onMouseDown: (e: any) => {
      if (e.evt.button === 0 || e.evt.button === 1) {
        e.evt.preventDefault();
        handleStageDown(e.evt.clientX, e.evt.clientY, e.evt.button);
      }
    },
    onTouchStart: (e: any) => {
      const t = e.evt.touches[0];
      if (t) {
        e.evt.preventDefault();
        handleStageDown(t.clientX, t.clientY, 0);
      }
    },
    onMouseMove: (e: any) => handleStageMove(e.evt.clientX, e.evt.clientY),
    onTouchMove: (e: any) => {
      const t = e.evt.touches[0];
      if (t) handleStageMove(t.clientX, t.clientY);
    },
    onMouseUp: handleStageUp,
    onTouchEnd: handleStageUp,
    onMouseLeave: handleStageUp,
  };

  const handleStageDblClick = useCallback(
    (e?: any) => {
      if (tool !== "room" || !draft || draft.points.length < 3) return;
      // Genuineness guard: a real double-click means the last two pointer
      // DOWNS were at (nearly) the same spot. Fast corner-by-corner drawing
      // produces downs at different spots that Konva/the browser can still
      // report as dblclick (same target, within the double-click time) —
      // those must NOT close the ring.
      const downs = downsRef.current;
      if (downs.length < 2) return;
      const [a, b] = downs.slice(-2);
      if (Math.hypot(a!.x - b!.x, a!.y - b!.y) > 6) return; // not in-place
      closeDraft(draft.points.map((d) => d.id));
    },
    [tool, draft, closeDraft]
  );

  // --- grid lines -------------------------------------------------------------------
  const gridLines = useMemo(() => {
    if (view.scale < 14) return [];
    const lines: { x1: number; y1: number; x2: number; y2: number; major: boolean }[] = [];
    const half = Math.max(size.w, size.h) / view.scale;
    const cx = (size.w / 2 - view.x) / view.scale;
    const cy = (size.h / 2 - view.y) / view.scale;
    const x0 = Math.floor(cx - half);
    const x1 = Math.ceil(cx + half);
    const y0 = Math.floor(cy - half);
    const y1 = Math.ceil(cy + half);
    for (let x = x0; x <= x1; x++) {
      lines.push({ x1: x, y1: y0, x2: x, y2: y1, major: x % 5 === 0 });
    }
    for (let y = y0; y <= y1; y++) {
      lines.push({ x1: x0, y1: y, x2: x1, y2: y, major: y % 5 === 0 });
    }
    return lines;
  }, [view, size.w, size.h]);

  const w2s = (p: Pt) => ({ x: p.x * view.scale + view.x, y: p.y * view.scale + view.y });

  // --- opening symbols ----------------------------------------------------------------
  const renderOpening = (opening: PlanOpening, key: string) => {
    const data = wallsData.find((w) => w.wall.id === opening.wallId);
    if (!data) return null;
    // Match the opening to its rendered position by t along the wall.
    const t = Math.max(0, Math.min(1, opening.t));
    const center = {
      x: data.segment.a.x + (data.segment.b.x - data.segment.a.x) * t,
      y: data.segment.a.y + (data.segment.b.y - data.segment.a.y) * t,
    };
    const angleDeg = (data.segment.angle * 180) / Math.PI;
    const isSelected = selection?.kind === "opening" && selection.id === opening.id;
    const s = w2s(center);
    return (
      <Group key={key} x={s.x} y={s.y} rotation={angleDeg}>
        <Rect
          width={opening.width * view.scale}
          height={Math.max(2, (data.wall.thickness + 0.05) * view.scale)}
          offsetX={(opening.width * view.scale) / 2}
          offsetY={Math.max(2, (data.wall.thickness + 0.05) * view.scale) / 2}
          fill={opening.kind === "door" ? "#ffffff" : "#cfe8ff"}
          stroke={isSelected ? "#c98a3e" : opening.kind === "door" ? "#8a7a5c" : "#5c8ab8"}
          strokeWidth={isSelected ? 2.5 : 1}
        />
        {opening.kind === "door" && (
          <Line
            points={[0, 0, 0, -opening.width * view.scale, opening.width * view.scale / 2, -opening.width * view.scale]}
            stroke="#8a7a5c"
            strokeWidth={1}
            listening={false}
          />
        )}
        {opening.kind === "window" && (
          <Line points={[-(opening.width * view.scale) / 2, 0, (opening.width * view.scale) / 2, 0]} stroke="#5c8ab8" strokeWidth={1} listening={false} />
        )}
        <Rect
          width={Math.max(10, opening.width * view.scale + 8)}
          height={Math.max(10, (data.wall.thickness + 0.12) * view.scale)}
          offsetX={Math.max(10, opening.width * view.scale + 8) / 2}
          offsetY={Math.max(10, (data.wall.thickness + 0.12) * view.scale) / 2}
          fill="transparent"
          onMouseDown={(e: any) => {
            if (tool === "select" && e.evt.button === 0) {
              e.cancelBubble = true;
              onSelection({ kind: "opening", id: opening.id });
            }
          }}
          onTouchStart={(e: any) => {
            if (tool === "select") {
              e.cancelBubble = true;
              onSelection({ kind: "opening", id: opening.id });
            }
          }}
        />
      </Group>
    );
  };

  const cursorClass =
    tool === "select" ? "cursor-default" : tool === "pan" ? "cursor-grab" : "cursor-crosshair";

  return (
    <div className="relative min-h-0 flex-1 overflow-hidden rounded-lg border border-charcoal/15 bg-white" ref={wrapRef}>
      <Stage
        ref={stageRef}
        width={size.w}
        height={size.h}
        className={cursorClass}
        {...bindPointing}
        onDblClick={handleStageDblClick}
        onDblTap={handleStageDblClick}
      >
        <Layer>
          {/* grid */}
          {gridLines.map((l, i) => (
            <Line
              key={`g${i}`}
              points={[w2s({ x: l.x1, y: l.y1 }).x, w2s({ x: l.x1, y: l.y1 }).y, w2s({ x: l.x2, y: l.y2 }).x, w2s({ x: l.x2, y: l.y2 }).y]}
              stroke={l.major ? "rgba(60,50,35,0.13)" : "rgba(60,50,35,0.06)"}
              strokeWidth={1}
              listening={false}
            />
          ))}

          {/* blueprint underlay (own layer, adjustable) */}
          {bgImage && floor.background && (
            <KonvaImage
              image={bgImage}
              x={w2s({ x: floor.background.x, y: floor.background.y }).x}
              y={w2s({ x: floor.background.x, y: floor.background.y }).y}
              width={floor.background.w * view.scale}
              height={floor.background.h * view.scale}
              opacity={floor.background.opacity}
              onMouseDown={(e: any) => {
                if (tool === "select" && e.evt.button === 0) {
                  e.cancelBubble = true;
                  onSelection({ kind: "background" });
                  const world = toWorld(e.evt.clientX, e.evt.clientY);
                  dragRef.current = { mode: "background", last: world };
                }
              }}
              onTouchStart={(e: any) => {
                if (tool === "select") {
                  e.cancelBubble = true;
                  onSelection({ kind: "background" });
                  const t = e.evt.touches[0];
                  if (t) dragRef.current = { mode: "background", last: toWorld(t.clientX, t.clientY) };
                }
              }}
            />
          )}

          {/* rooms */}
          {roomsData.map(({ room, pts, centroid, area }) => {
            const flat = pts.flatMap((p) => [w2s(p).x, w2s(p).y]);
            const selected = selection?.kind === "room" && selection.id === room.id;
            const invalid = invalidRoomIds.has(room.id);
            const c = w2s(centroid);
            const label =
              room.name +
              (plan.scale.calibrated ? `\n${area.toFixed(1)} ${plan.scale.units === "ft" ? "sq ft" : "m²"}` : "") +
              (room.manualDimensions ? `\n(${room.manualDimensions} — manual)` : "");
            return (
              <Group key={room.id}>
                <Line
                  points={flat}
                  closed
                  fill={invalid ? "rgba(220,80,60,0.12)" : selected ? "rgba(201,138,62,0.18)" : "rgba(60,50,35,0.05)"}
                  stroke={invalid ? "#dc503c" : selected ? "#c98a3e" : "rgba(60,50,35,0.35)"}
                  strokeWidth={selected || invalid ? 2.5 : 1.5}
                  onMouseDown={(e: any) => {
                    if (tool === "select" && e.evt.button === 0) {
                      e.cancelBubble = true;
                      onSelection({ kind: "room", id: room.id });
                      dragRef.current = { mode: "room", id: room.id, last: toWorld(e.evt.clientX, e.evt.clientY) };
                    }
                  }}
                  onTouchStart={(e: any) => {
                    if (tool === "select") {
                      e.cancelBubble = true;
                      onSelection({ kind: "room", id: room.id });
                      const t = e.evt.touches[0];
                      if (t) dragRef.current = { mode: "room", id: room.id, last: toWorld(t.clientX, t.clientY) };
                    }
                  }}
                />
                <KText
                  x={c.x}
                  y={c.y - (plan.scale.calibrated || room.manualDimensions ? 18 : 8)}
                  text={label}
                  fontSize={Math.max(10, Math.min(14, view.scale * 0.22))}
                  fontFamily="inherit"
                  fill={invalid ? "#dc503c" : "#3a3227"}
                  align="center"
                  listening={false}
                />
              </Group>
            );
          })}

          {/* walls (shared core with the 3D viewer) */}
          {wallsData.map(({ wall, segment, pieces }) => {
            const selected = selection?.kind === "wall" && selection.id === wall.id;
            return (
              <Group key={wall.id}>
                {pieces.map((piece, i) => {
                  const a = w2s(piece.start);
                  const b = w2s(piece.end);
                  if (piece.kind === "wall") {
                    return (
                      <Line
                        key={i}
                        points={[a.x, a.y, b.x, b.y]}
                        stroke={selected ? "#c98a3e" : "#3a3227"}
                        strokeWidth={Math.max(2, wall.thickness * view.scale)}
                        lineCap="butt"
                        onMouseDown={(e: any) => {
                          if (tool === "select" && e.evt.button === 0) {
                            e.cancelBubble = true;
                            onSelection({ kind: "wall", id: wall.id });
                          }
                          if ((tool === "door" || tool === "window") && e.evt.button === 0) {
                            e.cancelBubble = true;
                            const hit = pointToSegment(toWorld(e.evt.clientX, e.evt.clientY), segment.a, segment.b);
                            onDocChange(addOpening(plan, wall.id, tool, hit.t), true);
                          }
                        }}
                        onTouchStart={(e: any) => {
                          if (tool === "select") {
                            e.cancelBubble = true;
                            onSelection({ kind: "wall", id: wall.id });
                          }
                          if (tool === "door" || tool === "window") {
                            e.cancelBubble = true;
                            const t = e.evt.touches[0];
                            if (t) {
                              const hit = pointToSegment(toWorld(t.clientX, t.clientY), segment.a, segment.b);
                              onDocChange(addOpening(plan, wall.id, tool, hit.t), true);
                            }
                          }
                        }}
                      />
                    );
                  }
                  return null; // gaps are rendered by the opening symbols below
                })}
              </Group>
            );
          })}

          {/* openings */}
          {floor.openings.map((o) => renderOpening(o, o.id))}

          {/* vertices */}
          {view.scale > 18 &&
            floor.vertices.map((v) => {
              const s = w2s(v);
              return (
                <Circle
                  key={v.id}
                  x={s.x}
                  y={s.y}
                  radius={Math.max(3, Math.min(7, view.scale * 0.09))}
                  fill="#ffffff"
                  stroke="#3a3227"
                  strokeWidth={1.5}
                  onMouseDown={(e: any) => {
                    if (tool === "select" && e.evt.button === 0) {
                      e.cancelBubble = true;
                      dragRef.current = { mode: "vertex", id: v.id };
                    }
                  }}
                  onTouchStart={(e: any) => {
                    if (tool === "select") {
                      e.cancelBubble = true;
                      dragRef.current = { mode: "vertex", id: v.id };
                    }
                  }}
                />
              );
            })}

          {/* drawing previews */}
          {draft && draft.points.length > 0 && (
            <Group listening={false}>
              <Line
                points={draft.points.flatMap((d) => [w2s(d.p).x, w2s(d.p).y])}
                stroke="#c98a3e"
                strokeWidth={2}
                dash={[6, 4]}
              />
              {preview && (
                <Line
                  points={[
                    w2s(draft.points[draft.points.length - 1]!.p).x,
                    w2s(draft.points[draft.points.length - 1]!.p).y,
                    w2s(snap(preview)).x,
                    w2s(snap(preview)).y,
                  ]}
                  stroke="#c98a3e"
                  strokeWidth={1.5}
                  dash={[4, 4]}
                  opacity={0.7}
                />
              )}
              <Circle x={w2s(draft.points[0]!.p).x} y={w2s(draft.points[0]!.p).y} radius={6} stroke="#c98a3e" strokeWidth={2} />
              {draft.points.map((d, i) => (
                <Circle key={i} x={w2s(d.p).x} y={w2s(d.p).y} radius={3.5} fill="#c98a3e" />
              ))}
            </Group>
          )}

          {wallDraft && preview && (
            <Line
              listening={false}
              points={[w2s(wallDraft).x, w2s(wallDraft).y, w2s(snap(preview)).x, w2s(snap(preview)).y]}
              stroke="#5c8ab8"
              strokeWidth={Math.max(2, plan.defaultWallThickness * view.scale)}
              opacity={0.6}
            />
          )}

          {calib.length === 1 && (
            <Circle listening={false} x={w2s(calib[0]!).x} y={w2s(calib[0]!).y} radius={5} stroke="#dc503c" strokeWidth={2} />
          )}
          {calib.length >= 2 && (
            <Line
              listening={false}
              points={[w2s(calib[0]!).x, w2s(calib[0]!).y, w2s(calib[1]!).x, w2s(calib[1]!).y]}
              stroke="#dc503c"
              strokeWidth={2}
              dash={[8, 5]}
            />
          )}

          {/* Stage D: furniture (AI concept + user-placed) */}
          {(floor.furniture ?? []).map((f: PlanFurniture) => {
            const s = w2s({ x: f.x, y: f.y });
            const isSelected = selection?.kind === "furniture" && selection.id === f.id;
            const px = { w: Math.max(6, f.w * view.scale), h: Math.max(6, f.h * view.scale) };
            return (
              <Group
                key={f.id}
                x={s.x}
                y={s.y}
                rotation={f.rotation}
                draggable={tool === "select"}
                onDragStart={() => {
                  if (tool === "select") onSelection({ kind: "furniture", id: f.id });
                }}
                onDragEnd={(e: any) => {
                  if (tool !== "select") return;
                  const node = e.target;
                  const world = snap({
                    x: (node.x() - view.x) / view.scale,
                    y: (node.y() - view.y) / view.scale,
                  });
                  node.position({ x: world.x * view.scale + view.x, y: world.y * view.scale + view.y });
                  onDocChange(moveFurniture(plan, floor.id, f.id, world), true);
                }}
              >
                <Rect
                  width={px.w}
                  height={px.h}
                  offsetX={px.w / 2}
                  offsetY={px.h / 2}
                  cornerRadius={Math.min(4, px.w / 6)}
                  fill={isSelected ? "rgba(201,138,62,0.25)" : f.uncertain ? "rgba(60,50,35,0.07)" : "rgba(60,50,35,0.12)"}
                  stroke={isSelected ? "#c98a3e" : f.uncertain ? "rgba(60,50,35,0.5)" : "#3a3227"}
                  strokeWidth={isSelected ? 2.5 : 1}
                  dash={f.uncertain ? [5, 4] : undefined}
                />
                {px.w > 26 && px.h > 12 && (
                  <KText
                    text={f.label || furnitureLabel(f.kind)}
                    fontSize={Math.max(8, Math.min(11, view.scale * 0.16))}
                    fontFamily="inherit"
                    fill={f.uncertain ? "rgba(60,50,35,0.55)" : "#3a3227"}
                    align="center"
                    verticalAlign="middle"
                    width={px.w}
                    height={px.h}
                    offsetX={px.w / 2}
                    offsetY={px.h / 2}
                    listening={false}
                  />
                )}
                {/* invisible hit area so tiny items stay grabbable */}
                <Rect width={px.w + 10} height={px.h + 10} offsetX={(px.w + 10) / 2} offsetY={(px.h + 10) / 2} fill="transparent" />
              </Group>
            );
          })}

          {/* Stage D: concept-plan watermark — ALWAYS on AI-origin plans */}
          {plan.concept && (
            <Group listening={false}>
              <Rect
                x={size.w / 2 - 150}
                y={6}
                width={300}
                height={22}
                cornerRadius={4}
                fill="rgba(255,255,255,0.85)"
                stroke="rgba(201,138,62,0.6)"
                strokeWidth={1}
              />
              <KText
                x={size.w / 2}
                y={17}
                text={CONCEPT_DISCLAIMER + (plan.scale.calibrated ? " — scale calibrated by owner" : "")}
                fontSize={11}
                fontStyle="600"
                fontFamily="inherit"
                fill="#8a6a2e"
                align="center"
                verticalAlign="middle"
              />
            </Group>
          )}

          {/* empty-state hint */}
          {floor.vertices.length === 0 && !draft && (
            <KText
              x={size.w / 2}
              y={size.h / 2 - 30}
              text={
                tool === "room"
                  ? "Click to place corners — click the first point (or double-click) to close the room"
                  : "Pick the Room tool to start drawing, upload a blueprint as a reference layer — or use AI concept (top right)"
              }
              fontSize={13}
              fill="rgba(60,50,35,0.45)"
              align="center"
              listening={false}
            />
          )}
        </Layer>
      </Stage>

      {/* viewport controls */}
      <div className="absolute bottom-3 right-3 flex flex-col gap-1 rounded-lg border border-charcoal/10 bg-white/90 p-1 shadow-sm">
        <button onClick={() => zoomAt(1.25)} className="rounded p-1.5 text-charcoal/60 hover:bg-charcoal/5" title="Zoom in" aria-label="Zoom in">
          <ZoomIn size={14} />
        </button>
        <button onClick={() => zoomAt(1 / 1.25)} className="rounded p-1.5 text-charcoal/60 hover:bg-charcoal/5" title="Zoom out" aria-label="Zoom out">
          <ZoomOut size={14} />
        </button>
        <button onClick={fitToView} className="rounded p-1.5 text-charcoal/60 hover:bg-charcoal/5" title="Fit to view" aria-label="Fit to view">
          <Maximize2 size={14} />
        </button>
      </div>
      <div className="pointer-events-none absolute left-3 top-3 flex items-center gap-1.5 rounded-md bg-white/85 px-2 py-1 font-mono text-[10px] text-charcoal/55">
        <Crosshair size={10} />
        {Math.round(view.scale)} px / {plan.scale.units === "ft" ? "ft" : "m"}
        {plan.scale.calibrated ? " · calibrated" : " · uncalibrated"}
      </div>
    </div>
  );
}
