import React, { useMemo, useState } from "react";
import { Sparkles, Loader2, AlertTriangle, CheckCircle2, Image as ImageIcon, Wand2 } from "lucide-react";
import type { Tour } from "../../types";
import { analyzeFloorPlan, preparePanorama } from "../../lib/analyzeFloorPlan";
import type { ConceptAnalysis } from "../../lib/conceptPlan";
import { CONCEPT_DISCLAIMER } from "../../lib/conceptPlan";

/**
 * Stage D (Phase 5A/5E) — the AI Concept Floor Plan generator panel.
 *
 * Flow: pick one 360° panorama stop → preview it (with the honesty note
 * about what a single panorama CAN'T reveal) → Generate → the validated
 * analysis is handed to PlanStudio, which converts it into editable plan
 * geometry. Regenerating an existing plan always asks for confirmation,
 * and a FAILED regeneration never touches the current plan.
 */

type Props = {
  tour: Tour;
  /** True when the current plan already has content (regeneration guard). */
  planHasContent: boolean;
  onGenerated: (analysis: ConceptAnalysis, source: { stopId: string; stopTitle?: string }) => void;
  onClose: () => void;
};

type Phase = "pick" | "preparing" | "analyzing" | "error";

export default function ConceptGenerator({ tour, planHasContent, onGenerated, onClose }: Props) {
  const panoramaStops = useMemo(
    () => tour.stops.filter((s) => s.media?.kind === "panorama" && Boolean(s.media?.dataUrl || s.media?.url)),
    [tour.stops]
  );
  const [stopId, setStopId] = useState<string>(panoramaStops[0]?.id ?? "");
  const [phase, setPhase] = useState<Phase>(panoramaStops.length ? "pick" : "error");
  const [error, setError] = useState<string | null>(
    panoramaStops.length ? null : "This tour has no 360° panorama scenes yet — upload one first, then come back."
  );
  const [confirmRegen, setConfirmRegen] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);

  const selected = panoramaStops.find((s) => s.id === stopId) ?? null;
  const busy = phase === "preparing" || phase === "analyzing";

  async function loadPreview(id: string) {
    setStopId(id);
    setPreview(null);
    const stop = panoramaStops.find((s) => s.id === id);
    if (!stop?.media?.dataUrl) return; // cloud-only media: no local preview
    const prepared = await preparePanorama(stop.media.dataUrl).catch(() => null);
    if (prepared?.ok) setPreview(prepared.previewDataUrl);
  }

  async function generate() {
    if (!selected) return;
    if (planHasContent && !confirmRegen) {
      setConfirmRegen(true);
      return;
    }
    setConfirmRegen(false);
    setPhase("preparing");
    setError(null);
    // Local media required: the analysis needs the actual pixels. Cloud-only
    // panoramas (media.url without dataUrl) are rejected with a clear reason
    // instead of silently analysing a thumbnail.
    if (!selected.media?.dataUrl) {
      setPhase("error");
      setError("This panorama is only stored in the cloud — open the scene and re-add the image locally to analyse it.");
      return;
    }
    setPhase("analyzing");
    const result = await analyzeFloorPlan(selected.media.dataUrl);
    if (!result.ok) {
      // The existing plan is untouched — a failed regeneration never
      // destroys the current layout.
      setPhase("error");
      setError(result.error);
      return;
    }
    onGenerated(result.analysis, { stopId: selected.id, stopTitle: selected.title });
  }

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-ink/70 p-4">
      <div className="flex max-h-[90vh] w-full max-w-lg flex-col overflow-hidden rounded-xl bg-bone shadow-2xl">
        <div className="flex items-center justify-between border-b border-charcoal/10 px-4 py-3">
          <div className="flex items-center gap-2">
            <Wand2 size={15} className="text-brass" />
            <h3 className="font-display text-sm font-semibold">AI concept floor plan</h3>
          </div>
          <button
            onClick={busy ? undefined : onClose}
            disabled={busy}
            className="rounded p-1 text-charcoal/40 hover:text-charcoal disabled:opacity-30"
            aria-label="Close"
          >
            ✕
          </button>
        </div>

        <div className="flex-1 space-y-3 overflow-y-auto px-4 py-4">
          {/* honesty note — always visible, not a tooltip */}
          <div className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-[11px] leading-relaxed text-amber-800">
            One panorama cannot reveal every wall or establish exact measurements. The result is an
            editable <b>concept sketch</b> of the visible room, marked “{CONCEPT_DISCLAIMER}” —
            uncertain items (occluded or behind the camera) are drawn dashed for your review.
          </div>

          {panoramaStops.length > 0 && (
            <label className="block">
              <span className="text-[11px] font-medium text-charcoal/70">360° panorama scene</span>
              <select
                value={stopId}
                onChange={(e) => void loadPreview(e.target.value)}
                disabled={busy}
                className="mt-1 w-full rounded-md border border-charcoal/15 bg-white px-2.5 py-2 text-xs text-charcoal disabled:opacity-50"
              >
                {panoramaStops.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.title || "Untitled scene"}
                  </option>
                ))}
              </select>
            </label>
          )}

          {preview ? (
            <div className="overflow-hidden rounded-lg border border-charcoal/10 bg-white">
              <img src={preview} alt="Selected panorama preview" className="h-32 w-full object-cover" />
            </div>
          ) : (
            selected && (
              <div className="flex h-20 items-center justify-center gap-2 rounded-lg border border-dashed border-charcoal/20 text-[11px] text-charcoal/50">
                <ImageIcon size={14} /> preview unavailable (cloud-stored panorama)
              </div>
            )
          )}

          {phase === "error" && error && (
            <div className="flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-[11px] text-red-700">
              <AlertTriangle size={13} className="mt-0.5 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {confirmRegen && (
            <div className="rounded-lg border border-amber-300 bg-amber-50 px-3 py-2.5 text-[11px] text-amber-900">
              <p className="font-medium">Replace the current plan with a new AI concept?</p>
              <p className="mt-1 text-amber-800">
                Your current layout will be replaced (undo works until the plan saves; the previous
                saved version stays in the tour history). If the new analysis fails, the current plan
                is kept untouched.
              </p>
              <div className="mt-2 flex gap-2">
                <button
                  onClick={() => void generate()}
                  className="rounded-md bg-amber-600 px-2.5 py-1 text-[11px] font-semibold text-white"
                >
                  Yes, regenerate
                </button>
                <button
                  onClick={() => setConfirmRegen(false)}
                  className="rounded-md border border-amber-400 px-2.5 py-1 text-[11px] font-medium text-amber-800"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>

        <div className="flex items-center justify-between gap-2 border-t border-charcoal/10 px-4 py-3">
          <span className="text-[10px] leading-tight text-charcoal/45">
            Uses your daily AI quota. Results are cached per image — re-analysing the same panorama
            doesn't consume quota.
          </span>
          <button
            onClick={() => void generate()}
            disabled={busy || !selected || panoramaStops.length === 0}
            className="flex shrink-0 items-center gap-1.5 rounded-md bg-sage px-3.5 py-2 text-xs font-semibold text-white disabled:opacity-50"
          >
            {busy ? <Loader2 size={13} className="animate-spin" /> : <Sparkles size={13} />}
            {phase === "preparing" ? "Preparing…" : phase === "analyzing" ? "Analyzing…" : planHasContent ? "Regenerate" : "Generate concept"}
          </button>
        </div>
      </div>
    </div>
  );
}
