import { useState } from "react";
import {
  X,
  Camera,
  Trash2,
  History,
  Loader2,
  AlertTriangle,
  GitCompareArrows,
  Wand2,
} from "lucide-react";
import { Tour } from "../types";
import { mediaSrc } from "../types";
import {
  allSnapshots,
  captureSnapshot,
  formatSnapshotDate,
  resolveSnapshotMedia,
  snapshotsForStop,
  withSnapshotAdded,
  withSnapshotDeleted,
} from "../lib/snapshots";

type Props = {
  tour: Tour;
  activeStopId: string | null;
  onChange: (tour: Tour) => void;
  onClose: () => void;
  /** Stage label suggested by the last AI scene analysis, if any. */
  suggestedStage?: string;
};

/**
 * Construction progress tracking UI (Feature D). Timeline of versioned
 * snapshots per scene, side-by-side compare against the CURRENT media,
 * append-only history. Persisted via the tour itself (localStorage draft +
 * published copy) — never React state alone.
 */
export default function ConstructionPanel({ tour, activeStopId, onChange, onClose, suggestedStage }: Props) {
  const [selectedStopId, setSelectedStopId] = useState<string | null>(activeStopId);
  const [stageLabel, setStageLabel] = useState("");
  const [note, setNote] = useState("");
  // Default capture date = today; the input is a date the user can backdate.
  const [captureDate, setCaptureDate] = useState(new Date().toISOString().slice(0, 10));
  const [error, setError] = useState<string | null>(null);
  const [comparingId, setComparingId] = useState<string | null>(null);

  const stop = tour.stops.find((s) => s.id === selectedStopId) ?? null;
  const stopSnapshots = selectedStopId ? snapshotsForStop(tour, selectedStopId) : [];
  const tourSnapshots = allSnapshots(tour);
  const comparing = comparingId ? tour.snapshots?.find((s) => s.id === comparingId) ?? null : null;
  const comparingMedia = comparing ? resolveSnapshotMedia(tour, comparing) : null;

  function save() {
    if (!selectedStopId) return;
    setError(null);
    const capturedAt = new Date(`${captureDate}T12:00:00`).getTime();
    const result = captureSnapshot(tour, selectedStopId, stageLabel, Number.isFinite(capturedAt) ? capturedAt : Date.now(), note);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    onChange(withSnapshotAdded(tour, result.snapshot));
    setStageLabel("");
    setNote("");
    setComparingId(result.snapshot.id);
  }

  function renderMedia(media: { kind?: string; dataUrl: string; url?: string } | null, label: string, sublabel?: string) {
    return (
      <div className="flex min-w-0 flex-1 flex-col">
        <div className="mb-1.5 flex items-baseline justify-between gap-2">
          <span className="truncate text-xs font-medium">{label}</span>
          {sublabel && <span className="shrink-0 font-mono text-[10px] text-charcoal/40">{sublabel}</span>}
        </div>
        <div className="flex aspect-video items-center justify-center overflow-hidden rounded-lg border border-charcoal/15 bg-black">
          {media ? (
            media.kind === "video" ? (
              <video src={mediaSrc(media as any)} className="h-full w-full object-cover" controls muted />
            ) : (
              <img src={mediaSrc(media as any)} alt={label} className="h-full w-full object-cover" />
            )
          ) : (
            <span className="px-4 text-center text-xs text-white/30">No media</span>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/70 p-4 backdrop-blur-sm">
      <div className="flex h-full max-h-[90vh] w-full max-w-4xl flex-col overflow-hidden rounded-xl bg-bone shadow-2xl">
        <div className="flex shrink-0 items-center justify-between border-b border-charcoal/10 px-5 py-3">
          <div className="flex items-center gap-2">
            <History className="text-brass" size={16} />
            <h2 className="font-display text-sm font-semibold">Construction progress</h2>
            <span className="rounded-full bg-charcoal/5 px-2 py-0.5 font-mono text-[10px] text-charcoal/50">
              {tourSnapshots.length} snapshot{tourSnapshots.length === 1 ? "" : "s"}
            </span>
          </div>
          <button onClick={onClose} className="rounded p-1 text-charcoal/40 hover:text-charcoal" aria-label="Close">
            <X size={18} />
          </button>
        </div>

        <div className="flex min-h-0 flex-1 flex-col overflow-y-auto lg:flex-row">
          {/* Left: capture + timeline */}
          <div className="flex min-h-0 flex-1 flex-col">
            {/* Scene picker */}
            <div className="shrink-0 border-b border-charcoal/10 px-5 py-3">
              <label className="font-mono text-[10px] uppercase tracking-wider text-charcoal/40">Scene / room</label>
              <select
                value={selectedStopId ?? ""}
                onChange={(e) => {
                  setSelectedStopId(e.target.value || null);
                  setComparingId(null);
                }}
                className="mt-1 w-full rounded-md border border-charcoal/15 bg-white px-3 py-2 text-sm"
              >
                <option value="">Choose a scene…</option>
                {tour.stops.map((s, i) => (
                  <option key={s.id} value={s.id}>
                    {i + 1}. {s.title || "Untitled"}
                  </option>
                ))}
              </select>
            </div>

            {stop ? (
              <div className="flex-1 overflow-y-auto px-5 py-4">
                {/* Capture card */}
                <div className="rounded-lg border border-dashed border-charcoal/20 p-4">
                  <p className="flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wide text-charcoal/45">
                    <Camera size={12} /> Save today's snapshot
                  </p>
                  {stop.media ? (
                    <>
                      <div className="mt-3 grid gap-3 sm:grid-cols-2">
                        <div>
                          <label className="text-[10px] uppercase tracking-wide text-charcoal/40">Capture date</label>
                          <input
                            type="date"
                            value={captureDate}
                            max={new Date().toISOString().slice(0, 10)}
                            onChange={(e) => setCaptureDate(e.target.value)}
                            className="mt-1 w-full rounded-md border border-charcoal/15 bg-white px-3 py-2 text-sm"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] uppercase tracking-wide text-charcoal/40">Stage label</label>
                          <div className="mt-1 flex gap-1.5">
                            <input
                              value={stageLabel}
                              onChange={(e) => setStageLabel(e.target.value)}
                              placeholder='e.g. "Brickwork complete"'
                              className="w-full rounded-md border border-charcoal/15 bg-white px-3 py-2 text-sm"
                            />
                            {suggestedStage && (
                              <button
                                onClick={() => setStageLabel(suggestedStage)}
                                title={`Use AI suggestion: ${suggestedStage}`}
                                className="flex shrink-0 items-center gap-1 rounded-md border border-brass/40 bg-brass/10 px-2 text-[10px] font-medium text-brass"
                              >
                                <Wand2 size={10} /> AI
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                      <input
                        value={note}
                        onChange={(e) => setNote(e.target.value)}
                        placeholder="Optional note (what changed since last time)"
                        className="mt-2 w-full rounded-md border border-charcoal/15 bg-white px-3 py-2 text-xs"
                      />
                      {error && (
                        <p className="mt-2 flex items-center gap-1 text-[11px] text-red-500">
                          <AlertTriangle size={11} /> {error}
                        </p>
                      )}
                      <button
                        onClick={save}
                        className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-md bg-charcoal px-3 py-2.5 text-xs font-medium text-bone hover:bg-ink"
                      >
                        <Camera size={13} /> Save snapshot of this scene
                      </button>
                      <p className="mt-2 text-[10px] leading-relaxed text-charcoal/40">
                        Snapshots are versioned — saving never overwrites earlier captures, and identical media is
                        stored once and referenced, not duplicated.
                      </p>
                    </>
                  ) : (
                    <p className="mt-2 text-xs text-charcoal/40">
                      This scene has no media yet — upload a photo in the editor first.
                    </p>
                  )}
                </div>

                {/* Timeline */}
                <div className="mt-5">
                  <p className="font-mono text-[10px] uppercase tracking-wider text-charcoal/40">
                    Timeline — {stopSnapshots.length} capture{stopSnapshots.length === 1 ? "" : "s"}
                  </p>
                  {stopSnapshots.length === 0 ? (
                    <p className="mt-3 rounded-md border border-dashed border-charcoal/15 px-4 py-6 text-center text-xs text-charcoal/40">
                      No history for this scene yet. Save the first snapshot above.
                    </p>
                  ) : (
                    <ul className="mt-3 space-y-2">
                      {stopSnapshots.map((snap, i) => {
                        const media = resolveSnapshotMedia(tour, snap);
                        const next = stopSnapshots[i + 1]; // older
                        const isComparing = comparingId === snap.id;
                        return (
                          <li
                            key={snap.id}
                            className={`flex items-center gap-3 rounded-lg border p-2.5 transition-colors ${
                              isComparing ? "border-brass bg-brass/10" : "border-charcoal/10 bg-white/60"
                            }`}
                          >
                            <div className="h-14 w-20 shrink-0 overflow-hidden rounded border border-charcoal/10 bg-black">
                              {media && media.kind !== "video" ? (
                                <img src={mediaSrc(media)} alt="" className="h-full w-full object-cover" />
                              ) : (
                                <div className="flex h-full items-center justify-center font-mono text-[9px] text-white/40">
                                  {media ? "VIDEO" : "—"}
                                </div>
                              )}
                            </div>
                            <div className="min-w-0 flex-1">
                              <p className="truncate text-xs font-medium">{snap.stageLabel}</p>
                              <p className="mt-0.5 font-mono text-[10px] text-charcoal/45">
                                {formatSnapshotDate(snap.capturedAt)}
                                {next ? ` · +${Math.max(1, Math.round((snap.capturedAt - next.capturedAt) / 86400000))}d` : " · first"}
                              </p>
                              {snap.note && <p className="mt-0.5 truncate text-[10px] text-charcoal/50">{snap.note}</p>}
                            </div>
                            <div className="flex shrink-0 flex-col gap-1">
                              <button
                                onClick={() => setComparingId(isComparing ? null : snap.id)}
                                className={`flex items-center gap-1 rounded px-2 py-1 text-[10px] font-medium ${
                                  isComparing ? "bg-brass text-white" : "bg-charcoal/5 text-charcoal/60 hover:bg-charcoal/10"
                                }`}
                              >
                                <GitCompareArrows size={10} /> Compare
                              </button>
                              <button
                                onClick={() => {
                                  if (window.confirm(`Delete the "${snap.stageLabel}" snapshot from ${formatSnapshotDate(snap.capturedAt)}?`)) {
                                    onChange(withSnapshotDeleted(tour, snap.id));
                                    if (comparingId === snap.id) setComparingId(null);
                                  }
                                }}
                                className="flex items-center justify-center gap-1 rounded px-2 py-1 text-[10px] text-charcoal/35 hover:text-red-500"
                              >
                                <Trash2 size={10} />
                              </button>
                            </div>
                          </li>
                        );
                      })}
                    </ul>
                  )}
                </div>
              </div>
            ) : (
              <div className="flex flex-1 items-center justify-center px-6 text-center text-sm text-charcoal/40">
                Choose a scene to capture and compare its progress history.
              </div>
            )}
          </div>

          {/* Right: compare view */}
          <div className="shrink-0 border-t border-charcoal/10 bg-white/60 p-5 lg:w-[46%] lg:border-l lg:border-t-0">
            <p className="font-mono text-[10px] uppercase tracking-wider text-charcoal/40">Compare</p>
            {comparing && stop ? (
              <div className="mt-3 flex flex-col gap-4">
                <div className="flex gap-3">
                  {renderMedia(comparingMedia, comparing.stageLabel, formatSnapshotDate(comparing.capturedAt))}
                </div>
                <div className="flex items-center justify-center gap-2 text-charcoal/30">
                  <span className="h-px flex-1 bg-charcoal/10" /> vs today <span className="h-px flex-1 bg-charcoal/10" />
                </div>
                <div className="flex gap-3">
                  {renderMedia(stop.media, "Current media", "live")}
                </div>
                <p className="text-[10px] leading-relaxed text-charcoal/45">
                  Comparing scene “{stop.title}”. Switch snapshots from the timeline on the left — every capture stays
                  in history.
                </p>
              </div>
            ) : (
              <div className="mt-3 flex h-40 items-center justify-center rounded-lg border border-dashed border-charcoal/15 text-center text-xs text-charcoal/40">
                Pick a snapshot and press Compare to see it side-by-side with today's media.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
