import { Loader2 } from "lucide-react";
import { remainingGenerations } from "../lib/generatePanorama";
import { PanoramaCheck } from "../lib/panoramaCheck";

export function PanoramaWarningModal({
  check,
  onAutoGenerate,
  onUseAsPhoto,
  onChooseDifferent,
  onUseAnyway,
}: {
  check: PanoramaCheck;
  onAutoGenerate: () => void;
  onUseAsPhoto: () => void;
  onChooseDifferent: () => void;
  onUseAnyway: () => void;
}) {
  const remaining = remainingGenerations();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-charcoal/50 px-6 backdrop-blur-sm">
      <div className="w-full max-w-sm rounded-lg bg-white p-6 shadow-xl">
        <p className="font-display text-base font-semibold">Not a standard panorama shape</p>
        <p className="mt-2 text-sm text-charcoal/60">
          This image is {check.width}×{check.height} (about {check.ratio.toFixed(2)}:1). A real
          360° panorama is close to 2:1. If you wrap this on a sphere it will look warped near the
          top and bottom.
        </p>
        <div className="mt-5 flex flex-col gap-2">
          <button
            onClick={onAutoGenerate}
            disabled={remaining <= 0}
            className="rounded-md bg-brass px-4 py-2.5 text-sm font-medium text-bone hover:opacity-90 disabled:opacity-40"
          >
            {remaining > 0 ? "Auto-generate a 360° from this photo (AI)" : "AI generation limit reached for now"}
          </button>
          <button
            onClick={onUseAsPhoto}
            className="rounded-md bg-charcoal px-4 py-2.5 text-sm font-medium text-bone hover:bg-ink"
          >
            Use as regular photo instead
          </button>
          <button
            onClick={onChooseDifferent}
            className="rounded-md border border-charcoal/15 px-4 py-2.5 text-sm font-medium text-charcoal/70 hover:border-charcoal/30"
          >
            Choose a different photo
          </button>
          <button onClick={onUseAnyway} className="text-xs text-charcoal/40 underline hover:text-charcoal/60">
            Use it as a 360° photo anyway
          </button>
          {remaining > 0 && (
            <p className="mt-1 text-center text-[10px] text-charcoal/30">
              {remaining} AI generation{remaining === 1 ? "" : "s"} left
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

export function GeneratingPanoramaModal() {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-charcoal/50 px-6 backdrop-blur-sm">
      <div className="flex items-center gap-3 rounded-lg bg-white px-6 py-4 shadow-xl">
        <Loader2 size={18} className="animate-spin text-brass" />
        <span className="text-sm text-charcoal/70">Generating panorama…</span>
      </div>
    </div>
  );
}
