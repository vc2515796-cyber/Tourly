import { useEffect, useMemo, useRef, useState } from "react";
import {
  X,
  UploadCloud,
  Loader2,
  AlertTriangle,
  Copy,
  ImageIcon,
  RotateCw,
  Wand2,
  Trash2,
  ArrowUp,
  ArrowDown,
  CheckCircle2,
  Info,
  Eye,
} from "lucide-react";
import { compressImage } from "../lib/imageCompress";
import { phashFromDataUrl, findDuplicateGroups, hammingDistance, DUPLICATE_HAMMING_THRESHOLD, type Phash } from "../lib/phash";
import { checkImageQuality, describeQualityWarnings, type QualityFlags } from "../lib/imageQuality";
import { checkEquirectangular } from "../lib/panoramaCheck";
import {
  classifyScenes,
  cachedClassification,
  ROOM_CATEGORIES,
  CATEGORY_LABELS,
  type RoomCategory,
  type SceneClassification,
} from "../lib/classifyScenes";

/**
 * Stage B1 — AI Smart Upload.
 *
 * A staging area between "the person picked photos" and "scenes were
 * created": files are validated, previewed, checked locally for duplicates
 * (perceptual hash) and quality (blur/darkness/resolution), optionally
 * classified by the server-side AI (category, title, description, order) —
 * and EVERY AI suggestion is editable before anything is applied. The
 * original File objects are kept untouched until apply; an AI failure
 * never removes a staged photo.
 */

export type SmartUploadItem = {
  /** Final, user-confirmed values handed back to the editor on apply. */
  file: File;
  previewDataUrl: string;
  title: string;
  category: RoomCategory;
  note: string;
  treatAs360: boolean;
};

type StageState = "staging" | "ready" | "failed";

type Staged = {
  id: string;
  file: File;
  previewDataUrl: string;
  state: StageState;
  error?: string;
  phash: Phash | null;
  quality: QualityFlags | null;
  panoramaCandidate: boolean;
  /** index of the earlier staged item this looks like, if any */
  duplicateOfStaged?: number;
  /** stop id of an existing scene this looks like, if any */
  duplicateOfStopId?: string;
  ai: SceneClassification | null;
  aiState: "idle" | "analyzing" | "done" | "error";
  aiError?: string;
  // user-editable fields (pre-filled from AI when available)
  title: string;
  category: RoomCategory;
  note: string;
  treatAs360: boolean;
};

type Props = {
  existingStops: { id: string; title: string; mediaDataUrl: string | null }[];
  onClose: () => void;
  onApply: (items: SmartUploadItem[]) => void;
};

const MAX_RAW_IMAGE_BYTES = 30 * 1024 * 1024;
const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];

export default function SmartUploadPanel({ existingStops, onClose, onApply }: Props) {
  const [staged, setStaged] = useState<Staged[]>([]);
  const [ingestError, setIngestError] = useState<string | null>(null);
  const [aiNotice, setAiNotice] = useState<string | null>(null);
  const [aiRunning, setAiRunning] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [applying, setApplying] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  /** phash of each existing scene's media, computed once when staging ends */
  const existingHashes = useRef<{ stopId: string; title: string; phash: Phash }[]>([]);

  // --- ingestion ------------------------------------------------------------

  async function ingestFiles(files: FileList | File[]) {
    const list = Array.from(files);
    if (list.length === 0) return;
    setIngestError(null);
    setAiNotice(null);

    // 1. Static validation first — nothing staged for rejected files.
    const rejected: string[] = [];
    const accepted: File[] = [];
    for (const f of list) {
      if (!ACCEPTED_IMAGE_TYPES.includes(f.type)) {
        rejected.push(`"${f.name}" — unsupported type (use JPEG, PNG or WebP)`);
      } else if (f.size > MAX_RAW_IMAGE_BYTES) {
        rejected.push(`"${f.name}" — ${(f.size / 1024 / 1024).toFixed(0)} MB is over the 30 MB limit`);
      } else {
        accepted.push(f);
      }
    }
    if (rejected.length) setIngestError(rejected.join("; "));
    if (accepted.length === 0) return;

    // 2. Stage each file: preview, phash, quality, panorama candidacy.
    //    The ORIGINAL file is preserved untouched; only a preview copy is
    //    compressed for display.
    for (const file of accepted) {
      const id = crypto.randomUUID();
      setStaged((prev) => [
        ...prev,
        {
          id,
          file,
          previewDataUrl: "",
          state: "staging",
          phash: null,
          quality: null,
          panoramaCandidate: false,
          ai: null,
          aiState: "idle",
          title: "",
          category: "unknown",
          note: "",
          treatAs360: false,
        },
      ]);

      try {
        const readDataUrl = await readFileAsDataUrl(file);
        const previewDataUrl = await compressImage(readDataUrl, { maxDim: 1280, quality: 0.82 });
        const [phash, quality, panoCheck] = await Promise.all([
          phashFromDataUrl(previewDataUrl).catch(() => null),
          checkImageQuality(previewDataUrl),
          checkEquirectangular(previewDataUrl).catch(() => null),
        ]);
        setStaged((prev) =>
          prev.map((s) =>
            s.id === id
              ? {
                  ...s,
                  previewDataUrl,
                  phash,
                  quality,
                  panoramaCandidate: Boolean(
                    panoCheck?.isEquirectangular && panoCheck.width >= 2048
                  ),
                  treatAs360: Boolean(panoCheck?.isEquirectangular && panoCheck.width >= 2048),
                  state: "ready",
                }
              : s
          )
        );
      } catch (err: any) {
        setStaged((prev) =>
          prev.map((s) =>
            s.id === id ? { ...s, state: "failed", error: err?.message ?? "Couldn't read this file." } : s
          )
        );
      }
    }

    // 3. Once everything settled, hash existing scenes once, then flag
    //    duplicates (batch-internal + against existing scenes).
    setTimeout(() => void runDuplicateDetection(), 300);
  }

  async function runDuplicateDetection() {
    // Hash existing scene media (only once per panel session).
    if (existingHashes.current.length === 0) {
      const hashes: { stopId: string; title: string; phash: Phash }[] = [];
      for (const stop of existingStops) {
        if (!stop.mediaDataUrl) continue;
        const ph = await phashFromDataUrl(stop.mediaDataUrl).catch(() => null);
        if (ph) hashes.push({ stopId: stop.id, title: stop.title, phash: ph });
      }
      existingHashes.current = hashes;
    }

    setStaged((prev) => {
      if (prev.some((s) => s.state === "staging")) return prev; // not settled yet
      const hashes = prev.map((s) => s.phash);
      const inBatch = findDuplicateGroups(hashes);
      return prev.map((s, i) => {
        if (!s.phash) return s;
        const dupStaged = inBatch.get(i);
        if (dupStaged !== undefined) {
          return { ...s, duplicateOfStaged: dupStaged, duplicateOfStopId: undefined };
        }
        const existing = existingHashes.current.find((h) => h.phash && hashClose(s.phash!, h.phash));
        if (existing) {
          return { ...s, duplicateOfStaged: undefined, duplicateOfStopId: existing.stopId };
        }
        return { ...s, duplicateOfStaged: undefined, duplicateOfStopId: undefined };
      });
    });
  }

  useEffect(() => {
    // When the last staging item settles, run duplicate detection (covers
    // the normal path too, not just the setTimeout path).
    if (staged.length > 0 && staged.every((s) => s.state !== "staging")) {
      const anyUnflagged = staged.some((s) => s.phash && s.duplicateOfStaged === undefined && s.duplicateOfStopId === undefined);
      if (anyUnflagged || existingHashes.current.length === 0) {
        void runDuplicateDetection();
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [staged.map((s) => s.state).join(",")]);

  // --- AI classification ----------------------------------------------------

  async function runAiSuggestion() {
    const targets = staged.filter((s) => s.state === "ready");
    if (targets.length === 0) return;
    setAiRunning(true);
    setAiNotice(null);

    const anyCached = targets.some((s) => s.phash && cachedClassification(s.phash));
    setStaged((prev) =>
      prev.map((s) =>
        s.state === "ready" && !(s.phash && cachedClassification(s.phash))
          ? { ...s, aiState: "analyzing", aiError: undefined }
          : s
      )
    );

    const result = await classifyScenes(
      targets.filter((s) => !s.phash || !cachedClassification(s.phash)).map((s) => ({
        id: s.id,
        phash: s.phash ?? s.id, // no phash → unique key, no caching benefit but still works
        dataUrl: s.previewDataUrl,
      })),
      [
        ...existingStops.map((s) => s.title),
        ...targets.map((s) => s.title).filter(Boolean),
      ]
    );

    setAiRunning(false);

    if (!result.ok) {
      setStaged((prev) =>
        prev.map((s) => (s.aiState === "analyzing" ? { ...s, aiState: "error", aiError: result.error } : s))
      );
      setAiNotice(
        result.quotaExhausted
          ? `${result.error} You can still add the photos now and fill in titles yourself — nothing was lost.`
          : `${result.error} Titles stay fully editable — add the photos and fill them in yourself.`
      );
      return;
    }

    // Apply results as EDITABLE pre-fills (never auto-commit a "final" value).
    const failedSet = new Set(result.failedIds ?? []);
    setStaged((prev) =>
      prev.map((s) => {
        const fromCache = s.phash ? cachedClassification(s.phash) : undefined;
        const r = result.results.find((x) => x.id === s.id) ?? fromCache;
        if (failedSet.has(s.id)) {
          return { ...s, aiState: "error" as const, aiError: result.failureReason ?? "AI analysis failed for this photo." };
        }
        if (!r) return s.aiState === "analyzing" ? { ...s, aiState: "idle" } : s;
        return {
          ...s,
          ai: r,
          aiState: "done",
          aiError: undefined,
          title: s.title || r.title,
          category: r.category,
          note: s.note || r.description,
        };
      })
    );
    if (result.partial && failedSet.size > 0) {
      // Honest partial summary: keep what worked, say what didn't, and the
      // retry button re-sends ONLY the failures (successful ones are cached).
      setAiNotice(
        `${result.results.length} photo${result.results.length === 1 ? "" : "s"} analysed; ${failedSet.size} failed — ${result.failureReason ?? "try again"}. Tap "AI titles" again to retry just the failed ones.`
      );
    } else if (anyCached) {
      setAiNotice("Some photos reused earlier AI results instead of asking again.");
    }
  }

  function sortyBySuggestedOrder() {
    setStaged((prev) => {
      const withOrder = prev.map((s, i) => ({ s, i, order: s.ai?.order ?? i + 1 }));
      withOrder.sort((a, b) => a.order - b.order || a.i - b.i);
      return withOrder.map((x) => x.s);
    });
  }

  function moveItem(index: number, dir: -1 | 1) {
    setStaged((prev) => {
      const target = index + dir;
      if (target < 0 || target >= prev.length) return prev;
      const next = [...prev];
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  }

  function removeItem(id: string) {
    setStaged((prev) => prev.filter((s) => s.id !== id));
  }

  function retryFailed() {
    // "Failed" here means the file couldn't be read/decoded — a retry has to
    // re-ingest from the original File, which we still hold.
    const failed = staged.filter((s) => s.state === "failed");
    for (const item of failed) removeItem(item.id);
    void ingestFiles(failed.map((f) => f.file));
  }

  // --- apply ----------------------------------------------------------------

  async function handleApply() {
    const ready = staged.filter((s) => s.state === "ready");
    if (ready.length === 0) return;
    setApplying(true);
    onApply(
      ready.map((s) => ({
        file: s.file, // the ORIGINAL, untouched file — not the preview
        previewDataUrl: s.previewDataUrl,
        title: s.title.trim() || "Untitled scene",
        category: s.category,
        note: s.note.trim(),
        treatAs360: s.treatAs360 && s.panoramaCandidate,
      }))
    );
    // Parent closes the panel; no state updates here.
  }

  const readyCount = staged.filter((s) => s.state === "ready").length;
  const failedCount = staged.filter((s) => s.state === "failed").length;
  const dupCount = staged.filter((s) => s.duplicateOfStaged !== undefined || s.duplicateOfStopId !== undefined).length;
  const warnCount = staged.filter((s) => describeQualityWarnings(s.quality).length > 0).length;
  const aiDoneCount = staged.filter((s) => s.aiState === "done").length;

  const summary = useMemo(() => {
    const bits: string[] = [];
    if (readyCount) bits.push(`${readyCount} ready`);
    if (failedCount) bits.push(`${failedCount} failed`);
    if (dupCount) bits.push(`${dupCount} possible duplicate${dupCount > 1 ? "s" : ""}`);
    if (warnCount) bits.push(`${warnCount} quality warning${warnCount > 1 ? "s" : ""}`);
    return bits.join(" · ");
  }, [readyCount, failedCount, dupCount, warnCount]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/70 p-2 backdrop-blur-sm sm:p-4">
      <div className="flex h-full max-h-[94vh] w-full max-w-6xl flex-col overflow-hidden rounded-xl bg-bone shadow-2xl">
        {/* header */}
        <div className="flex shrink-0 items-center justify-between border-b border-charcoal/10 px-4 py-3 sm:px-5">
          <div className="flex items-center gap-2">
            <UploadCloud className="text-brass" size={16} />
            <h2 className="font-display text-sm font-semibold">Smart upload</h2>
            {summary && <span className="hidden text-[11px] text-charcoal/45 sm:inline">— {summary}</span>}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => fileRef.current?.click()}
              className="rounded-md border border-charcoal/15 px-2.5 py-1.5 text-xs font-medium text-charcoal/70 hover:border-charcoal/30"
            >
              Add photos
            </button>
            <button onClick={onClose} className="rounded p-1 text-charcoal/40 hover:text-charcoal" aria-label="Close">
              <X size={18} />
            </button>
          </div>
        </div>

        <input
          ref={fileRef}
          type="file"
          accept="image/jpeg,image/png,image/webp"
          multiple
          className="hidden"
          onChange={(e) => {
            if (e.target.files?.length) void ingestFiles(e.target.files);
            e.target.value = "";
          }}
        />

        {(ingestError || aiNotice) && (
          <div className="flex items-start gap-2 border-b border-amber-200 bg-amber-50 px-4 py-2 text-xs text-amber-800 sm:px-5">
            <AlertTriangle size={13} className="mt-0.5 shrink-0" />
            <span>{ingestError || aiNotice}</span>
          </div>
        )}

        <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
          {/* staging grid */}
          <div className="min-h-0 flex-1 overflow-y-auto p-3 sm:p-4">
            {staged.length === 0 ? (
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragOver(true);
                }}
                onDragLeave={() => setDragOver(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setDragOver(false);
                  if (e.dataTransfer.files?.length) void ingestFiles(e.dataTransfer.files);
                }}
                className={`flex aspect-video max-h-72 w-full flex-col items-center justify-center gap-3 rounded-lg border-2 border-dashed transition-colors ${
                  dragOver ? "border-brass bg-brass/5" : "border-charcoal/20 bg-white"
                }`}
              >
                <UploadCloud size={28} className="text-charcoal/35" />
                <p className="text-sm font-medium text-charcoal/60">Drop property photos here</p>
                <p className="text-xs text-charcoal/40">or use “Add photos” — JPEG / PNG / WebP, up to 30 MB each</p>
                <p className="max-w-md text-center text-[11px] leading-relaxed text-charcoal/35">
                  Duplicates and quality issues are flagged locally for you to review. AI room suggestions are optional
                  and always editable.
                </p>
              </div>
            ) : (
              <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3">
                {staged.map((s, i) => (
                  <StagedCard
                    key={s.id}
                    item={s}
                    index={i}
                    total={staged.length}
                    onRemove={() => removeItem(s.id)}
                    onMove={(d) => moveItem(i, d)}
                    onPatch={(patch) => setStaged((prev) => prev.map((x) => (x.id === s.id ? { ...x, ...patch } : x)))}
                  />
                ))}
              </ul>
            )}
          </div>

          {/* side rail */}
          <div className="shrink-0 space-y-3 border-t border-charcoal/10 bg-white/70 p-4 lg:w-72 lg:border-l lg:border-t-0">
            <div>
              <p className="font-mono text-[11px] uppercase tracking-wider text-charcoal/40">AI suggestions</p>
              <p className="mt-1.5 text-[11px] leading-relaxed text-charcoal/45">
                Optional: ask the AI to suggest a room category, title, description and tour order for every photo.
                Everything is editable before it's applied.
              </p>
              <button
                onClick={runAiSuggestion}
                disabled={aiRunning || readyCount === 0}
                className="mt-2 flex w-full items-center justify-center gap-1.5 rounded-md bg-charcoal px-3 py-2 text-xs font-medium text-bone disabled:opacity-40"
              >
                {aiRunning ? <Loader2 size={13} className="animate-spin" /> : <Wand2 size={13} />}
                {aiRunning ? "Analyzing…" : readyCount === aiDoneCount && aiDoneCount > 0 ? "Re-run AI" : "Suggest with AI"}
              </button>
              {aiDoneCount > 0 && (
                <button
                  onClick={sortyBySuggestedOrder}
                  className="mt-2 flex w-full items-center justify-center gap-1.5 rounded-md border border-charcoal/15 px-3 py-1.5 text-[11px] font-medium text-charcoal/60 hover:border-charcoal/30"
                >
                  <ArrowUp size={11} /> Sort by suggested tour order
                </button>
              )}
            </div>

            <div className="rounded-md bg-charcoal/5 p-2.5 text-[10px] leading-relaxed text-charcoal/50">
              <div className="flex items-start gap-1.5">
                <Info size={11} className="mt-0.5 shrink-0" />
                <span>
                  Duplicate detection and quality checks run on-device. Categories are AI guesses, not verified facts —
                  room sizes are never estimated from photos.
                </span>
              </div>
            </div>

            <div className="space-y-2 border-t border-charcoal/10 pt-3">
              {failedCount > 0 && (
                <button
                  onClick={retryFailed}
                  className="flex w-full items-center justify-center gap-1.5 rounded-md border border-red-200 bg-red-50 px-3 py-1.5 text-xs font-medium text-red-600 hover:border-red-300"
                >
                  <RotateCw size={12} /> Retry {failedCount} failed file{failedCount > 1 ? "s" : ""}
                </button>
              )}
              <button
                onClick={handleApply}
                disabled={applying || readyCount === 0}
                className="flex w-full items-center justify-center gap-1.5 rounded-md bg-sage px-3 py-2 text-xs font-semibold text-white disabled:opacity-40"
              >
                {applying ? <Loader2 size={13} className="animate-spin" /> : <CheckCircle2 size={13} />}
                {applying ? "Adding…" : `Add ${readyCount || ""} scene${readyCount === 1 ? "" : "s"}`}
              </button>
              <p className="text-center text-[10px] text-charcoal/40">
                Originals are preserved — scenes get the untouched files.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function hashClose(a: Phash, b: Phash): boolean {
  return hammingDistance(a, b) <= DUPLICATE_HAMMING_THRESHOLD;
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error("Couldn't read this file."));
    reader.readAsDataURL(file);
  });
}

// --- staged card -------------------------------------------------------------

function StagedCard({
  item,
  index,
  total,
  onRemove,
  onMove,
  onPatch,
}: {
  item: Staged;
  index: number;
  total: number;
  onRemove: () => void;
  onMove: (dir: -1 | 1) => void;
  onPatch: (patch: Partial<Staged>) => void;
}) {
  const warnings = describeQualityWarnings(item.quality);
  const duplicateLabel = item.duplicateOfStaged !== undefined
    ? `possible duplicate of photo #${item.duplicateOfStaged + 1}`
    : item.duplicateOfStopId
    ? "possible duplicate of an existing scene"
    : null;

  if (item.state === "failed") {
    return (
      <li className="flex flex-col justify-between rounded-lg border border-red-200 bg-red-50/60 p-3">
        <div className="flex items-start gap-2">
          <AlertTriangle size={14} className="mt-0.5 shrink-0 text-red-500" />
          <div className="min-w-0">
            <p className="truncate text-xs font-medium text-charcoal">{item.file.name}</p>
            <p className="mt-0.5 text-[11px] text-red-600">{item.error}</p>
          </div>
        </div>
        <div className="mt-2 flex justify-end">
          <button onClick={onRemove} className="flex items-center gap-1 rounded p-1 text-charcoal/40 hover:text-red-500" title="Remove">
            <Trash2 size={12} />
          </button>
        </div>
      </li>
    );
  }

  return (
    <li className="flex flex-col overflow-hidden rounded-lg border border-charcoal/10 bg-white">
      <div className="relative aspect-video w-full select-none overflow-hidden bg-charcoal/5">
        {item.state === "staging" || !item.previewDataUrl ? (
          <div className="flex h-full items-center justify-center">
            <Loader2 size={18} className="animate-spin text-charcoal/30" />
          </div>
        ) : (
          <img src={item.previewDataUrl} alt={item.title || item.file.name} className="h-full w-full object-cover" draggable={false} />
        )}
        <div className="absolute left-1.5 top-1.5 flex flex-col items-start gap-1">
          {item.panoramaCandidate && (
            <span className="rounded bg-ink/80 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wide text-bone" title="Passed the 2:1 equirectangular dimension check">
              360° detected
            </span>
          )}
          {duplicateLabel && (
            <span className="flex items-center gap-1 rounded bg-amber-500/90 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wide text-white" title={duplicateLabel}>
              <Copy size={9} /> {duplicateLabel}
            </span>
          )}
          {warnings.map((w) => (
            <span key={w} className="rounded bg-amber-500/90 px-1.5 py-0.5 text-[9px] font-medium uppercase tracking-wide text-white">
              {w}
            </span>
          ))}
          {item.aiState === "analyzing" && (
            <span className="flex items-center gap-1 rounded bg-brass px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wide text-white">
              <Loader2 size={9} className="animate-spin" /> AI
            </span>
          )}
          {item.aiState === "error" && (
            <span className="rounded bg-red-500/90 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wide text-white" title={item.aiError}>
              AI failed
            </span>
          )}
        </div>
        <div className="absolute bottom-1.5 right-1.5 flex gap-1">
          <button
            onClick={() => onMove(-1)}
            disabled={index === 0}
            className="rounded bg-ink/70 p-1 text-bone disabled:opacity-30"
            title="Move earlier in tour"
            aria-label="Move earlier"
          >
            <ArrowUp size={11} />
          </button>
          <button
            onClick={() => onMove(1)}
            disabled={index === total - 1}
            className="rounded bg-ink/70 p-1 text-bone disabled:opacity-30"
            title="Move later in tour"
            aria-label="Move later"
          >
            <ArrowDown size={11} />
          </button>
          <button onClick={onRemove} className="rounded bg-ink/70 p-1 text-bone hover:text-red-300" title="Remove this photo" aria-label="Remove">
            <Trash2 size={11} />
          </button>
        </div>
        <span className="absolute right-1.5 top-1.5 flex items-center gap-1 rounded bg-ink/60 px-1.5 py-0.5 font-mono text-[9px] text-bone">
          <ImageIcon size={9} /> {index + 1}
        </span>
      </div>

      {item.state === "ready" && (
        <div className="flex flex-col gap-2 p-2.5">
          <input
            value={item.title}
            onChange={(e) => onPatch({ title: e.target.value })}
            placeholder="Scene title"
            className="w-full rounded border border-charcoal/15 bg-bone/50 px-2 py-1.5 text-xs outline-none focus:border-brass"
          />
          <div className="flex gap-1.5">
            <select
              value={item.category}
              onChange={(e) => onPatch({ category: e.target.value as RoomCategory })}
              className="min-w-0 flex-1 rounded border border-charcoal/15 bg-bone/50 px-1.5 py-1.5 text-xs outline-none focus:border-brass"
              aria-label="Room category"
            >
              {ROOM_CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {CATEGORY_LABELS[c]}
                </option>
              ))}
            </select>
            {item.panoramaCandidate && (
              <label
                className="flex shrink-0 cursor-pointer items-center gap-1 rounded border border-charcoal/15 px-2 text-[10px] text-charcoal/60"
                title="This photo passed the 2:1 dimension check for equirectangular panoramas. Confirm it really is a 360° capture."
              >
                <input
                  type="checkbox"
                  checked={item.treatAs360}
                  onChange={(e) => onPatch({ treatAs360: e.target.checked })}
                  className="accent-brass"
                />
                <Eye size={10} /> 360°
              </label>
            )}
          </div>
          <textarea
            value={item.note}
            onChange={(e) => onPatch({ note: e.target.value })}
            placeholder="Short description (optional)"
            rows={2}
            className="w-full resize-none rounded border border-charcoal/15 bg-bone/50 px-2 py-1.5 text-xs outline-none focus:border-brass"
          />
          {item.aiState === "done" && item.ai && (
            <p className="text-[9px] leading-relaxed text-charcoal/40">
              AI suggestion — confidence {(item.ai.confidence * 100).toFixed(0)}% (self-reported). Edit anything above
              before applying.
            </p>
          )}
          {item.aiState === "error" && (
            <div className="flex items-center justify-between gap-2 rounded bg-red-50 px-2 py-1 text-[10px] text-red-600">
              <span className="truncate" title={item.aiError}>
                {item.aiError}
              </span>
            </div>
          )}
        </div>
      )}
    </li>
  );
}
