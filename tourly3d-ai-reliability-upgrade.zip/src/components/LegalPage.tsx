import { ReactNode } from "react";
import { Link } from "react-router-dom";
import { MapPin, ArrowLeft } from "lucide-react";
import { usePageMeta } from "../lib/usePageMeta";

export default function LegalPage({
  eyebrow,
  title,
  updated,
  children,
}: {
  eyebrow: string;
  title: string;
  updated: string;
  children: ReactNode;
}) {
  usePageMeta({ title: `${title} — Tourly`, description: `Tourly ${title.toLowerCase()}.` });

  return (
    <div className="min-h-full bg-bone text-charcoal">
      <header className="flex items-center justify-between px-6 py-5 sm:px-10">
        <Link to="/" className="flex items-center gap-2">
          <MapPin className="text-brass" size={18} strokeWidth={2.5} />
          <span className="font-serif text-lg italic tracking-tight">Tourly</span>
        </Link>
        <Link to="/" className="flex items-center gap-1.5 text-sm text-charcoal/50 hover:text-charcoal">
          <ArrowLeft size={15} />
          Back
        </Link>
      </header>

      <main className="mx-auto max-w-2xl px-6 py-12 sm:px-10">
        <p className="text-xs font-semibold uppercase tracking-[0.15em] text-sage">{eyebrow}</p>
        <h1 className="mt-2 font-serif text-4xl tracking-tight">{title}</h1>
        <p className="mt-2 text-xs text-charcoal/40">Last updated {updated}</p>
        <div className="prose-legal mt-8 flex flex-col gap-6 text-sm leading-relaxed text-charcoal/70">
          {children}
        </div>
      </main>
    </div>
  );
}
