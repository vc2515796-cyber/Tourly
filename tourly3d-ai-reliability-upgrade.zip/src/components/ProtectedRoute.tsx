import { ReactNode } from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "../lib/auth";

export default function ProtectedRoute({ children }: { children: ReactNode }) {
  const { user, loading, configured } = useAuth();

  // If Firebase hasn't been configured (no env vars set), don't lock people
  // out of their locally-saved drafts — pass through, but SAY SO. A silent
  // pass-through made broken deployments look like "signed in" access
  // (editor loads from localStorage while sign-in is broken); this banner
  // keeps that state honest. Server-side, publishing still requires a
  // verified Firebase ID token either way (see publish-tour.mts).
  if (!configured) {
    return (
      <>
        <div className="border-b border-brass/30 bg-brass/10 px-5 py-2 text-xs text-charcoal/70">
          Local mode — Firebase auth isn't configured on this deployment, so
          you're viewing locally-saved drafts without being signed in.
          Publishing and cloud features stay disabled until the site owner
          sets the <code>VITE_FIREBASE_*</code> variables (see AUTH-SETUP.md).
        </div>
        {children}
      </>
    );
  }

  if (loading) {
    return (
      <div className="flex min-h-full items-center justify-center bg-bone">
        <p className="font-mono text-xs text-charcoal/40">Loading…</p>
      </div>
    );
  }

  if (!user) return <Navigate to="/login" replace />;

  return <>{children}</>;
}
