import { Stop, mediaSrc } from "../types";
import { ImageIcon, Circle, RotateCw, PanelTop, Sparkles } from "lucide-react";

type Props = {
  stops: Stop[];
  activeIndex: number;
  onSelect: (index: number) => void;
  variant?: "dark" | "light";
};

export default function RouteStrip({ stops, activeIndex, onSelect, variant = "dark" }: Props) {
  const isDark = variant === "dark";

  return (
    <div
      className={`route-scroll flex items-end gap-0 overflow-x-auto px-6 py-4 ${
        isDark ? "bg-ink-soft/90 backdrop-blur" : "bg-bone-soft"
      }`}
    >
      {stops.map((stop, i) => {
        const isActive = i === activeIndex;
        const isLast = i === stops.length - 1;
        return (
          <div key={stop.id} className="flex items-end shrink-0">
            <button
              onClick={() => onSelect(i)}
              className="group flex flex-col items-center gap-2 px-3 focus-visible:outline-none"
              aria-current={isActive}
              aria-label={`Go to stop ${i + 1}: ${stop.title}`}
            >
              <div
                className={`relative h-14 w-20 overflow-hidden rounded-md border-2 transition-all ${
                  isActive
                    ? "border-brass shadow-[0_0_0_3px_rgba(201,138,62,0.25)]"
                    : isDark
                    ? "border-white/10 group-hover:border-white/30"
                    : "border-charcoal/10 group-hover:border-charcoal/30"
                }`}
              >
                {stop.media ? (
                  stop.media.kind === "video" ? (
                    stop.media.url || stop.media.dataUrl ? (
                      <video src={mediaSrc(stop.media)} className="h-full w-full object-cover" muted />
                    ) : (
                      <div
                        className={`flex h-full w-full items-center justify-center ${
                          isDark ? "bg-white/5 text-white/30" : "bg-charcoal/5 text-charcoal/30"
                        }`}
                      >
                        <ImageIcon size={16} />
                      </div>
                    )
                  ) : (
                    <>
                      <img src={mediaSrc(stop.media)} alt="" className="h-full w-full object-cover" loading="lazy" />
                      {stop.media.kind === "panorama" && stop.media.synthetic && (
                        <span
                          className="absolute bottom-0.5 right-0.5 rounded-full bg-ink/70 p-0.5 text-brass"
                          title="AI-generated panorama — not a real capture"
                        >
                          <Sparkles size={9} />
                        </span>
                      )}
                      {stop.media.kind === "panorama" && !stop.media.synthetic && (
                        <span className="absolute bottom-0.5 right-0.5 rounded-full bg-ink/70 p-0.5 text-brass">
                          <RotateCw size={9} />
                        </span>
                      )}
                      {stop.media.kind === "wide" && (
                        <span className="absolute bottom-0.5 right-0.5 rounded-full bg-ink/70 p-0.5 text-brass">
                          <PanelTop size={9} />
                        </span>
                      )}
                    </>
                  )
                ) : (
                  <div
                    className={`flex h-full w-full items-center justify-center ${
                      isDark ? "bg-white/5 text-white/30" : "bg-charcoal/5 text-charcoal/30"
                    }`}
                  >
                    <ImageIcon size={16} />
                  </div>
                )}
              </div>
              <span
                className={`font-mono text-[10px] tracking-wide ${
                  isActive
                    ? "text-brass"
                    : isDark
                    ? "text-white/40 group-hover:text-white/70"
                    : "text-charcoal/40 group-hover:text-charcoal/70"
                }`}
              >
                {String(i + 1).padStart(2, "0")}
              </span>
            </button>
            {!isLast && (
              <div className="mb-6 flex w-8 items-center justify-center">
                <div
                  className={`h-px w-full border-t-2 border-dotted ${
                    isDark ? "border-white/15" : "border-charcoal/15"
                  }`}
                />
              </div>
            )}
          </div>
        );
      })}
      {stops.length === 0 && (
        <div className={`flex items-center gap-2 text-sm ${isDark ? "text-white/40" : "text-charcoal/40"}`}>
          <Circle size={12} />
          No stops yet
        </div>
      )}
    </div>
  );
}
