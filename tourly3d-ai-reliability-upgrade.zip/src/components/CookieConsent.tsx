import { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  analyticsConfigured,
  getConsent,
  inIframe,
  setConsent,
  trackPageView,
  OPEN_SETTINGS_EVENT,
} from "../lib/analytics";

/** Sends a SPA page_view on every route change (no-op without consent). */
export function RouteTracker() {
  const location = useLocation();
  useEffect(() => {
    trackPageView(location.pathname + location.search);
  }, [location]);
  return null;
}

/** Only renders when analytics is actually configured — no banner for
 *  cookies that don't exist. Accept and Decline are equally prominent. */
export default function CookieConsent() {
  const [open, setOpen] = useState(() => analyticsConfigured && !inIframe() && getConsent() === null);

  useEffect(() => {
    const reopen = () => setOpen(true);
    window.addEventListener(OPEN_SETTINGS_EVENT, reopen);
    return () => window.removeEventListener(OPEN_SETTINGS_EVENT, reopen);
  }, []);

  if (!analyticsConfigured || inIframe() || !open) return null;

  function choose(value: "granted" | "denied") {
    setConsent(value);
    setOpen(false);
  }

  return (
    <div
      role="dialog"
      aria-label="Analytics cookies"
      className="fixed inset-x-3 bottom-3 z-[60] mx-auto max-w-2xl rounded-xl border border-charcoal/15 bg-white p-4 shadow-2xl sm:inset-x-6"
    >
      <p className="text-sm text-charcoal/80">
        We'd like to use Google Analytics (with IP anonymization) to see which pages are useful. It's
        optional — Tourly works exactly the same if you decline.{" "}
        <Link to="/privacy" className="font-medium text-brass underline">
          Privacy Policy
        </Link>
      </p>
      <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:justify-end">
        <button
          onClick={() => choose("denied")}
          className="rounded-full border border-charcoal/25 px-5 py-2.5 text-sm font-medium text-charcoal/80 hover:border-charcoal/50"
        >
          Decline
        </button>
        <button
          onClick={() => choose("granted")}
          className="rounded-full border border-charcoal/25 bg-charcoal px-5 py-2.5 text-sm font-medium text-bone hover:bg-ink"
        >
          Accept analytics
        </button>
      </div>
    </div>
  );
}
