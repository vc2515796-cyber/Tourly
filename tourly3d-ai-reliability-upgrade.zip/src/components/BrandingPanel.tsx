import { useRef, useState } from "react";
import { X, Palette, Upload, Trash2, Loader2, Eye } from "lucide-react";
import { Branding, Tour } from "../types";
import {
  prepareLogoFile,
  safeLogoSrc,
  sanitizeBranding,
  isValidHexColor,
  normalizeHex,
  DEFAULT_BRANDING,
} from "../lib/branding";

type Props = {
  tour: Tour;
  onChange: (branding: Branding | undefined) => void;
  onClose: () => void;
};

/**
 * White-label branding settings (Feature E). Everything entered here
 * persists with the tour and renders on the PUBLIC viewer — agency name,
 * logo (validated upload or https URL), primary/accent colors, and an
 * optional branded splash while the first panorama loads. Validation is
 * strict: bad hex values and unsafe logo URLs never get saved.
 */
export default function BrandingPanel({ tour, onChange, onClose }: Props) {
  const initial = tour.branding ?? {};
  const [agencyName, setAgencyName] = useState(initial.agencyName ?? "");
  const [logoUrl, setLogoUrl] = useState(initial.logoUrl ?? "");
  const [primaryColor, setPrimaryColor] = useState(initial.primaryColor ?? DEFAULT_BRANDING.primaryColor);
  const [accentColor, setAccentColor] = useState(initial.accentColor ?? DEFAULT_BRANDING.accentColor);
  const [splashEnabled, setSplashEnabled] = useState(initial.splashEnabled ?? true);
  const [logoBusy, setLogoBusy] = useState(false);
  const [logoError, setLogoError] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const previewLogo = safeLogoSrc(logoUrl);

  async function handleLogoFile(file: File) {
    setLogoError(null);
    setLogoBusy(true);
    const result = await prepareLogoFile(file);
    setLogoBusy(false);
    if (!result.ok) {
      setLogoError(result.error);
      return;
    }
    setLogoUrl(result.dataUrl);
  }

  function save() {
    setError(null);
    const branding: Branding = { splashEnabled };
    const name = agencyName.trim();
    if (name) branding.agencyName = name;
    const logo = safeLogoSrc(logoUrl);
    if (logo) branding.logoUrl = logo;
    if (isValidHexColor(primaryColor)) branding.primaryColor = normalizeHex(primaryColor);
    else if (primaryColor.trim()) {
      setError("Primary color must be a hex value like #1a1a1a.");
      return;
    }
    if (isValidHexColor(accentColor)) branding.accentColor = normalizeHex(accentColor);
    else if (accentColor.trim()) {
      setError("Accent color must be a hex value like #c98a3e.");
      return;
    }
    onChange(sanitizeBranding(branding));
    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/70 p-4 backdrop-blur-sm">
      <div className="flex max-h-[90vh] w-full max-w-lg flex-col overflow-hidden rounded-xl bg-bone shadow-2xl">
        <div className="flex shrink-0 items-center justify-between border-b border-charcoal/10 px-5 py-3">
          <div className="flex items-center gap-2">
            <Palette className="text-brass" size={16} />
            <h2 className="font-display text-sm font-semibold">Branding (white-label)</h2>
          </div>
          <button onClick={onClose} className="rounded p-1 text-charcoal/40 hover:text-charcoal" aria-label="Close">
            <X size={18} />
          </button>
        </div>

        <div className="flex-1 space-y-5 overflow-y-auto px-5 py-4">
          <div>
            <label className="text-[11px] font-medium uppercase tracking-wide text-charcoal/40">Agency name</label>
            <input
              value={agencyName}
              onChange={(e) => setAgencyName(e.target.value)}
              placeholder="e.g. Skyline Estates"
              className="mt-1.5 w-full rounded-md border border-charcoal/15 bg-white px-3 py-2 text-sm outline-none focus:border-brass"
            />
            <p className="mt-1 text-[10px] text-charcoal/40">
              Shown on the public tour header. Leave blank to keep the default Tourly wordmark.
            </p>
          </div>

          <div>
            <label className="text-[11px] font-medium uppercase tracking-wide text-charcoal/40">Logo</label>
            <div className="mt-1.5 flex items-center gap-3">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center overflow-hidden rounded-md border border-charcoal/15 bg-white">
                {logoBusy ? (
                  <Loader2 size={16} className="animate-spin text-charcoal/40" />
                ) : previewLogo ? (
                  <img src={previewLogo} alt="Logo preview" className="max-h-full max-w-full object-contain p-1" />
                ) : (
                  <span className="font-mono text-[9px] text-charcoal/30">none</span>
                )}
              </div>
              <div className="flex min-w-0 flex-1 flex-col gap-1.5">
                <div className="flex gap-1.5">
                  <button
                    onClick={() => fileRef.current?.click()}
                    className="flex items-center gap-1 rounded-md border border-charcoal/15 px-2.5 py-1.5 text-[11px] font-medium text-charcoal/70 hover:border-charcoal/30"
                  >
                    <Upload size={11} /> Upload
                  </button>
                  {logoUrl && (
                    <button
                      onClick={() => setLogoUrl("")}
                      className="flex items-center gap-1 rounded-md border border-charcoal/15 px-2.5 py-1.5 text-[11px] font-medium text-red-500 hover:border-red-300"
                    >
                      <Trash2 size={11} /> Remove
                    </button>
                  )}
                </div>
                <input
                  value={logoUrl.startsWith("data:") ? "" : logoUrl}
                  onChange={(e) => setLogoUrl(e.target.value)}
                  placeholder="…or paste an https:// logo URL"
                  className="w-full rounded-md border border-charcoal/15 bg-white px-2.5 py-1.5 text-[11px] outline-none focus:border-brass"
                />
              </div>
            </div>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleLogoFile(file);
                e.target.value = "";
              }}
            />
            {logoError && <p className="mt-1.5 text-[10px] text-red-500">{logoError}</p>}
            <p className="mt-1 text-[10px] text-charcoal/40">
              PNG/JPG/WebP/SVG, auto-compressed to ≤ 300 KB. External logos must be https://.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-medium uppercase tracking-wide text-charcoal/40">Primary color</label>
              <div className="mt-1.5 flex items-center gap-2">
                <input
                  type="color"
                  value={isValidHexColor(primaryColor) ? normalizeHex(primaryColor) : DEFAULT_BRANDING.primaryColor}
                  onChange={(e) => setPrimaryColor(e.target.value)}
                  className="h-9 w-11 cursor-pointer rounded border border-charcoal/15 bg-white p-1"
                  aria-label="Pick primary color"
                />
                <input
                  value={primaryColor}
                  onChange={(e) => setPrimaryColor(e.target.value)}
                  className="w-full rounded-md border border-charcoal/15 bg-white px-2.5 py-2 font-mono text-xs"
                  placeholder="#c98a3e"
                />
              </div>
            </div>
            <div>
              <label className="text-[11px] font-medium uppercase tracking-wide text-charcoal/40">Accent color</label>
              <div className="mt-1.5 flex items-center gap-2">
                <input
                  type="color"
                  value={isValidHexColor(accentColor) ? normalizeHex(accentColor) : DEFAULT_BRANDING.accentColor}
                  onChange={(e) => setAccentColor(e.target.value)}
                  className="h-9 w-11 cursor-pointer rounded border border-charcoal/15 bg-white p-1"
                  aria-label="Pick accent color"
                />
                <input
                  value={accentColor}
                  onChange={(e) => setAccentColor(e.target.value)}
                  className="w-full rounded-md border border-charcoal/15 bg-white px-2.5 py-2 font-mono text-xs"
                  placeholder="#f2ead8"
                />
              </div>
            </div>
          </div>

          <label className="flex cursor-pointer items-start gap-2.5 rounded-md border border-charcoal/10 bg-white/60 p-3">
            <input
              type="checkbox"
              checked={splashEnabled}
              onChange={(e) => setSplashEnabled(e.target.checked)}
              className="mt-0.5 h-4 w-4 accent-brass"
            />
            <span className="text-xs">
              <span className="font-medium">Branded splash screen</span>
              <span className="mt-0.5 block text-[10px] leading-relaxed text-charcoal/45">
                Brief logo + name overlay while the first panorama loads. Never blocks the tour — it fades as soon as
                the scene is ready.
              </span>
            </span>
          </label>

          {error && <p className="text-[11px] text-red-500">{error}</p>}

          {/* Live mini-preview of the public viewer header */}
          <div>
            <p className="flex items-center gap-1 text-[10px] font-medium uppercase tracking-wide text-charcoal/40">
              <Eye size={11} /> Public viewer preview
            </p>
            <div
              className="mt-1.5 flex items-center justify-between rounded-lg border border-charcoal/10 p-3"
              style={{ backgroundColor: "#1a1a1a" }}
            >
              <div className="flex min-w-0 items-center gap-2">
                {previewLogo ? (
                  <img src={previewLogo} alt="" className="h-6 w-6 rounded object-contain" />
                ) : (
                  <span
                    className="flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-bold"
                    style={{ backgroundColor: isValidHexColor(primaryColor) ? normalizeHex(primaryColor) : DEFAULT_BRANDING.primaryColor, color: "#fff" }}
                  >
                    T
                  </span>
                )}
                <span className="truncate text-xs font-semibold" style={{ color: "#f2ead8" }}>
                  {agencyName || "Tourly"}
                </span>
              </div>
              <span
                className="shrink-0 rounded-full px-2.5 py-1 text-[10px] font-medium"
                style={{
                  backgroundColor: isValidHexColor(primaryColor) ? normalizeHex(primaryColor) : DEFAULT_BRANDING.primaryColor,
                  color: "#fff",
                }}
              >
                Enquire
              </span>
            </div>
          </div>
        </div>

        <div className="flex shrink-0 items-center justify-end gap-2 border-t border-charcoal/10 px-5 py-3">
          <button
            onClick={() => {
              onChange(undefined);
              onClose();
            }}
            className="rounded-md border border-charcoal/15 px-3 py-2 text-xs font-medium text-charcoal/60 hover:border-charcoal/30"
          >
            Reset to default
          </button>
          <button
            onClick={save}
            className="rounded-md bg-charcoal px-4 py-2 text-xs font-medium text-bone hover:bg-ink"
          >
            Save branding
          </button>
        </div>
      </div>
    </div>
  );
}
