import { useEffect, useMemo, useState } from "react";
import { X, Loader2, RefreshCw, Copy, Save, PencilLine, CheckCircle2, Info, AlertTriangle, History } from "lucide-react";
import type { Tour } from "../types";
import { generateMarketing, type MarketingCopy, type MarketingFactsInput } from "../lib/generateMarketing";
import { polygonArea, roomPoints, vertexById } from "../lib/plan/geometry";

/**
 * Stage B4 — the grounded AI listing copywriter.
 *
 * Fact-first: the creator fills in what they can (price, location, size…);
 * anything missing is reported back as "not provided" rather than silently
 * invented. Every generated field is EDITABLE before use, drafts can be
 * saved with the tour, and nothing is ever auto-published — the copy leaves
 * this modal only via an explicit copy action by the creator.
 */

const FIELD_LABELS: [keyof MarketingCopy & string, string][] = [
  ["headline", "Listing headline"],
  ["title", "Listing title"],
  ["shortDescription", "Short description"],
  ["longDescription", "Listing description"],
  ["highlights", "Key highlights (one per line)"],
  ["buyerSummary", "Buyer-facing summary"],
  ["whatsappMessage", "WhatsApp enquiry / promo message"],
  ["instagramCaption", "Instagram caption"],
  ["seoTitle", "SEO title"],
  ["seoDescription", "SEO meta description"],
  ["tourIntro", "Property-tour introduction"],
];

type Props = {
  tour: Tour;
  onClose: () => void;
  onSaveDraft: (draft: Tour["marketingDrafts"]) => void;
};

export function MarketingModal({ tour, onClose, onSaveDraft }: Props) {
  const [facts, setFacts] = useState<MarketingFactsInput>({
    propertyType: "",
    location: "",
    size: "",
    price: "",
    bedrooms: "",
    bathrooms: "",
    amenities: [],
    audience: "Home buyers",
    tone: "Warm, professional",
    language: "en",
    channel: "Property portal listing",
  });
  const [amenitiesText, setAmenitiesText] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copy, setCopy] = useState<MarketingCopy | null>(null);
  const [edited, setEdited] = useState<Record<string, string>>({});
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [savedFlash, setSavedFlash] = useState(false);
  const [showDrafts, setShowDrafts] = useState(false);

  // Honest verified fact from our own geometry: the calibrated plan total.
  const planAreaM2 = useMemo(() => {
    if (!tour.plan?.scale?.calibrated) return undefined;
    let total = 0;
    for (const floor of tour.plan.floors) {
      const resolve = vertexById(floor.vertices);
      for (const room of floor.rooms) total += polygonArea(roomPoints(room, resolve));
    }
    return total > 0 ? total : undefined;
  }, [tour.plan]);

  const [usePlanArea, setUsePlanArea] = useState(true);

  async function run() {
    setLoading(true);
    setError(null);
    const factInput: MarketingFactsInput = {
      ...facts,
      amenities: amenitiesText
        .split(",")
        .map((a) => a.trim())
        .filter(Boolean)
        .slice(0, 15),
      planAreaM2: usePlanArea ? planAreaM2 : undefined,
    };
    const result = await generateMarketing(
      tour.name,
      tour.subtitle,
      tour.stops.map((s) => ({ title: s.title, note: s.note })),
      factInput
    );
    setLoading(false);
    if (result.ok) {
      setCopy(result.copy);
      setEdited({});
    } else {
      setError(result.error);
    }
  }

  // First open: generate straight away from what the tour already contains,
  // so the button in the editor keeps its old one-click behaviour.
  useEffect(() => {
    void run();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function fieldValue(key: string): string {
    if (key === "highlights") {
      // Array on the wire, one-per-line in the editor — local edits stay
      // local (no AI request needed to fix a line).
      if (typeof edited.highlights === "string") return edited.highlights;
      return (copy?.highlights ?? []).join("\n");
    }
    return edited[key] ?? ((copy as any)?.[key] as string | undefined) ?? "";
  }

  function setFieldValue(key: string, value: string) {
    setEdited((prev) => ({ ...prev, [key]: value }));
  }

  async function copyField(key: string) {
    const text =
      key === "highlights"
        ? fieldValue(key)
            .split("\n")
            .map((l) => l.trim())
            .filter(Boolean)
            .map((l) => `• ${l}`)
            .join("\n")
        : fieldValue(key);
    try {
      await navigator.clipboard.writeText(text);
      setCopiedField(key);
      setTimeout(() => setCopiedField(null), 1600);
    } catch {
      // Clipboard can be blocked — the text stays selectable for manual copy.
    }
  }

  function saveDraft() {
    if (!copy) return;
    const fields: Record<string, string> = {};
    for (const [key] of FIELD_LABELS) fields[key] = fieldValue(key);
    const drafts = [
      {
        id: crypto.randomUUID(),
        createdAt: Date.now(),
        language: facts.language ?? "en",
        channel: facts.channel ?? "",
        fields,
      },
      ...(tour.marketingDrafts ?? []),
    ].slice(0, 10);
    onSaveDraft(drafts);
    setSavedFlash(true);
    setTimeout(() => setSavedFlash(false), 1800);
  }

  const missing = copy?.missingFields ?? [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-charcoal/50 px-3 py-4 backdrop-blur-sm sm:px-6">
      <div className="flex max-h-[92vh] w-full max-w-3xl flex-col overflow-hidden rounded-xl bg-white shadow-xl">
        {/* header */}
        <div className="flex shrink-0 items-center justify-between border-b border-charcoal/10 px-5 py-3">
          <div className="flex items-center gap-2">
            <PencilLine className="text-brass" size={15} />
            <p className="font-display text-sm font-semibold">AI listing copywriter</p>
          </div>
          <div className="flex items-center gap-2">
            {tour.marketingDrafts && tour.marketingDrafts.length > 0 && (
              <button
                onClick={() => setShowDrafts((s) => !s)}
                className="flex items-center gap-1 rounded-md border border-charcoal/15 px-2 py-1 text-[11px] font-medium text-charcoal/60 hover:border-charcoal/30"
              >
                <History size={11} /> Drafts ({tour.marketingDrafts.length})
              </button>
            )}
            <button onClick={onClose} className="text-charcoal/40 hover:text-charcoal" aria-label="Close">
              <X size={16} />
            </button>
          </div>
        </div>

        <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">
          {showDrafts && (
            <div className="mb-4 space-y-2 rounded-lg border border-charcoal/10 bg-bone/50 p-3">
              {tour.marketingDrafts?.map((d) => (
                <button
                  key={d.id}
                  onClick={() => {
                    setCopy((prev) => prev ?? ({ title: "Draft" } as MarketingCopy));
                    setEdited(d.fields);
                    setShowDrafts(false);
                  }}
                  className="flex w-full items-center justify-between rounded border border-charcoal/10 bg-white px-3 py-2 text-left text-xs hover:border-brass"
                >
                  <span className="min-w-0 flex-1 truncate">
                    {d.fields.headline || d.fields.title || "Untitled draft"}
                  </span>
                  <span className="ml-2 shrink-0 font-mono text-[10px] text-charcoal/40">
                    {new Date(d.createdAt).toLocaleDateString()} · {d.language} · {d.channel || "—"}
                  </span>
                </button>
              ))}
            </div>
          )}

          {/* facts form */}
          <div className="grid grid-cols-2 gap-2.5">
            <Field label="Property type" value={facts.propertyType ?? ""} onChange={(v) => setFacts((f) => ({ ...f, propertyType: v }))} placeholder="e.g. 2BHK apartment" />
            <Field label="Location" value={facts.location ?? ""} onChange={(v) => setFacts((f) => ({ ...f, location: v }))} placeholder="Area, city (as you want it shown)" />
            <Field label="Price" value={facts.price ?? ""} onChange={(v) => setFacts((f) => ({ ...f, price: v }))} placeholder="e.g. ₹85 lakh" />
            <Field label="Size" value={facts.size ?? ""} onChange={(v) => setFacts((f) => ({ ...f, size: v }))} placeholder="e.g. 950 sq ft" />
            <Field label="Bedrooms" value={facts.bedrooms ?? ""} onChange={(v) => setFacts((f) => ({ ...f, bedrooms: v }))} placeholder="e.g. 2" />
            <Field label="Bathrooms" value={facts.bathrooms ?? ""} onChange={(v) => setFacts((f) => ({ ...f, bathrooms: v }))} placeholder="e.g. 2" />
            <Field label="Audience" value={facts.audience ?? ""} onChange={(v) => setFacts((f) => ({ ...f, audience: v }))} placeholder="Who is this for?" />
            <Field label="Tone" value={facts.tone ?? ""} onChange={(v) => setFacts((f) => ({ ...f, tone: v }))} placeholder="e.g. Warm, professional" />
            <div className="col-span-2">
              <label className="text-[10px] font-medium uppercase tracking-wide text-charcoal/40">Amenities (comma-separated)</label>
              <input
                value={amenitiesText}
                onChange={(e) => setAmenitiesText(e.target.value.slice(0, 300))}
                placeholder="e.g. modular kitchen, society gym, covered parking"
                className="mt-1 w-full rounded-md border border-charcoal/15 bg-bone/40 px-2.5 py-2 text-xs outline-none focus:border-brass"
              />
            </div>
            <div>
              <label className="text-[10px] font-medium uppercase tracking-wide text-charcoal/40">Language</label>
              <select
                value={facts.language}
                onChange={(e) => setFacts((f) => ({ ...f, language: e.target.value as MarketingFactsInput["language"] }))}
                className="mt-1 w-full rounded-md border border-charcoal/15 bg-bone/40 px-2 py-2 text-xs outline-none focus:border-brass"
              >
                <option value="en">English</option>
                <option value="hi">हिंदी (Hindi)</option>
                <option value="hinglish">Hinglish</option>
              </select>
            </div>
            <div>
              <label className="text-[10px] font-medium uppercase tracking-wide text-charcoal/40">Channel</label>
              <select
                value={facts.channel}
                onChange={(e) => setFacts((f) => ({ ...f, channel: e.target.value }))}
                className="mt-1 w-full rounded-md border border-charcoal/15 bg-bone/40 px-2 py-2 text-xs outline-none focus:border-brass"
              >
                <option>Property portal listing</option>
                <option>WhatsApp</option>
                <option>Instagram</option>
                <option>Website / SEO</option>
                <option>General</option>
              </select>
            </div>
          </div>

          {planAreaM2 !== undefined && (
            <label className="mt-2.5 flex cursor-pointer items-center gap-1.5 rounded-md bg-emerald-50 px-2.5 py-1.5 text-[10px] text-emerald-800">
              <input type="checkbox" checked={usePlanArea} onChange={(e) => setUsePlanArea(e.target.checked)} className="accent-brass" />
              <Info size={11} className="shrink-0" />
              Use the floor plan's calibrated total — {planAreaM2.toFixed(1)} m² (measured from your plan geometry, not a guess)
            </label>
          )}

          <button
            onClick={run}
            disabled={loading}
            className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-md bg-charcoal px-3 py-2 text-xs font-semibold text-bone disabled:opacity-40"
          >
            {loading ? <Loader2 size={13} className="animate-spin" /> : <RefreshCw size={13} />}
            {loading ? "Drafting from your facts…" : copy ? "Regenerate" : "Generate copy"}
          </button>

          {/* honest missing-info notice */}
          {copy && missing.length > 0 && (
            <div className="mt-3 flex items-start gap-2 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-[11px] leading-relaxed text-amber-800">
              <AlertTriangle size={12} className="mt-0.5 shrink-0" />
              <span>
                <b>Not provided (and not invented):</b> {missing.join(", ")}. Add them above and regenerate for stronger,
                more specific copy.
              </span>
            </div>
          )}
          {copy?.note && (
            <p className="mt-2 text-[10px] leading-relaxed text-charcoal/40">{copy.note}</p>
          )}

          {loading && !copy && (
            <div className="flex items-center gap-2 py-10 text-sm text-charcoal/50">
              <Loader2 size={16} className="animate-spin" /> Drafting from your tour's content…
            </div>
          )}

          {error && (
            <div className="py-6">
              <p className="text-sm text-charcoal/60">{error}</p>
              <button onClick={run} className="mt-3 flex items-center gap-1.5 rounded-md bg-charcoal px-3 py-1.5 text-xs font-medium text-bone">
                <RefreshCw size={12} /> Try again
              </button>
            </div>
          )}

          {/* editable outputs */}
          {copy && (
            <div className="mt-4 flex flex-col gap-3.5">
              {FIELD_LABELS.map(([key, label]) => (
                <div key={String(key)}>
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-medium uppercase tracking-wide text-charcoal/40">{label}</span>
                    <button
                      onClick={() => copyField(String(key))}
                      className={`flex items-center gap-1 text-[11px] ${copiedField === key ? "text-emerald-600" : "text-brass hover:underline"}`}
                    >
                      {copiedField === key ? <CheckCircle2 size={11} /> : <Copy size={11} />}
                      {copiedField === key ? "Copied" : "Copy"}
                    </button>
                  </div>
                  <textarea
                    value={fieldValue(String(key))}
                    onChange={(e) => setFieldValue(String(key), e.target.value)}
                    rows={["longDescription", "tourIntro", "highlights", "buyerSummary"].includes(String(key)) ? 3 : 2}
                    className="mt-1 w-full resize-y rounded-md border border-charcoal/10 bg-bone/40 p-2 text-sm leading-relaxed text-charcoal/85 outline-none focus:border-brass"
                  />
                </div>
              ))}

              <div className="flex items-center gap-2">
                <button
                  onClick={saveDraft}
                  className={`flex flex-1 items-center justify-center gap-1.5 rounded-md px-3 py-2 text-xs font-semibold text-white ${savedFlash ? "bg-emerald-600" : "bg-sage"}`}
                >
                  {savedFlash ? <CheckCircle2 size={13} /> : <Save size={13} />}
                  {savedFlash ? "Saved with tour" : "Save draft with tour"}
                </button>
                <p className="flex-1 text-[10px] leading-relaxed text-charcoal/40">
                  Drafts stay private to your tour. Copy is only shared when YOU copy it out — nothing auto-publishes.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Field({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <div>
      <label className="text-[10px] font-medium uppercase tracking-wide text-charcoal/40">{label}</label>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value.slice(0, 120))}
        placeholder={placeholder}
        className="mt-1 w-full rounded-md border border-charcoal/15 bg-bone/40 px-2.5 py-2 text-xs outline-none focus:border-brass"
      />
    </div>
  );
}
