import { useEffect, useRef, useState } from "react";
import { Map, X, Maximize2, Minimize2, Compass } from "lucide-react";
import { Tour } from "../types";
import { radarRotationDeg } from "../lib/floorPlan";
import { hexToRgba } from "../lib/branding";

type Props = {
  tour: Tour;
  activeStopId: string;
  cameraYawDeg: number;
  onSelectStop: (stopId: string) => void;
  /** Branding accent for markers/cone; defaults to brass. */
  accentColor?: string;
};

/**
 * Public-viewer floor-plan HUD (Feature C). A responsive overlay showing
 * the blueprint with clickable room markers, an active-room highlight, and
 * — ONLY when the creator calibrated the marker's compass — a radar/FOV
 * cone that rotates with the live camera yaw. No calibration, no cone: we
 * never show a direction indicator we can't justify.
 */
export default function FloorPlanHUD({ tour, activeStopId, cameraYawDeg, onSelectStop, accentColor }: Props) {
  const [open, setOpen] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const planRef = useRef<HTMLDivElement>(null);

  const floorPlan = tour.floorPlan;
  const accent = accentColor ?? "#c98a3e";

  useEffect(() => {
    if (!floorPlan || floorPlan.markers.length === 0) setOpen(false);
  }, [floorPlan]);

  if (!floorPlan || floorPlan.markers.length === 0) return null;

  const activeMarker = floorPlan.markers.find((m) => m.stopId === activeStopId);
  const coneRotation = activeMarker ? radarRotationDeg(cameraYawDeg, activeMarker.northYaw) : null;

  return (
    <>
      <button
        onClick={() => setOpen((o) => !o)}
        className={`fixed bottom-36 right-4 z-30 flex items-center gap-1.5 rounded-full px-3.5 py-2.5 text-xs font-medium shadow-xl backdrop-blur transition-colors sm:bottom-40 sm:right-8 ${
          open ? "bg-brass text-bone" : "bg-ink/70 text-bone hover:bg-ink/90"
        }`}
        style={open ? { backgroundColor: accent } : undefined}
        aria-pressed={open}
      >
        <Map size={14} /> Floor plan
      </button>

      {open && (
        <div
          className={`fixed z-30 overflow-hidden rounded-xl border border-white/10 bg-ink/95 shadow-2xl backdrop-blur ${
            expanded
              ? "inset-x-4 bottom-4 top-16 sm:inset-x-8 sm:bottom-8 sm:top-20"
              : "bottom-4 right-4 h-56 w-64 sm:bottom-8 sm:right-8 sm:h-72 sm:w-96"
          }`}
        >
          <div className="flex items-center justify-between border-b border-white/10 px-3 py-2">
            <span className="text-[11px] font-medium text-bone/80">
              {expanded ? "Floor plan — tap a room" : "Floor plan"}
            </span>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setExpanded((e) => !e)}
                className="rounded p-1 text-bone/50 hover:text-bone"
                aria-label={expanded ? "Shrink floor plan" : "Expand floor plan"}
              >
                {expanded ? <Minimize2 size={13} /> : <Maximize2 size={13} />}
              </button>
              <button
                onClick={() => setOpen(false)}
                className="rounded p-1 text-bone/50 hover:text-bone"
                aria-label="Close floor plan"
              >
                <X size={14} />
              </button>
            </div>
          </div>
          <div
            ref={planRef}
            className="relative h-[calc(100%-33px)] w-full overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={floorPlan.url && floorPlan.url.startsWith("https://") ? floorPlan.url : floorPlan.dataUrl}
              alt="Floor plan"
              className="h-full w-full object-contain"
              draggable={false}
            />
            {floorPlan.markers.map((m) => {
              const stop = tour.stops.find((s) => s.id === m.stopId);
              if (!stop) return null;
              const isActive = m.stopId === activeStopId;
              return (
                <button
                  key={m.stopId}
                  onClick={() => onSelectStop(m.stopId)}
                  style={{ left: `${m.x * 100}%`, top: `${m.y * 100}%` }}
                  className="group absolute -translate-x-1/2 -translate-y-1/2"
                  title={stop.title}
                >
                  {/* Radar cone — only when the creator calibrated this marker. */}
                  {isActive && coneRotation !== null && (
                    <span
                      className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-50% -translate-y-50%"
                      style={{
                        width: expanded ? 110 : 84,
                        height: expanded ? 110 : 84,
                        background: `conic-gradient(from ${coneRotation - 26}deg, ${hexToRgba(accent, 0.55)} 0deg, ${hexToRgba(
                          accent,
                          0.12
                        )} 52deg, transparent 52deg)`,
                        borderRadius: "50%",
                        transform: "translate(-50%, -50%)",
                      }}
                    />
                  )}
                  <span
                    className={`relative flex items-center justify-center rounded-full border-2 shadow-md transition-transform group-hover:scale-110 ${
                      isActive ? "h-5 w-5 border-white" : "h-3.5 w-3.5 border-white/80"
                    }`}
                    style={{
                      backgroundColor: isActive ? accent : "rgba(26,26,26,0.75)",
                      animation: isActive ? "hud-pulse 2s ease-in-out infinite" : undefined,
                    }}
                  />
                  <span
                    className={`pointer-events-none absolute left-1/2 top-full mt-1 -translate-x-1/2 whitespace-nowrap rounded px-1.5 py-0.5 text-[9px] font-medium text-white transition-opacity ${
                      isActive || expanded ? "opacity-100" : "opacity-0 group-hover:opacity-100"
                    }`}
                    style={{ backgroundColor: "rgba(10,10,10,0.8)" }}
                  >
                    {stop.title}
                  </span>
                </button>
              );
            })}
            {activeMarker && coneRotation === null && (
              <div className="absolute bottom-2 left-2 flex items-center gap-1 rounded bg-black/60 px-2 py-1 text-[9px] text-bone/70">
                <Compass size={10} /> Direction not calibrated for this room
              </div>
            )}
          </div>
        </div>
      )}
      <style>{`
        @keyframes hud-pulse {
          0%, 100% { box-shadow: 0 0 0 0 rgba(255,255,255,0.35); }
          50% { box-shadow: 0 0 0 6px rgba(255,255,255,0); }
        }
      `}</style>
    </>
  );
}
