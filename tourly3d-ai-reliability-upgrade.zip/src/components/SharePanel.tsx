import { useEffect, useState } from "react";
import { Check, Copy, Download, ExternalLink, Loader2, MessageCircle, QrCode, ShieldCheck } from "lucide-react";
import { buildShareUrl, buildEmbedUrl } from "../lib/tourAnalytics";
import { generateShareQr } from "../lib/qr";

/**
 * Stage C — post-publish share panel. Everything an agent needs to get
 * the tour in front of buyers: the public link (tagged ?src=link), a QR
 * code for print/brochures (?src=qr), a WhatsApp share (?src=wa) and an
 * embed snippet (?embed=1&src=embed). The src tags are what make the
 * Analytics page able to show where visitors came from.
 *
 * Honest limits surfaced in the UI: the public URL is only verified
 * working when the agent clicks "Open" themselves — this panel never
 * claims the deployed endpoint was tested by anyone else.
 */

export default function SharePanel({ tourId, tourName, passwordProtected }: { tourId: string; tourName: string; passwordProtected: boolean }) {
  const shareUrl = buildShareUrl(tourId, "link");
  const qrUrl = buildShareUrl(tourId, "qr");
  const waUrl = `https://wa.me/?text=${encodeURIComponent(`Take a 3D walkthrough of "${tourName}": ${buildShareUrl(tourId, "wa")}`)}`;

  const [qr, setQr] = useState<{ state: "loading" } | { state: "ok"; dataUrl: string } | { state: "error"; message: string }>({ state: "loading" });
  const [copied, setCopied] = useState<"link" | "embed" | "wa" | null>(null);

  useEffect(() => {
    let cancelled = false;
    setQr({ state: "loading" });
    generateShareQr(qrUrl).then((result) => {
      if (cancelled) return;
      setQr(result.ok ? { state: "ok", dataUrl: result.dataUrl } : { state: "error", message: result.error });
    });
    return () => {
      cancelled = true;
    };
  }, [qrUrl]);

  async function copy(which: "link" | "embed" | "wa", text: string) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(which);
      setTimeout(() => setCopied(null), 1800);
    } catch {
      // Clipboard blocked — the text stays selectable in the input row.
    }
  }

  const embedSnippet = `<iframe src="${buildEmbedUrl(tourId)}" width="100%" height="520" style="border:0;border-radius:12px" allow="fullscreen; accelerometer; gyroscope" loading="lazy"></iframe>`;

  return (
    <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
      {/* Public link + open (the real test) */}
      <div className="rounded-lg border border-charcoal/10 bg-white p-4">
        <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-charcoal/50">
          <ExternalLink size={13} className="text-brass" /> Public link
        </p>
        <div className="mt-2 flex items-center gap-1.5">
          <input
            readOnly
            value={shareUrl}
            onFocus={(e) => e.currentTarget.select()}
            className="min-w-0 flex-1 rounded-md border border-charcoal/15 bg-bone/40 px-2 py-1.5 font-mono text-[11px]"
            aria-label="Public tour link"
          />
          <button
            onClick={() => copy("link", shareUrl)}
            className="flex shrink-0 items-center gap-1 rounded-md border border-charcoal/15 px-2 py-1.5 text-[11px] font-medium hover:bg-charcoal/5"
          >
            {copied === "link" ? <Check size={12} className="text-emerald-600" /> : <Copy size={12} />}
            {copied === "link" ? "Copied" : "Copy"}
          </button>
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-2">
          <a
            href={buildShareUrl(tourId, "link")}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 rounded-md bg-sage px-2.5 py-1.5 text-[11px] font-semibold text-white hover:opacity-90"
          >
            <ExternalLink size={12} /> Open & test it
          </a>
          {passwordProtected && (
            <span className="flex items-center gap-1 text-[10px] text-charcoal/45">
              <ShieldCheck size={11} className="text-sage" /> Password-protected — visitors will be asked for it.
            </span>
          )}
        </div>
      </div>

      {/* QR code */}
      <div className="rounded-lg border border-charcoal/10 bg-white p-4">
        <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-charcoal/50">
          <QrCode size={13} className="text-brass" /> QR code
        </p>
        <div className="mt-2 flex items-center gap-3">
          <div className="flex h-24 w-24 shrink-0 items-center justify-center rounded-md border border-charcoal/10 bg-white">
            {qr.state === "loading" && <Loader2 size={18} className="animate-spin text-charcoal/30" />}
            {qr.state === "ok" && <img src={qr.dataUrl} alt={`QR code for the ${tourName} tour`} className="h-full w-full object-contain" />}
            {qr.state === "error" && <span className="p-2 text-center text-[9px] leading-tight text-charcoal/40">{qr.message}</span>}
          </div>
          <div className="min-w-0 text-[11px] text-charcoal/55">
            <p>Print it on a board or brochure — the scan opens the tour on any phone.</p>
            {qr.state === "ok" && (
              <a
                href={qr.dataUrl}
                download={`tourly-${tourId}-qr.png`}
                className="mt-1.5 inline-flex items-center gap-1 font-medium text-sage hover:underline"
              >
                <Download size={12} /> Download PNG
              </a>
            )}
            <p className="mt-1 text-[10px] text-charcoal/40">Scans are counted as “QR” in Analytics.</p>
          </div>
        </div>
      </div>

      {/* WhatsApp + embed */}
      <div className="rounded-lg border border-charcoal/10 bg-white p-4">
        <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-charcoal/50">
          <MessageCircle size={13} className="text-brass" /> Share & embed
        </p>
        <a
          href={waUrl}
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => copy("wa", waUrl)}
          className="mt-2 flex w-full items-center justify-center gap-1.5 rounded-md bg-[#25D366] px-3 py-2 text-[11px] font-semibold text-white hover:opacity-90"
        >
          <MessageCircle size={13} /> Share on WhatsApp
        </a>
        <p className="mt-1 text-[10px] text-charcoal/40">
          Opens WhatsApp with the message ready — you pick the chat and press send yourself.
        </p>
        <div className="mt-2 flex items-center gap-1.5">
          <code className="min-w-0 flex-1 truncate rounded-md border border-charcoal/15 bg-bone/40 px-2 py-1.5 font-mono text-[10px]">
            {embedSnippet}
          </code>
          <button
            onClick={() => copy("embed", embedSnippet)}
            className="flex shrink-0 items-center gap-1 rounded-md border border-charcoal/15 px-2 py-1.5 text-[11px] font-medium hover:bg-charcoal/5"
          >
            {copied === "embed" ? <Check size={12} className="text-emerald-600" /> : <Copy size={12} />}
            {copied === "embed" ? "Copied" : "Copy"}
          </button>
        </div>
        <p className="mt-1 text-[10px] text-charcoal/40">Paste into any website that accepts HTML.</p>
      </div>
    </div>
  );
}
