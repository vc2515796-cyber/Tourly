import { lazy, Suspense } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Landing from "./pages/Landing";
import NotFound from "./pages/NotFound";
import { AuthProvider } from "./lib/auth";
import ProtectedRoute from "./components/ProtectedRoute";
import CookieConsent, { RouteTracker } from "./components/CookieConsent";

// Everything except the landing page is code-split, so first load doesn't
// download the editor, three.js viewer, or Firebase UI up front.
const Home = lazy(() => import("./pages/Home"));
const Editor = lazy(() => import("./pages/Editor"));
const Viewer = lazy(() => import("./pages/Viewer"));
const Founder = lazy(() => import("./pages/Founder"));
const Analytics = lazy(() => import("./pages/Analytics"));
const Login = lazy(() => import("./pages/Login"));
const Privacy = lazy(() => import("./pages/Privacy"));
const Terms = lazy(() => import("./pages/Terms"));
const Notices = lazy(() => import("./pages/Notices"));
const Leads = lazy(() => import("./pages/Leads"));
// Admin-only AI diagnostics — unlisted route; the SERVER (ADMIN_EMAILS +
// verified token) is the real gate, ProtectedRoute is just clean UX.
const AiDiagnostics = lazy(() => import("./pages/AiDiagnostics"));

function PageLoader() {
  return (
    <div role="status" aria-live="polite" className="flex min-h-full items-center justify-center bg-bone">
      <p className="font-mono text-xs text-charcoal/65">Loading…</p>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <RouteTracker />
        <Suspense fallback={<PageLoader />}>
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/login" element={<Login />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/notices" element={<Notices />} />
            <Route
              path="/dashboard"
              element={
                <ProtectedRoute>
                  <Home />
                </ProtectedRoute>
              }
            />
            <Route
              path="/editor/:id"
              element={
                <ProtectedRoute>
                  <Editor />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/ai"
              element={
                <ProtectedRoute>
                  <AiDiagnostics />
                </ProtectedRoute>
              }
            />
            {/* Public — shared tour links must work for anyone, signed in or not */}
            <Route path="/tour/:id" element={<Viewer />} />
            <Route path="/founder" element={<Founder />} />
            <Route
              path="/analytics"
              element={
                <ProtectedRoute>
                  <Analytics />
                </ProtectedRoute>
              }
            />
            <Route
              path="/leads"
              element={
                <ProtectedRoute>
                  <Leads />
                </ProtectedRoute>
              }
            />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Suspense>
        <CookieConsent />
      </BrowserRouter>
    </AuthProvider>
  );
}
