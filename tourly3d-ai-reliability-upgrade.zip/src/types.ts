export type StopMedia = {
  kind: "image" | "video" | "panorama" | "wide";
  dataUrl: string;
  /** True when this panorama wasn't a real capture — AI generated the
   *  surrounding scene from a single regular photo. Always keep some
   *  honest marker when this is true; never present it as a real scan. */
  synthetic?: boolean;
  /** Cloud object-storage URL (S3-compatible, set when the deployment has
   *  S3_* env vars configured and the upload succeeded). When present the
   *  VIEWER loads the full-resolution media from this URL; `dataUrl` then
   *  holds only a small embedded preview/thumbnail (or "" for video), which
   *  keeps every existing code path (thumbs, AI analysis, publishing
   *  fallback) working. Optional and absent on all pre-existing tours. */
  url?: string;
};

export type Hotspot = {
  id: string;
  targetStopId: string;
  label: string;
  /** degrees, standard equirectangular convention: yaw -180..180, pitch -90..90 */
  yaw: number;
  pitch: number;
  iconStyle?: "chevron" | "circle" | "arrow";
};

export type Stop = {
  id: string;
  title: string;
  note: string;
  media: StopMedia | null;
  hotspots: Hotspot[];
};

/** A room marker placed on the tour's floor-plan blueprint.
 *  Coordinates are NORMALIZED (0..1) against the blueprint image's natural
 *  dimensions, so markers stay aligned no matter how the overlay is scaled
 *  or cropped on screen. Placement is MANUAL — there is no automatic
 *  geometric mapping between panorama pixels and blueprint coordinates. */
export type FloorPlanMarker = {
  stopId: string;
  /** 0..1 of blueprint width, left → right */
  x: number;
  /** 0..1 of blueprint height, top → bottom */
  y: number;
  /** Manual calibration: the panorama camera yaw (degrees, same convention
   *  as hotspots) that points "up" on the blueprint. The viewer's radar
   *  cone rotates relative to this. 0 = uncalibrated (cone hidden). */
  northYaw?: number;
};

export type FloorPlan = {
  dataUrl: string;
  /** Cloud URL variant (same convention as StopMedia.url) — optional. */
  url?: string;
  /** Natural pixel dimensions of the blueprint, captured at upload time so
   *  marker normalization stays correct even before the image re-decodes. */
  width: number;
  height: number;
  markers: FloorPlanMarker[];
};

/** A persisted, versioned historical capture of one scene. Append-only:
 *  saving a new snapshot never overwrites an earlier one. Large media is
 *  deduplicated — if the scene's media hasn't changed since the previous
 *  snapshot, the new snapshot references it by id instead of copying the
 *  (potentially multi-MB) dataUrl again. */
export type ConstructionSnapshot = {
  id: string;
  tourId: string;
  stopId: string;
  /** Capture date (epoch ms) — user-editable so a backdated photo can be
   *  recorded honestly. */
  capturedAt: number;
  stageLabel: string;
  note?: string;
  stopTitle: string;
  mediaKind?: StopMedia["kind"];
  mediaUrl?: string;
  mediaDataUrl?: string;
  /** Dedup: when the media is identical to an earlier snapshot, only this
   *  reference is stored and mediaDataUrl/mediaUrl are omitted. */
  sameMediaAsSnapshotId?: string;
};

/** Optional white-label branding (Feature E). */
export type Branding = {
  agencyName?: string;
  /** data:image/... (validated + compressed at upload) or an https:// URL.
   *  javascript:/http: URLs are rejected client-side. */
  logoUrl?: string;
  /** Hex color, e.g. #1a1a1a — validated before saving. */
  primaryColor?: string;
  accentColor?: string;
  /** Show a brief branded splash while the first panorama loads. */
  splashEnabled?: boolean;
};

/** Stage B2/B3: the typed, versioned floor-plan document (rooms, walls,
 *  doors/windows, floors, scale calibration) edited in the Plan Studio and
 *  rendered by both the 2D editor and the 3D dollhouse. Lives inside the
 *  tour so it persists + publishes through the existing pipeline. */
export type TourPlan = import("./lib/plan/model").FloorPlanDocument;

/** Stage B4: a copywriter draft the creator chose to keep. Always a DRAFT —
 *  nothing is published anywhere without the creator copying it out or
 *  approving it explicitly. */
export type SavedMarketingDraft = {
  id: string;
  createdAt: number;
  /** language / channel context the draft was generated for */
  language: string;
  channel: string;
  fields: Record<string, string>;
};

export type Tour = {
  id: string;
  name: string;
  subtitle: string;
  createdAt: number;
  updatedAt: number;
  stops: Stop[];
  /** Optional WhatsApp number (with country code, digits only) shown as an
   *  enquiry button on the public tour. Undefined on older tours. */
  whatsappNumber?: string;
  /** Optional password for the PUBLISHED copy. Kept only in the creator's
   *  own browser; on publish it's sent separately, hashed server-side, and
   *  never stored inside the shared tour data. */
  viewPassword?: string;
  /** Optional folder name for organising tours on the dashboard. */
  folder?: string;
  /** Optional floor-plan blueprint + room markers (Feature C). */
  floorPlan?: FloorPlan;
  /** Optional append-only construction progress snapshots (Feature D). */
  snapshots?: ConstructionSnapshot[];
  /** Optional white-label branding (Feature E). */
  branding?: Branding;
  /** Stage B2/B3: optional floor-plan document (Plan Studio). Additive —
   *  older tours without it are untouched, and its absence changes nothing. */
  plan?: TourPlan;
  /** Stage B4: saved AI copywriter drafts (each user-editable before use). */
  marketingDrafts?: SavedMarketingDraft[];
};

/** Resolves the media source a viewer/thumbnail should actually load:
 *  the cloud URL when present, else the embedded dataUrl. */
export function mediaSrc(media: StopMedia | null | undefined): string {
  if (!media) return "";
  return media.url && media.url.startsWith("https://") ? media.url : media.dataUrl;
}
