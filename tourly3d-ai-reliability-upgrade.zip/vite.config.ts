import { defineConfig, Plugin } from "vite";
import react from "@vitejs/plugin-react";

// Netlify exposes the site's primary URL as `URL` at build time. It's used
// to make canonical / Open Graph URLs absolute (link-preview crawlers need
// absolute image URLs). Override with VITE_SITE_URL for a custom domain.
// (globalThis avoids needing @types/node just for this config file.)
const buildEnv: Record<string, string | undefined> = (globalThis as any).process?.env ?? {};
const SITE_URL = (buildEnv.VITE_SITE_URL || buildEnv.URL || "").replace(/\/$/, "");

function siteUrlPlugin(): Plugin {
  return {
    name: "tourly-site-url",
    transformIndexHtml: (html) => html.split("__SITE_URL__").join(SITE_URL),
  };
}

export default defineConfig({
  plugins: [react(), siteUrlPlugin()],
  build: {
    rollupOptions: {
      output: {
        // Keep the heavy libraries in their own cacheable chunks so the
        // landing page doesn't wait on code it doesn't use yet.
        manualChunks: {
          three: ["three"],
          firebase: ["firebase/app", "firebase/auth"],
          react: ["react", "react-dom", "react-router-dom"],
        },
      },
    },
  },
});
