/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#14181C",
        "ink-soft": "#1E2329",
        bone: "#F9F8F3",
        "bone-soft": "#F1EEE4",
        brass: "#B83C20",
        "brass-soft": "#E4512F",
        sage: "#295545",
        charcoal: "#1A1D1C",
      },
      fontFamily: {
        display: ["'Space Grotesk'", "sans-serif"],
        serif: ["'Fraunces'", "serif"],
        body: ["'Inter'", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"],
      },
    },
  },
  plugins: [],
};
