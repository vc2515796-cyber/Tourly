# Tourly3D — Netlify deployment quick start

This ZIP contains a single top-level `tourly3d/` folder with the project inside. Do not upload the ZIP itself into your GitHub repository. Extract it first and use the `tourly3d/` folder contents.

## Recommended: Git-based deployment (supports Netlify Functions)

1. Extract this ZIP on your device.
2. Upload the *contents* of this folder to the root of a GitHub repository. The repository root must contain `package.json`, `package-lock.json`, `index.html`, `src/`, `netlify/`, and `netlify.toml`.
3. In Netlify, choose **Add new site / Add new project → Import an existing project** and select that repository.
4. Set the base/root directory to blank or `.` (the folder containing `package.json`).
5. Build command: `npm run build`
6. Publish directory: `dist`
7. Functions directory: `netlify/functions` (already specified in `netlify.toml`).
8. Deploy. Configure only the environment variables needed for features you enable. See `DEPLOY.md` and `.env.example`.

`netlify.toml` already defines the build, SPA fallback redirect, security headers, asset caching, edge function routing, and `NPM_FLAGS = "--include=dev"` (see below). Netlify should read these settings from the repository.

## Build requirements (important)

`npm run build` compiles TypeScript (`tsc`), typechecks the Netlify Functions, and runs `vite build`. All compiler/bundler/type packages (including `@types/node`, `@types/react`, `@types/react-dom`, `@types/three` and `vite/client`) are declared in **`dependencies`** of `package.json`, so any complete install contains them.

Do NOT install with production-only flags. An install that skips packages —

- `npm install --production`
- `npm ci --omit=dev`
- or a `NODE_ENV=production` / `NPM_FLAGS=--production` environment setting on CI

— previously made the build fail with `tsc: not found` or errors like `TS2688: Cannot find type definition file for 'vite/client'` / `TS2307: Cannot find module 'react' or its corresponding type declarations`.

If you ever see such errors: delete `node_modules`, run a plain `npm install`, and make sure the Netlify UI does not set `NPM_FLAGS` to `--production`/`--omit=dev`. The build also runs a preflight check (`scripts/preflight-build.mjs`) that names exactly what is missing and how to fix it.

## If your build environment reports missing packages anyway

This package's manifests have been machine-audited as consistent: `package.json` declares all 21 dependencies (including TypeScript, Vite, Tailwind, every `@types/*` and `@netlify/*` package) with **no devDependencies**, and `package-lock.json` (lockfileVersion 3) locks all 401 packages — a complete install has been verified with npm 9, npm 10 and npm 11, including `npm ci --omit=dev`. If your environment still reports packages missing, the problem is outside this folder. Check, in order:

1. **Which `package.json` is your build actually using?** The ZIP extracts to a `tourly3d/` folder; the build must run inside it. On Netlify: Site configuration → Build & deploy → Base directory. A `package.json` that keeps the toolchain in `devDependencies` is an **older copy** of this project, not this ZIP's files.
2. **Did the install step fail?** Read the lines above the error. A failed install (network error, registry proxy, `ENOTFOUND`/`E404`, out of disk) leaves `node_modules` empty or partial, which every later step then reports as "package missing".
3. **Is another package manager or lockfile present?** A `yarn.lock` or `pnpm-lock.yaml` in the build directory makes the installer ignore `package-lock.json`. This project is npm-only — remove other lockfiles.
4. **Environment overrides.** Netlify UI environment variables override `netlify.toml`; make sure `NPM_FLAGS` is not `--production`/`--omit=dev` and `NODE_ENV` is not forcing a production install. (With this manifest even `--omit=dev` installs the toolchain — but that setting combined with an older manifest is exactly what previously broke builds.)
5. **Node version.** `package.json` declares `engines.node >= 18` (Vite 5 requirement). The preflight banner prints the Node/npm versions it runs under — include them in any bug report.

## Important

- Do not upload only this ZIP file to GitHub: Netlify will not automatically extract it, and the build will fail with a missing `package.json` error.
- Netlify Drop is for static output and is not the recommended deployment path for this project because the app includes Netlify Functions. Use Git-based deployment.
- Do not commit `.env` files, service-account JSON files, or real API credentials. Set secrets in Netlify Site configuration → Environment variables.
- A successful upload/package check does not prove the production build or external integrations work. Review the deploy log. Follow `DEPLOY.md` for Firebase, Gemini, storage, and optional messaging configuration.
