# Deploying Tourly3D — complete setup walkthrough

This guide takes a fresh clone of this repo to a working production
deployment on Netlify, including every optional provider (cloud storage,
WhatsApp, Telegram). **Follow it top to bottom; every step names the exact
buttons to click and the exact env vars to set.**

If you only want the core app (editor + viewer + publishing + AI), you need
sections 1–4 only. Cloud storage (5) is strongly recommended for production;
messaging (6, 7) is optional.

---

## 1. One-time deploy (5 minutes)

1. Push this folder to a Git repository (GitHub / GitLab / Bitbucket).
2. In [Netlify](https://app.netlify.com): **Add new site → Import an existing
   project**, pick the repo. Netlify reads `netlify.toml` automatically:
   - Build command: `npm run build`
   - Publish directory: `dist`
   - Functions directory: `netlify/functions`
   - Edge function: `tour-meta` on `/tour/*`
3. Deploy. The site builds and serves, but sign-in, publishing and AI need
   the env vars below — until then the app tells you exactly what's missing
   (it never fakes success).

> No Netlify account settings need changing for functions — they use the
> modern Functions v2 API with explicit `path` config (e.g.
> `/api/publish-tour`), and `netlify.toml` already contains the SPA
> redirect, security headers, and asset cache headers.

## 2. Environment variables (where and why)

Set in **Netlify → Site configuration → Environment variables** (NOT in the
code, never committed):

| Variable | Required for | Scope |
|---|---|---|
| `VITE_FIREBASE_API_KEY` … `VITE_FIREBASE_APP_ID` | Sign-in (§3) | Build — public by design (Firebase web config) |
| `GEMINI_API_KEY` | All AI features (§4) | Server only |
| `FIREBASE_SERVICE_ACCOUNT_KEY` | Publishing, cloud uploads, messaging codes (§3) | Server only |
| `S3_BUCKET`, `S3_REGION`, `S3_ACCESS_KEY_ID`, `S3_SECRET_ACCESS_KEY` | Cloud media storage (§5) | Server only |
| `S3_ENDPOINT`, `S3_PUBLIC_URL_BASE` | Optional — R2/MinIO/Wasabi, CDN | Server only |
| `WHATSAPP_TOKEN`, `WHATSAPP_APP_SECRET`, `WHATSAPP_VERIFY_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID` | WhatsApp bot (§6) | Server only |
| `TELEGRAM_BOT_TOKEN`, `TELEGRAM_WEBHOOK_SECRET` | Telegram bot (§7) | Server only |
| `VITE_GA_MEASUREMENT_ID` | Optional Google Analytics 4 | Build — public |
| `VITE_SITE_URL` | Optional — only for a custom domain that isn't the Netlify primary | Build |

Rules the build enforces on itself:
- `VITE_`-prefixed values are inlined into the browser bundle — that's why
  only Firebase config and the GA id are `VITE_`. The
  `scripts/check-secrets.mjs` pre-build step **fails the build** if a real
  Google API key, a private key block, or a secret-looking `VITE_` variable
  appears in `src/`, `public/`, or `index.html`.
- Everything server-side lives only in Netlify's env store and is read at
  function-invocation time (`process.env`), never at build time.

## 2b. Stage B + C features — no NEW REQUIRED environment variables

Everything Stage B and Stage C added reuses the two integrations above:

| Feature | Needs |
|---|---|
| Smart upload (duplicate + quality checks, Plan Studio 2D/3D) | nothing — fully local |
| Smart upload AI suggestions, copywriter AI, lead follow-up drafts | `GEMINI_API_KEY` (§4) |
| Lead capture + the /leads CRM + CSV export | `FIREBASE_SERVICE_ACCOUNT_KEY` (§3) — the same setup publishing uses |
| Engagement analytics (/analytics) + QR codes + embeds | `FIREBASE_SERVICE_ACCOUNT_KEY` (§3) for the dashboard; the public tracking endpoint itself needs no credentials |

**One OPTIONAL group was added in the latest build** — the Gemini model
selection & reliability knobs (`GEMINI_TEXT_MODEL`,
`GEMINI_TEXT_MODEL_FALLBACK`, `GEMINI_IMAGE_MODEL`,
`GEMINI_IMAGE_MODEL_FALLBACK`, `GEMINI_MAX_RETRIES`, `GEMINI_TIMEOUT_MS`,
`GEMINI_TOTAL_BUDGET_MS`, `GEMINI_BACKOFF_BASE_MS`). They all have safe,
verified defaults and need no setup; see `NETLIFY-SETUP.md` §2 for the
full table and when (if ever) to touch them.

Leads live in a new Netlify Blobs store (`waypoint-leads`), engagement
counts in `waypoint-analytics` — no extra setup, no second database. Data
model details: `SCHEMA.md`. Analytics starts counting when this version
deploys (no historical backfill — that would be fabrication).

## 3. Firebase (authentication + server-side verification)

> Concise step-by-step with a troubleshooting table: **AUTH-SETUP.md**
> (project root). Key gotcha: Firebase authorized domains have no
> wildcard support — each Netlify deploy-preview subdomain
> (`deploy-preview-N--<site>.netlify.app`) must be added individually,
> or use a stable branch subdomain (`main--<site>.netlify.app`, add
> once). Sign-in attempts from unauthorized domains fail with
> `auth/unauthorized-domain`; the app now surfaces that error with the
> exact remediation instead of a generic message.

1. [console.firebase.google.com](https://console.firebase.google.com) →
   **Add project** (or use an existing one).
2. **Build → Authentication → Get started → Email/Password → Enable.**
   (Anonymous sign-in also works if you prefer — the client only uses
   email/password today.)
3. **Project settings → General → Your apps → Web app (</>)** → register →
   copy the `firebaseConfig` values into the six `VITE_FIREBASE_*` env vars.
4. **Authentication → Settings → Authorized domains** → add your Netlify
   domain (e.g. `your-site.netlify.app`) and any custom domain. Without
   this, sign-in popups/redirects are blocked by Firebase after deploy.
5. **Project settings → Service accounts → Generate new private key** →
   download the JSON. Minify it to ONE line (e.g.
   `jq -c . service-account.json`) and paste the whole line as
   `FIREBASE_SERVICE_ACCOUNT_KEY`.
   - This is what lets `/api/publish-tour`, `/api/media-upload` (cloud
     mode) and `/api/messaging-link` verify the caller's identity
     server-side (verified Firebase ID tokens). Without it those endpoints
     return a clear 503 instead of running unauthenticated.

## 4. Gemini (all AI features)

1. Get an API key at [aistudio.google.com/apikey](https://aistudio.google.com/apikey).
2. Set `GEMINI_API_KEY` in Netlify env vars.

That's it. Features this unlocks: scene auto-detect (room labels +
descriptions + construction stages with confidence), hotspot suggestions,
scene sequence suggestion, marketing copy, the visitor-facing tour
assistant, silent panorama enhancement/seam fixing, AI panorama and 3D
render generation (both explicit, cost-capped, and always marked as
synthetic). All AI output is a **suggestion** the creator reviews — nothing
AI-generated is ever auto-published as fact, and AI-generated images are
always labelled.

## 5. Cloud media storage (S3-compatible — recommended)

Without this, media is embedded inside the tour JSON (localStorage +
Netlify Blobs) with hard size limits (≈ 5 MB tours, 15 MB videos). With it,
uploads go to your bucket and only small previews stay embedded.

Works with **AWS S3, Cloudflare R2, MinIO, Wasabi** — anything
S3-compatible.

1. Create a bucket. Example (AWS S3):
   - Region: anything (set `S3_REGION` to match)
   - **Public access**: the bucket must serve objects publicly over HTTP
     (published tours load their media in any browser) — or put a CDN in
     front and set `S3_PUBLIC_URL_BASE`.
   - Block Public Access: OFF (or use a CDN and keep the bucket private).
   - Bucket policy for public read (AWS example):
     ```json
     {
       "Version": "2012-10-17",
       "Statement": [{
         "Sid": "PublicReadGetObject",
         "Effect": "Allow",
         "Principal": "*",
         "Action": "s3:GetObject",
         "Resource": "arn:aws:s3:::YOUR-BUCKET/*"
       }]
     }
     ```
2. **CORS configuration** on the bucket (the browser PUTs directly with a
   presigned URL, so CORS must allow it):
   ```json
   [
     {
       "AllowedOrigins": ["https://your-site.netlify.app", "https://your-custom-domain"],
       "AllowedMethods": ["PUT", "GET", "DELETE"],
       "AllowedHeaders": ["content-type"],
       "ExposeHeaders": ["etag"],
       "MaxAgeSeconds": 3600
     }
   ]
   ```
3. Create an IAM user or role with access limited to this bucket
   (`s3:PutObject`, `s3:GetObject`, `s3:DeleteObject` on
   `arn:aws:s3:::YOUR-BUCKET/*`) and create an access key.
4. Set `S3_BUCKET`, `S3_REGION`, `S3_ACCESS_KEY_ID`, `S3_SECRET_ACCESS_KEY`.
   For R2/MinIO/Wasabi also set `S3_ENDPOINT`
   (e.g. `https://ACCOUNT.r2.cloudflarestorage.com`) — path-style
   addressing is used automatically for custom endpoints.

How it works at runtime: the browser asks `/api/media-upload` for a
**presigned PUT URL** (SigV4, 15-minute expiry, one specific object key
`tours/<uid>/<yyyy-mm>/<uuid>.<ext>`). Credentials never leave the server.
Upload progress, failure states, and per-user rate limits (60 uploads/hour)
are all real. Deleting a scene offers to delete its cloud object too — the
server refuses keys outside your own prefix, so nobody can delete anyone
else's media.

## 6. WhatsApp tour-building bot (optional)

Requires a Meta developer account and a WhatsApp Business Account — this
external approval cannot be done from code.

1. [developers.facebook.com](https://developers.facebook.com) → **My Apps →
   Create App → Business** type.
2. Add the **WhatsApp** product. You get a test phone number and a
   temporary access token immediately.
3. Set env vars:
   - `WHATSAPP_PHONE_NUMBER_ID` — from the WhatsApp → API Setup dashboard.
   - `WHATSAPP_TOKEN` — a **permanent** token: Business settings → Users →
     System users → create one with `whatsapp_business_messaging` +
     `whatsapp_business_management` → generate token.
   - `WHATSAPP_APP_SECRET` — App settings → Basic → App secret.
   - `WHATSAPP_VERIFY_TOKEN` — any string you invent (used in step 5).
4. Deploy (or redeploy) so the env vars exist.
5. App dashboard → **Webhooks → WhatsApp**:
   - Callback URL: `https://YOUR-SITE/api/whatsapp-webhook`
   - Verify token: the value of `WHATSAPP_VERIFY_TOKEN`
   - Subscribe to the **messages** field.
6. Use it: in Tourly → **Dashboard → Build tours over chat → Generate
   connect code**, then from your WhatsApp account send the bot:
   `start YOURCODE`. Afterwards every photo/video you send becomes a scene
   (AI-labelled when Gemini is configured), and the bot replies with the
   public tour URL. Commands: `new` (start a fresh tour), `link` (resend
   URL), `help`.

Security: every POST is HMAC-SHA256-verified against `WHATSAPP_APP_SECRET`
(`X-Hub-Signature-256`) **before** anything is parsed or processed; message
ids are deduplicated (providers retry); processing status is tracked per
message; failures are reported truthfully in the chat reply.

## 7. Telegram tour-building bot (optional)

1. Talk to [@BotFather](https://t.me/BotFather) → `/newbot` → copy the
   token → `TELEGRAM_BOT_TOKEN`.
2. Invent a long random string → `TELEGRAM_WEBHOOK_SECRET`.
3. Deploy (or redeploy) so the env vars exist.
4. Register the webhook once (the secret token header is then verified on
   every delivery):
   ```bash
   curl "https://api.telegram.org/bot<TOKEN>/setWebhook" \
     -d "url=https://YOUR-SITE/api/telegram-webhook" \
     -d "secret_token=<TELEGRAM_WEBHOOK_SECRET>"
   ```
5. Use it exactly like WhatsApp: generate a connect code in the dashboard,
   send `/start YOURCODE` to your bot, then send photos/videos.

## 8. Custom domains (manual — an honest integration boundary)

The app does **not** attempt to automate DNS or domain purchase — creating
a URL in code does not and cannot configure DNS. The remaining steps, done
by hand once:

1. Netlify → **Domain management → Add a domain** → follow the wizard
   (registers/buys or connects an existing domain).
2. At your registrar, point the domain at Netlify:
   - Apex: `A` record → `75.2.60.5`
   - www/subdomain: `CNAME` → `your-site.netlify.app`
   (Netlify shows the exact records for your site in the same UI.)
3. Wait for DNS propagation, then enable
   **HTTPS → Force HTTPS** (the app already sends HSTS headers).
4. If the custom domain is the canonical public URL, set `VITE_SITE_URL` to
   it (used for canonical/OG URLs, sitemap, and the URLs the bots reply
   with) and set the bucket's CORS config (§5) to allow the custom origin.

## 9. Local development

```bash
npm install
cp .env.example .env      # fill in at least the Firebase VITE_* values
npx netlify dev           # runs Vite + Functions + Blobs locally
```

`npm run dev` (plain Vite) also works for UI work, but API calls will show
their honest "not available in this environment" errors — that's by design.

## 10. Troubleshooting quick reference

| Symptom | Cause → fix |
|---|---|
| "/leads says Lead management isn't available (503)" | Same as publishing: set FIREBASE_SERVICE_ACCOUNT_KEY (§3) |
| "AI suggestions aren't configured (503)" in Smart Upload / copywriter / follow-up drafts | Set GEMINI_API_KEY (§4) — everything else keeps working without it |
| 3D tab shows a rendering error on very old devices | WebGL unavailable — the 2D editor is unaffected; nothing is lost |

| Symptom | Cause / fix |
|---|---|
| Build fails: `tsc: not found`, or `TS2688: Cannot find type definition file for 'vite/client'` / `'node'`, or `TS2307: Cannot find module 'react'/'three' or its corresponding type declarations` | Dependencies were installed production-only (`npm install --production`, `npm ci --omit=dev`, or `NODE_ENV=production` / `NPM_FLAGS=--production` in CI). The compiler, bundler and all type packages are in `dependencies` now — run `rm -rf node_modules && npm install`, and in the Netlify UI make sure `NPM_FLAGS` is not `--production`/`--omit=dev` (netlify.toml already sets `NPM_FLAGS = "--include=dev"`). `scripts/preflight-build.mjs` names exactly what is missing |
| Publish button: "Publishing isn't available yet…" | `FIREBASE_SERVICE_ACCOUNT_KEY` missing (§3.5) |
| Uploads say "isn't configured" with a visible notice | `S3_*` vars missing (§5) — or intentionally use embedded mode |
| Upload fails at the PUT step | Bucket CORS config (§5.2) — the exact error names it |
| AI buttons: "not configured" | `GEMINI_API_KEY` missing (§4) |
| WhatsApp webhook URL won't verify | Verify token mismatch (§6.5) or env vars not yet deployed |
| Telegram 401s in function logs | `secret_token` in setWebhook ≠ `TELEGRAM_WEBHOOK_SECRET` |
| Sign-in works locally, blocked in production | Firebase Authorized domains (§3.4) |
| Link previews show generic card | Edge function needs the tour published; check `tour-meta` in the Functions log |
