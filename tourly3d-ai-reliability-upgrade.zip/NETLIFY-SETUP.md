# NETLIFY-SETUP — exact build settings & environment variables

One-page deployment sheet for Tourly3D on Netlify. For provider walkthroughs
(Firebase, S3, WhatsApp, Telegram) see `DEPLOY.md`; for a fast path see
`NETLIFY-QUICKSTART.md`. This file lists exactly what Netlify needs.

---

## 1. Build settings (from `netlify.toml` — verify, don't retype)

| Netlify setting | Value |
|---|---|
| Base directory | *(blank / repository root — the folder containing `package.json`)* |
| Build command | `npm run build` |
| Publish directory | `dist` |
| Functions directory | `netlify/functions` |
| Edge function | `tour-meta` on `/tour/*` (auto-registered) |
| Node.js | Any supported LTS ≥ 18 (build sets the runtime; no manual override needed) |

Already encoded in `netlify.toml` and applied automatically: the SPA fallback
redirect (`/* → /index.html`), security headers (HSTS, nosniff, referrer,
permissions-policy), immutable asset caching, and
`NPM_FLAGS = "--include=dev"` (**do not** override this to
`--production`/`--omit=dev` — the build compiles TypeScript and needs the
toolchain packages; see the warning in `NETLIFY-QUICKSTART.md`).

## 2. Environment variables — the complete list of NAMES

Set these in **Netlify → Site configuration → Environment variables**
(never in committed files). Values below are placeholders — paste your own.
`VITE_`-prefixed vars are inlined into the browser bundle at build time and
are public by design (Firebase web config); everything else is server-only.

### Required (core app)

| Name | Scope | Notes |
|---|---|---|
| `VITE_FIREBASE_API_KEY` | Build | Firebase web config (public by design) |
| `VITE_FIREBASE_AUTH_DOMAIN` | Build | Optional — derived from project id when omitted |
| `VITE_FIREBASE_PROJECT_ID` | Build | Firebase web config |
| `VITE_FIREBASE_STORAGE_BUCKET` | Build | Firebase web config |
| `VITE_FIREBASE_MESSAGING_SENDER_ID` | Build | Firebase web config |
| `VITE_FIREBASE_APP_ID` | Build | Firebase web config |
| `GEMINI_API_KEY` | Server only | From https://aistudio.google.com/apikey — powers every AI feature |
| `FIREBASE_SERVICE_ACCOUNT_KEY` | Server only | Full service-account JSON as ONE line — server-side ID-token verification, publishing, cloud uploads, messaging codes |

### Optional — Gemini model selection & reliability (NEW in this build)

All have safe verified defaults; set only if Google retires a model or you
need different behaviour. Model ids must be copied exactly from
https://ai.google.dev/gemini-api/docs/models — never invent one.

| Name | Default | Notes |
|---|---|---|
| `GEMINI_TEXT_MODEL` | `gemini-3.8-flash` | Primary text/vision model (stable) |
| `GEMINI_TEXT_MODEL_FALLBACK` | `gemini-3.1-flash-lite` | Flash-Lite fallback text model; `""` disables |
| `GEMINI_IMAGE_MODEL` | `gemini-3.1-flash-image` | Primary image model ("Nano Banana 2", stable) |
| `GEMINI_IMAGE_MODEL_FALLBACK` | `gemini-nano-banana-2.1` | Fallback image model; `""` disables |
| `GEMINI_MAX_RETRIES` | `2` | Bounded retries per model (hard max 5) |
| `GEMINI_TIMEOUT_MS` | `20000` | Per-attempt timeout |
| `GEMINI_TOTAL_BUDGET_MS` | `24000` | Wall-clock budget across all attempts + both models — keeps the function inside Netlify's synchronous execution limit |
| `GEMINI_BACKOFF_BASE_MS` | `500` | Exponential-backoff base |

Retry behaviour (no configuration needed): transient failures only (HTTP
429/500/503/504, timeouts, network errors) are retried with exponential
backoff + jitter and `Retry-After` awareness; a 401/403 (bad key) fails
fast with no retry and no fallback; a 404 (retired model) skips straight to
the fallback model.

### Optional — AI usage quotas & result caching (NEW in this build)

All have safe defaults; set only to change the limits. Quotas are per
VERIFIED account per UTC day (per-IP for anonymous callers); cache hits
never consume quota.

| Name | Default | Notes |
|---|---|---|
| `AI_DAILY_QUOTA_DEFAULT` | `40` | Default for any AI feature without its own override |
| `AI_DAILY_QUOTA_ANALYZE_FLOORPLAN` | `10` | AI Concept Floor Plan analyses per user/day |
| `AI_DAILY_QUOTA_INTERIOR_CONCEPT` | `10` | AI interior-concept images per user/day |
| `AI_DAILY_QUOTA_LEAD_INSIGHTS` | `30` | Lead summaries per user/day |
| `AI_DAILY_QUOTA_GENERATE_MARKETING` | `30` | Copywriter runs per user/day |
| `AI_DAILY_QUOTA_ANALYZE_SCENE` | `30` | Single-scene auto-detect per user/day |
| `AI_DAILY_QUOTA_CLASSIFY_SCENES` | `15` | Smart-upload batches (each covers up to 12 photos) |
| `AI_DAILY_QUOTA_SUGGEST_HOTSPOTS` | `30` | Hotspot suggestions per user/day |
| `AI_DAILY_QUOTA_SUGGEST_SEQUENCE` | `30` | Sequence suggestions per user/day |
| `AI_DAILY_QUOTA_LEAD_DRAFT` | `30` | Follow-up drafts per user/day |
| `AI_DAILY_QUOTA_TOUR_ASSISTANT` | `40` | Tour Q&A per IP/day (public, buyer-facing) |
| `AI_DAILY_QUOTA_ENHANCE_PANORAMA` | `10` | Image enhancement — fails CLOSED if the limiter is unreachable |
| `AI_DAILY_QUOTA_GENERATE_3D_RENDER` | `10` | 3D renders — fails CLOSED |
| `AI_DAILY_QUOTA_GENERATE_PANORAMA` | `10` | Panorama generation — fails CLOSED |
| `AI_CACHE_TTL_HOURS` | `24` | How long a cached AI result stays valid (floor plans, scene analyses, copy, drafts, Q&A) |

Failed attempts count as usage (a request is a request) — that is what
keeps the quota honest against retry abuse. Cache hits never consume quota,
and identical concurrent requests are coalesced into ONE provider call.

### Optional — secondary AI provider + reliability controls + admin diagnostics (NEW in this build)

Gemini stays the PRIMARY provider. Optionally configure ONE secondary
(Groq or Mistral — Groq wins if both are set) that text requests fall back
to when Gemini hits rate limits, daily quotas, outages, timeouts or network
errors. **Nothing here is required** — with no secondary key the app
behaves exactly as before.

| Name | Default | Notes |
|---|---|---|
| `GROQ_API_KEY` | unset | Enables Groq as the secondary provider (server-only secret) |
| `GROQ_MODEL` | `openai/gpt-oss-120b` | Verify current models at console.groq.com/docs/models |
| `MISTRAL_API_KEY` | unset | Enables Mistral as the secondary (used only if Groq is unset) |
| `MISTRAL_MODEL` | `mistral-small-latest` | Verify at docs.mistral.ai |
| `AI_DISABLE_FALLBACK_PROVIDER` | unset | Kill switch — disables the secondary without deleting its key |
| `AI_FALLBACK_ALLOW_VISION` | unset | Text-only by default. `true` sends image requests to the secondary too (configure a vision model first, and mind the privacy disclosure) |
| `AI_FALLBACK_MAX_RETRIES` | `1` | Secondary retries per request (max 3) |
| `AI_BREAKER_THRESHOLD` | `4` | Consecutive failures before a provider is skipped |
| `AI_BREAKER_COOLDOWN_MS` | `60000` | Cooldown before the provider is retried (min 1000) |
| `AI_MAX_CONCURRENT_PER_PROVIDER` | `4` | In-flight cap per provider per function instance |
| `ADMIN_EMAILS` | unset | Comma-separated emails allowed to view `/admin/ai` diagnostics. Unset = nobody has access |

**Configuring the secondary provider (optional):**
1. Create a key at console.groq.com/keys (or console.mistral.ai) — free
   tiers exist at the time of writing; check the provider's own rate-limit
   pages for CURRENT numbers (they change — this document deliberately
   doesn't quote them as facts).
2. Set `GROQ_API_KEY` (or `MISTRAL_API_KEY`) in Netlify env vars. Deploy.
3. Sign in as the admin account, open `/admin/ai`, and use **Test
   connection** — it makes ONE minimal request per configured provider and
   reports ok/fail with a sanitized category, never raw provider output.
4. To disable it later: set `AI_DISABLE_FALLBACK_PROVIDER=true` (or delete
   the key) and redeploy. Gemini-only behaviour resumes.

**Rotating a compromised key:** delete the old value in Netlify →
Environment variables, set the new one, redeploy, then run Test connection
from `/admin/ai`. Old keys never appear in logs (everything logged is
sanitized) and never ship in the browser bundle.

**Admin diagnostics (`/admin/ai`):** shows configured providers, model ids,
last success/error times, error categories (kinds only), rate-limit and
quota events, breaker trips, cache hit ratio, and per-feature quotas — no
API keys, no customer data, ever. The page makes ZERO provider requests on
load; the explicit Test-connection button is rate-limited to once per 30s.
Authorization is server-side: a verified Firebase ID token whose email is
in `ADMIN_EMAILS` — no frontend flag can bypass it.

### Optional — cloud media storage (recommended for production)

| Name | Scope | Notes |
|---|---|---|
| `S3_BUCKET` | Server only | S3-compatible bucket for tour media |
| `S3_REGION` | Server only | e.g. `ap-south-1` |
| `S3_ACCESS_KEY_ID` | Server only | Server-signed uploads only — browser never sees keys |
| `S3_SECRET_ACCESS_KEY` | Server only | — |
| `S3_ENDPOINT` | Server only | For R2 / MinIO / Wasabi |
| `S3_PUBLIC_URL_BASE` | Server only | CDN front, if any |

### Optional — WhatsApp / Telegram bots, analytics

| Name | Scope | Notes |
|---|---|---|
| `WHATSAPP_TOKEN` | Server only | WhatsApp Cloud API system-user token |
| `WHATSAPP_APP_SECRET` | Server only | Verifies `X-Hub-Signature-256` |
| `WHATSAPP_VERIFY_TOKEN` | Server only | Webhook handshake token (your choice) |
| `WHATSAPP_PHONE_NUMBER_ID` | Server only | From the Meta dashboard |
| `TELEGRAM_BOT_TOKEN` | Server only | From @BotFather |
| `TELEGRAM_WEBHOOK_SECRET` | Server only | Long random string |
| `VITE_GA_MEASUREMENT_ID` | Build | GA4 id (`G-XXXXXXX`); blank = no analytics |
| `VITE_SITE_URL` | Build | Only for a custom domain that isn't the Netlify primary |

## 3. Deploy steps

1. Extract the ZIP; push the **contents of the `tourly3d/` folder** (not the
   ZIP, not the folder itself) to a Git repository. The repo root must
   contain `package.json`, `package-lock.json`, `netlify.toml`, `src/`,
   `netlify/`.
2. Netlify → **Add new site → Import an existing project** → pick the repo.
   Confirm the build settings from §1 (they come from `netlify.toml`).
3. Add the environment variables from §2 (start with the Required group).
4. Deploy. The first build runs preflight checks, a frontend secret scan,
   TypeScript checks for app + functions, and the Vite build.
5. Verify: open the site → sign in works (Firebase) → create a tour →
   publish → open the public link. AI buttons return honest JSON errors
   until `GEMINI_API_KEY` is set — never fake success.

## 4. Verifying the AI fallback configuration

After setting `GEMINI_API_KEY`, test one AI feature (e.g. editor →
"Auto-detect room"). Then check **Netlify → Functions → analyze-scene logs**:
- Success needs no log entry.
- A transient failure logs one line like
  `[gemini] analyze-scene (text): all models failed (server) — …` with a
  sanitized attempt list (provider + model ids + outcomes only — never your
  key). Kinds you may see: `rate-limit` (short-term), `quota-exhausted`
  (the provider's DAILY limit is gone — no same-model retry burn),
  `server`/`timeout`/`network`, `malformed` (2xx with an unusable body —
  never a fake success), `auth` (check the key), `breaker-open` (the
  provider is in its cooldown after repeated failures).
- Function logs are the ONLY place model/attempt details appear; the
  browser only ever sees a safe message plus a `retryable` flag.

## 4b. AI cost model (checked 2026-10-16, ai.google.dev/gemini-api/docs/pricing)

- **Text/vision features** (scene analysis, classification, copywriter,
  lead insights/drafts, tour Q&A, hotspot/sequence suggestions,
  **concept floor-plan analysis**): `gemini-3.8-flash` (fallback
  `gemini-3.1-flash-lite`) — **free tier available**; paid tier ≈ $0.75 per 1M
  input tokens / $3.75 per 1M output tokens through 2026-12-31 (promo
  pricing; verify the page before budgeting).
- **Image features** (panorama generation/enhancement, 3D render,
  interior concepts): `gemini-3.1-flash-image` (fallback
  `gemini-nano-banana-2.1`) — image models are **token-priced on the paid
  tier**; check the pricing page for current rates. These features stay
  OPTIONAL — with no key configured every one of them returns an honest
  "not configured" message instead of costing anything.
- **Every AI feature requires `GEMINI_API_KEY`.** Nothing AI-related runs
  without it, and no feature promises unlimited free usage — the daily
  quotas in §2 bound spend per account.

## 5. Rollback

- **Git deploys:** Netlify → Deploys → any earlier deploy → **Publish
  deploy** (instant, no rebuild).
- **Bad env var:** change it back in Site configuration → Environment
  variables → **Deploy** (triggers rebuild). The optional Gemini vars can
  all be deleted to return to verified defaults.
- Nothing in this app deletes data on deploy; published tours live in
  Netlify Blobs and are untouched by redeploys.

## 6. Do-not-do list (things that have broken deploys before)

- Do not set `NPM_FLAGS` to `--production` / `--omit=dev`.
- Do not prefix any secret with `VITE_` (it would ship to the browser; the
  build's secret scanner also fails the deploy on secret-shaped `VITE_`
  vars).
- Do not commit `.env` files or service-account JSON — the repository needs
  none of them; `.env.example` documents names only.
- Do not rename the `netlify/functions` folder or move `netlify.toml`.
