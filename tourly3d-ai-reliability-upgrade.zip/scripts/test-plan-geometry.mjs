/**
 * Unit tests for Stage B2/B3 pure plan geometry (src/lib/plan/geometry.ts)
 * and the floor-plan model loader (src/lib/plan/model.ts).
 *
 * These are the functions BOTH the 2D editor and the 3D dollhouse are built
 * on, so their correctness is what "the same geometry in 2D and 3D" rests
 * on — they get real unit tests, not just visual inspection.
 *
 * Run: node scripts/test-plan-geometry.mjs
 */
import { spawnSync } from "node:child_process";
import { pathToFileURL, fileURLToPath } from "node:url";
import { mkdirSync } from "node:fs";

const ROOT = fileURLToPath(new URL("..", import.meta.url));
const OUT = `${ROOT}/node_modules/.tmp/libtest`;
mkdirSync(OUT, { recursive: true });

// model.ts imports nothing browser-only at module top level (crypto.randomUUID
// only runs inside factories), so it bundles cleanly for Node too.
const build = spawnSync(
  "npx",
  [
    "esbuild",
    `${ROOT}src/lib/plan/geometry.ts`,
    "--bundle",
    "--platform=node",
    "--format=esm",
    `--outdir=${OUT}/plan`,
    "--out-extension:.js=.mjs",
  ],
  { stdio: "pipe", encoding: "utf8" }
);
if (build.status !== 0) {
  console.error("esbuild failed:\n" + build.stdout + build.stderr);
  process.exit(1);
}

const build2 = spawnSync(
  "npx",
  [
    "esbuild",
    `${ROOT}src/lib/plan/ops.ts`,
    `${ROOT}src/lib/plan/model.ts`,
    "--bundle",
    "--platform=node",
    "--format=esm",
    `--outdir=${OUT}/plan`,
    "--out-extension:.js=.mjs",
  ],
  { stdio: "pipe", encoding: "utf8" }
);
if (build2.status !== 0) {
  console.error("esbuild (ops) failed:\n" + build2.stdout + build2.stderr);
  process.exit(1);
}
const G = await import(pathToFileURL(`${OUT}/plan/geometry.mjs`).href);
const M = await import(pathToFileURL(`${OUT}/plan/model.mjs`).href);
const OPS = await import(pathToFileURL(`${OUT}/plan/ops.mjs`).href);
const crypto = globalThis.crypto;

let passed = 0;
let failed = 0;
function check(name, condition, detail = "") {
  if (condition) {
    passed++;
    console.log(`  PASS  ${name}`);
  } else {
    failed++;
    console.log(`  FAIL  ${name} — ${detail}`);
  }
}
const approx = (a, b, eps = 1e-6) => Math.abs(a - b) <= eps;

// --- polygon math --------------------------------------------------------------

console.log("polygon area / perimeter / centroid\n");
const square = [
  { x: 0, y: 0 },
  { x: 4, y: 0 },
  { x: 4, y: 4 },
  { x: 0, y: 4 },
];
check("unit square area = 16", approx(G.polygonArea(square), 16), `got ${G.polygonArea(square)}`);
check("square perimeter = 16", approx(G.polygonPerimeter(square), 16), `got ${G.polygonPerimeter(square)}`);
check("square centroid = (2,2)", approx(G.polygonCentroid(square).x, 2) && approx(G.polygonCentroid(square).y, 2));

// A concave "L" — the classic case where naive triangulation/centroid breaks.
const lShape = [
  { x: 0, y: 0 },
  { x: 6, y: 0 },
  { x: 6, y: 2 },
  { x: 2, y: 2 },
  { x: 2, y: 6 },
  { x: 0, y: 6 },
];
const lArea = 20; // 6×2 bar + 2×6 column − 2×2 overlap = 20
check(`L-shape area = ${lArea} (concave handled)`, approx(G.polygonArea(lShape), lArea), `got ${G.polygonArea(lShape)}`);

// Clockwise winding must give the same ABSOLUTE area.
const reversed = [...square].reverse();
check("winding-reversed square has same |area|", approx(G.polygonArea(reversed), 16));
check("polygonWinding detects CW vs CCW", G.polygonWinding(square) === 1 && G.polygonWinding(reversed) === -1);

const tri = [
  { x: 0, y: 0 },
  { x: 10, y: 0 },
  { x: 0, y: 10 },
];
check("right triangle area = 50", approx(G.polygonArea(tri), 50));
check("triangle centroid = (10/3, 10/3)", approx(G.polygonCentroid(tri).x, 10 / 3) && approx(G.polygonCentroid(tri).y, 10 / 3));

console.log("\npoint in polygon\n");
check("point clearly inside square", G.pointInPolygon({ x: 2, y: 2 }, square));
check("point clearly outside square", !G.pointInPolygon({ x: 5, y: 2 }, square));
check("point inside the L notch is OUTSIDE", !G.pointInPolygon({ x: 4, y: 4 }, lShape));
check("point inside the L's wide bar is INSIDE", G.pointInPolygon({ x: 4, y: 1 }, lShape));

console.log("\nsimplicity (self-intersection)\n");
const bowtie = [
  { x: 0, y: 0 },
  { x: 4, y: 4 },
  { x: 4, y: 0 },
  { x: 0, y: 4 },
];
check("bowtie polygon is NOT simple", G.isSimplePolygon(bowtie) === false);
check("square IS simple", G.isSimplePolygon(square) === true);
check("L-shape IS simple (concave but not self-crossing)", G.isSimplePolygon(lShape) === true);
check("repeated vertex is NOT simple", G.isSimplePolygon([...square, { x: 0, y: 0 }]) === false);
check("fewer than 3 points is NOT simple", G.isSimplePolygon([{ x: 0, y: 0 }, { x: 1, y: 1 }]) === false);

console.log("\nroom validation\n");
const vIssues = G.validateRoomRing("r1", bowtie);
check("bowtie room yields an error", vIssues.some((i) => i.level === "error"), JSON.stringify(vIssues));
const okIssues = G.validateRoomRing("r2", square);
check("valid square room yields no errors", !okIssues.some((i) => i.level === "error"), JSON.stringify(okIssues));
const collinear = [
  { x: 0, y: 0 },
  { x: 5, y: 0 },
  { x: 10, y: 0 },
];
check("collinear triangle is an error (no area)", G.validateRoomRing("r3", collinear).some((i) => i.level === "error"));

// --- point/segment + walls + openings ------------------------------------------

console.log("\npoint-to-segment\n");
const seg = { a: { x: 0, y: 0 }, b: { x: 10, y: 0 } };
check("perpendicular hit at t=0.5", approx(G.pointToSegment({ x: 5, y: 3 }, seg.a, seg.b).dist, 3));
check("clamps to endpoint beyond b", approx(G.pointToSegment({ x: 15, y: 2 }, seg.a, seg.b).dist, Math.hypot(5, 2)));

console.log("\nwall pieces (the 2D/3D shared core)\n");
const wall = { id: "w1", a: "v1", b: "v2", thickness: 0.12 };
const resolve = (id) => (id === "v1" ? { x: 0, y: 0 } : { x: 10, y: 0 });
const segment = G.wallSegment(wall, resolve);
check("wall length 10", approx(segment.length, 10));

// One door centered at t=0.5, width 1 → pieces: [0..4.5 wall][4.5..5.5 door][5.5..10 wall]
const door = { id: "o1", wallId: "w1", kind: "door", t: 0.5, width: 1, height: 2.1, sillHeight: 0 };
const pieces = G.wallPieces(segment, [door]);
check("door splits the wall into 3 pieces", pieces.length === 3, JSON.stringify(pieces));
check("middle piece is the door gap", pieces[1]?.kind === "door-gap");
check("solid pieces surround the gap", pieces[0]?.kind === "wall" && pieces[2]?.kind === "wall");
check("gap is exactly the door width", approx(G.polygonPerimeter([pieces[1].start, pieces[1].end]) / 2, 1), `${pieces[1].start.x}..${pieces[1].end.x}`);
check("first solid piece ends where the gap starts", approx((pieces[0] || {}).end.x, 4.5) && approx((pieces[1] || {}).start.x, 4.5));
check("last solid piece starts where the gap ends", approx((pieces[1] || {}).end.x, 5.5) && approx((pieces[2] || {}).start.x, 5.5));
check("solid pieces reconstruct the full wall", approx(pieces[0].end.x - pieces[0].start.x + (pieces[2].end.x - pieces[2].start.x), 9));

// Window + door on the same wall, non-overlapping.
const window = { id: "o2", wallId: "w1", kind: "window", t: 0.2, width: 1.5, height: 1.2, sillHeight: 0.9 };
const pieces2 = G.wallPieces(segment, [door, window]);
check("window + door yield 5 pieces", pieces2.length === 5, JSON.stringify(pieces2.map((p) => p.kind)));
check("window gap present", pieces2.some((p) => p.kind === "window-gap"));

// Overlapping openings: an opening that would run off the wall end gets clamped.
const edgeDoor = { id: "o3", wallId: "w1", kind: "door", t: 0.99, width: 2, height: 2.1, sillHeight: 0 };
const clamped = G.placeOpening(edgeDoor, segment);
check("opening near the wall end is clamped inside (t ≤ 1 - width/2/len)", clamped.t <= 1 - clamped.width / 2 / 10 + 1e-9, `t=${clamped.t}`);
const clampedPieces = G.wallPieces(segment, [edgeDoor]);
check("clamped pieces still tile the wall without negative lengths", clampedPieces.every((p) => p.end.x >= p.start.x - 1e-9));

// A wall shorter than the door: width clamps, never inverted.
const tinySeg = G.wallSegment({ id: "w2", a: "v1", b: "v3", thickness: 0.1 }, (id) =>
  id === "v1" ? { x: 0, y: 0 } : { x: 0.5, y: 0 }
);
const bigDoor = { id: "o4", wallId: "w2", kind: "door", t: 0.5, width: 3, height: 2.1, sillHeight: 0 };
const tinyPieces = G.wallPieces(tinySeg, [bigDoor]);
check("opening wider than its wall clamps, never inverts geometry", tinyPieces.every((p) => p.end.x >= p.start.x - 1e-9), JSON.stringify(tinyPieces));

console.log("\nsolid pieces for 3D\n");
const solids = G.solidWallPieces(segment, [door]);
check("solidWallPieces returns only wall pieces", solids.length === 2 && solids.every((p) => p.kind === "wall"));

console.log("\nfloor bounds\n");
check(
  "bounds span vertices and background",
  (() => {
    const floor = {
      id: "f",
      name: "F",
      elevation: 0,
      vertices: [
        { id: "a", x: 1, y: 1 },
        { id: "b", x: 5, y: 1 },
        { id: "c", x: 5, y: 4 },
      ],
      walls: [],
      openings: [],
      rooms: [],
      background: { dataUrl: "d", width: 100, height: 100, opacity: 0.5, x: 0, y: 0, w: 2, h: 2 },
      createdAt: 0,
      updatedAt: 0,
    };
    const b = G.floorBounds(floor);
    return b && b.minX === 0 && b.minY === 0 && b.maxX === 5 && b.maxY === 4;
  })()
);
check("empty floor → null bounds", G.floorBounds({ id: "f", name: "", elevation: 0, vertices: [], walls: [], openings: [], rooms: [], createdAt: 0, updatedAt: 0 }) === null);

// --- editor operations (ops.ts) — the mutation layer the canvas drives -------

console.log("\neditor operations (create/draw/delete semantics)\n");

const plan = M.createPlan("tour-1");
check("createPlan makes one ground floor, uncalibrated", plan.floors.length === 1 && plan.scale.calibrated === false && plan.floors[0].rooms.length === 0);

// Draw a 4×3 room via the same ops the canvas calls.
let p = plan;
const corners = [
  { x: 0, y: 0 },
  { x: 4, y: 0 },
  { x: 4, y: 3 },
  { x: 0, y: 3 },
];
const ids = [];
for (const c of corners) {
  const r = OPS.addVertex(p, c);
  p = r.plan;
  ids.push(r.vertexId);
}
const created = OPS.createRoom(p, { polygon: ids });
p = created.plan;
check("createRoom returns the room", Boolean(created.room));
const floor1 = OPS.floorOf(p);
check("room ring registered with 4 vertices", floor1.rooms.length === 1 && floor1.rooms[0].polygon.length === 4);
check("room walls created for every edge (4, no duplicates)", floor1.walls.length === 4, `walls=${floor1.walls.length}`);

// Adjacent room sharing two vertices must NOT duplicate the shared wall.
const shared = [ids[1], ids[2]]; // the right edge of room 1
const extra = [];
for (const c of [{ x: 6, y: 0 }, { x: 6, y: 3 }]) {
  const r = OPS.addVertex(p, c);
  p = r.plan;
  extra.push(r.vertexId);
}
const second = OPS.createRoom(p, { polygon: [shared[0], extra[0], extra[1], shared[1]], name: "Study" });
p = second.plan;
const floor2 = OPS.floorOf(p);
check("adjacent room reuses the shared wall (7 walls for 2 rooms, not 8)", floor2.walls.length === 7, `walls=${floor2.walls.length}`);
check("second room registered", floor2.rooms.length === 2 && floor2.rooms[1].name === "Study");

// addVertex snaps to an existing corner.
const snapRes = OPS.addVertex(p, { x: 0.01, y: 0.01 }, 0.5);
check("addVertex snaps to a nearby existing corner", snapRes.vertexId === ids[0] && OPS.floorOf(snapRes.plan).vertices.length === floor2.vertices.length);

// Openings: door on the shared wall, clamped positions.
const sharedWall = OPS.wallBetween(floor2, shared[0], shared[1]);
check("wallBetween finds the shared wall", Boolean(sharedWall));
p = OPS.addOpening(p, sharedWall.id, "door", 0.5);
const floor3 = OPS.floorOf(p);
check("door added to the wall", floor3.openings.length === 1 && floor3.openings[0].kind === "door");
const sharedSeg = G.wallSegment(sharedWall, (id) => {
  const v = floor3.vertices.find((x) => x.id === id);
  return { x: v.x, y: v.y };
});
const sharedPieces = G.wallPieces(sharedSeg, floor3.openings);
check("wall still fully tiled around the door", sharedPieces.length === 3 && sharedPieces[1].kind === "door-gap");

// Deleting the FIRST room keeps the shared wall (still used by room 2),
// removes its 3 exclusive walls, and cleans up orphaned corners.
p = OPS.deleteRoom(p, floor3.rooms[0].id);
const floor4 = OPS.floorOf(p);
check("deleted room gone", floor4.rooms.length === 1 && floor4.rooms[0].name === "Study");
check("shared wall survives (used by the other room)", floor4.walls.some((w) => w.id === sharedWall.id));
check("exclusive walls removed (4 left: shared + Study's 3)", floor4.walls.length === 4, `walls=${floor4.walls.length}`);
check("orphaned corners cleaned (6 − 3 exclusive-wall-only vertices…)", floor4.vertices.length === floor4.walls.length ? true : floor4.vertices.every((v) => floor4.walls.some((w) => w.a === v.id || w.b === v.id) || floor4.rooms.some((r) => r.polygon.includes(v.id))), `vertices=${floor4.vertices.length}`);
check("openings on removed walls cleaned", floor4.openings.length === 1 && floor4.openings[0].wallId === sharedWall.id);

// Deleting the remaining room removes everything it owned.
p = OPS.deleteRoom(p, floor4.rooms[0].id);
const floor5 = OPS.floorOf(p);
check("deleting the last room clears rooms/walls/openings/vertices", floor5.rooms.length === 0 && floor5.walls.length === 0 && floor5.openings.length === 0 && floor5.vertices.length === 0, `v=${floor5.vertices.length} w=${floor5.walls.length}`);

console.log("\ncalibration rescale\n");
// Rebuild a room, then calibrate: the user says the 4-unit wall is really 5 m.
{
  let q = M.createPlan("tour-1");
  const cids = [];
  for (const c of [
    { x: 0, y: 0 },
    { x: 4, y: 0 },
    { x: 4, y: 3 },
    { x: 0, y: 3 },
  ]) {
    const r = OPS.addVertex(q, c);
    q = r.plan;
    cids.push(r.vertexId);
  }
  q = OPS.createRoom(q, { polygon: cids }).plan;
  const before = G.polygonArea(OPS.floorOf(q).rooms[0].polygon.map((id) => {
    const v = OPS.floorOf(q).vertices.find((x) => x.id === id);
    return { x: v.x, y: v.y };
  }));
  const calib = OPS.applyCalibration(q, 5 / 4, 5, 4); // factor 1.25
  const f = OPS.floorOf(calib);
  const pts = f.rooms[0].polygon.map((id) => {
    const v = f.vertices.find((x) => x.id === id);
    return { x: v.x, y: v.y };
  });
  check("calibration marks the scale calibrated with provenance", calib.scale.calibrated === true && calib.scale.referenceLength === 5 && calib.scale.drawnLength === 4);
  check("vertices rescaled by the factor (4 → 5)", Math.abs(pts[1].x - 5) < 1e-9 && Math.abs(pts[2].y - 3.75) < 1e-2, `${pts[1].x},${pts[2].y}`);
  check("area scales by factor² (12 → 18.75)", Math.abs(G.polygonArea(pts) - before * (5 / 4) ** 2) < 0.05, `${G.polygonArea(pts)}`);
  const bad = OPS.applyCalibration(calib, -1, 5, 4);
  check("a non-positive factor is refused (no data destruction)", bad === calib);
}

console.log("\nplan loader (safe migration)\n");
{
  const okPlan = M.createPlan("tour-9");
  const loaded = M.loadPlan(JSON.parse(JSON.stringify(okPlan)), "tour-9");
  check("round-trip load of a valid plan succeeds", loaded.ok === true && loaded.plan.id === okPlan.id);

  const future = JSON.parse(JSON.stringify(okPlan));
  future.schemaVersion = 99;
  const futureLoad = M.loadPlan(future, "tour-9");
  check("unknown NEWER schema version is rejected (never mangled)", futureLoad.ok === false && /schema version/.test(futureLoad.error));

  const broken = JSON.parse(JSON.stringify(okPlan));
  broken.floors[0].walls.push({ id: "w-dangling", a: "nope", b: "nada", thickness: 0.1 });
  const brokenLoad = M.loadPlan(broken, "tour-9");
  check(
    "dangling wall endpoints are dropped with a warning (recovery, not crash)",
    brokenLoad.ok === true && brokenLoad.warnings.length > 0 && !brokenLoad.plan.floors[0].walls.some((w) => w.id === "w-dangling")
  );

  const noFloors = JSON.parse(JSON.stringify(okPlan));
  noFloors.floors = [];
  check("a plan with no floors is rejected", M.loadPlan(noFloors, "tour-9").ok === false);

  const wrongTour = M.loadPlan(JSON.parse(JSON.stringify(okPlan)), "other-tour");
  check("tourId mismatch produces a warning, not rejection", wrongTour.ok === true && wrongTour.warnings.some((w) => /tourId/.test(w)));

  check("formatLength/formatArea units", M.formatLength("m", 4.2) === "4.20 m" && M.formatLength("ft", 1) === "3.3 ft");
}

console.log(`\nResult: ${passed} passed, ${failed} failed`);
process.exit(failed === 0 ? 0 : 1);
