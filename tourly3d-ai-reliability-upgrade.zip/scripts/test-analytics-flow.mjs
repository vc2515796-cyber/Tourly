/**
 * Hermetic buyer-engagement analytics tests — run in a CHILD process by
 * scripts/smoke-functions.mjs (npm run test:smoke).
 *
 * Same isolation pattern as test-leads-flow.mjs (in-memory Blobs store
 * with prefix-aware list, deterministic firebase-admin verifier):
 *
 *   track-event (public) : validation + whitelists, unknown tour 404,
 *                          enquiry kinds refused (server-recorded only),
 *                          rate limit, aggregate + unique-visitor
 *                          dedupe/cap behaviour, source tagging
 *   capture-lead         : enquiry + visit-request events recorded
 *                          server-side (and only there)
 *   analytics-summary    : verified-token scoping (bob sees zero of
 *                          alice's tours), aggregation, conversion rate,
 *                          week-over-week delta, honest 503/401
 *
 * NOT proven here (needs a real deployment, documented in DEPLOY.md):
 * live Blobs persistence, real Netlify request routing, and that deployed
 * pages actually fire the client events (browser-verified separately).
 */
import { register } from "node:module";
import { pathToFileURL } from "node:url";
import { fileURLToPath } from "node:url";

register("./smoke-auth-loader.mjs", import.meta.url);

const BASE = fileURLToPath(new URL("../node_modules/.tmp/fntest", import.meta.url));
const ORIGIN = "https://tourly.example.netlify.app";

let passed = 0;
let failed = 0;

function check(name, condition, detail) {
  if (condition) {
    passed++;
    console.log(`  PASS  ${name}`);
  } else {
    failed++;
    console.log(`  FAIL  ${name} — ${detail}`);
  }
}

const jsonOf = async (r) => {
  try {
    return await r.clone().json();
  } catch {
    return null;
  }
};

const VALID_SA_KEY = JSON.stringify({
  project_id: "tourly-test",
  client_email: "smoke@test.iam.gserviceaccount.com",
  private_key: "not-a-real-key",
});

const post = (path, body, token) =>
  new Request(`${ORIGIN}${path}`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      ...(token ? { authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify(body),
  });

const get = (path, token) =>
  new Request(`${ORIGIN}${path}`, {
    headers: token ? { authorization: `Bearer ${token}` } : {},
  });

async function main() {
  process.env.FIREBASE_SERVICE_ACCOUNT_KEY = VALID_SA_KEY;

  const { default: trackEvent } = await import(pathToFileURL(`${BASE}/track-event.mjs`).href);
  const { default: analyticsSummary } = await import(pathToFileURL(`${BASE}/analytics-summary.mjs`).href);
  const { default: captureLead } = await import(pathToFileURL(`${BASE}/capture-lead.mjs`).href);
  const { backing, getStore } = await import("@netlify/blobs");
  const analytics = () => backing.get("waypoint-analytics");

  // Materialise stores, then seed: alice owns tour-a; bob owns tour-b;
  // an orphan tour exists without an owner.
  void getStore({ name: "waypoint-analytics" });
  const toursStore = getStore({ name: "waypoint-tours" });
  const setTourJson = (key, value) => backing.get("waypoint-tours").set(key, { text: JSON.stringify(value), json: value });
  setTourJson("an-tour-a", { id: "an-tour-a", name: "Alice's 2BHK", stops: [{ id: "s1", title: "Living room" }, { id: "s2", title: "Kitchen" }] });
  setTourJson("owner:an-tour-a", { uid: "uid-alice" });
  setTourJson("an-tour-b", { id: "an-tour-b", name: "Bob's Villa", stops: [] });
  setTourJson("owner:an-tour-b", { uid: "uid-bob" });
  setTourJson("an-tour-orphan", { id: "an-tour-orphan", name: "Nobody's" });
  void toursStore;

  console.log("[track-event — validation]");
  const t405 = await trackEvent(get("/api/track-event"));
  check("GET rejected with 405", t405.status === 405, `status=${t405.status}`);
  const v1 = await trackEvent(post("/api/track-event", { tourId: "an-tour-a", kind: "nope" }));
  check("unknown kind rejected (400)", v1.status === 400, `status=${v1.status}`);
  const v2 = await trackEvent(post("/api/track-event", { tourId: "an-tour-a", kind: "enquiry" }));
  check("enquiry kind REFUSED from the public (server-recorded only)", v2.status === 400, `status=${v2.status}`);
  const v3 = await trackEvent(post("/api/track-event", { tourId: "an-tour-a", kind: "visit-request" }));
  check("visit-request kind REFUSED from the public", v3.status === 400, `status=${v3.status}`);
  const v4 = await trackEvent(post("/api/track-event", { tourId: "an-tour-a", kind: "tour-view", source: "billboard" }));
  check("unknown source rejected (400)", v4.status === 400, `status=${v4.status}`);
  const v5 = await trackEvent(post("/api/track-event", { tourId: "an-tour-a", kind: "scene-view" }));
  check("scene-view without sceneId rejected (400)", v5.status === 400, `status=${v5.status}`);
  const v6 = await trackEvent(post("/api/track-event", { tourId: "does-not-exist", kind: "tour-view" }));
  check("unknown tour rejected (404) — nothing tracked for drafts", v6.status === 404, `status=${v6.status}`);
  const v7 = await trackEvent(post("/api/track-event", { tourId: "an-tour-a", kind: "tour-view", visitorId: "short" }));
  check("malformed visitorId rejected (400)", v7.status === 400, `status=${v7.status}`);

  console.log("[track-event — aggregation + uniques]");
  const todayKey = new Date().toISOString().slice(0, 10);
  const dayKey = `stats:an-tour-a:${todayKey}`;

  const ok1 = await trackEvent(post("/api/track-event", { tourId: "an-tour-a", kind: "tour-view", source: "qr", visitorId: "visitor-token-one-0001" }));
  check("valid tour-view accepted (200)", ok1.status === 200, `status=${ok1.status}`);
  // Same visitor again (refresh path) — event counts, unique must not.
  await trackEvent(post("/api/track-event", { tourId: "an-tour-a", kind: "tour-view", source: "qr", visitorId: "visitor-token-one-0001" }));
  // A second visitor.
  await trackEvent(post("/api/track-event", { tourId: "an-tour-a", kind: "tour-view", source: "wa", visitorId: "visitor-token-two-0002" }));
  await trackEvent(post("/api/track-event", { tourId: "an-tour-a", kind: "scene-view", source: "qr", sceneId: "s1" }));
  await trackEvent(post("/api/track-event", { tourId: "an-tour-a", kind: "hotspot", source: "qr", sceneId: "s1" }));

  const day = analytics()?.get(dayKey)?.json;
  check("day document created under stats:{tourId}:{date}", Boolean(day), `key=${dayKey}`);
  check("3 tour-views counted (refreshes count as views)", day?.events?.["tour-view"] === 3, `events=${JSON.stringify(day?.events)}`);
  check("unique visitors deduped (2 browsers, not 3 opens)", day?.uniques?.length === 2, `uniques=${day?.uniques?.length}`);
  check("visitor tokens hashed — raw token never stored", !JSON.stringify(day).includes("visitor-token-one-0001"), "raw token found in doc");
  check("sources split (qr=4: 2 views + scene + hotspot, wa=1)", day?.sources?.qr === 4 && day?.sources?.wa === 1, `sources=${JSON.stringify(day?.sources)}`);
  check("scene opens attributed to scene s1 (hotspot not mixed in)", day?.scenes?.s1 === 1, `scenes=${JSON.stringify(day?.scenes)}`);
  check("hotspot click counted", day?.events?.hotspot === 1, `events=${JSON.stringify(day?.events)}`);

  console.log("[track-event — rate limit]");
  let got429 = false;
  for (let i = 0; i < 62 && !got429; i++) {
    const r = await trackEvent(post("/api/track-event", { tourId: "an-tour-b", kind: "tour-view", visitorId: `burst-visitor-${i}` }));
    if (r.status === 429) got429 = true;
  }
  check("burst above 60/min from one IP rate-limited (429)", got429, "no 429 within 62 rapid requests");

  console.log("[capture-lead — server-side enquiry analytics]");
  const e1 = await captureLead(
    post("/api/capture-lead", {
      tourId: "an-tour-a",
      name: "Rahul",
      phone: "9812345678",
      message: "Can I visit on Sunday morning?",
      consent: true,
      visitRequested: true,
    })
  );
  check("enquiry with visit request captured (200)", e1.status === 200, `status=${e1.status}`);
  const leadKeys = [...(backing.get("waypoint-leads")?.keys() ?? [])].filter((k) => k.startsWith("lead:"));
  const storedLead = backing.get("waypoint-leads").get(leadKeys[0]).json;
  check("visitRequested persisted on the lead", storedLead.visitRequested === true, `visitRequested=${storedLead.visitRequested}`);
  const dayAfterLead = analytics()?.get(dayKey)?.json;
  check("enquiry event recorded server-side (once)", dayAfterLead?.events?.enquiry === 1, `enquiry=${dayAfterLead?.events?.enquiry}`);
  check("visit-request event recorded server-side", dayAfterLead?.events?.["visit-request"] === 1, `vr=${dayAfterLead?.events?.["visit-request"]}`);

  console.log("[analytics-summary — auth + ownership]");
  const s1 = await analyticsSummary(get("/api/analytics-summary?ids=an-tour-a"));
  check("no token → 401", s1.status === 401, `status=${s1.status}`);
  const s2 = await analyticsSummary(get("/api/analytics-summary?ids=an-tour-a", "garbage-token"));
  check("garbage token → 401", s2.status === 401, `status=${s2.status}`);
  const sBadIds = await analyticsSummary(get("/api/analytics-summary", "test-id-token-alice"));
  check("missing ids → 400", sBadIds.status === 400, `status=${sBadIds.status}`);

  const s3 = await analyticsSummary(get("/api/analytics-summary?ids=an-tour-a,an-tour-b", "test-id-token-alice"));
  const s3b = await jsonOf(s3);
  check("alice's summary loads (200)", s3.status === 200 && s3b?.ok === true, `status=${s3.status}`);
  check(
    "ownership scoping: only alice's tour returned, bob's excluded silently",
    s3b?.tours?.length === 1 && s3b.tours[0].id === "an-tour-a",
    `tours=${JSON.stringify(s3b?.tours?.map((t) => t.id))}`
  );
  const aliceTour = s3b?.tours?.[0];
  check("tour views aggregated (3)", aliceTour?.views === 3, `views=${aliceTour?.views}`);
  check("uniques aggregated (2)", aliceTour?.uniques === 2, `uniques=${aliceTour?.uniques}`);
  check("enquiry counted in summary (1)", aliceTour?.enquiries === 1, `enquiries=${aliceTour?.enquiries}`);
  check("visit request counted in summary (1)", aliceTour?.visitRequests === 1, `vr=${aliceTour?.visitRequests}`);
  check(
    "conversion rate = enquiries/views with one decimal",
    aliceTour?.conversionRate === 33.3,
    `rate=${aliceTour?.conversionRate}`
  );
  check("top scene list built from scene ids", aliceTour?.topScenes?.[0]?.sceneId === "s1", `top=${JSON.stringify(aliceTour?.topScenes)}`);
  check("overall totals mirror the tour", s3b?.overall?.views === 3 && s3b?.overall?.enquiries === 1, `overall=${JSON.stringify(s3b?.overall)}`);

  const s4 = await analyticsSummary(get("/api/analytics-summary?ids=an-tour-a", "test-id-token-bob"));
  const s4b = await jsonOf(s4);
  check("bob requesting alice's id sees an EMPTY tour list (no error, no data)", s4.status === 200 && s4b?.tours?.length === 0, `tours=${s4b?.tours?.length}`);

  console.log("[analytics-summary — unconfigured + zero data]");
  const saKey = process.env.FIREBASE_SERVICE_ACCOUNT_KEY;
  delete process.env.FIREBASE_SERVICE_ACCOUNT_KEY;
  const s5 = await analyticsSummary(get("/api/analytics-summary?ids=an-tour-a", "test-id-token-alice"));
  const s5b = await jsonOf(s5);
  check("no service account → honest 503 naming the env var", s5.status === 503 && /FIREBASE_SERVICE_ACCOUNT_KEY/.test(String(s5b?.error)), `status=${s5.status}`);
  process.env.FIREBASE_SERVICE_ACCOUNT_KEY = saKey;

  // A brand-new tour with no events: zero views, conversion null (not 0%).
  setTourJson("an-tour-fresh", { id: "an-tour-fresh", name: "Fresh listing", stops: [] });
  setTourJson("owner:an-tour-fresh", { uid: "uid-alice" });
  const s6 = await analyticsSummary(get("/api/analytics-summary?ids=an-tour-fresh", "test-id-token-alice"));
  const s6b = await jsonOf(s6);
  check("fresh tour: zero views, zero enquiries, conversion NULL (never a fake 0%)", s6b?.tours?.[0]?.views === 0 && s6b?.tours?.[0]?.conversionRate === null, `tour=${JSON.stringify(s6b?.tours?.[0])}`);

  console.log(`\nANALYTICS_SUMMARY: ${passed} ${failed}`);
  process.exit(failed === 0 ? 0 : 1);
}

main().catch((err) => {
  console.error("ANALYTICS FLOW RUNNER ERROR:", err);
  process.exit(1);
});
