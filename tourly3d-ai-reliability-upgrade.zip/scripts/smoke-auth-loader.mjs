/**
 * Loader hooks for the hermetic auth-flow smoke tests
 * (scripts/smoke-auth-flow.mjs).
 *
 * Redirects the three external packages the bundled functions import to
 * deterministic in-process mocks — @netlify/blobs to an in-memory store,
 * firebase-admin to a fixed token→identity mapping — so the FULL publish
 * flow (token verification, ownership claim, cross-user 403) can be tested
 * with no network, no Firebase project, and no Netlify environment.
 *
 * These mocks are TEST-ONLY infrastructure and never ship in the deployed
 * functions — Netlify's bundler uses the real packages.
 */
export async function resolve(specifier, context, nextResolve) {
  const mocks = {
    "@netlify/blobs": new URL("./mocks/netlify-blobs.mjs", import.meta.url).href,
    "firebase-admin/app": new URL("./mocks/firebase-admin-app.mjs", import.meta.url).href,
    "firebase-admin/auth": new URL("./mocks/firebase-admin-auth.mjs", import.meta.url).href,
  };
  if (mocks[specifier]) {
    return { url: mocks[specifier], shortCircuit: true };
  }
  return nextResolve(specifier, context);
}
