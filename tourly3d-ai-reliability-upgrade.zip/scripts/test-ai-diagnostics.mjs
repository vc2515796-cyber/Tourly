/**
 * Hermetic admin AI-diagnostics tests (Phase 8) — child process with the
 * same mocked-externals pattern as test-concept-flow.mjs (in-memory Blobs,
 * deterministic alice/bob token verifier, mocked fetch for live pings).
 *
 * Verifies the SECURITY SHAPE above all:
 *   - anonymous → 401, no operational detail
 *   - invalid token → 401
 *   - signed-in NON-admin → 403, no operational detail
 *   - admin (ADMIN_EMAILS) → 200 with the safe snapshot
 *   - the snapshot NEVER contains API keys or secret env values
 *   - GET makes ZERO provider requests (no quota spent on page loads)
 *   - POST test → exactly ONE minimal request per CONFIGURED provider,
 *     sanitized result (no provider bodies), and is rate-limited (429 on
 *     an immediate second test)
 *   - unconfigured secondary shows up as a safe indicator, not an error
 *
 * NOT proven here: real provider behaviour (mocked fetch), real Blobs.
 */
import { register } from "node:module";
import { pathToFileURL, fileURLToPath } from "node:url";

register("./smoke-auth-loader.mjs", import.meta.url);

const BASE = fileURLToPath(new URL("../node_modules/.tmp/fntest", import.meta.url));
const ORIGIN = "https://tourly.example.netlify.app";

let passed = 0;
let failed = 0;
function check(name, condition, detail) {
  if (condition) {
    passed++;
    console.log(`  PASS  ${name}`);
  } else {
    failed++;
    console.log(`  FAIL  ${name} — ${detail}`);
  }
}
const jsonOf = async (r) => {
  try {
    return await r.clone().json();
  } catch {
    return null;
  }
};

const VALID_SA_KEY = JSON.stringify({
  project_id: "tourly-test",
  client_email: "smoke@test.iam.gserviceaccount.com",
  private_key: "not-a-real-key",
});

const req = (method, path, token, body, ip = "9.9.9.9") =>
  new Request(`${ORIGIN}${path}`, {
    method,
    headers: {
      "content-type": "application/json",
      "x-nf-client-connection-ip": ip,
      ...(token ? { authorization: `Bearer ${token}` } : {}),
    },
    ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
  });

async function main() {
  const diagnostics = (await import(pathToFileURL(`${BASE}/ai-diagnostics.mjs`).href)).default;

  process.env.FIREBASE_SERVICE_ACCOUNT_KEY = VALID_SA_KEY;
  process.env.GEMINI_API_KEY = "AIzaFakeGeminiKeyForTests0123456789";
  process.env.GROQ_API_KEY = "gsk_fake_groq_key_for_tests_0123456789";
  process.env.ADMIN_EMAILS = "alice@example.com";
  delete process.env.GROQ_MODEL;

  const realFetch = globalThis.fetch;
  const fetchCalls = [];
  globalThis.fetch = (url, init) => {
    fetchCalls.push({ url: String(url), init });
    const u = String(url);
    if (u.includes("api.groq.com")) {
      return Promise.resolve(
        new Response(JSON.stringify({ choices: [{ message: { content: "{\"ok\":true}" } }] }), { status: 200 })
      );
    }
    // Gemini ping path.
    return Promise.resolve(
      new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text: "{\"ok\":true}" }] } }] }), { status: 200 })
    );
  };

  console.log("\nGroup A — authorization (server-side, every request)\n");

  const r405 = await diagnostics(req("PUT", "/api/ai-diagnostics", "test-id-token-alice"));
  check("PUT rejected 405", r405.status === 405, `status=${r405.status}`);

  const rAnon = await diagnostics(req("GET", "/api/ai-diagnostics", null));
  const bAnon = await jsonOf(rAnon);
  check("anonymous → 401", rAnon.status === 401, `status=${rAnon.status}`);
  check("anonymous gets NO operational detail", !bAnon?.providers && !bAnon?.metrics, JSON.stringify(bAnon));

  const rBad = await diagnostics(req("GET", "/api/ai-diagnostics", "not-a-real-token"));
  check("invalid token → 401", rBad.status === 401, `status=${rBad.status}`);

  const rBob = await diagnostics(req("GET", "/api/ai-diagnostics", "test-id-token-bob"));
  const bBob = await jsonOf(rBob);
  check("signed-in NON-admin → 403", rBob.status === 403, `status=${rBob.status}`);
  check("non-admin gets NO operational detail", !bBob?.providers && !bBob?.metrics, JSON.stringify(bBob));

  console.log("\nGroup B — admin snapshot (safe fields only)\n");

  fetchCalls.length = 0;
  const rAlice = await diagnostics(req("GET", "/api/ai-diagnostics", "test-id-token-alice"));
  const bAlice = await jsonOf(rAlice);
  check("admin → 200", rAlice.status === 200, `status=${rAlice.status}`);
  check("GET made ZERO provider requests (no quota on page load)", fetchCalls.length === 0, `calls=${fetchCalls.length}`);
  check("providers listed with names + model ids", bAlice?.providers?.length === 2 && bAlice.providers.some((p) => p.id === "gemini") && bAlice.providers.some((p) => p.id === "groq"), JSON.stringify(bAlice?.providers));
  check("groq default model reported", bAlice?.providers?.find((p) => p.id === "groq")?.models?.text?.[0] === "openai/gpt-oss-120b", JSON.stringify(bAlice?.providers?.find((p) => p.id === "groq")));
  check("features + quotas listed", Array.isArray(bAlice?.features) && bAlice.features.length >= 10, JSON.stringify(bAlice?.features?.length));
  check("config flags present", bAlice?.config?.geminiConfigured === true && bAlice?.config?.secondaryProvider === "groq" && bAlice?.config?.adminConfigured === true, JSON.stringify(bAlice?.config));
  check("honest note about timestamps vs live health", /history|not a live/i.test(String(bAlice?.note ?? "")), String(bAlice?.note));
  const snapshotStr = JSON.stringify(bAlice);
  check("snapshot NEVER contains the Gemini key", !snapshotStr.includes("AIzaFakeGeminiKey"), "leaked");
  check("snapshot NEVER contains the Groq key", !snapshotStr.includes("gsk_fake_groq"), "leaked");
  // Structural check: only the known-safe top-level keys exist (no
  // prompts/photos/leads arrays could have been smuggled in).
  check(
    "snapshot has ONLY the known-safe top-level keys",
    Object.keys(bAlice ?? {}).every((k) => ["ok", "providers", "metrics", "features", "config", "note"].includes(k)),
    Object.keys(bAlice ?? {}).join(",")
  );

  console.log("\nGroup C — live test (explicit, rate-limited, minimal)\n");

  fetchCalls.length = 0;
  const rTest = await diagnostics(req("POST", "/api/ai-diagnostics", "test-id-token-alice", { test: true }));
  const bTest = await jsonOf(rTest);
  check("test → 200", rTest.status === 200, `status=${rTest.status}`);
  check("exactly ONE request per configured provider (gemini + groq)", fetchCalls.filter((c) => c.url.includes("generativelanguage")).length === 1 && fetchCalls.filter((c) => c.url.includes("api.groq.com")).length === 1, JSON.stringify(fetchCalls.map((c) => c.url)));
  check("results are sanitized (provider, model, ok, kind — no bodies)", bTest?.results?.length === 2 && bTest.results.every((r) => r.ok === true && typeof r.latencyMs === "number" && !("body" in r)), JSON.stringify(bTest?.results));
  const testStr = JSON.stringify(bTest);
  check("test response NEVER contains keys", !testStr.includes("AIzaFakeGeminiKey") && !testStr.includes("gsk_fake_groq"), "leaked");

  // Immediate second test → rate limited (max 1 per 30s).
  const rTest2 = await diagnostics(req("POST", "/api/ai-diagnostics", "test-id-token-alice", { test: true }, "9.9.9.9"));
  check("immediate second live test → 429 (rate-limited)", rTest2.status === 429, `status=${rTest2.status}`);

  console.log("\nGroup D — unconfigured states are safe indicators\n");

  delete process.env.GROQ_API_KEY;
  delete process.env.GEMINI_API_KEY;
  const rNoKeys = await diagnostics(req("GET", "/api/ai-diagnostics", "test-id-token-alice"));
  const bNoKeys = await jsonOf(rNoKeys);
  check("snapshot still works with no providers configured", rNoKeys.status === 200 && bNoKeys?.config?.geminiConfigured === false && bNoKeys?.config?.secondaryProvider === null, JSON.stringify(bNoKeys?.config));
  check("gemini marked not-configured in providers list", bNoKeys?.providers?.[0]?.configured === false, JSON.stringify(bNoKeys?.providers));

  delete process.env.ADMIN_EMAILS;
  const rNoAdmin = await diagnostics(req("GET", "/api/ai-diagnostics", "test-id-token-alice"));
  check("ADMIN_EMAILS unset → even alice gets 403 (fail closed)", rNoAdmin.status === 403, `status=${rNoAdmin.status}`);

  globalThis.fetch = realFetch;
  console.log(`\nDIAGNOSTICS_SUMMARY: ${passed} ${failed}`);
  process.exitCode = failed === 0 ? 0 : 1;
}

main().catch((err) => {
  console.error("DIAGNOSTICS SUITE ERROR:", err);
  process.exit(1);
});
