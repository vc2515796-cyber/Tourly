// Build preflight: verify the compiler, bundler and every type package used by
// `npm run build` are actually installed BEFORE the build starts, and print an
// actionable diagnosis when they are not.
//
// Why this exists: these packages used to live in devDependencies, and an
// install that omits them (`npm install --production`, `npm ci --omit=dev`,
// NODE_ENV=production / NPM_FLAGS=--production in CI) silently stripped them,
// producing cryptic failures like "tsc: not found" or
// "TS2688: Cannot find type definition file for 'vite/client'" /
// "TS2307: Cannot find module 'react' or its corresponding type declarations".
// All build packages are now declared in "dependencies" (see package.json), so
// a COMPLETE install of THIS manifest always contains them. When they are
// missing anyway, one of these is true:
//   A) node_modules was built from a different/older manifest or a partial
//      install (wrong directory, stale checkout, failed install step,
//      non-npm package manager, or a leftover production-mode install);
//   B) the package.json next to this script is an OLD copy that still keeps
//      the toolchain in devDependencies — i.e. you are NOT building this
//      project's current files.
// This script tells you which case you are in and exactly what to do.
import { existsSync, readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = join(HERE, "..");

const REQUIRED = [
  "typescript",          // runs `tsc -b` + functions typecheck
  "vite",                // bundler + `vite/client` type library
  "@vitejs/plugin-react",
  "tailwindcss",         // PostCSS pipeline used by vite build
  "postcss",
  "autoprefixer",
  "@types/node",         // tsconfig.functions.json "types": ["node"]
  "@types/react",        // react/react-dom ship without declarations
  "@types/react-dom",
  "@types/three",        // three@0.166 does not bundle its own types
  "@netlify/functions",  // imported by netlify/functions/*.mts
  "@netlify/edge-functions",
];

// --- environment banner (helps remote diagnosis: report these numbers) ---
let npmVersion = "unknown";
try {
  const r = spawnSync("npm", ["--version"], { encoding: "utf8", timeout: 15000 });
  if (r.status === 0 && r.stdout) npmVersion = r.stdout.trim();
} catch { /* non-fatal */ }
console.log(`✔ preflight: node ${process.version}, npm ${npmVersion}`);
console.log(`✔ preflight: manifest ${join(ROOT, "package.json")}`);

// --- does THIS package.json declare the toolchain in dependencies? ---
let manifest;
try {
  manifest = JSON.parse(readFileSync(join(ROOT, "package.json"), "utf8"));
} catch (err) {
  console.error(`✖ Cannot read package.json next to this script: ${err.message}`);
  process.exit(1);
}
const deps = manifest.dependencies || {};
const undeclared = REQUIRED.filter((p) => !(p in deps));
if (undeclared.length > 0) {
  console.error(`✖ This package.json does NOT declare the build toolchain in "dependencies":`);
  for (const p of undeclared) console.error(`    - ${p}`);
  console.error(`
  You are almost certainly building an OLD copy of this project. Since the
  "Netlify build fix", package.json lists every build tool (typescript, vite,
  tailwind, all @types/* and @netlify/* packages) under "dependencies" and has
  NO devDependencies. A package.json without them is a previous version.

  Fix: re-extract the tourly3d-netlify-build-fixed.zip you received, copy its
  contents (including package.json AND package-lock.json) over your project
  folder / repository, delete node_modules, and install again with
  "npm install". On Netlify, also check Site configuration → Build & deploy:
  the Base directory must be the folder that contains THIS package.json (the
  ZIP extracts to a "tourly3d/" folder), not the repository root or another
  copy of the project.`);
  process.exit(1);
}

// --- are they actually installed in node_modules? ---
const missing = [];
for (const pkg of REQUIRED) {
  const manifestPath = join(ROOT, "node_modules", pkg, "package.json");
  let ok = existsSync(manifestPath);
  if (ok) {
    try { JSON.parse(readFileSync(manifestPath, "utf8")); } catch { ok = false; }
  }
  if (!ok) missing.push(pkg);
}

if (missing.length > 0) {
  console.error("✖ Build toolchain is incompletely installed. Missing:");
  for (const pkg of missing) console.error(`    - ${pkg}`);
  console.error(`
  This package.json correctly declares all of them in "dependencies" (verified
  above), so a complete "npm install" / "npm ci" of THIS folder installs them
  all — this has been verified with npm 9, npm 10 and npm 11, including
  "npm ci --omit=dev". If they are missing anyway, node_modules was created
  differently. Check, in this order:

  1. Was the install step skipped or did it FAIL? Read the install log above
     this message. A failed install (network error, registry proxy, ENOTFOUND,
     E404) leaves node_modules empty/partial — fix the install error first.
  2. Are you in the right directory? The build must run where this
     package.json lives (the ZIP extracts to a "tourly3d/" folder). On
     Netlify, Site configuration → Build & deploy → Base directory.
  3. Is another package manager or manifest in play? A yarn.lock or
     pnpm-lock.yaml (or a different package.json) in the build directory
     makes the installer ignore package-lock.json. Remove stale lockfiles
     from other package managers and use npm with this project.
  4. Is a leftover production-mode environment present? Netlify UI env vars
     can override netlify.toml: make sure NPM_FLAGS is NOT "--production" or
     "--omit=dev" in Site configuration → Environment variables. (With this
     package.json even --omit=dev installs the toolchain, but removing the
     flag also rules out an old manifest being installed.)

  Then: rm -rf node_modules && npm install   (local)
        or clear caches/retry the install    (Netlify)`);
  process.exit(1);
}

console.log("✔ Build toolchain present (compiler, bundler, type packages)");
