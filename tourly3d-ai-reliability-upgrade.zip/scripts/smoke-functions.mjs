/**
 * Tourly3D function smoke tests — runnable anywhere, no external credentials
 * and no network calls needed.
 *
 * Bundles the Netlify Functions exactly the way Netlify deploys them, then
 * exercises the paths that must work WITHOUT any provider configured
 * (honest JSON failures, no crashes, never the SPA's HTML) plus the
 * signature/secret/validation security boundaries with env vars set
 * in-process.
 *
 * Run: npm run test:smoke
 */
import crypto from "node:crypto";
import { spawnSync } from "node:child_process";
import { pathToFileURL } from "node:url";
import { fileURLToPath } from "node:url";

const BASE = fileURLToPath(new URL("../node_modules/.tmp/fntest", import.meta.url));
const ORIGIN = "https://tourly.example.netlify.app";

let passed = 0;
let failed = 0;

function check(name, condition, detail) {
  if (condition) {
    passed++;
    console.log(`  PASS  ${name}`);
  } else {
    failed++;
    console.log(`  FAIL  ${name} — ${detail}`);
  }
}

async function jsonOf(response) {
  try {
    return await response.clone().json();
  } catch {
    return null;
  }
}

const isJson = (r) => r.headers.get("content-type") === "application/json";
const importFn = (name) => import(pathToFileURL(`${BASE}/${name}.mjs`).href);

async function main() {
  // ---- GROUP 1: no credentials configured -------------------------------
  console.log("Group 1 — honest behaviour with NOTHING configured\n");

  const mediaUpload = (await importFn("media-upload")).default;
  console.log("[media-upload]");
  const r1 = await mediaUpload(new Request(`${ORIGIN}/api/media-upload`));
  const b1 = await jsonOf(r1);
  check(
    "GET reports unconfigured state as JSON",
    r1.status === 200 && b1?.configured === false && isJson(r1),
    `status=${r1.status}`
  );
  const r2 = await mediaUpload(
    new Request(`${ORIGIN}/api/media-upload`, { method: "POST", body: "{}", headers: { "content-type": "application/json" } })
  );
  check(
    "POST without S3 config fails honestly (501 JSON, no fake success)",
    r2.status === 501 && typeof (await jsonOf(r2))?.error === "string",
    `status=${r2.status}`
  );
  const r3 = await mediaUpload(new Request(`${ORIGIN}/api/media-upload`, { method: "POST", body: "not-json" }));
  check("error responses are always JSON, never the SPA's HTML", isJson(r3), `content-type=${r3.headers.get("content-type")}`);

  const waWebhook = (await importFn("whatsapp-webhook")).default;
  console.log("[whatsapp-webhook]");
  const w1 = await waWebhook(new Request(`${ORIGIN}/api/whatsapp-webhook`));
  check("GET health probe returns 200 JSON", w1.status === 200 && (await jsonOf(w1))?.ok === true, `status=${w1.status}`);
  const w2 = await waWebhook(
    new Request(`${ORIGIN}/api/whatsapp-webhook`, { method: "POST", body: JSON.stringify({ entry: [] }) })
  );
  check(
    "POST without WHATSAPP_* config returns honest 503 JSON (never a fake 200)",
    w2.status === 503 && typeof (await jsonOf(w2))?.error === "string",
    `status=${w2.status}`
  );
  const w3 = await waWebhook(
    new Request(`${ORIGIN}/api/whatsapp-webhook?hub.mode=subscribe&hub.verify_token=wrong&hub.challenge=123`)
  );
  check("verification handshake rejects a wrong token (403)", w3.status === 403, `status=${w3.status}`);

  const tgWebhook = (await importFn("telegram-webhook")).default;
  console.log("[telegram-webhook]");
  const t1 = await tgWebhook(
    new Request(`${ORIGIN}/api/telegram-webhook`, { method: "POST", body: JSON.stringify({ update_id: 1 }) })
  );
  check(
    "POST without TELEGRAM_* config returns honest 503 JSON",
    t1.status === 503 && typeof (await jsonOf(t1))?.error === "string",
    `status=${t1.status}`
  );

  const publishTour = (await importFn("publish-tour")).default;
  console.log("[publish-tour]");
  const p1 = await publishTour(
    new Request(`${ORIGIN}/api/publish-tour`, {
      method: "POST",
      body: JSON.stringify({ tour: { id: "abc", stops: [{ id: "s1", media: { kind: "image", dataUrl: "x" } }] } }),
    })
  );
  check(
    "publish without FIREBASE_SERVICE_ACCOUNT_KEY refuses (503) rather than running unauthenticated",
    p1.status === 503,
    `status=${p1.status}`
  );
  const p2 = await publishTour(
    new Request(`${ORIGIN}/api/publish-tour`, {
      method: "POST",
      body: JSON.stringify({ tour: { id: "abc", stops: [] } }),
    })
  );
  check(
    "publish of an empty tour is rejected with a useful message (400)",
    p2.status === 400 && typeof (await jsonOf(p2))?.error === "string",
    `status=${p2.status}`
  );
  const p3 = await publishTour(
    new Request(`${ORIGIN}/api/publish-tour`, {
      method: "POST",
      body: JSON.stringify({ tour: { id: "meta:evil", stops: [] } }),
    })
  );
  check("reserved tour-id prefixes are rejected (anti-collision guard)", p3.status === 400, `status=${p3.status}`);

  const getTour = (await importFn("get-tour")).default;
  console.log("[get-tour]");
  const g0 = await getTour(new Request(`${ORIGIN}/api/tour`));
  check("missing id parameter → 400 JSON", g0.status === 400 && isJson(g0), `status=${g0.status}`);
  const g1 = await getTour(new Request(`${ORIGIN}/api/tour?id=does-not-exist`));
  check(
    "storage unavailable (local, no Blobs) → clean JSON 500, no crash, no HTML",
    g1.status === 500 && typeof (await jsonOf(g1))?.error === "string" && isJson(g1),
    `status=${g1.status}`
  );

  const messagingLink = (await importFn("messaging-link")).default;
  console.log("[messaging-link]");
  const m1 = await messagingLink(new Request(`${ORIGIN}/api/messaging-link`));
  const m1body = await jsonOf(m1);
  check(
    "GET reports both providers unconfigured as JSON booleans",
    m1.status === 200 && m1body?.whatsappConfigured === false && m1body?.telegramConfigured === false,
    `status=${m1.status}`
  );
  const m2 = await messagingLink(
    new Request(`${ORIGIN}/api/messaging-link`, { method: "POST", body: JSON.stringify({ action: "create-code" }) })
  );
  check(
    "code creation without server auth config is refused (503) — never issues codes anonymously",
    m2.status === 503,
    `status=${m2.status}`
  );

  const analyzeScene = (await importFn("analyze-scene")).default;
  console.log("[analyze-scene]");
  const a1 = await analyzeScene(
    new Request(`${ORIGIN}/api/analyze-scene`, {
      method: "POST",
      body: JSON.stringify({ imageBase64: "AAAA", mimeType: "image/jpeg" }),
    })
  );
  check(
    "Gemini analysis without GEMINI_API_KEY fails honestly (503, no fake results)",
    a1.status === 503 && (await jsonOf(a1))?.error === "Scene analysis not configured",
    `status=${a1.status}`
  );

  const classifyScenes = (await importFn("classify-scenes")).default;
  console.log("[classify-scenes]");
  const c1 = await classifyScenes(
    new Request(`${ORIGIN}/api/classify-scenes`, {
      method: "POST",
      body: JSON.stringify({ images: [] }),
      headers: { "content-type": "application/json" },
    })
  );
  check(
    "empty batch without GEMINI_API_KEY still validated first (400, not 503)",
    c1.status === 400 && typeof (await jsonOf(c1))?.error === "string",
    `status=${c1.status}`
  );
  const c2 = await classifyScenes(
    new Request(`${ORIGIN}/api/classify-scenes`, {
      method: "POST",
      body: JSON.stringify({ images: [{ id: "i1", imageBase64: "AAAA", mimeType: "image/jpeg" }] }),
      headers: { "content-type": "application/json" },
    })
  );
  check(
    "classification without GEMINI_API_KEY fails honestly (503, no fake categories)",
    c2.status === 503 && typeof (await jsonOf(c2))?.error === "string",
    `status=${c2.status}`
  );
  const c3 = await classifyScenes(new Request(`${ORIGIN}/api/classify-scenes`));
  check("GET method rejected 405 JSON", c3.status === 405 && isJson(c3), `status=${c3.status}`);

  // ---- GROUP 2: security paths with env vars set in-process -------------
  console.log("\nGroup 2 — security paths with provider env vars set (no external calls)\n");

  // Stage B4: full copywriter plumbing with a MOCKED Gemini response — this
  // tests request parsing + response shaping + missing-fact reporting, NOT
  // model quality (no real API call is made or claimed).
  console.log("[generate-marketing — mocked Gemini round-trip]");
  process.env.GEMINI_API_KEY = "fake-key-for-validation-only";
  const generateMarketingFn = (await importFn("generate-marketing")).default;
  const realFetch = globalThis.fetch;
  let capturedPrompt = "";
  globalThis.fetch = async (_url, init) => {
    try {
      capturedPrompt = JSON.parse(init?.body ?? "{}")?.contents?.[0]?.parts?.[0]?.text ?? "";
    } catch {}
    return new Response(
      JSON.stringify({
        candidates: [
          {
            content: {
              parts: [
                {
                  text: JSON.stringify({
                    title: "Sunlit 2BHK near Metro",
                    headline: "Bright 2BHK, walk to Metro",
                    shortDescription: "A bright 2BHK tour.",
                    longDescription: "A bright 2BHK with a wide balcony.",
                    instagramCaption: "Sunlit vibes #2bhk #hometour",
                    whatsappMessage: "See this 2BHK: {tourLink}",
                    seoTitle: "2BHK Tour | Sunlit Home",
                    seoDescription: "Walk through a bright 2BHK from your phone.",
                    tourIntro: "Welcome — step inside this bright 2BHK.",
                  }),
                },
              ],
            },
          },
        ],
      }),
      { status: 200, headers: { "content-type": "application/json" } }
    );
  };
  try {
    const gm = await generateMarketingFn(
      new Request(`${ORIGIN}/api/generate-marketing`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          tourName: "My 2BHK",
          subtitle: "",
          stops: [{ title: "Living room" }],
          facts: { propertyType: "2BHK apartment", price: "₹85 lakh", language: "hinglish", channel: "WhatsApp" },
        }),
      })
    );
    const gmBody = await jsonOf(gm);
    check("mocked Gemini round-trip returns 200 with all fields", gm.status === 200 && gmBody?.title === "Sunlit 2BHK near Metro" && typeof gmBody?.tourIntro === "string", `status=${gm.status}`);
    check(
      "missing facts reported honestly (location/size/beds/baths), never fabricated into the prompt",
      Array.isArray(gmBody?.missingFields) && ["location/address", "size", "bedrooms", "bathrooms"].every((f) => gmBody.missingFields.includes(f)),
      `missing=${JSON.stringify(gmBody?.missingFields)}`
    );
    check("old 7-field contract preserved for existing callers", typeof gmBody?.whatsappMessage === "string" && typeof gmBody?.seoTitle === "string");
    check(
      "supplied facts reach the prompt; missing ones listed as never-invent",
      capturedPrompt.includes("85 lakh") && capturedPrompt.includes("2BHK apartment") && capturedPrompt.includes("NOT provided"),
      `prompt head: ${capturedPrompt.slice(0, 120)}`
    );
    check(
      "Hinglish language instruction reaches the prompt",
      capturedPrompt.includes("Hinglish"),
      `no language rule found`
    );
  } finally {
    globalThis.fetch = realFetch;
  }

  // Stage C round 2: function-level wiring of the Gemini fallback engine —
  // the engine itself has a dedicated 52-check suite (test-gemini-fallback);
  // these two checks prove the HTTP handlers translate GeminiError into the
  // right status + safe JSON (no key material, retryable flag present).
  console.log("[analyze-scene — fallback engine error wiring]");
  process.env.GEMINI_API_KEY = "fake-key-for-validation-only";
  process.env.GEMINI_MAX_RETRIES = "0";
  process.env.GEMINI_BACKOFF_BASE_MS = "1";
  const analyzeSceneFn = (await importFn("analyze-scene")).default;
  const sceneBody = JSON.stringify({ imageBase64: "AAAA", mimeType: "image/jpeg" });
  try {
    globalThis.fetch = async () => new Response('{"error":"overloaded"}', { status: 503, headers: { "content-type": "application/json" } });
    const a1 = await analyzeSceneFn(
      new Request(`${ORIGIN}/api/analyze-scene`, { method: "POST", headers: { "content-type": "application/json" }, body: sceneBody })
    );
    const a1b = await jsonOf(a1);
    check(
      "all models busy (503) → honest 502 JSON with retryable:true and no key material",
      a1.status === 502 && a1b?.retryable === true && !/fake-key/.test(JSON.stringify(a1b)) && isJson(a1),
      `status=${a1.status} body=${JSON.stringify(a1b)}`
    );
    globalThis.fetch = async () => new Response('{"error":"API key not valid"}', { status: 401, headers: { "content-type": "application/json" } });
    const a2 = await analyzeSceneFn(
      new Request(`${ORIGIN}/api/analyze-scene`, { method: "POST", headers: { "content-type": "application/json" }, body: sceneBody })
    );
    const a2b = await jsonOf(a2);
    check(
      "invalid key (401) → 503 config error, NOT retried, no key echoed",
      a2.status === 503 && a2b?.retryable === false && /GEMINI_API_KEY/.test(String(a2b?.error)) && !/fake-key/.test(JSON.stringify(a2b)),
      `status=${a2.status} body=${JSON.stringify(a2b)}`
    );
  } finally {
    globalThis.fetch = realFetch;
    delete process.env.GEMINI_MAX_RETRIES;
    delete process.env.GEMINI_BACKOFF_BASE_MS;
  }

  // WhatsApp signature validation
  process.env.WHATSAPP_TOKEN = "test-token";
  process.env.WHATSAPP_APP_SECRET = "test-app-secret";
  process.env.WHATSAPP_PHONE_NUMBER_ID = "123456789";
  process.env.WHATSAPP_VERIFY_TOKEN = "my-verify-token";

  console.log("[whatsapp-webhook — signed]");
  const waBody = JSON.stringify({ object: "whatsapp_business_account", entry: [] });
  const goodSig = "sha256=" + crypto.createHmac("sha256", "test-app-secret").update(waBody).digest("hex");
  const s1 = await waWebhook(
    new Request(`${ORIGIN}/api/whatsapp-webhook`, {
      method: "POST",
      body: waBody,
      headers: { "content-type": "application/json", "x-hub-signature-256": "sha256=" + "0".repeat(64) },
    })
  );
  check("POST with a FORGED signature is rejected 401 before any processing", s1.status === 401, `status=${s1.status}`);
  const s2 = await waWebhook(
    new Request(`${ORIGIN}/api/whatsapp-webhook`, {
      method: "POST",
      body: waBody,
      headers: { "content-type": "application/json", "x-hub-signature-256": goodSig },
    })
  );
  check(
    "POST with a VALID HMAC signature is accepted (200, 0 messages processed)",
    s2.status === 200 && (await jsonOf(s2))?.processed === 0,
    `status=${s2.status}`
  );
  const s3 = await waWebhook(
    new Request(`${ORIGIN}/api/whatsapp-webhook?hub.mode=subscribe&hub.verify_token=my-verify-token&hub.challenge=echo-me-42`)
  );
  check(
    "verification handshake echoes the challenge for the correct token",
    s3.status === 200 && (await s3.text()) === "echo-me-42",
    `status=${s3.status}`
  );

  // Telegram secret-token validation
  process.env.TELEGRAM_BOT_TOKEN = "000:test-bot-token";
  process.env.TELEGRAM_WEBHOOK_SECRET = "super-secret-webhook";

  console.log("[telegram-webhook — authenticated]");
  const t2 = await tgWebhook(
    new Request(`${ORIGIN}/api/telegram-webhook`, {
      method: "POST",
      body: JSON.stringify({ update_id: 1 }),
      headers: { "content-type": "application/json", "x-telegram-bot-api-secret-token": "wrong-secret" },
    })
  );
  check("POST with a wrong secret token is rejected 401", t2.status === 401, `status=${t2.status}`);
  const t3 = await tgWebhook(
    new Request(`${ORIGIN}/api/telegram-webhook`, {
      method: "POST",
      body: JSON.stringify({ update_id: 2 }), // no message → acknowledged without touching storage
      headers: { "content-type": "application/json", "x-telegram-bot-api-secret-token": "super-secret-webhook" },
    })
  );
  check(
    "POST with the correct secret token is accepted (200 for a non-message update)",
    t3.status === 200 && (await jsonOf(t3))?.ok === true,
    `status=${t3.status}`
  );

  // Gemini input validation (API key present, malformed body → 400 before any API call)
  process.env.GEMINI_API_KEY = "fake-key-for-validation-only";

  console.log("[analyze-scene — validated]");
  const a2 = await analyzeScene(
    new Request(`${ORIGIN}/api/analyze-scene`, {
      method: "POST",
      body: JSON.stringify({ mimeType: "image/jpeg" }),
      headers: { "content-type": "application/json" },
    })
  );
  check("missing imageBase64 rejected with 400 (validation before any API call)", a2.status === 400, `status=${a2.status}`);
  const a3 = await analyzeScene(
    new Request(`${ORIGIN}/api/analyze-scene`, {
      method: "POST",
      body: JSON.stringify({ imageBase64: "A".repeat(5_000_000), mimeType: "image/jpeg" }),
      headers: { "content-type": "application/json" },
    })
  );
  check("oversized image payload rejected with 413", a3.status === 413, `status=${a3.status}`);

  console.log("[classify-scenes — validated]");
  const c4 = await classifyScenes(
    new Request(`${ORIGIN}/api/classify-scenes`, {
      method: "POST",
      body: JSON.stringify({ images: Array.from({ length: 13 }, (_, i) => ({ id: `i${i}`, imageBase64: "AAAA", mimeType: "image/jpeg" })) }),
      headers: { "content-type": "application/json" },
    })
  );
  check("batch over the 12-image cap rejected with 400", c4.status === 400, `status=${c4.status}`);
  const c5 = await classifyScenes(
    new Request(`${ORIGIN}/api/classify-scenes`, {
      method: "POST",
      body: JSON.stringify({ images: [{ id: "i1" }, { id: "i1", imageBase64: "AAAA", mimeType: "image/jpeg" }] }),
      headers: { "content-type": "application/json" },
    })
  );
  check("duplicate image ids in one batch rejected with 400", c5.status === 400, `status=${c5.status}`);
  const c6 = await classifyScenes(
    new Request(`${ORIGIN}/api/classify-scenes`, {
      method: "POST",
      body: JSON.stringify({ images: [{ id: "i1", imageBase64: "A".repeat(1_000_000), mimeType: "image/jpeg" }] }),
      headers: { "content-type": "application/json" },
    })
  );
  check("oversized per-image payload rejected with 413 before any API call", c6.status === 413, `status=${c6.status}`);
  const c7 = await classifyScenes(
    new Request(`${ORIGIN}/api/classify-scenes`, {
      method: "POST",
      body: "not-json",
    })
  );
  check("invalid JSON body rejected with 400 JSON", c7.status === 400 && isJson(c7), `status=${c7.status}`);

  // ---- GROUP 3: full auth + ownership flow (mocked externals) -----------
  // Runs in a child process so its module mocks (in-memory Blobs store,
  // deterministic firebase-admin verifier) don't leak into the tests above,
  // which deliberately exercise the REAL unconfigured-blobs failure paths.
  console.log("\nGroup 3 — authenticated publishing & ownership (mocked externals)\n");
  const harnessUrl = new URL("./smoke-auth-flow.mjs", import.meta.url);
  const child = spawnSync(process.execPath, [fileURLToPath(harnessUrl)], {
    encoding: "utf8",
    env: { ...process.env, FIREBASE_SERVICE_ACCOUNT_KEY: "" },
    timeout: 60_000,
  });
  process.stdout.write(child.stdout ?? "");
  if (child.stderr) process.stderr.write(child.stderr);
  const summaryMatch = String(child.stdout ?? "").match(/AUTHFLOW_SUMMARY:\s*(\d+)\s+(\d+)/);
  if (summaryMatch) {
    const childPassed = Number(summaryMatch[1]);
    const childFailed = Number(summaryMatch[2]);
    passed += childPassed;
    failed += childFailed;
    console.log(`  (auth-flow suite: ${childPassed} passed, ${childFailed} failed — included above)`);
  } else {
    failed++;
    console.log(`  FAIL  auth-flow suite ran to completion — exit=${child.status}, see output above`);
  }

  // ---- GROUP 4: lead workflow (mocked externals) ---------------------------
  // Second child process: same isolation reasons as Group 3.
  console.log("\nGroup 4 — lead capture & CRM (mocked externals)\n");
  const leadsHarnessUrl = new URL("./test-leads-flow.mjs", import.meta.url);
  const leadsChild = spawnSync(process.execPath, [fileURLToPath(leadsHarnessUrl)], {
    encoding: "utf8",
    env: { ...process.env, FIREBASE_SERVICE_ACCOUNT_KEY: "" },
    timeout: 60_000,
  });
  process.stdout.write(leadsChild.stdout ?? "");
  if (leadsChild.stderr) process.stderr.write(leadsChild.stderr);
  const leadsMatch = String(leadsChild.stdout ?? "").match(/LEADFLOW_SUMMARY:\s*(\d+)\s+(\d+)/);
  if (leadsMatch) {
    const lp = Number(leadsMatch[1]);
    const lf = Number(leadsMatch[2]);
    passed += lp;
    failed += lf;
    console.log(`  (leads-flow suite: ${lp} passed, ${lf} failed — included above)`);
  } else {
    failed++;
    console.log(`  FAIL  leads-flow suite ran to completion — exit=${leadsChild.status}, see output above`);
  }

  // ---- GROUP 5: buyer-engagement analytics (mocked externals) --------------
  // Third child process: same isolation reasons as Groups 3-4.
  console.log("\nGroup 5 — engagement analytics (mocked externals)\n");
  const analyticsHarnessUrl = new URL("./test-analytics-flow.mjs", import.meta.url);
  const analyticsChild = spawnSync(process.execPath, [fileURLToPath(analyticsHarnessUrl)], {
    encoding: "utf8",
    env: { ...process.env, FIREBASE_SERVICE_ACCOUNT_KEY: "" },
    timeout: 60_000,
  });
  process.stdout.write(analyticsChild.stdout ?? "");
  if (analyticsChild.stderr) process.stderr.write(analyticsChild.stderr);
  const analyticsMatch = String(analyticsChild.stdout ?? "").match(/ANALYTICS_SUMMARY:\s*(\d+)\s+(\d+)/);
  if (analyticsMatch) {
    const ap = Number(analyticsMatch[1]);
    const af = Number(analyticsMatch[2]);
    passed += ap;
    failed += af;
    console.log(`  (analytics-flow suite: ${ap} passed, ${af} failed — included above)`);
  } else {
    failed++;
    console.log(`  FAIL  analytics-flow suite ran to completion — exit=${analyticsChild.status}, see output above`);
  }

  // ---- GROUP 6: Stage D AI upgrade (mocked externals) ------------------------
  // Fourth child process: AI concept floor plan + quotas/cache + lead
  // insights + tour-assistant scoping + copywriter quota.
  console.log("\nGroup 6 — Stage D AI features (mocked externals)\n");
  const conceptHarnessUrl = new URL("./test-concept-flow.mjs", import.meta.url);
  const conceptChild = spawnSync(process.execPath, [fileURLToPath(conceptHarnessUrl)], {
    encoding: "utf8",
    env: { ...process.env, FIREBASE_SERVICE_ACCOUNT_KEY: "" },
    timeout: 90_000,
  });
  process.stdout.write(conceptChild.stdout ?? "");
  if (conceptChild.stderr) process.stderr.write(conceptChild.stderr);
  const conceptMatch = String(conceptChild.stdout ?? "").match(/CONCEPT_SUMMARY:\s*(\d+)\s+(\d+)/);
  if (conceptMatch) {
    const cp = Number(conceptMatch[1]);
    const cf = Number(conceptMatch[2]);
    passed += cp;
    failed += cf;
    console.log(`  (concept-flow suite: ${cp} passed, ${cf} failed — included above)`);
  } else {
    failed++;
    console.log(`  FAIL  concept-flow suite ran to completion — exit=${conceptChild.status}, see output above`);
  }


  // ---- GROUP 7: admin AI diagnostics (mocked externals, child process) ----
  console.log("\nGroup 7 — admin AI diagnostics (mocked externals)\n");
  const diagHarnessUrl = new URL("./test-ai-diagnostics.mjs", import.meta.url);
  const diagChild = spawnSync(process.execPath, [fileURLToPath(diagHarnessUrl)], {
    encoding: "utf8",
    env: { ...process.env, FIREBASE_SERVICE_ACCOUNT_KEY: "" },
    timeout: 90_000,
  });
  process.stdout.write(diagChild.stdout ?? "");
  if (diagChild.stderr) process.stderr.write(diagChild.stderr);
  const diagMatch = String(diagChild.stdout ?? "").match(/DIAGNOSTICS_SUMMARY:\s*(\d+)\s+(\d+)/);
  if (diagMatch) {
    const dp = Number(diagMatch[1]);
    const df = Number(diagMatch[2]);
    passed += dp;
    failed += df;
    console.log(`  (diagnostics suite: ${dp} passed, ${df} failed — included above)`);
  } else {
    failed++;
    console.log(`  FAIL  diagnostics suite ran to completion — exit=${diagChild.status}, see output above`);
  }

  console.log(`\nResult: ${passed} passed, ${failed} failed`);
  process.exit(failed === 0 ? 0 : 1);
}

main().catch((err) => {
  console.error("SMOKE TEST RUNNER ERROR:", err);
  process.exit(1);
});
