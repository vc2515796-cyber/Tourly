/**
 * Stage D unit tests — the AI Concept Floor Plan geometry engine (pure
 * client-side logic; no network, no credentials, no DOM).
 *
 * Covers:
 *   - analysis → FloorPlanDocument conversion (outline → vertices/walls/
 *     room ring; openings projected onto walls; furniture with uncertainty
 *     flags and nominal sizes; uncalibrated scale; concept provenance meta)
 *   - refusal to fabricate (degenerate/short outlines rejected)
 *   - wall dedupe (AI's duplicate ring edges collapse into one wall)
 *   - unknown furniture kinds coerced to "other" with safe default sizes
 *   - snapshotOfConceptPlan (no unbounded nesting)
 *   - loadPlan with the Stage-D furniture extension (valid kept, invalid
 *     dropped with a warning) + full save→load round trip
 *   - the NOT-TO-SCALE watermark rule (needsConceptWatermark)
 *
 * NOT covered here (browser-only, honestly not claimed): Konva canvas
 * rendering, drag interactions, and stage.toDataURL PNG rasterisation.
 *
 * Run: node scripts/test-concept-plan.mjs   (chained into npm run test:units)
 */
import { spawnSync } from "node:child_process";
import { pathToFileURL, fileURLToPath } from "node:url";

const OUT = fileURLToPath(new URL("../node_modules/.tmp/concepttest", import.meta.url));

const bundle = spawnSync(
  process.platform === "win32" ? "npx.cmd" : "npx",
  [
    "esbuild", "src/lib/conceptPlan.ts",
    "--bundle", "--packages=external", "--platform=node", "--format=esm",
    `--outdir=${OUT}`, "--out-extension:.js=.mjs",
  ],
  { stdio: "pipe", cwd: fileURLToPath(new URL("..", import.meta.url)) }
);
if (bundle.status !== 0) {
  console.error("esbuild bundling of conceptPlan.ts failed:\n" + bundle.stdout + bundle.stderr);
  process.exit(1);
}

// conceptPlan.ts re-exports model helpers it uses; bundle the model loader
// separately for the loadPlan/furniture tests.
const bundle2 = spawnSync(
  process.platform === "win32" ? "npx.cmd" : "npx",
  [
    "esbuild", "src/lib/plan/model.ts",
    "--bundle", "--packages=external", "--platform=node", "--format=esm",
    `--outdir=${OUT}`, "--out-extension:.js=.mjs",
  ],
  { stdio: "pipe", cwd: fileURLToPath(new URL("..", import.meta.url)) }
);
if (bundle2.status !== 0) {
  console.error("esbuild bundling of plan/model.ts failed:\n" + bundle2.stdout + bundle2.stderr);
  process.exit(1);
}

const {
  analysisToFloorPlan,
  snapshotOfConceptPlan,
  needsConceptWatermark,
  CONCEPT_DISCLAIMER,
} = await import(pathToFileURL(`${OUT}/conceptPlan.mjs`).href);
const { loadPlan } = await import(pathToFileURL(`${OUT}/model.mjs`).href);

let passed = 0;
let failed = 0;
function check(name, condition, detail = "") {
  if (condition) {
    passed++;
    console.log(`  PASS  ${name}`);
  } else {
    failed++;
    console.log(`  FAIL  ${name} — ${detail}`);
  }
}

// --- a realistic valid analysis (as the SERVER would validate it) -----------
const validAnalysis = {
  schemaVersion: 1,
  roomType: "Living Room",
  confidence: 0.7,
  roomOutline: [
    { x: 0.1, y: 0.1 }, { x: 0.9, y: 0.1 }, { x: 0.9, y: 0.8 }, { x: 0.1, y: 0.8 },
  ],
  walls: [
    // duplicates the top ring edge (must NOT create a second wall)
    { a: { x: 0.1, y: 0.1 }, b: { x: 0.9, y: 0.1 }, certain: true },
    // an interior wall
    { a: { x: 0.9, y: 0.4 }, b: { x: 0.6, y: 0.4 }, certain: false },
  ],
  openings: [
    { kind: "door", x: 0.5, y: 0.8, certain: true },   // bottom edge → t≈0.5
    { kind: "window", x: 0.9, y: 0.6, certain: false }, // right edge
  ],
  furniture: [
    { kind: "sofa", x: 0.3, y: 0.2, rotation: 90, certain: true },
    { kind: "banana", x: 0.5, y: 0.5, certain: false }, // unknown kind → other
    { kind: "bed", x: 0.7, y: 0.65, w: 0.2, h: 0.25, certain: false },
  ],
  uncertaintyNotes: ["walls behind the camera are inferred"],
  model: "gemini-3.8-flash",
};

const source = { stopId: "stop-1", stopTitle: "Living Room" };

console.log("Group A — analysis → floor-plan conversion\n");
{
  const result = analysisToFloorPlan(validAnalysis, "tour-1", source);
  check("valid analysis converts", result.ok, JSON.stringify(result).slice(0, 120));
  if (result.ok) {
    const plan = result.plan;
    const floor = plan.floors[0];
    check("plan stays UNCALIBRATED (no fake measurements)", plan.scale.calibrated === false);
    check("4 ring vertices + 2 interior-wall endpoints = 6 vertices; 4 ring walls + 1 interior = 5 walls", floor.vertices.length === 6 && floor.walls.length === 5, `v=${floor.vertices.length} w=${floor.walls.length}`);
    check("duplicate ring edge deduped; interior wall added", floor.walls.length === 5);
    check("one room named from the analysis", floor.rooms.length === 1 && floor.rooms[0].name === "Living Room");
    check("room polygon references every ring vertex", floor.rooms[0].polygon.length === 4);

    const nominal = 8; // NOMINAL_SPAN — keep in sync with conceptPlan.ts
    check("normalized coords map to nominal plan units (0.1 → 0.8)", Math.abs(floor.vertices[0].x - 0.1 * nominal) < 1e-9);

    const door = floor.openings.find((o) => o.kind === "door");
    check("door projected onto the nearest wall at t≈0.5", door && Math.abs(door.t - 0.5) < 0.05, `t=${door?.t}`);
    const win = floor.openings.find((o) => o.kind === "window");
    check("window carries its uncertainty flag", win?.uncertain === true);

    const sofa = floor.furniture.find((f) => f.kind === "sofa");
    check("certain furniture keeps uncertain=false", sofa?.uncertain === false);
    check("sofa rotation preserved", Math.abs((sofa?.rotation ?? -1) - 90) < 1e-9);
    const banana = floor.furniture.find((f) => f.label !== undefined ? false : f.kind === "other");
    check("unknown furniture kind coerced to 'other' with default size", floor.furniture.some((f) => f.kind === "other") && (banana?.w ?? 0) > 0);
    const bed = floor.furniture.find((f) => f.kind === "bed");
    check("AI w/h scaled into nominal units and clamped", bed && bed.w === 0.2 * nominal, `w=${bed?.w}`);
    check("uncertain furniture flagged", bed?.uncertain === true);

    check("concept provenance recorded", plan.concept?.generatedBy === "ai-concept-v1" && plan.concept.sourceStopId === "stop-1" && plan.concept.model === "gemini-3.8-flash");
    check("uncertainty notes carried over", plan.concept?.uncertaintyNotes[0] === "walls behind the camera are inferred");
    check("watermark required while concept origin", needsConceptWatermark(plan) === true);

    const snap = snapshotOfConceptPlan(plan);
    check("snapshot strips its own nested snapshot (no unbounded nesting)", snap.concept?.generatedSnapshot === undefined);
  }
}

console.log("\nGroup B — refusal to fabricate\n");
{
  const degenerate = analysisToFloorPlan({ ...validAnalysis, roomOutline: [{ x: 0.5, y: 0.5 }, { x: 0.51, y: 0.5 }, { x: 0.505, y: 0.5 }] }, "tour-1", source);
  check("degenerate (collinear) outline rejected", degenerate.ok === false);
  const short = analysisToFloorPlan({ ...validAnalysis, roomOutline: [{ x: 0.1, y: 0.1 }, { x: 0.9, y: 0.9 }] }, "tour-1", source);
  check("outline with < 3 points rejected", short.ok === false);
  const noFurnitureNoWalls = analysisToFloorPlan(
    { ...validAnalysis, furniture: [], walls: [] },
    "tour-1",
    source
  );
  check("empty furniture/walls still converts (empty room is valid)", noFurnitureNoWalls.ok === true);
}

console.log("\nGroup C — persistence round trip (existing plan loader)\n");
{
  const result = analysisToFloorPlan(validAnalysis, "tour-1", source);
  if (result.ok) {
    const snap = snapshotOfConceptPlan(result.plan);
    const conceptMeta = result.plan.concept;
    const withSnapshot = { ...result.plan, concept: { ...conceptMeta, generatedSnapshot: snap } };
    // Simulate save → storage → reload exactly as the tour pipeline does.
    const persisted = JSON.parse(JSON.stringify(withSnapshot));
    const loaded = loadPlan(persisted, "tour-1");
    check("saved concept plan loads back cleanly", loaded.ok, loaded.ok ? "" : loaded.error);
    if (loaded.ok) {
      const f = loaded.plan.floors[0];
      check("furniture survives the round trip", (f.furniture ?? []).length === 3);
      check("concept metadata + snapshot survive", loaded.plan.concept?.generatedSnapshot !== undefined);
      check("openings + uncertainty flags survive", f.openings.length === 2 && f.openings.some((o) => o.uncertain));
    }

    // Broken furniture items are dropped, not fatal.
    const broken = JSON.parse(JSON.stringify(withSnapshot));
    broken.floors[0].furniture = [
      ...broken.floors[0].furniture,
      { id: "bad-1", kind: "spaceship", x: "not-a-number", y: 1 }, // invalid
      { id: "bad-2", kind: "bed", x: 1, y: 1 }, // valid
    ];
    const loadedBroken = loadPlan(broken, "tour-1");
    check("invalid furniture dropped with a warning, valid kept", loadedBroken.ok && loadedBroken.warnings.some((w) => w.includes("furniture")) && loadedBroken.plan.floors[0].furniture.some((f) => f.id === "bad-2") && !loadedBroken.plan.floors[0].furniture.some((f) => f.id === "bad-1"));

    // A pre-Stage-D plan (no furniture, no concept) still loads untouched.
    const legacy = JSON.parse(JSON.stringify(withSnapshot));
    delete legacy.floors[0].furniture;
    delete legacy.concept;
    const loadedLegacy = loadPlan(legacy, "tour-1");
    check("pre-Stage-D plans remain fully valid", loadedLegacy.ok && needsConceptWatermark(loadedLegacy.plan) === false);
  }
}

console.log("\nGroup D — watermark contract\n");
{
  check("disclaimer text is exactly the mandated wording", CONCEPT_DISCLAIMER === "CONCEPTUAL FLOOR PLAN — NOT TO SCALE");
  check("no concept → no watermark", needsConceptWatermark(null) === false);
}

console.log(`\n============================================================`);
console.log(`Concept plan engine: ${passed} passed, ${failed} failed`);
if (failed) process.exit(1);
