/**
 * Unit tests for the Stage B1 pure algorithm cores:
 *   - src/lib/phash.ts          (dHash + hamming distance + duplicate grouping)
 *   - src/lib/imageQuality.ts   (brightness + Laplacian blur scoring)
 *
 * These libs are written with a pure core that accepts ImageData-like
 * objects, so the algorithms are testable in Node without a browser
 * canvas. The browser wrappers (FileReader/Image/canvas) are exercised in
 * real usage, not here — that distinction is kept honest in the docs.
 *
 * Run: node scripts/test-phash.mjs   (bundled first via esbuild)
 */
import { spawnSync } from "node:child_process";
import { pathToFileURL, fileURLToPath } from "node:url";
import { mkdirSync } from "node:fs";

const ROOT = fileURLToPath(new URL("..", import.meta.url));
const OUT = `${ROOT}/node_modules/.tmp/libtest`;
mkdirSync(OUT, { recursive: true });

// Bundle the two TS libs exactly the way Vite ships them for the browser.
const build = spawnSync(
  "npx",
  [
    "esbuild",
    `${ROOT}src/lib/phash.ts`,
    `${ROOT}src/lib/imageQuality.ts`,
    "--bundle",
    "--platform=browser",
    "--format=esm",
    `--outdir=${OUT}`,
    "--out-extension:.js=.mjs",
  ],
  { stdio: "pipe", encoding: "utf8" }
);
if (build.status !== 0) {
  console.error("esbuild failed:\n" + build.stdout + build.stderr);
  process.exit(1);
}

const { dhashCore, hammingDistance, areLikelyDuplicates, findDuplicateGroups } = await import(
  pathToFileURL(`${OUT}/phash.mjs`).href
);
const { scoreQualityCore, laplacianVarianceCore, DARK_BRIGHTNESS_THRESHOLD, BLUR_VARIANCE_THRESHOLD } = await import(
  pathToFileURL(`${OUT}/imageQuality.mjs`).href
);

let passed = 0;
let failed = 0;
function check(name, condition, detail = "") {
  if (condition) {
    passed++;
    console.log(`  PASS  ${name}`);
  } else {
    failed++;
    console.log(`  FAIL  ${name} — ${detail}`);
  }
}

// --- synthetic image helpers -------------------------------------------------

/** Builds an RGBA buffer of w×h from a luma function. */
function synthImage(w, h, lumaFn) {
  const data = new Uint8ClampedArray(w * h * 4);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const v = Math.max(0, Math.min(255, Math.round(lumaFn(x, y))));
      const i = (y * w + x) * 4;
      data[i] = v;
      data[i + 1] = v;
      data[i + 2] = v;
      data[i + 3] = 255;
    }
  }
  return { width: w, height: h, data };
}

/** Left→right horizontal gradient — dHash of this is all-ones-ish and stable. */
const gradientImage = (w = 64, h = 64) => synthImage(w, h, (x) => (x / w) * 255);
/** Vertical gradient — every horizontal comparison is equal → all-zero hash. */
const vGradientImage = (w = 64, h = 64) => synthImage(w, h, (x, y) => (y / h) * 255);
/** Checkerboard — high-frequency detail. */
const checkerImage = (w = 64, h = 64, cell = 4) => synthImage(w, h, (x, y) => ((Math.floor(x / cell) + Math.floor(y / cell)) % 2 ? 230 : 20));
/** Flat mid-gray — no edges at all (max blur). */
const flatImage = (w = 64, h = 64) => synthImage(w, h, () => 128);
/** Noisy texture — extremely high edge variance. */
const noiseImage = (w = 64, h = 64, seed = 42) => {
  let s = seed;
  const rand = () => ((s = (s * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
  return synthImage(w, h, () => rand() * 255);
};

console.log("dHash core\n");
const h1 = dhashCore(gradientImage());
check("hash is 16 hex chars (64 bits)", /^[0-9a-f]{16}$/.test(h1), h1);
const h1Again = dhashCore(gradientImage(48, 80)); // different size, same structure
check("horizontal gradient hash is size-invariant", hammingDistance(h1, h1Again) <= 6, `dist=${hammingDistance(h1, h1Again)}`);
// A REVERSED (decreasing) gradient flips every comparison bit — all 0s
// become all 1s, the maximum possible distance.
const reversedGradient = synthImage(64, 64, (x) => 255 - (x / 64) * 255);
const h2 = dhashCore(reversedGradient);
check("reversed gradient hash differs maximally (≥ 58 bits)", hammingDistance(h1, h2) >= 58, `dist=${hammingDistance(h1, h2)}`);
check("identical input → distance 0", hammingDistance(h1, dhashCore(gradientImage())) === 0);

console.log("\nhamming distance + duplicate grouping\n");
check("hammingDistance('00','00') === 0", hammingDistance("0000000000000000", "0000000000000000") === 0);
check("hammingDistance('00','ff') === 64 (every bit differs)", hammingDistance("0000000000000000", "ffffffffffffffff") === 64);
check("hammingDistance('00','01') === 1", hammingDistance("0000000000000000", "0000000000000001") === 1);
check("mismatched lengths → Infinity (never a false match)", hammingDistance("00", "0000") === Infinity);
check("areLikelyDuplicates respects the threshold", areLikelyDuplicates("0000000000000000", "0000000000000001", 1) === true && areLikelyDuplicates("0000000000000000", "0000000000000003", 1) === false);

const near = noiseImage(64, 64, 7);
const nearPerturbed = (() => {
  // Same seed pattern + a mild sinusoidal perturbation — a stand-in for
  // the tiny shifts a re-save/re-compress introduces.
  let s = 7;
  const rand = () => ((s = (s * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
  return synthImage(64, 64, (x, y) => rand() * 255 + Math.sin(x * 0.4 + y * 0.2) * 3);
})();
const other = noiseImage(64, 64, 999);
const groups = findDuplicateGroups([dhashCore(near), dhashCore(other), dhashCore(nearPerturbed), null]);
check("perturbed copy is grouped with its original", groups.get(2) === 0, `map=${JSON.stringify([...groups])}`);
check("different image is not flagged", !groups.has(1), `dist=${hammingDistance(dhashCore(near), dhashCore(other))}`);
check("null hash (undecodable) never matches anything", !groups.has(3));

console.log("\nquality scoring core\n");
const dark = scoreQualityCore(synthImage(32, 32, () => 5)); // near-black
const bright = scoreQualityCore(synthImage(32, 32, () => 250)); // near-white
check(`very dark image scores below the dark threshold (${dark.brightness} < ${DARK_BRIGHTNESS_THRESHOLD})`, dark.brightness < DARK_BRIGHTNESS_THRESHOLD, `brightness=${dark.brightness}`);
check(`bright image scores above the dark threshold (${bright.brightness})`, bright.brightness >= DARK_BRIGHTNESS_THRESHOLD, `brightness=${bright.brightness}`);
check("reported dimensions match the input", bright.width === 32 && bright.height === 32);

const sharpVar = laplacianVarianceCore(checkerImage());
const flatVar = laplacianVarianceCore(flatImage());
check(`checkerboard edge variance is high (${sharpVar.toFixed(0)} ≥ ${BLUR_VARIANCE_THRESHOLD})`, sharpVar !== null && sharpVar >= BLUR_VARIANCE_THRESHOLD, `var=${sharpVar}`);
check(`flat image edge variance is ~0 (flagged blurry)`, flatVar !== null && flatVar < BLUR_VARIANCE_THRESHOLD, `var=${flatVar}`);
check("tiny image (no interior pixels) → null, never a wrong verdict", laplacianVarianceCore(synthImage(2, 2, () => 128)) === null);
const noiseVar = laplacianVarianceCore(noiseImage());
check(`noise variance is far above the blur threshold (${noiseVar.toFixed(0)})`, noiseVar > BLUR_VARIANCE_THRESHOLD * 10, `var=${noiseVar}`);

console.log(`\nResult: ${passed} passed, ${failed} failed`);
process.exit(failed === 0 ? 0 : 1);
