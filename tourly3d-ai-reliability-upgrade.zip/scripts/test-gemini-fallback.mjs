/**
 * Gemini fallback-engine tests — hermetic, no network, no credentials.
 *
 * Bundles netlify/functions/_gemini.mts exactly the way Netlify deploys it,
 * then mocks globalThis.fetch to exercise every mandated scenario:
 *
 *   1.  Primary model succeeds
 *   2.  Fallback model succeeds after a temporary primary-model failure
 *   3.  Both models fail
 *   4.  Invalid API key / permission error (401/403) — no retry, no fallback
 *   5.  Unsupported model (404) — fallback recovers; disabled fallback fails clean
 *   6.  Timeout + retry exhaustion
 *   plus: Retry-After honouring, wall-clock budget bounds, key sanitisation,
 *   multimodal payload passthrough, caller-signal abort, env model resolution,
 *   400-fallback, unconfigured key.
 *
 * Run: node scripts/test-gemini-fallback.mjs   (chained into npm run test:units)
 */
import { spawnSync } from "node:child_process";
import { pathToFileURL } from "node:url";
import { fileURLToPath } from "node:url";

const OUT = fileURLToPath(new URL("../node_modules/.tmp/gemtest", import.meta.url));

const bundle = spawnSync(
  process.platform === "win32" ? "npx.cmd" : "npx",
  [
    "esbuild", "netlify/functions/_gemini.mts",
    "--bundle", "--packages=external", "--platform=node", "--format=esm",
    `--outdir=${OUT}`, "--out-extension:.js=.mjs",
  ],
  { stdio: "pipe", cwd: fileURLToPath(new URL("..", import.meta.url)) }
);
if (bundle.status !== 0) {
  console.error("esbuild bundling of _gemini.mts failed:\n" + bundle.stdout + bundle.stderr);
  process.exit(1);
}
process.exitCode = 0;

// The reliability reset is imported FROM THE _gemini BUNDLE (which inlines
// _providers.mts) — a separately-bundled _providers.mjs would be a different
// instance and the reset would silently miss callGemini's own state.
const { callGemini, GeminiError, resolveModels, sanitizeDetail, resetReliabilityStateForTests } = await import(
  pathToFileURL(`${OUT}/_gemini.mjs`).href
);
const resetReliability = () => resetReliabilityStateForTests();

let passed = 0;
let failed = 0;
const failures = [];
function check(name, condition, detail = "") {
  if (condition) {
    passed++;
    console.log(`  PASS  ${name}`);
  } else {
    failed++;
    failures.push(name);
    console.log(`  FAIL  ${name} — ${detail}`);
  }
}

// --- fetch mocking -----------------------------------------------------------

const realFetch = globalThis.fetch;
let calls = []; // { url, init } per attempt
let behavior = null; // (url, init) => Response | Promise<Response>

function mockFetch(fn) {
  behavior = fn;
  calls = [];
  globalThis.fetch = (url, init) => {
    calls.push({ url: String(url), init });
    return behavior(url, init);
  };
}
const okBody = JSON.stringify({ candidates: [{ content: { parts: [{ text: "ok" }] } }] });
const ok = () => new Response(okBody, { status: 200, headers: { "content-type": "application/json" } });
const statusResponse = (status, body = "{}", headers = {}) =>
  new Response(body, { status, headers: { "content-type": "application/json", ...headers } });

/** A fetch that never resolves on its own and rejects on abort — exactly how
 *  a real hanging request behaves when the AbortController fires. */
const hanging = (url, init) =>
  new Promise((_resolve, reject) => {
    init?.signal?.addEventListener("abort", () => {
      reject(new DOMException("The operation was aborted", "AbortError"));
    });
  });

const FAST = { maxRetries: 1, timeoutMs: 2_000, totalBudgetMs: 10_000, backoffBaseMs: 1 };

async function expectGeminiError(promise) {
  try {
    await promise;
    return null;
  } catch (err) {
    if (err instanceof GeminiError) return err;
    return { wrongError: err };
  }
}

// --- run ---------------------------------------------------------------------

const savedEnv = { ...process.env };

async function main() {
  process.env.GEMINI_API_KEY = "fake-key-for-tests-only";

  console.log("Group A — model resolution (env vars)\n");
  {
    delete process.env.GEMINI_TEXT_MODEL;
    delete process.env.GEMINI_TEXT_MODEL_FALLBACK;
    delete process.env.GEMINI_IMAGE_MODEL;
    delete process.env.GEMINI_IMAGE_MODEL_FALLBACK;
    const t = resolveModels("text");
    const i = resolveModels("image");
    check(
      "defaults resolve to verified stable models",
      t[0] === "gemini-3.8-flash" && t[1] === "gemini-3.1-flash-lite" && i[0] === "gemini-3.1-flash-image" && i[1] === "gemini-nano-banana-2.1",
      `text=${t} image=${i}`
    );
    process.env.GEMINI_TEXT_MODEL = "custom-a";
    process.env.GEMINI_TEXT_MODEL_FALLBACK = "custom-b";
    check(
      "env overrides both primary and fallback",
      JSON.stringify(resolveModels("text")) === JSON.stringify(["custom-a", "custom-b"]),
      `got ${resolveModels("text")}`
    );
    process.env.GEMINI_TEXT_MODEL_FALLBACK = "";
    check("empty fallback string disables fallback", resolveModels("text").length === 1, `got ${resolveModels("text")}`);
    process.env.GEMINI_TEXT_MODEL_FALLBACK = "custom-a";
    check("fallback equal to primary is deduped", resolveModels("text").length === 1, `got ${resolveModels("text")}`);
    delete process.env.GEMINI_TEXT_MODEL;
    delete process.env.GEMINI_TEXT_MODEL_FALLBACK;
  }

  console.log("\nGroup B — scenario 1: primary model succeeds\n");
  resetReliability();
  {
    const payload = {
      contents: [{ parts: [{ text: "hi" }, { inline_data: { mime_type: "image/jpeg", data: "QUJD" } }] }],
      generationConfig: { responseMimeType: "application/json" },
    };
    mockFetch(() => ok());
    const result = await callGemini("text", payload, { ...FAST, functionName: "test" });
    check("returns the 2xx response on the FIRST attempt", calls.length === 1 && result.response.status === 200, `calls=${calls.length}`);
    check("default primary model used (gemini-3.8-flash)", calls[0].url.includes("/models/gemini-3.8-flash:generateContent"), calls[0].url);
    check("multimodal payload passed through verbatim", JSON.parse(calls[0].init.body).contents[0].parts[1].inline_data.data === "QUJD");
    check("API key sent in HEADER, never in the URL", calls[0].init.headers["x-goog-api-key"] === "fake-key-for-tests-only" && !calls[0].url.includes("key="), calls[0].url);
    check("result exposes which model answered", result.model === "gemini-3.8-flash", result.model);
  }

  console.log("\nGroup C — scenario 2: fallback model succeeds after temporary primary failure\n");
  resetReliability();
  {
    mockFetch((url) => (url.includes("gemini-3.8-flash") ? statusResponse(503, '{"error":"overloaded"}') : ok()));
    const t0 = Date.now();
    const result = await callGemini("text", { contents: [{ parts: [{ text: "hi" }] }] }, { ...FAST, functionName: "test" });
    const elapsed = Date.now() - t0;
    check("primary retried once (bounded), then fallback succeeded", calls.length === 3, `calls=${calls.length}`);
    check(
      "attempts hit primary, primary, fallback in order",
      calls[0].url.includes("gemini-3.8-flash") && calls[1].url.includes("gemini-3.8-flash") && calls[2].url.includes("gemini-3.1-flash-lite"),
      calls.map((c) => c.url.split("/models/")[1]).join(" → ")
    );
    check("fallback response returned", result.response.status === 200 && result.model === "gemini-3.1-flash-lite", result.model);
    check("exponential backoff with tiny base stays fast", elapsed < 1_500, `${elapsed}ms`);
  }

  console.log("\nGroup D — scenario 3: both models fail\n");
  resetReliability();
  {
    mockFetch(() => statusResponse(503, '{"error":"overloaded"}'));
    const err = await expectGeminiError(callGemini("text", { contents: [{ parts: [{ text: "hi" }] }] }, { ...FAST, functionName: "test" }));
    check("throws a classified GeminiError", err instanceof GeminiError, String(err && err.wrongError));
    check("every attempt made: 2 primary (1 retry) + 2 fallback (1 retry)", calls.length === 4, `calls=${calls.length}`);
    check("classified as transient server failure (kind=server)", err.kind === "server", err.kind);
    check("maps to HTTP 502 with retryable=true", err.httpStatus === 502 && err.retryable === true, `${err.httpStatus}/${err.retryable}`);
    check("safe message names no internal details", !/AIza|fake-key|generativelanguage/.test(err.safeMessage), err.safeMessage);
    check("attempt log is complete for diagnostics", err.attempts.length === 4 && err.attempts.every((a) => a.outcome === "http" && a.status === 503), JSON.stringify(err.attempts.length));
  }

  console.log("\nGroup E — scenario 4: invalid API key / permission error\n");
  resetReliability();
  {
    for (const status of [401, 403]) {
      mockFetch(() => statusResponse(status, '{"error":"API key not valid"}'));
      const err = await expectGeminiError(callGemini("text", { contents: [{ parts: [{ text: "hi" }] }] }, { ...FAST, functionName: "test" }));
      check(`HTTP ${status}: throws immediately, exactly ONE call (no retry, no fallback)`, calls.length === 1, `calls=${calls.length}`);
      check(`HTTP ${status}: classified as auth, NOT retryable`, err.kind === "auth" && err.retryable === false, `${err.kind}/${err.retryable}`);
      check(`HTTP ${status}: honest 503 (server misconfiguration, not the visitor's session)`, err.httpStatus === 503, String(err.httpStatus));
      check(`HTTP ${status}: message points the site owner at GEMINI_API_KEY`, /GEMINI_API_KEY/.test(err.safeMessage), err.safeMessage);
    }
  }

  console.log("\nGroup F — scenario 5: unsupported model (404)\n");
  resetReliability();
  {
    // Primary model id retired/typo'd → 404; fallback model still works.
    mockFetch((url) => (url.includes("gemini-3.8-flash") ? statusResponse(404, '{"error":"model not found"}') : ok()));
    const result = await callGemini("text", { contents: [{ parts: [{ text: "hi" }] }] }, { ...FAST, functionName: "test" });
    check("404 on primary is NOT retried (1 call to primary)", calls.filter((c) => c.url.includes("gemini-3.8-flash")).length === 1, `primary calls=${calls.filter((c) => c.url.includes("gemini-3.8-flash")).length}`);
    check("fallback model recovers from a retired primary", result.model === "gemini-3.1-flash-lite" && result.response.status === 200, result.model);

    // Fallback disabled → clean, specific error.
    process.env.GEMINI_TEXT_MODEL_FALLBACK = "";
    mockFetch(() => statusResponse(404, '{"error":"model not found"}'));
    const err = await expectGeminiError(callGemini("text", { contents: [{ parts: [{ text: "hi" }] }] }, { ...FAST, functionName: "test" }));
    check("no fallback configured → single attempt, classified not-found", calls.length === 1 && err.kind === "not-found", `calls=${calls.length} kind=${err.kind}`);
    check("not-found points at the GEMINI_*_MODEL settings", /GEMINI_\*_MODEL/.test(err.safeMessage), err.safeMessage);
    check("not-found is not retryable", err.retryable === false, String(err.retryable));
    delete process.env.GEMINI_TEXT_MODEL_FALLBACK;
  }

  console.log("\nGroup G — scenario 6: timeout and retry exhaustion\n");
  resetReliability();
  {
    // Every attempt hangs until the per-attempt timeout fires.
    mockFetch(hanging);
    const t0 = Date.now();
    const err = await expectGeminiError(
      callGemini("text", { contents: [{ parts: [{ text: "hi" }] }] }, { maxRetries: 1, timeoutMs: 80, totalBudgetMs: 5_000, backoffBaseMs: 1, functionName: "test" })
    );
    const elapsed = Date.now() - t0;
    check("each model got its initial attempt + 1 bounded retry", calls.length === 4, `calls=${calls.length}`);
    check("classified as timeout with HTTP 504, retryable", err.kind === "timeout" && err.httpStatus === 504 && err.retryable === true, `${err.kind}/${err.httpStatus}`);
    check("total time bounded (4×80ms attempts + tiny backoffs)", elapsed < 1_500, `${elapsed}ms`);
  }

  console.log("\nGroup H — caller abort propagation\n");
  resetReliability();
  {
    mockFetch(hanging);
    const controller = new AbortController();
    setTimeout(() => controller.abort(), 60);
    let threw = null;
    try {
      await callGemini("text", { contents: [{ parts: [{ text: "hi" }] }] }, { signal: controller.signal, maxRetries: 5, timeoutMs: 10_000, totalBudgetMs: 10_000, backoffBaseMs: 1 });
    } catch (err) {
      threw = err;
    }
    check("caller abort rethrown as AbortError (NOT swallowed into GeminiError)", threw?.name === "AbortError" && !(threw instanceof GeminiError), `${threw?.name}/${threw?.constructor?.name}`);

    // Caller aborts while we're sleeping between attempts.
    mockFetch((url, init) =>
      init?.signal?.aborted
        ? Promise.reject(new DOMException("The operation was aborted", "AbortError"))
        : statusResponse(503, "{}")
    );
    const c2 = new AbortController();
    setTimeout(() => c2.abort(), 30);
    let threw2 = null;
    try {
      await callGemini("text", { contents: [{ parts: [{ text: "hi" }] }] }, { signal: c2.signal, maxRetries: 5, timeoutMs: 2_000, totalBudgetMs: 10_000, backoffBaseMs: 200 });
    } catch (err) {
      threw2 = err;
    }
    check("abort during backoff stops the retry loop (no new attempt after abort)", threw2?.name === "AbortError", `${threw2?.name}`);
  }

  console.log("\nGroup I — rate-limit-aware behaviour (429 + Retry-After)\n");
  resetReliability();
  {
    // Retry-After: 0 → immediate retry is allowed.
    let n = 0;
    mockFetch(() => (n++ === 0 ? statusResponse(429, "{}", { "retry-after": "0" }) : ok()));
    const result = await callGemini("text", { contents: [{ parts: [{ text: "hi" }] }] }, { ...FAST, functionName: "test" });
    check("429 with Retry-After: 0 retries and succeeds", result.response.status === 200 && calls.length === 2, `calls=${calls.length}`);

    // Retry-After is honoured with a real (short) wait.
    let m = 0;
    mockFetch(() => (m++ === 0 ? statusResponse(429, "{}", { "retry-after": "1" }) : ok()));
    const t0 = Date.now();
    await callGemini("text", { contents: [{ parts: [{ text: "hi" }] }] }, { ...FAST, functionName: "test" });
    const waited = Date.now() - t0;
    check("Retry-After: 1 waits ~1s before the retry (honoured, capped)", waited >= 900 && waited < 2_500, `${waited}ms`);

    // A huge Retry-After inside a small budget must give up, not sleep forever.
    mockFetch(() => statusResponse(429, "{}", { "retry-after": "60" }));
    const t1 = Date.now();
    const err = await expectGeminiError(
      callGemini("text", { contents: [{ parts: [{ text: "hi" }] }] }, { maxRetries: 2, timeoutMs: 500, totalBudgetMs: 900, backoffBaseMs: 1, functionName: "test" })
    );
    const elapsed = Date.now() - t1;
    check("huge Retry-After is capped by the wall-clock budget (no 60s sleep)", elapsed < 2_000, `${elapsed}ms`);
    check("rate-limit exhaustion maps to HTTP 429, retryable", err.kind === "rate-limit" && err.httpStatus === 429 && err.retryable === true, `${err.kind}/${err.httpStatus}`);
  }

  console.log("\nGroup J — wall-clock budget bounds everything\n");
  resetReliability();
  {
    mockFetch(() => statusResponse(503, "{}"));
    const t0 = Date.now();
    const err = await expectGeminiError(
      callGemini("text", { contents: [{ parts: [{ text: "hi" }] }] }, { maxRetries: 5, timeoutMs: 2_000, totalBudgetMs: 1_200, backoffBaseMs: 300, functionName: "test" })
    );
    const elapsed = Date.now() - t0;
    check("budget stops the loop before all 12 possible attempts (≤6 made)", calls.length <= 6, `calls=${calls.length}`);
    check("never exceeds budget by more than in-flight slack", elapsed < 2_000, `${elapsed}ms`);
    check("still reports an honest classified error", err instanceof GeminiError, String(err && err.wrongError));
  }

  console.log("\nGroup K — sanitisation of error details\n");
  resetReliability();
  {
    const leaky = JSON.stringify({
      error: { message: "key " + "AIzaSyD-" + "FakeKeyMaterial0123456789abcdefg rejected; Bearer ya29.a0FakeTokenValue1234567890 expired", status: "INVALID_ARGUMENT" },
    });
    mockFetch(() => statusResponse(500, leaky));
    const err = await expectGeminiError(callGemini("text", { contents: [{ parts: [{ text: "hi" }] }] }, { maxRetries: 0, timeoutMs: 1_000, totalBudgetMs: 2_000, functionName: "test" }));
    check("API-key-shaped strings redacted from detail", !/AIzaSyD-FakeKeyMaterial/.test(err.detail) && err.detail.includes("[redacted]"), err.detail);
    check("bearer tokens redacted from detail", !/ya29\.a0FakeTokenValue/.test(err.detail), err.detail);
    check("safe message never contains key material", !/AIza|ya29\./.test(err.safeMessage), err.safeMessage);
    check("standalone sanitizeDetail redacts key= query params", !/key=secret/.test(sanitizeDetail("https://x.example/?key=secret1234567890&y=1")));
  }

  console.log("\nGroup L — 400 bad request falls back once, never retried\n");
  resetReliability();
  {
    mockFetch((url) => (url.includes("gemini-3.8-flash") ? statusResponse(400, '{"error":"bad param"}') : ok()));
    const result = await callGemini("text", { contents: [{ parts: [{ text: "hi" }] }] }, { ...FAST, functionName: "test" });
    check("400 on primary → exactly one primary call, fallback succeeds", calls.filter((c) => c.url.includes("gemini-3.8-flash")).length === 1 && result.model === "gemini-3.1-flash-lite", `calls=${calls.length} model=${result.model}`);

    mockFetch(() => statusResponse(400, '{"error":"bad param"}'));
    const err = await expectGeminiError(callGemini("text", { contents: [{ parts: [{ text: "hi" }] }] }, { ...FAST, functionName: "test" }));
    check("400 on BOTH models → bad-request, 2 calls total, not retryable", calls.length === 2 && err.kind === "bad-request" && err.retryable === false, `calls=${calls.length} kind=${err.kind}`);
  }

  console.log("\nGroup M — unconfigured server\n");
  resetReliability();
  {
    delete process.env.GEMINI_API_KEY;
    mockFetch(() => ok());
    const err = await expectGeminiError(callGemini("text", { contents: [{ parts: [{ text: "hi" }] }] }, FAST));
    check("missing GEMINI_API_KEY → auth-classified 503 before any fetch", calls.length === 0 && err.kind === "auth" && err.httpStatus === 503, `calls=${calls.length} ${err.kind}/${err.httpStatus}`);
    check("message explains the missing env var", /GEMINI_API_KEY/.test(err.safeMessage), err.safeMessage);
    process.env.GEMINI_API_KEY = "fake-key-for-tests-only";
  }

  // --- summary ---------------------------------------------------------------
  globalThis.fetch = realFetch;
  console.log(`\n============================================================`);
  console.log(`Gemini fallback engine: ${passed} passed, ${failed} failed`);
  if (failed) {
    console.log("Failed checks:\n  - " + failures.join("\n  - "));
    process.exit(1);
  }
}

try {
  await main();
} finally {
  globalThis.fetch = realFetch;
  // restore the environment exactly as we found it
  for (const k of Object.keys(process.env)) if (!(k in savedEnv)) delete process.env[k];
  for (const [k, v] of Object.entries(savedEnv)) process.env[k] = v;
}
