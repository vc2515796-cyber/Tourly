/** TEST-ONLY firebase-admin/app mock (see smoke-auth-loader.mjs). */
export function getApps() {
  return [];
}
export function initializeApp(options) {
  return { name: "__smoke__", options };
}
export function cert(credential) {
  return credential;
}
