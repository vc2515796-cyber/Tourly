/**
 * TEST-ONLY firebase-admin/auth mock (see smoke-auth-loader.mjs).
 *
 * verifyIdToken resolves for two well-known test tokens (alice / bob) and
 * throws an auth/argument-error-shaped error for everything else — exactly
 * the contract the real SDK exposes. The bundled function's own
 * project-mismatch diagnostic then decodes rejected JWTs' `aud`, which is
 * how the harness exercises the cross-project 401 path.
 */
const KNOWN_TOKENS = new Map([
  ["test-id-token-alice", { uid: "uid-alice", email: "alice@example.com" }],
  ["test-id-token-bob", { uid: "uid-bob", email: "bob@example.com" }],
]);

export function getAuth() {
  return {
    async verifyIdToken(token) {
      if (KNOWN_TOKENS.has(token)) return KNOWN_TOKENS.get(token);
      const err = new Error("Mock verifyIdToken: invalid or expired token");
      err.errorInfo = { code: "auth/argument-error" };
      throw err;
    },
  };
}
