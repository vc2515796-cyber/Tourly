/**
 * TEST-ONLY in-memory replacement for @netlify/blobs (see
 * smoke-auth-loader.mjs). Implements exactly the Store surface the
 * functions use: get/set/setJSON/delete/list, plus a `backing` Map the
 * harness can inspect to assert what was actually persisted.
 */
const backing = new Map(); // storeName -> Map(key -> { text, json })

class MemoryStore {
  constructor(name) {
    this.name = name;
    if (!backing.has(name)) backing.set(name, new Map());
  }
  get map() {
    return backing.get(this.name);
  }
  async get(key, opts) {
    const v = this.map.get(key);
    if (v === undefined) return null;
    return opts?.type === "json" ? v.json : v.text;
  }
  async set(key, value) {
    this.map.set(key, { text: value, json: value });
  }
  async setJSON(key, value) {
    this.map.set(key, { text: JSON.stringify(value), json: value });
  }
  async delete(key) {
    this.map.delete(key);
  }
  async list({ prefix } = {}) {
    const keys = [...this.map.keys()].filter((key) => (prefix ? key.startsWith(prefix) : true));
    return { blobs: keys.map((key) => ({ key })) };
  }
}

export function getStore({ name }) {
  return new MemoryStore(name);
}

export { backing };
