// Fails the build if something that looks like a secret ended up in code that
// ships to the browser. Firebase web config is public by design and is read
// from VITE_FIREBASE_* env vars (never hard-coded), so a literal key in src/
// is a mistake. Server secrets (GEMINI_API_KEY) belong only in
// netlify/functions and Netlify's environment settings.
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, extname } from "node:path";

const ROOTS = ["src", "public", "index.html"];
const SKIP_EXT = new Set([".png", ".jpg", ".jpeg", ".webp", ".ico", ".gif", ".woff", ".woff2"]);
const PATTERNS = [
  [/AIza[0-9A-Za-z_\-]{35}/, "Google API key literal"],
  [/sk-[A-Za-z0-9]{24,}/, "secret-key style token"],
  [/-----BEGIN [A-Z ]*PRIVATE KEY-----/, "private key block"],
  [/GEMINI_API_KEY/, "reference to the server-only Gemini key"],
  [/import\.meta\.env\.VITE_[A-Z0-9_]*(SECRET|PRIVATE|PASSWORD|GEMINI)/, "secret-looking VITE_ variable (would be public)"],
];

function* walk(path) {
  const st = statSync(path);
  if (st.isFile()) { yield path; return; }
  for (const name of readdirSync(path)) yield* walk(join(path, name));
}

let problems = 0;
for (const root of ROOTS) {
  for (const file of walk(root)) {
    if (SKIP_EXT.has(extname(file).toLowerCase())) continue;
    const text = readFileSync(file, "utf8");
    for (const [re, label] of PATTERNS) {
      if (re.test(text)) {
        console.error(`✖ ${file}: ${label}`);
        problems++;
      }
    }
  }
}

if (problems) {
  console.error(`\nFound ${problems} possible frontend secret(s). Move them server-side (netlify/functions) or into Netlify env vars.`);
  process.exit(1);
}
console.log("✔ No frontend secrets found in src/, public/, or index.html");
