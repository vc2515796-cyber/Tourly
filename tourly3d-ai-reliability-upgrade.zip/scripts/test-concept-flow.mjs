/**
 * Hermetic Stage D (AI upgrade) flow tests — run in a CHILD process by
 * scripts/smoke-functions.mjs (npm run test:smoke).
 *
 * Same isolation pattern as test-leads-flow / test-analytics-flow (loader
 * swaps @netlify/blobs for an in-memory store and firebase-admin for a
 * deterministic alice/bob verifier; Gemini is a mocked fetch):
 *
 *   analyze-floorplan : auth (401/403 paths), validation (415/413/400),
 *                       malformed model JSON → honest 502, invalid geometry
 *                       → honest 502, valid analysis → 200 (clamped +
 *                       schema-validated), content-hash cache (hit skips the
 *                       AI call AND the quota), per-user daily quota (429),
 *                       usage recorded in waypoint-ai-usage
 *   interior-concept  : 401 unauthenticated, 415 bad style, 503 unconfigured
 *                       key, 200 with the illustrative note
 *   lead-insights     : 401, 404 unknown lead, 403 cross-account, 200 with
 *                       summaries/next-actions, buyer's phone NOT in prompt
 *   tour-assistant    : answers are scoped to the REQUESTED tour's content
 *                       only (a second tour's data never reaches the prompt)
 *   generate-marketing: daily quota for anonymous (per-IP) callers, and the
 *                       new highlights/buyerSummary fields validate through
 *
 * NOT proven here: real Gemini behaviour, real Blobs persistence, browser
 * canvas interactions (documented in VERIFICATION.md).
 */
import { register } from "node:module";
import { pathToFileURL, fileURLToPath } from "node:url";

register("./smoke-auth-loader.mjs", import.meta.url);

const BASE = fileURLToPath(new URL("../node_modules/.tmp/fntest", import.meta.url));
const ORIGIN = "https://tourly.example.netlify.app";

let passed = 0;
let failed = 0;
function check(name, condition, detail) {
  if (condition) {
    passed++;
    console.log(`  PASS  ${name}`);
  } else {
    failed++;
    console.log(`  FAIL  ${name} — ${detail}`);
  }
}
const jsonOf = async (r) => {
  try {
    return await r.clone().json();
  } catch {
    return null;
  }
};

const VALID_SA_KEY = JSON.stringify({
  project_id: "tourly-test",
  client_email: "smoke@test.iam.gserviceaccount.com",
  private_key: "not-a-real-key",
});

const post = (path, body, token, ip = "9.9.9.9") =>
  new Request(`${ORIGIN}${path}`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-nf-client-connection-ip": ip,
      ...(token ? { authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify(body),
  });

// A server-validated-shaped analysis the mocked Gemini returns.
const geminiAnalysis = (over = {}) => ({
  schemaVersion: 1,
  roomType: "Living Room",
  confidence: 0.8,
  roomOutline: [
    { x: 0.1, y: 0.1 }, { x: 0.9, y: 0.1 }, { x: 0.9, y: 0.8 }, { x: 0.1, y: 0.8 },
  ],
  walls: [{ a: { x: 0.1, y: 0.1 }, b: { x: 0.9, y: 0.1 }, certain: true }],
  openings: [{ kind: "door", x: 0.5, y: 0.8, certain: true }],
  furniture: [{ kind: "sofa", x: 0.3, y: 0.2, certain: false }],
  uncertaintyNotes: ["walls behind the camera are inferred"],
  ...over,
});

const geminiOk = (payload) =>
  new Response(
    JSON.stringify({
      candidates: [{ content: { parts: [{ text: JSON.stringify(payload) }] } }],
    }),
    { status: 200, headers: { "content-type": "application/json" } }
  );

async function main() {
  const analyzeFloorPlan = (await import(pathToFileURL(`${BASE}/analyze-floorplan.mjs`).href)).default;
  const interiorConcept = (await import(pathToFileURL(`${BASE}/interior-concept.mjs`).href)).default;
  const leadInsights = (await import(pathToFileURL(`${BASE}/lead-insights.mjs`).href)).default;
  const tourAssistant = (await import(pathToFileURL(`${BASE}/tour-assistant.mjs`).href)).default;
  const generateMarketing = (await import(pathToFileURL(`${BASE}/generate-marketing.mjs`).href)).default;
  const { backing, getStore } = await import("@netlify/blobs");
  // Materialise the stores the seeds below write to (the mock creates each
  // store's backing Map lazily on first getStore call).
  void getStore({ name: "waypoint-leads" });
  void getStore({ name: "waypoint-tours" });
  void getStore({ name: "waypoint-ai-usage" });

  // ---- GROUP A: analyze-floorplan — auth + validation -----------------------
  console.log("Group A — analyze-floorplan auth & validation\n");

  process.env.FIREBASE_SERVICE_ACCOUNT_KEY = VALID_SA_KEY;
  process.env.GEMINI_API_KEY = "fake-key-for-validation-only";
  delete process.env.GEMINI_MAX_RETRIES;
  delete process.env.GEMINI_BACKOFF_BASE_MS;

  const realFetch = globalThis.fetch;
  let geminiCalls = 0;
  let lastPrompt = "";
  const mockGemini = (fn) => {
    globalThis.fetch = (url, init) => {
      geminiCalls++;
      try {
        lastPrompt = JSON.parse(init?.body ?? "{}")?.contents?.[0]?.parts?.[0]?.text ?? "";
      } catch {}
      return fn(url, init);
    };
  };

  const ALICE_IP = "10.1.1.1"; // distinct IP so the per-IP burst limit (10/min)
  const CAROL_IP = "10.3.3.3";  // fresh IP for cache-regression checks (same
                                 // burst window as alice would 429 on the 11th call)
  const BOB_IP = "10.2.2.2";   // doesn't fire before the QUOTA under test
  const r405 = await analyzeFloorPlan(new Request(`${ORIGIN}/api/analyze-floorplan`));
  check("GET rejected 405 JSON", r405.status === 405, `status=${r405.status}`);

  const savedKey = process.env.FIREBASE_SERVICE_ACCOUNT_KEY;
  delete process.env.FIREBASE_SERVICE_ACCOUNT_KEY;
  const r503 = await analyzeFloorPlan(post("/api/analyze-floorplan", {}, null, ALICE_IP));
  check("unconfigured deployment → honest 503 naming the env var", r503.status === 503 && /FIREBASE_SERVICE_ACCOUNT_KEY/.test(String((await jsonOf(r503))?.error)), `status=${r503.status}`);
  process.env.FIREBASE_SERVICE_ACCOUNT_KEY = savedKey;

  const r401a = await analyzeFloorPlan(post("/api/analyze-floorplan", { imageBase64: "AAAA", mimeType: "image/jpeg" }, null, ALICE_IP));
  check("no token → 401 (agent feature, sign-in required)", r401a.status === 401, `status=${r401a.status}`);
  const r401b = await analyzeFloorPlan(post("/api/analyze-floorplan", { imageBase64: "AAAA", mimeType: "image/jpeg" }, "not-a-real-token", ALICE_IP));
  check("invalid token → 401", r401b.status === 401, `status=${r401b.status}`);

  const alice = "test-id-token-alice";
  const r415 = await analyzeFloorPlan(post("/api/analyze-floorplan", { imageBase64: "AAAA", mimeType: "image/gif" }, alice, ALICE_IP));
  check("non-JPEG/PNG panorama → 415", r415.status === 415, `status=${r415.status}`);
  const r413 = await analyzeFloorPlan(post("/api/analyze-floorplan", { imageBase64: "A".repeat(4_000_001), mimeType: "image/jpeg" }, alice, ALICE_IP));
  check("oversized payload → 413", r413.status === 413, `status=${r413.status}`);
  const r400 = await analyzeFloorPlan(post("/api/analyze-floorplan", {}, alice, ALICE_IP));
  check("missing fields → 400", r400.status === 400, `status=${r400.status}`);

  // ---- GROUP B: analyze-floorplan — honest failures --------------------------
  console.log("\nGroup B — analyze-floorplan honest failures (never a fabricated plan)\n");

  mockGemini(() => geminiOk({ candidates: [{ content: { parts: [{ text: "I cannot answer that." }] } }] }));
  let r = await analyzeFloorPlan(post("/api/analyze-floorplan", { imageBase64: "QkFEMUpTT04x", mimeType: "image/jpeg" }, alice, ALICE_IP));
  let b = await jsonOf(r);
  check("malformed model JSON → honest 502, no layout invented", r.status === 502 && !b?.roomOutline, `status=${r.status}`);

  mockGemini(() => geminiOk({ roomType: "X", roomOutline: [{ x: 0.1, y: 0.1 }, { x: 0.9, y: 0.9 }] }));
  r = await analyzeFloorPlan(post("/api/analyze-floorplan", { imageBase64: "QkFEMUpTT04y", mimeType: "image/jpeg" }, alice, ALICE_IP));
  check("invalid geometry (outline < 3 points) → honest 502", r.status === 502, `status=${r.status}`);

  // ---- GROUP C: analyze-floorplan — success, cache, quota, usage -------------
  console.log("\nGroup C — analysis success, content-hash cache, quota, usage tracking\n");

  // Out-of-range + unknown-kind garbage that validation must CLAMP/coerce.
  const messy = geminiAnalysis({
    confidence: 4.2,
    roomOutline: [
      { x: -0.5, y: 0.1 }, { x: 1.7, y: 0.1 }, { x: 0.9, y: 0.8 }, { x: 0.1, y: 0.8 },
    ],
    furniture: [
      { kind: "sofa", x: 0.3, y: 0.2, certain: false },
      { kind: "teleporter", x: 0.5, y: 0.5, certain: true },
    ],
  });
  mockGemini(() => geminiOk(messy));
  r = await analyzeFloorPlan(post("/api/analyze-floorplan", { imageBase64: "SU1BR0Ux", mimeType: "image/jpeg", crops: [{ imageBase64: "AAAA", label: "front" }] }, alice, ALICE_IP));
  b = await jsonOf(r);
  check("valid analysis → 200 with schemaVersion + model + disclaimer", r.status === 200 && b?.schemaVersion === 1 && b?.model === "gemini-3.8-flash" && b?.disclaimer === "CONCEPTUAL FLOOR PLAN — NOT TO SCALE", `status=${r.status}`);
  check("out-of-range coordinates clamped into 0..1", b?.roomOutline?.every((p) => p.x >= 0 && p.x <= 1 && p.y >= 0 && p.y <= 1), JSON.stringify(b?.roomOutline));
  check("confidence clamped into 0..1", b?.confidence === 1, `confidence=${b?.confidence}`);
  check("unknown furniture kind coerced to 'other'", b?.furniture?.some((f) => f.kind === "other"), JSON.stringify(b?.furniture?.map((f) => f.kind)));
  check("uncertainty flags preserved", b?.furniture?.[0]?.certain === false && b?.furniture?.[0]?.kind === "sofa");
  check("crops are labelled as views of the same panorama in the prompt", /same panorama/i.test(lastPrompt), lastPrompt.slice(0, 200));

  // Cache: same image + same crops again → cached:true, and the AI was NOT
  // called again. (The cache key includes the crops — a correctness fix —
  // so the replay must send IDENTICAL inputs.)
  const callsBefore = geminiCalls;
  r = await analyzeFloorPlan(post("/api/analyze-floorplan", { imageBase64: "SU1BR0Ux", mimeType: "image/jpeg", crops: [{ imageBase64: "AAAA", label: "front" }] }, alice, ALICE_IP));
  b = await jsonOf(r);
  check("same panorama + same crops → cached:true (no new AI call)", r.status === 200 && b?.cached === true && geminiCalls === callsBefore, `cached=${b?.cached} calls=${geminiCalls - callsBefore}`);

  // Same panorama but a DIFFERENT crop set is a different input — it must be
  // a cache MISS (never reuse a result generated from different views).
  const callsBefore2 = geminiCalls;
  r = await analyzeFloorPlan(post("/api/analyze-floorplan", { imageBase64: "SU1BR0Ux", mimeType: "image/jpeg", crops: [{ imageBase64: "BBBB", label: "back" }] }, alice, CAROL_IP));
  b = await jsonOf(r);
  check("same panorama, different crops → cache miss (fresh AI call)", r.status === 200 && b?.cached === false && geminiCalls === callsBefore2 + 1, `cached=${b?.cached} calls=${geminiCalls - callsBefore2}`);

  // Quota (fresh scope: bob) — env-driven, default unlimited-ish → set to 2.
  process.env.AI_DAILY_QUOTA_ANALYZE_FLOORPLAN = "2";
  const bob = "test-id-token-bob";
  mockGemini(() => geminiOk(geminiAnalysis()));
  const rb1 = await analyzeFloorPlan(post("/api/analyze-floorplan", { imageBase64: "Qk9CSU1HMQ==", mimeType: "image/jpeg" }, bob, BOB_IP));
  const rb2 = await analyzeFloorPlan(post("/api/analyze-floorplan", { imageBase64: "Qk9CSU1HMg==", mimeType: "image/jpeg" }, bob, BOB_IP));
  const rb3 = await analyzeFloorPlan(post("/api/analyze-floorplan", { imageBase64: "Qk9CSU1HMw==", mimeType: "image/jpeg" }, bob, BOB_IP));
  const rb3b = await jsonOf(rb3);
  check("quota 2/day: first two calls pass", rb1.status === 200 && rb2.status === 200, `${rb1.status}/${rb2.status}`);
  check("third call → clear 429 with quota info", rb3.status === 429 && rb3b?.quota?.limit === 2 && rb3b?.quota?.remaining === 0, `status=${rb3.status} body=${JSON.stringify(rb3b)}`);
  const rb4 = await analyzeFloorPlan(post("/api/analyze-floorplan", { imageBase64: "Qk9CSU1HMg==", mimeType: "image/jpeg" }, bob, BOB_IP));
  check("cache hit still succeeds after quota exhaustion (no quota consumed)", rb4.status === 200 && (await jsonOf(rb4))?.cached === true, `status=${rb4.status}`);
  delete process.env.AI_DAILY_QUOTA_ANALYZE_FLOORPLAN;

  // Usage recorded: aggregate counters per user per day, no personal data.
  const usageMap = backing.get("waypoint-ai-usage");
  const usageKeys = [...usageMap.keys()].filter((k) => k.startsWith("usage:"));
  const aliceUsageKey = usageKeys.find((k) => k.includes("uid-alice"));
  check("usage doc exists for alice", Boolean(aliceUsageKey), usageKeys.join(","));
  if (aliceUsageKey) {
    const doc = usageMap.get(aliceUsageKey).json;
    const feature = doc?.features?.["analyze-floorplan"];
    check(
      "usage tracked: count/ok/models recorded, NO image data or prompts stored",
      feature?.count >= 3 && feature?.ok >= 3 && feature?.models?.["gemini-3.8-flash"] >= 3 && !JSON.stringify(doc).includes("SU1BR0Ux") && !JSON.stringify(doc).includes("Living Room"),
      JSON.stringify(feature)
    );
  }

  // ---- GROUP D: interior-concept ----------------------------------------------
  console.log("\nGroup D — interior-concept (optional, honest states)\n");

  const ri401 = await interiorConcept(post("/api/interior-concept", { imageBase64: "AAAA", mimeType: "image/jpeg", style: "modern" }, null, "10.3.3.3"));
  check("no token → 401", ri401.status === 401, `status=${ri401.status}`);
  const ri415 = await interiorConcept(post("/api/interior-concept", { imageBase64: "AAAA", mimeType: "image/jpeg", style: "baroque" }, alice, "10.3.3.3"));
  check("unsupported style → 415 listing the whitelist", ri415.status === 415, `status=${ri415.status}`);

  const savedGeminiKey = process.env.GEMINI_API_KEY;
  delete process.env.GEMINI_API_KEY;
  const ri503 = await interiorConcept(post("/api/interior-concept", { imageBase64: "AAAA", mimeType: "image/jpeg", style: "modern" }, alice, "10.3.3.3"));
  check("unconfigured key → honest 503 (never a fake image)", ri503.status === 503, `status=${ri503.status}`);
  process.env.GEMINI_API_KEY = savedGeminiKey;

  mockGemini(() =>
    new Response(
      JSON.stringify({
        candidates: [{ content: { parts: [{ inlineData: { mimeType: "image/png", data: "aV9hbV9hbl9pbGx1c3RyYXRpb24=" } }] } }],
      }),
      { status: 200, headers: { "content-type": "application/json" } }
    )
  );
  const riOk = await interiorConcept(post("/api/interior-concept", { imageBase64: "AAAA", mimeType: "image/jpeg", style: "minimal" }, alice, "10.3.3.3"));
  const riOkBody = await jsonOf(riOk);
  check(
    "valid request → 200 image + illustrative note",
    riOk.status === 200 && riOkBody?.imageBase64?.length > 10 && /illustrative only/i.test(String(riOkBody?.note)),
    `status=${riOk.status}`
  );

  // ---- GROUP E: lead-insights (Phase 7) ----------------------------------------
  console.log("\nGroup E — lead-insights (auth, ownership, privacy)\n");

  // Seed a lead owned by alice (same store layout as _leads.mts).
  const leadsStore = backing.get("waypoint-leads");
  const now = Date.now();
  leadsStore.set("lead:uid-alice:lead-1", {
    text: JSON.stringify({
      id: "lead-1",
      tourId: "tour-alpha",
      tourName: "Alpha 2BHK",
      stopTitle: "Living room",
      name: "Ravi Buyer",
      phone: "+919999999999",
      email: "ravi@example.com",
      message: "Is this 2BHK available for immediate move-in? I need 2 parking spots.",
      consent: true,
      stage: "new",
      ownerUid: "uid-alice",
      createdAt: now,
      updatedAt: now,
      activities: [],
    }),
    json: {
      id: "lead-1",
      tourId: "tour-alpha",
      tourName: "Alpha 2BHK",
      stopTitle: "Living room",
      name: "Ravi Buyer",
      phone: "+919999999999",
      email: "ravi@example.com",
      message: "Is this 2BHK available for immediate move-in? I need 2 parking spots.",
      consent: true,
      stage: "new",
      ownerUid: "uid-alice",
      createdAt: now,
      updatedAt: now,
      activities: [],
    },
  });
  const toursStore = backing.get("waypoint-tours");
  const setTourJson = (key, value) => toursStore.set(key, { text: JSON.stringify(value), json: value });
  setTourJson("tour-alpha", { name: "Alpha 2BHK", stops: [{ title: "Living room", note: "spacious" }] });

  const rl401 = await leadInsights(post("/api/lead-insights", { leadId: "lead-1" }, null, "10.4.4.4"));
  check("no token → 401", rl401.status === 401, `status=${rl401.status}`);
  const rl404 = await leadInsights(post("/api/lead-insights", { leadId: "nope" }, alice, "10.4.4.4"));
  check("unknown lead → 404", rl404.status === 404, `status=${rl404.status}`);
  const rl403 = await leadInsights(post("/api/lead-insights", { leadId: "lead-1" }, "test-id-token-bob", "10.4.4.4"));
  const rl403b = await jsonOf(rl403);
  check(
    "bob cannot read alice's lead → 404 via owner-scoped keys (no existence oracle, no data leaked)",
    rl403.status === 404 && !rl403b?.enquirySummary,
    `status=${rl403.status} body=${JSON.stringify(rl403b)?.slice(0, 120)}`
  );

  mockGemini(() =>
    geminiOk({
      enquirySummary: "Buyer asked about immediate move-in and parking.",
      buyerRequirements: ["Immediate move-in", "2 parking spots"],
      suggestedNextActions: ["Call the buyer to confirm availability", "Share parking photos"],
    })
  );
  const rlOk = await leadInsights(post("/api/lead-insights", { leadId: "lead-1" }, alice, "10.4.4.4"));
  const rlOkBody = await jsonOf(rlOk);
  check(
    "valid call → summaries + next actions, all marked AI-generated",
    rlOk.status === 200 && rlOkBody?.aiGenerated === true && Array.isArray(rlOkBody?.buyerRequirements) && Array.isArray(rlOkBody?.suggestedNextActions) && rlOkBody?.stage === "new",
    `status=${rlOk.status}`
  );
  check(
    "buyer's phone/email are NOT sent to the model (privacy)",
    !lastPrompt.includes("9999999999") && !lastPrompt.includes("ravi@example.com") && lastPrompt.includes("parking"),
    lastPrompt.slice(0, 300)
  );

  // ---- GROUP F: tour-assistant scoping (Phase 8) --------------------------------
  console.log("\nGroup F — tour Q&A uses only the requested property's data\n");

  // tour-assistant is STATELESS by design: it answers from the tour content
  // the caller supplies (the public viewer sends only the tour it is
  // viewing) and never reads the tours store — so unrelated properties'
  // data cannot leak into a prompt. Prove both halves of that contract.
  setTourJson("tour-beta", { name: "Beta Villa", stops: [{ title: "Secret Beta Vault", note: "confidential" }] });
  setTourJson("owner:tour-beta", { ownerUid: "uid-bob" });
  setTourJson("owner:tour-alpha", { ownerUid: "uid-alice" });

  mockGemini(() => geminiOk({ answer: "Yes, it is available." }));
  const rq = await tourAssistant(
    post("/api/tour-assistant", {
      question: "Is it available now?",
      tourName: "Alpha 2BHK",
      subtitle: "Bright and airy",
      stops: [{ title: "Living room", note: "spacious" }],
    })
  );
  check("assistant answers for the requested tour", rq.status === 200, `status=${rq.status}`);
  check(
    "prompt contains exactly the caller's tour content (Alpha), never Beta's store data",
    lastPrompt.includes("Alpha 2BHK") && lastPrompt.includes("Living room") && !lastPrompt.includes("Beta Villa") && !lastPrompt.includes("Secret Beta Vault"),
    lastPrompt.slice(0, 300)
  );
  const rqBeta = await tourAssistant(
    post("/api/tour-assistant", {
      question: "Tell me about the vault.",
      tourName: "Beta Villa",
      stops: [{ title: "Secret Beta Vault", note: "confidential" }],
    })
  );
  check(
    "a different tour's call contains ITS data only (per-call isolation)",
    rqBeta.status === 200 && lastPrompt.includes("Beta Villa") && !lastPrompt.includes("Alpha 2BHK"),
    lastPrompt.slice(0, 300)
  );

  // ---- GROUP G: generate-marketing quota + new fields (Phase 4/9) ---------------
  console.log("\nGroup G — copywriter quota + highlights/buyerSummary\n");

  process.env.AI_DAILY_QUOTA_GENERATE_MARKETING = "1";
  mockGemini(() =>
    geminiOk({
      title: "Sunlit 2BHK near Metro",
      headline: "Bright 2BHK, walk to Metro",
      shortDescription: "A bright 2BHK tour.",
      longDescription: "A bright 2BHK with a wide balcony.",
      instagramCaption: "Sunlit vibes #2bhk",
      whatsappMessage: "See this 2BHK: {tourLink}",
      seoTitle: "2BHK Tour",
      seoDescription: "Walk through a bright 2BHK.",
      tourIntro: "Welcome inside.",
      highlights: ["Bright living room", "Wide balcony", "", "Near metro (owner-stated)"],
      buyerSummary: "A bright 2BHK for metro commuters.",
    })
  );
  const marketingBody = {
    tourName: "My 2BHK",
    subtitle: "",
    stops: [{ title: "Living room" }],
    facts: { propertyType: "2BHK apartment", price: "₹85 lakh", language: "en", channel: "WhatsApp" },
  };
  const rm1 = await generateMarketing(post("/api/generate-marketing", marketingBody, null, "10.5.5.5")); // anonymous → IP scope
  const rm1b = await jsonOf(rm1);
  check("first anonymous copywriter call passes", rm1.status === 200, `status=${rm1.status}`);
  check(
    "highlights validated (non-strings dropped, capped) + buyerSummary present",
    Array.isArray(rm1b?.highlights) && rm1b.highlights.length === 3 && typeof rm1b?.buyerSummary === "string",
    JSON.stringify(rm1b?.highlights)
  );
  const rm2 = await generateMarketing(post("/api/generate-marketing", marketingBody, null, "10.5.5.5"));
  const rm2b = await jsonOf(rm2);
  check(
    "identical copy request → cache hit (free, no quota consumed) even at quota 1",
    rm2.status === 200 && rm2b?.cached === true,
    `status=${rm2.status} cached=${rm2b?.cached}`
  );
  const rm3 = await generateMarketing(
    post(
      "/api/generate-marketing",
      { ...marketingBody, facts: { ...marketingBody.facts, price: "₹90 lakh" } }, // different facts → different cache key
      null,
      "10.5.5.5"
    )
  );
  const rm3b = await jsonOf(rm3);
  check("different facts with quota 1 → honest 429 with quota info", rm3.status === 429 && rm3b?.quota?.limit === 1, `status=${rm3.status}`);
  delete process.env.AI_DAILY_QUOTA_GENERATE_MARKETING;

  globalThis.fetch = realFetch;
  console.log(`\nCONCEPT_SUMMARY: ${passed} ${failed}`);
  if (failed) process.exit(1);
}

main().catch((err) => {
  console.error("CONCEPT FLOW RUNNER ERROR:", err);
  console.log(`\nCONCEPT_SUMMARY: ${passed} ${failed + 1}`);
  process.exit(1);
});
