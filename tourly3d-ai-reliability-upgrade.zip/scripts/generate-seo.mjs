// Writes public/robots.txt and public/sitemap.xml at build time using the
// site's real URL (Netlify's `URL` env var, or VITE_SITE_URL for a custom
// domain). Only public marketing/legal pages are listed — published tours are
// unlisted links and are deliberately NOT in the sitemap.
import { writeFileSync } from "node:fs";

const base = (process.env.VITE_SITE_URL || process.env.URL || "").replace(/\/$/, "");
const disallow = ["/dashboard", "/editor/", "/analytics", "/login"];

const robots = [
  "User-agent: *",
  "Allow: /",
  ...disallow.map((p) => `Disallow: ${p}`),
  "",
  // Explicit allow for OpenAI's crawler — sites that block it are excluded
  // from ChatGPT Search answers entirely (it doesn't fall back to treating
  // them as just-a-link). The wildcard block above already allows it, but
  // naming it removes any ambiguity for a bot that looks for its own rule.
  "User-agent: OAI-SearchBot",
  "Allow: /",
  ...(base ? ["", `Sitemap: ${base}/sitemap.xml`] : []),
  "",
].join("\n");
writeFileSync("public/robots.txt", robots);

if (!base) {
  console.warn("! No URL/VITE_SITE_URL at build time — wrote robots.txt without a Sitemap line and skipped sitemap.xml.");
} else {
  const pages = ["/", "/privacy", "/terms", "/notices", "/founder"];
  const today = new Date().toISOString().slice(0, 10);
  const xml =
    `<?xml version="1.0" encoding="UTF-8"?>\n` +
    `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n` +
    pages
      .map((p) => `  <url><loc>${base}${p}</loc><lastmod>${today}</lastmod></url>`)
      .join("\n") +
    `\n</urlset>\n`;
  writeFileSync("public/sitemap.xml", xml);
  console.log(`✔ Wrote robots.txt and sitemap.xml for ${base}`);
}
