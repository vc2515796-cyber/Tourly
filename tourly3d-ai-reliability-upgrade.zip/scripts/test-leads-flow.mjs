/**
 * Hermetic lead-workflow tests — run in a CHILD process by
 * scripts/smoke-functions.mjs (npm run test:smoke).
 *
 * Reuses the auth-flow mock infrastructure (in-memory Blobs store with
 * prefix-aware list, deterministic firebase-admin verifier) plus a mocked
 * global fetch for the one Gemini call, so the ENTIRE lead lifecycle is
 * exercised with zero network and zero real credentials:
 *
 *   capture (public)  : validation, honeypot, owner derived server-side,
 *                       dedupe window
 *   list   (agent)    : verified-token scoping — one agent cannot see
 *                       another agent's leads
 *   update (agent)    : stage/notes persist, activity trail, optimistic
 *                       concurrency 409, cross-agent 404
 *   draft  (agent+AI) : honest 503 without GEMINI_API_KEY, full draft
 *                       round-trip with a mocked model response
 *
 * NOT proven here (needs real provider accounts, documented in DEPLOY.md):
 * live Firebase tokens, real Blobs persistence, actual Gemini output
 * quality, and real WhatsApp delivery (which the app never claims).
 */
import { register } from "node:module";
import { pathToFileURL } from "node:url";
import { fileURLToPath } from "node:url";

register("./smoke-auth-loader.mjs", import.meta.url);

const BASE = fileURLToPath(new URL("../node_modules/.tmp/fntest", import.meta.url));
const ORIGIN = "https://tourly.example.netlify.app";

let passed = 0;
let failed = 0;

function check(name, condition, detail) {
  if (condition) {
    passed++;
    console.log(`  PASS  ${name}`);
  } else {
    failed++;
    console.log(`  FAIL  ${name} — ${detail}`);
  }
}

const jsonOf = async (r) => {
  try {
    return await r.clone().json();
  } catch {
    return null;
  }
};

const VALID_SA_KEY = JSON.stringify({
  project_id: "tourly-test",
  client_email: "smoke@test.iam.gserviceaccount.com",
  private_key: "not-a-real-key",
});

const post = (path, body, token) =>
  new Request(`${ORIGIN}${path}`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      ...(token ? { authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify(body),
  });

const get = (path, token) =>
  new Request(`${ORIGIN}${path}`, {
    headers: token ? { authorization: `Bearer ${token}` } : {},
  });

async function main() {
  process.env.FIREBASE_SERVICE_ACCOUNT_KEY = VALID_SA_KEY;
  delete process.env.GEMINI_API_KEY;

  const { default: captureLead } = await import(pathToFileURL(`${BASE}/capture-lead.mjs`).href);
  const { default: leadsList } = await import(pathToFileURL(`${BASE}/leads-list.mjs`).href);
  const { default: leadUpdate } = await import(pathToFileURL(`${BASE}/lead-update.mjs`).href);
  const { default: leadDraft } = await import(pathToFileURL(`${BASE}/lead-draft.mjs`).href);
  const { backing, getStore } = await import("@netlify/blobs");

  // The mock's backing Map is created lazily per store name — materialise
  // both stores first, then seed through them.
  const toursStore = getStore({ name: "waypoint-tours" });
  const leadsStoreRaw = getStore({ name: "waypoint-leads" });
  const leadsStore = () => backing.get("waypoint-leads");
  const setTourJson = (key, value) => backing.get("waypoint-tours").set(key, { text: JSON.stringify(value), json: value });

  // Seed a published tour owned by ALICE (owner record = the only thing
  // capture-lead trusts for routing the lead).
  setTourJson("lead-tour-1", { id: "lead-tour-1", name: "Sunlit 2BHK", stops: [{ id: "s1", title: "Living room" }] });
  setTourJson("owner:lead-tour-1", { uid: "uid-alice" });
  // A tour that exists but was never published by an authenticated owner.
  setTourJson("lead-tour-orphan", { id: "lead-tour-orphan", name: "No owner" });
  void toursStore; void leadsStoreRaw;

  console.log("[capture-lead — validation]");
  const v1 = await captureLead(post("/api/capture-lead", { tourId: "lead-tour-1", message: "Interested!", consent: true }));
  check("missing contact channel rejected (400)", v1.status === 400, `status=${v1.status}`);
  const v2 = await captureLead(post("/api/capture-lead", { tourId: "lead-tour-1", message: "x", phone: "999", consent: true }));
  check("too-short message rejected (400)", v2.status === 400, `status=${v2.status}`);
  const v3 = await captureLead(post("/api/capture-lead", { tourId: "lead-tour-1", message: "Interested!", phone: "9876543210" }));
  check("missing consent rejected (400)", v3.status === 400, `status=${v3.status}`);
  const v4 = await captureLead(post("/api/capture-lead", { tourId: "lead-tour-1", message: "Interested!", phone: "9876543210", consent: true, email: "not-an-email" }));
  check("malformed email rejected (400)", v4.status === 400, `status=${v4.status}`);
  const v5 = await captureLead(post("/api/capture-lead", { tourId: "does-not-exist", message: "Interested!", phone: "9876543210", consent: true }));
  check("unknown tour rejected (404)", v5.status === 404, `status=${v5.status}`);
  const v6 = await captureLead(post("/api/capture-lead", { tourId: "lead-tour-orphan", message: "Interested!", phone: "9876543210", consent: true }));
  check("tour without an owner record rejected (404 — nothing to route to)", v6.status === 404, `status=${v6.status}`);
  const v7 = await captureLead(post("/api/capture-lead", { tourId: "lead-tour-1", message: "Interested!", phone: "9876543210", consent: true, company: "spam-bot" }));
  check("honeypot filled → silently accepted and discarded (200, no lead stored)", v7.status === 200 && [...(leadsStore()?.keys() ?? [])].filter((k) => k.startsWith("lead:")).length === 0, `status=${v7.status}`);

  console.log("[capture-lead — valid capture + server-side routing]");
  const c1 = await captureLead(
    post("/api/capture-lead", {
      tourId: "lead-tour-1",
      name: "Priya",
      phone: "98765 43210",
      email: "priya@example.com",
      message: "Is this still available? Can I visit this weekend?",
      consent: true,
      stopTitle: "Living room",
    })
  );
  const c1b = await jsonOf(c1);
  check("valid enquiry accepted (200)", c1.status === 200 && c1b?.ok === true, `status=${c1.status}`);
  const leadKeys = [...(leadsStore()?.keys() ?? [])].filter((k) => k.startsWith("lead:"));
  check("exactly one lead stored, under the OWNER's prefix (server-derived)", leadKeys.length === 1 && leadKeys[0].startsWith("lead:uid-alice:"), `keys=${JSON.stringify(leadKeys)}`);
  const storedLead = leadsStore().get(leadKeys[0]).json;
  check(
    "lead routed to the tour's verified owner, stage new, consent recorded",
    storedLead.ownerUid === "uid-alice" && storedLead.stage === "new" && storedLead.consent === true,
    `owner=${storedLead.ownerUid} stage=${storedLead.stage}`
  );
  check("tour name + scene context snapshotted for the CRM", storedLead.tourName === "Sunlit 2BHK" && storedLead.stopTitle === "Living room");

  console.log("[capture-lead — dedupe window]");
  const c2 = await captureLead(
    post("/api/capture-lead", {
      tourId: "lead-tour-1",
      phone: "9876543210", // same digits, different formatting
      message: "Sending again by accident",
      consent: true,
    })
  );
  const c2b = await jsonOf(c2);
  const leadKeysAfter = [...leadsStore().keys()].filter((k) => k.startsWith("lead:"));
  check("double-submit inside the window is deduped (duplicate: true, no new lead)", c2.status === 200 && c2b?.duplicate === true && leadKeysAfter.length === 1, `keys=${leadKeysAfter.length}`);

  console.log("[leads-list — verified-token scoping]");
  const l1 = await leadsList(get("/api/leads"));
  check("no token → 401", l1.status === 401, `status=${l1.status}`);
  const l2 = await leadsList(get("/api/leads", "garbage-token"));
  check("garbage token → 401", l2.status === 401, `status=${l2.status}`);
  const l3 = await leadsList(get("/api/leads", "test-id-token-alice"));
  const l3b = await jsonOf(l3);
  check("alice sees her captured lead", l3.status === 200 && l3b?.leads?.length === 1 && l3b.leads[0].name === "Priya", `count=${l3b?.leads?.length}`);
  const l4 = await leadsList(get("/api/leads", "test-id-token-bob"));
  const l4b = await jsonOf(l4);
  check("bob sees ZERO leads (prefix scoping — alice's leads are not addressable)", l4.status === 200 && l4b?.leads?.length === 0, `count=${l4b?.leads?.length}`);

  const leadId = l3b.leads[0].id;
  const leadUpdatedAt = l3b.leads[0].updatedAt;

  console.log("[lead-update — stages, notes, concurrency]");
  const u1 = await leadUpdate(post("/api/lead-update", { leadId, stage: "nope" }, "test-id-token-alice"));
  check("invalid stage rejected (400)", u1.status === 400, `status=${u1.status}`);
  const u2 = await leadUpdate(post("/api/lead-update", { leadId, stage: "contacted" }, "test-id-token-bob"));
  check("another agent cannot update alice's lead (404 — not addressable under their uid)", u2.status === 404, `status=${u2.status}`);
  const u3 = await leadUpdate(post("/api/lead-update", { leadId, expectedUpdatedAt: leadUpdatedAt - 99999, stage: "contacted" }, "test-id-token-alice"));
  check("stale expectedUpdatedAt → 409 conflict instead of silent clobber", u3.status === 409, `status=${u3.status}`);
  const u4 = await leadUpdate(post("/api/lead-update", { leadId, expectedUpdatedAt: leadUpdatedAt, stage: "contacted", note: "Called, asked about parking" }, "test-id-token-alice"));
  const u4b = await jsonOf(u4);
  check("stage + note update succeeds (200)", u4.status === 200 && u4b?.lead?.stage === "contacted", `status=${u4.status}`);
  const kinds = (u4b?.lead?.activities ?? []).map((a) => a.kind).sort();
  check("stage-change and note activities recorded in the trail", kinds.includes("stage-change") && kinds.includes("note"), `kinds=${JSON.stringify(kinds)}`);
  const updatedDoc = leadsStore().get(`lead:uid-alice:${leadId}`).json;
  check("stage + activities persisted in storage", updatedDoc.stage === "contacted" && updatedDoc.activities.length === 2, `stage=${updatedDoc.stage} acts=${updatedDoc.activities.length}`);
  const u5 = await leadUpdate(post("/api/lead-update", { leadId, expectedUpdatedAt: updatedDoc.updatedAt, nextActionAt: Date.now() + 86400000 }, "test-id-token-alice"));
  check("next-action date saved", u5.status === 200 && leadsStore().get(`lead:uid-alice:${leadId}`).json.nextActionAt > Date.now(), `status=${u5.status}`);

  console.log("[lead-draft — honest unconfigured + mocked Gemini]");
  const d1 = await leadDraft(post("/api/lead-draft", { leadId }, "test-id-token-alice"));
  const d1b = await jsonOf(d1);
  check("no GEMINI_API_KEY → honest 503 with manual-write fallback message", d1.status === 503 && /GEMINI_API_KEY/.test(String(d1b?.error)), `status=${d1.status} err=${d1b?.error}`);
  const d2 = await leadDraft(post("/api/lead-draft", { leadId }, "test-id-token-bob"));
  check("another agent cannot draft on alice's lead (404)", d2.status === 404, `status=${d2.status}`);

  process.env.GEMINI_API_KEY = "fake-key-for-validation-only";
  const realFetch = globalThis.fetch;
  let capturedPrompt = "";
  globalThis.fetch = async (_url, init) => {
    try {
      capturedPrompt = JSON.parse(init?.body ?? "{}")?.contents?.[0]?.parts?.[0]?.text ?? "";
    } catch {}
    const draftText = "Hi Priya, thanks for asking about the Sunlit 2BHK — shall we schedule a visit this weekend? Take the tour: {tourLink}";
    const geminiBody = JSON.stringify({
      candidates: [
        {
          content: {
            parts: [{ text: JSON.stringify({ draft: draftText }) }],
          },
        },
      ],
    });
    return new Response(geminiBody, { status: 200, headers: { "content-type": "application/json" } });
  };
  try {
    const d3 = await leadDraft(post("/api/lead-draft", { leadId, channel: "whatsapp", language: "hinglish" }, "test-id-token-alice"));
    const d3b = await jsonOf(d3);
    check("draft round-trip succeeds with mocked Gemini (200)", d3.status === 200 && /Priya/.test(String(d3b?.draft)), `status=${d3.status}`);
    check("draft labelled as draft-not-sent in the response", /nothing has been sent/i.test(String(d3b?.disclaimer)), `disclaimer=${d3b?.disclaimer}`);
    check(
      "the prompt is grounded in the ACTUAL enquiry + tour content, with never-invent rules",
      capturedPrompt.includes("Is this still available") && capturedPrompt.includes("Sunlit 2BHK") && capturedPrompt.includes("Do NOT invent"),
      `prompt head: ${capturedPrompt.slice(0, 100)}`
    );
    check("Hinglish + WhatsApp channel reach the prompt", capturedPrompt.includes("Hinglish") && capturedPrompt.includes("whatsapp"));
    const docAfter = leadsStore().get(`lead:uid-alice:${leadId}`).json;
    check("draft recorded in the activity trail (kind: draft)", docAfter.activities.some((a) => a.kind === "draft"), `acts=${docAfter.activities.length}`);
  } finally {
    globalThis.fetch = realFetch;
    delete process.env.GEMINI_API_KEY;
  }

  console.log("[capture-lead — method guard]");
  const m1 = await captureLead(new Request(`${ORIGIN}/api/capture-lead`));
  check("GET rejected 405 JSON", m1.status === 405, `status=${m1.status}`);

  console.log(`\nLEADFLOW_SUMMARY: ${passed} ${failed}`);
  process.exit(failed === 0 ? 0 : 1);
}

main().catch((err) => {
  console.error("LEAD-FLOW HARNESS ERROR:", err);
  process.exit(1);
});
