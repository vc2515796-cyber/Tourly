/**
 * AI provider-adapter + fallback-coordinator tests — hermetic, no network,
 * no credentials (Phase 2/3 of the reliability upgrade).
 *
 * Bundles _gemini.mts + _providers.mts exactly the way Netlify deploys
 * them, then mocks globalThis.fetch to exercise:
 *
 *   A.  Gemini success with no secondary configured (behaviour unchanged)
 *   B.  Gemini all-models fail → Groq fallback succeeds, response is
 *       NORMALIZED into the Gemini shape (candidates[0].content.parts[0].text)
 *   C.  Secondary NOT configured → Gemini-only, zero secondary URLs hit
 *   D.  Both providers fail → classified error, attempts log both providers
 *   E.  429 with a PerDay quota body → "quota-exhausted" (no same-model
 *       retry burn), fallback still attempted
 *   F.  429 with RetryInfo only → transient retry (unchanged behaviour)
 *   G.  Multimodal (inline_data) request never goes to the text-only
 *       secondary; AI_FALLBACK_ALLOW_VISION=true opts in
 *   H.  Image-generation kind never falls back
 *   I.  Malformed secondary 2xx (no choices[]) → honest failure, no fake
 *       success
 *   J.  Gemini 401 (bad Gemini key) + secondary configured → secondary
 *       still tried (its credentials are separate)
 *   K.  Circuit breaker: trips after N consecutive failures, skips the
 *       provider, auto-recovers after cooldown; a success resets the count
 *   L.  Concurrency cap: max 1 in flight per provider, FIFO queue works
 *   M.  Budget guard: no secondary attempt when the remaining wall-clock
 *       budget is too small for a useful result
 *   N.  Kill switch AI_DISABLE_FALLBACK_PROVIDER
 *   O.  Mistral used when Groq absent; no key material in any error detail
 *   P.  withCoalescing: concurrent identical requests share ONE execution
 *
 * Run: node scripts/test-ai-providers.mjs   (chained into npm run test:units)
 */
import { spawnSync } from "node:child_process";
import { pathToFileURL, fileURLToPath } from "node:url";

const OUT = fileToFileURL("../node_modules/.tmp/provtest");
function fileToFileURL(rel) {
  return fileURLToPath(new URL(rel, import.meta.url));
}

const bundle = spawnSync(
  process.platform === "win32" ? "npx.cmd" : "npx",
  [
    "esbuild", "netlify/functions/_gemini.mts", "netlify/functions/_providers.mts", "netlify/functions/_aiusage.mts",
    "--bundle", "--packages=external", "--platform=node", "--format=esm",
    `--outdir=${OUT}`, "--out-extension:.js=.mjs",
  ],
  { stdio: "pipe", cwd: fileURLToPath(new URL("..", import.meta.url)) }
);
if (bundle.status !== 0) {
  console.error("esbuild bundling failed:\n" + bundle.stdout + bundle.stderr);
  process.exit(1);
}
process.exitCode = 0;

// IMPORTANT: the reliability hooks (breakerSnapshot, reset…) are imported
// FROM THE _gemini BUNDLE — esbuild inlines _providers.mts into it, so a
// separately-bundled _providers.mjs would be a different instance with its
// own state. _gemini re-exports the hooks precisely for this reason.
const { callGemini, GeminiError, resolveSecondaryProvider, breakerSnapshot, resetReliabilityStateForTests } =
  await import(pathToFileURL(`${OUT}/_gemini.mjs`).href);
const { toOpenAiChatRequest, fromOpenAiChatResponse, payloadHasImages } =
  await import(pathToFileURL(`${OUT}/_providers.mjs`).href);
const { withCoalescing } = await import(pathToFileURL(`${OUT}/_aiusage.mjs`).href);

let passed = 0;
let failed = 0;
const failures = [];
function check(name, condition, detail = "") {
  if (condition) {
    passed++;
    console.log(`  PASS  ${name}`);
  } else {
    failed++;
    failures.push(name);
    console.log(`  FAIL  ${name} — ${detail}`);
  }
}

const realFetch = globalThis.fetch;

// --- helpers -----------------------------------------------------------------

const calls = [];
let mockImpl = null;
function mockFetch(fn) {
  mockImpl = fn;
}
globalThis.fetch = (url, init) => {
  calls.push({ url: String(url), init });
  return mockImpl ? mockImpl(String(url), init) : Promise.reject(new Error("no mock set"));
};

const GEMINI_OK = (text = '{"ok":true}') =>
  new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text }] } }] }), { status: 200, headers: { "content-type": "application/json" } });
const GROQ_OK = (text = '{"ok":true}') =>
  new Response(
    JSON.stringify({ choices: [{ message: { role: "assistant", content: text } }] }),
    { status: 200, headers: { "content-type": "application/json" } }
  );
const STATUS = (status, body = "{}", headers = {}) =>
  new Response(body, { status, headers: { "content-type": "application/json", ...headers } });

const TEXT_PAYLOAD = { contents: [{ parts: [{ text: "hi" }] }], generationConfig: { responseMimeType: "application/json" } };
const VISION_PAYLOAD = {
  contents: [{ parts: [{ text: "what is this?" }, { inline_data: { mime_type: "image/jpeg", data: "QUJD" } }] }],
};
const FAST = { maxRetries: 0, timeoutMs: 2_000, totalBudgetMs: 8_000, backoffBaseMs: 1, functionName: "provtest" };

const isGemini = (u) => u.includes("generativelanguage.googleapis.com");
const isGroq = (u) => u.includes("api.groq.com");
const isMistral = (u) => u.includes("api.mistral.ai");

async function expectGeminiError(p) {
  try {
    await p;
    return { wrongError: "resolved" };
  } catch (err) {
    if (err instanceof GeminiError) return err;
    return { wrongError: String(err?.name ?? err) };
  }
}

function resetEnv() {
  delete process.env.GROQ_API_KEY;
  delete process.env.GROQ_MODEL;
  delete process.env.MISTRAL_API_KEY;
  delete process.env.MISTRAL_MODEL;
  delete process.env.AI_DISABLE_FALLBACK_PROVIDER;
  delete process.env.AI_FALLBACK_ALLOW_VISION;
  delete process.env.AI_FALLBACK_MAX_RETRIES;
  delete process.env.AI_BREAKER_THRESHOLD;
  delete process.env.AI_BREAKER_COOLDOWN_MS;
  delete process.env.AI_MAX_CONCURRENT_PER_PROVIDER;
  process.env.GEMINI_API_KEY = "fake-key-for-tests-only";
  resetReliabilityStateForTests();
}

// --- A. Gemini success, no secondary (unchanged behaviour) --------------------

console.log("\nGroup A — Gemini only, success (no secondary configured)\n");
resetEnv();
{
  calls.length = 0;
  mockFetch((u) => GEMINI_OK('{"a":1}'));
  const r = await callGemini("text", TEXT_PAYLOAD, FAST);
  check("gemini answered", r.response.status === 200 && r.provider === "gemini", r.provider);
  const body = await r.response.json();
  check("response keeps the Gemini shape", body?.candidates?.[0]?.content?.parts?.[0]?.text === '{"a":1}', JSON.stringify(body));
  check("no secondary URL was contacted", calls.every((c) => isGemini(c.url)), calls.map((c) => c.url).join(","));
  check("secondary resolver returns null when unconfigured", resolveSecondaryProvider() === null, String(resolveSecondaryProvider()));
}

// --- B. Gemini fails → Groq fallback, normalized response ---------------------

console.log("\nGroup B — Gemini all models fail → Groq fallback succeeds\n");
resetEnv();
{
  process.env.GROQ_API_KEY = "gsk-fake-key-for-tests-0123456789";
  calls.length = 0;
  mockFetch((u) => (isGemini(u) ? STATUS(503, '{"error":"overloaded"}') : GROQ_OK('{"roomLabel":"Kitchen"}')));
  const r = await callGemini("text", TEXT_PAYLOAD, FAST);
  check("fallback succeeded via groq", r.provider === "groq" && r.response.status === 200, `${r.provider}`);
  check("groq model id reported", r.model === "openai/gpt-oss-120b", r.model);
  const body = await r.response.json();
  check(
    "secondary response NORMALIZED into Gemini shape",
    body?.candidates?.[0]?.content?.parts?.[0]?.text === '{"roomLabel":"Kitchen"}',
    JSON.stringify(body)
  );
  check("both providers attempted, in order", isGemini(calls[0].url) && isGroq(calls[calls.length - 1].url), calls.map((c) => c.url).join(","));
  check("attempts log includes provider names", r.attempts.some((a) => a.provider === "groq"), JSON.stringify(r.attempts.map((a) => a.provider)));
  // Request adapter shape: OpenAI-style body with system/user messages.
  const groqCall = calls.find((c) => isGroq(c.url));
  const groqBody = JSON.parse(groqCall.init.body);
  check("groq request is OpenAI-style (model + messages)", groqBody.model === "openai/gpt-oss-120b" && Array.isArray(groqBody.messages), JSON.stringify(groqBody).slice(0, 120));
  check("groq auth is a Bearer header, never a query param", /^Bearer /.test(groqCall.init.headers.Authorization) && !groqCall.url.includes("key="), groqCall.url);
}

// --- C. Both fail → classified error, both providers in the log ---------------

console.log("\nGroup C — both providers fail\n");
resetEnv();
{
  process.env.GROQ_API_KEY = "gsk-fake-key-for-tests-0123456789";
  calls.length = 0;
  mockFetch(() => STATUS(503, '{"error":"down"}'));
  const err = await expectGeminiError(callGemini("text", TEXT_PAYLOAD, FAST));
  check("classified server error", err instanceof GeminiError && err.kind === "server", `${err.kind}/${err.wrongError}`);
  check("safe message, no endpoints or keys", !/groq|mistral|gsk_|api\.|AIza/.test(err.safeMessage), err.safeMessage);
  check("attempt log spans both providers", err.attempts.some((a) => a.provider === "gemini") && err.attempts.some((a) => a.provider === "groq"), JSON.stringify(err.attempts.map((a) => `${a.provider}:${a.outcome}`)));
  check("no key material leaked into the sanitized detail", !/gsk-fake/.test(err.detail), err.detail.slice(0, 80));
}

// --- D. 429 daily quota vs RetryInfo ------------------------------------------

console.log("\nGroup D — 429 classification: daily quota vs transient\n");
resetEnv();
{
  process.env.GEMINI_MAX_RETRIES = "2";
  // PerDay quota in the body → quota-exhausted, no same-model retry burn.
  calls.length = 0;
  mockFetch(() =>
    STATUS(
      429,
      '{"error":{"code":429,"status":"RESOURCE_EXHAUSTED","details":[{"quotaId":"GenerateRequestsPerDayPerProjectPerModel","quotaMetric":"...free_tier_requests"}]}}',
      { "retry-after": "3600" }
    )
  );
  const err = await expectGeminiError(callGemini("text", TEXT_PAYLOAD, { ...FAST, totalBudgetMs: 6_000 }));
  check("PerDay 429 → kind quota-exhausted", err.kind === "quota-exhausted", err.kind);
  check("quota-exhausted maps to HTTP 429, not retryable", err.httpStatus === 429 && err.retryable === false, `${err.httpStatus}/${err.retryable}`);
  const geminiCalls = calls.filter((c) => isGemini(c.url));
  check("daily quota is NOT retried on the same model more than once per model", geminiCalls.length === 2, `calls=${geminiCalls.length}`);
  delete process.env.GEMINI_MAX_RETRIES;
}
resetEnv();
{
  // Plain transient 429 (RetryInfo-ish, no PerDay) → retried as before.
  let n = 0;
  calls.length = 0;
  mockFetch((u) => (isGemini(u) && n++ === 0 ? STATUS(429, '{"error":{"details":[{"retryDelay":"0s"}]}}', { "retry-after": "0" }) : GEMINI_OK()));
  const r = await callGemini("text", TEXT_PAYLOAD, { ...FAST, maxRetries: 1 });
  check("transient 429 retried and recovered", r.provider === "gemini" && r.response.status === 200, `${r.provider}`);
  check("daily-quota fallback attempted on quota-exhausted", true); // covered in group E
}

// --- E. quota-exhausted still tries the secondary -----------------------------

console.log("\nGroup E — quota-exhausted falls back to Groq\n");
resetEnv();
{
  process.env.GROQ_API_KEY = "gsk-fake-key-for-tests-0123456789";
  calls.length = 0;
  mockFetch((u) =>
    isGemini(u)
      ? STATUS(429, '{"error":{"details":[{"quotaId":"GenerateRequestsPerDayPerProjectPerModel"}]}}')
      : GROQ_OK('{"roomLabel":"Hall"}')
  );
  const r = await callGemini("text", TEXT_PAYLOAD, FAST);
  check("quota-exhausted on Gemini → served by Groq", r.provider === "groq" && r.response.status === 200, r.provider);
  const body = await r.response.json();
  check("normalized body parses through the standard path", body?.candidates?.[0]?.content?.parts?.[0]?.text === '{"roomLabel":"Hall"}', JSON.stringify(body));
}

// --- F. Vision never silently goes to a text-only secondary -------------------

console.log("\nGroup F — multimodal requests stay off the text-only secondary\n");
resetEnv();
{
  process.env.GROQ_API_KEY = "gsk-fake-key-for-tests-0123456789";
  calls.length = 0;
  mockFetch((u) => (isGemini(u) ? STATUS(503, "{}") : GROQ_OK("should-not-happen")));
  const err = await expectGeminiError(callGemini("text", VISION_PAYLOAD, FAST));
  check("vision request did NOT reach Groq (default)", !calls.some((c) => isGroq(c.url)), calls.map((c) => c.url).join(","));
  check("payloadHasImages detects the inline image", payloadHasImages(VISION_PAYLOAD) === true, "false");
  check("error mentions the AI service, not a partial success", err instanceof GeminiError && err.kind === "server", err.kind ?? err.wrongError);
  check("attempt log explains WHY the secondary was skipped", err.attempts.some((a) => a.detail && /text-only|multimodal/i.test(a.detail)), JSON.stringify(err.attempts.map((a) => a.detail)));
}
resetEnv();
{
  process.env.GROQ_API_KEY = "gsk-fake-key-for-tests-0123456789";
  process.env.AI_FALLBACK_ALLOW_VISION = "true";
  calls.length = 0;
  mockFetch((u) => (isGemini(u) ? STATUS(503, "{}") : GROQ_OK("vision-ok")));
  const r = await callGemini("text", VISION_PAYLOAD, FAST);
  check("explicit AI_FALLBACK_ALLOW_VISION=true sends vision to the secondary", r.provider === "groq", r.provider);
  const groqBody = JSON.parse(calls.find((c) => isGroq(c.url)).init.body);
  check("inline_data converted to an image_url data URL part", groqBody.messages.some((m) => Array.isArray(m.content) && m.content.some((p) => p.type === "image_url" && String(p.image_url.url).startsWith("data:image/jpeg;base64,"))), JSON.stringify(groqBody.messages).slice(0, 120));
}

// --- G. Image generation never falls back -------------------------------------

console.log("\nGroup G — image generation stays on Gemini\n");
resetEnv();
{
  process.env.GROQ_API_KEY = "gsk-fake-key-for-tests-0123456789";
  calls.length = 0;
  mockFetch((u) => (isGemini(u) ? STATUS(503, "{}") : GROQ_OK("nope")));
  const err = await expectGeminiError(callGemini("image", { contents: [{ parts: [{ text: "a room" }] }] }, FAST));
  check("image kind never contacts the secondary", !calls.some((c) => isGroq(c.url)), calls.map((c) => c.url).join(","));
  check("honest server error", err.kind === "server", err.kind ?? err.wrongError);
}

// --- H. Malformed secondary output → honest failure ---------------------------

console.log("\nGroup H — malformed secondary output is never a fake success\n");
resetEnv();
{
  process.env.GROQ_API_KEY = "gsk-fake-key-for-tests-0123456789";
  calls.length = 0;
  mockFetch((u) => (isGemini(u) ? STATUS(503, "{}") : new Response(JSON.stringify({ choices: [] }), { status: 200 })));
  const err = await expectGeminiError(callGemini("text", TEXT_PAYLOAD, FAST));
  check("2xx without choices[] → classified malformed failure (502, retryable)", err instanceof GeminiError && err.kind === "malformed" && err.httpStatus === 502, `${err.kind}/${err.wrongError}`);
  check("the malformed attempt is in the log", err.attempts.some((a) => a.provider === "groq" && a.outcome === "malformed"), JSON.stringify(err.attempts.map((a) => a.outcome)));
}

// --- I. Gemini 401 with a secondary configured ---------------------------------

console.log("\nGroup I — Gemini auth failure still tries the secondary\n");
resetEnv();
{
  process.env.GROQ_API_KEY = "gsk-fake-key-for-tests-0123456789";
  calls.length = 0;
  mockFetch((u) => (isGemini(u) ? STATUS(401, '{"error":"bad key"}') : GROQ_OK("ok")));
  const r = await callGemini("text", TEXT_PAYLOAD, FAST);
  check("Gemini 401 → Groq answered (separate credentials)", r.provider === "groq" && r.response.status === 200, r.provider);
}
resetEnv();
{
  calls.length = 0;
  mockFetch(() => STATUS(401, '{"error":"bad key"}'));
  const err = await expectGeminiError(callGemini("text", TEXT_PAYLOAD, FAST));
  check("without a secondary, Gemini 401 stays an honest auth 503", err.kind === "auth" && err.httpStatus === 503, `${err.kind}/${err.httpStatus}`);
}

// --- J. Circuit breaker ---------------------------------------------------------

console.log("\nGroup J — circuit breaker\n");
resetEnv();
{
  process.env.AI_BREAKER_THRESHOLD = "2";
  // NOTE: the cooldown has a 1s floor (deliberate — a shorter open window
  // is pointless), so sleep past 1s for the half-open recovery check.
  process.env.AI_BREAKER_COOLDOWN_MS = "1000";
  // Two consecutive whole-request failures trip the gemini breaker.
  mockFetch(() => STATUS(503, "{}"));
  await expectGeminiError(callGemini("text", TEXT_PAYLOAD, FAST));
  await expectGeminiError(callGemini("text", TEXT_PAYLOAD, FAST));
  check("breaker open after threshold failures", breakerSnapshot("gemini").open === true, JSON.stringify(breakerSnapshot("gemini")));
  calls.length = 0;
  const err = await expectGeminiError(callGemini("text", TEXT_PAYLOAD, FAST));
  check("open breaker skips the provider entirely (no fetch)", calls.length === 0, `calls=${calls.length}`);
  check("breaker-open error is honest and retryable", err.kind === "breaker-open" && err.httpStatus === 503 && err.retryable === true, `${err.kind}/${err.httpStatus}`);
  // Cooldown expires → provider retried (half-open recovery).
  await new Promise((r) => setTimeout(r, 1_250));
  check("breaker auto-closes after the cooldown", breakerSnapshot("gemini").open === false, JSON.stringify(breakerSnapshot("gemini")));
  calls.length = 0;
  mockFetch(() => GEMINI_OK());
  const r = await callGemini("text", TEXT_PAYLOAD, FAST);
  check("recovered provider serves again", r.provider === "gemini" && r.response.status === 200, r.provider);
  // A success resets the consecutive-failure count.
  check("success reset the failure streak", breakerSnapshot("gemini").consecutiveFailures === 0, JSON.stringify(breakerSnapshot("gemini")));
  delete process.env.AI_BREAKER_THRESHOLD;
  delete process.env.AI_BREAKER_COOLDOWN_MS;
}

// --- K. Concurrency cap ----------------------------------------------------------

console.log("\nGroup K — concurrency limiter\n");
resetEnv();
{
  process.env.AI_MAX_CONCURRENT_PER_PROVIDER = "1";
  let inFlight = 0;
  let maxInFlight = 0;
  mockFetch(async (u) => {
    if (isGemini(u)) {
      inFlight++;
      maxInFlight = Math.max(maxInFlight, inFlight);
      await new Promise((r) => setTimeout(r, 120));
      inFlight--;
      return GEMINI_OK();
    }
    return STATUS(500, "{}");
  });
  const [r1, r2] = await Promise.all([
    callGemini("text", TEXT_PAYLOAD, { ...FAST, totalBudgetMs: 10_000 }),
    callGemini("text", TEXT_PAYLOAD, { ...FAST, totalBudgetMs: 10_000 }),
  ]);
  check("both concurrent requests succeeded (FIFO queue)", r1.response.status === 200 && r2.response.status === 200, `${r1.provider}/${r2.provider}`);
  check("never more than 1 in flight per provider", maxInFlight === 1, `max=${maxInFlight}`);
  delete process.env.AI_MAX_CONCURRENT_PER_PROVIDER;
}

// --- L. Budget guard for the secondary -------------------------------------------

console.log("\nGroup L — budget guard\n");
resetEnv();
{
  process.env.GROQ_API_KEY = "gsk-fake-key-for-tests-0123456789";
  calls.length = 0;
  // Gemini fails after burning almost the whole budget → no time for a
  // useful secondary attempt → skip it honestly.
  mockFetch(async (u) => {
    if (isGemini(u)) {
      await new Promise((r) => setTimeout(r, 150));
      return STATUS(503, "{}");
    }
    return GROQ_OK("too-late");
  });
  const err = await expectGeminiError(
    callGemini("text", TEXT_PAYLOAD, { maxRetries: 0, timeoutMs: 2_000, totalBudgetMs: 1_600, backoffBaseMs: 1, functionName: "provtest" })
  );
  check("secondary NOT started when the remaining budget is too small", !calls.some((c) => isGroq(c.url)), calls.map((c) => c.url).join(","));
  check("budget-exhausted is recorded in the attempt log", err.attempts.some((a) => a.outcome === "budget-exhausted"), JSON.stringify(err.attempts.map((a) => a.outcome)));
}

// --- M. Kill switch + Mistral precedence -------------------------------------------

console.log("\nGroup M — kill switch, Mistral, provider resolution\n");
resetEnv();
{
  process.env.GROQ_API_KEY = "gsk-fake-key-for-tests-0123456789";
  process.env.MISTRAL_API_KEY = "fake-mistral-key-1234567890";
  check("Groq wins when both are configured (documented precedence)", resolveSecondaryProvider()?.id === "groq", resolveSecondaryProvider()?.id);
  process.env.AI_DISABLE_FALLBACK_PROVIDER = "true";
  check("kill switch disables the secondary", resolveSecondaryProvider() === null, String(resolveSecondaryProvider()));
  delete process.env.AI_DISABLE_FALLBACK_PROVIDER;
  delete process.env.GROQ_API_KEY;
  check("Mistral used when Groq absent", resolveSecondaryProvider()?.id === "mistral", resolveSecondaryProvider()?.id);
  check("Mistral default model id", resolveSecondaryProvider()?.model === "mistral-small-latest", resolveSecondaryProvider()?.model);
  calls.length = 0;
  mockFetch((u) => (isGemini(u) ? STATUS(503, "{}") : new Response(JSON.stringify({ choices: [{ message: { content: "bonjour" } }] }), { status: 200 })));
  const r = await callGemini("text", TEXT_PAYLOAD, FAST);
  check("Mistral fallback answers, normalized", r.provider === "mistral" && (await r.response.json()).candidates[0].content.parts[0].text === "bonjour", r.provider);
  delete process.env.MISTRAL_API_KEY;
}

// --- N. Request/response adapter unit checks ----------------------------------------

console.log("\nGroup N — adapter conversion details\n");
{
  const converted = toOpenAiChatRequest(
    {
      systemInstruction: { parts: [{ text: "be brief" }] },
      contents: [
        { role: "user", parts: [{ text: "hello" }, { inline_data: { mime_type: "image/png", data: "AABB" } }] },
        { role: "model", parts: [{ text: "hi there" }] },
      ],
      generationConfig: { responseMimeType: "application/json", temperature: 0.3, maxOutputTokens: 99 },
    },
    "some-model"
  );
  check("system instruction → system message", converted.messages[0]?.role === "system" && converted.messages[0]?.content === "be brief", JSON.stringify(converted.messages[0]));
  check("model role → assistant", converted.messages[2]?.role === "assistant", converted.messages[2]?.role);
  check("image part → image_url data URL", converted.messages[1]?.content?.[1]?.image_url?.url === "data:image/png;base64,AABB", JSON.stringify(converted.messages[1]));
  check("responseMimeType json → response_format json_object", converted.response_format?.type === "json_object", JSON.stringify(converted.response_format));
  check("temperature + maxOutputTokens carried over", converted.temperature === 0.3 && converted.max_tokens === 99, `${converted.temperature}/${converted.max_tokens}`);

  const normalized = fromOpenAiChatResponse({ choices: [{ message: { content: "segmented" } }] }, "m");
  check("string content normalized", normalized.candidates[0].content.parts[0].text === "segmented", JSON.stringify(normalized));
  const segmented = fromOpenAiChatResponse({ choices: [{ message: { content: [{ type: "text", text: "a" }, { type: "text", text: "b" }] } }] }, "m");
  check("segmented content joined", segmented.candidates[0].content.parts[0].text === "ab", JSON.stringify(segmented));
  check("payloadHasImages false for text-only", payloadHasImages(TEXT_PAYLOAD) === false, "true");
}

// --- O. Coalescing ---------------------------------------------------------------------

console.log("\nGroup O — request coalescing\n");
{
  let executions = 0;
  const fn = async () => {
    executions++;
    await new Promise((r) => setTimeout(r, 80));
    return `result-${executions}`;
  };
  const [a, b, c] = await Promise.all([withCoalescing("k", fn), withCoalescing("k", fn), withCoalescing("k", fn)]);
  check("three concurrent identical requests → ONE execution", executions === 1, `executions=${executions}`);
  check("all sharers got the same result", a === b && b === c && a === "result-1", `${a}/${b}/${c}`);
  const d = await withCoalescing("k", fn);
  check("after settle, the key is reusable (no stale sharing)", executions === 2 && d === "result-2", `executions=${executions}`);
  let failedExecutions = 0;
  const failing = async () => {
    failedExecutions++;
    throw new Error("boom");
  };
  const results = await Promise.allSettled([withCoalescing("f", failing), withCoalescing("f", failing)]);
  check("failures reject every sharer (never a fake success)", results.every((r) => r.status === "rejected") && failedExecutions === 1, JSON.stringify(results.map((r) => r.status)));
}

// --- done ------------------------------------------------------------------------------

globalThis.fetch = realFetch;
console.log("\n============================================================");
console.log(`AI provider fallback: ${passed} passed, ${failed} failed`);
if (failures.length) {
  console.log("Failed checks:\n  - " + failures.join("\n  - "));
  process.exitCode = 1;
}
