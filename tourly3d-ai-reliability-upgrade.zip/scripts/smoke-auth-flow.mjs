/**
 * Hermetic auth + publishing flow tests — run in a CHILD process by
 * scripts/smoke-functions.mjs (npm run test:smoke).
 *
 * Registers test-only module mocks (smoke-auth-loader.mjs) BEFORE importing
 * the bundled publish-tour function, so the full authenticated flow can be
 * exercised with zero network and zero real credentials:
 *
 *   - missing FIREBASE_SERVICE_ACCOUNT_KEY → honest 503 naming the variable
 *   - malformed key JSON → 503 config error (NOT a misleading 401)
 *   - key present, no Authorization header → 401, tour NOT stored
 *   - key present, garbage token → 401, tour NOT stored
 *   - token from a different Firebase project → specific mismatch 401
 *   - alice publishes → 200, ownership recorded server-side
 *   - bob publishes the SAME tour id → 403 (cannot publish another user's
 *     walkthrough), original owner record unchanged
 *   - alice re-publishes → 200 (owner may update their own tour)
 *   - password never persisted inside the public tour JSON (separate hash)
 *
 * What this does NOT prove: live Firebase sign-in and real Google-signed
 * tokens — that requires a configured Firebase project and is documented as
 * an external setup step in AUTH-SETUP.md. The verification CODE PATH is
 * identical; only the SDK's network verification is mocked.
 */
import { register } from "node:module";
import { pathToFileURL } from "node:url";
import { fileURLToPath } from "node:url";

// Mocks must be registered before the function is imported.
register("./smoke-auth-loader.mjs", import.meta.url);

const BASE = fileURLToPath(new URL("../node_modules/.tmp/fntest", import.meta.url));
const ORIGIN = "https://tourly.example.netlify.app";

let passed = 0;
let failed = 0;

function check(name, condition, detail) {
  if (condition) {
    passed++;
    console.log(`  PASS  ${name}`);
  } else {
    failed++;
    console.log(`  FAIL  ${name} — ${detail}`);
  }
}

const jsonOf = async (r) => {
  try {
    return await r.clone().json();
  } catch {
    return null;
  }
};

// A JWT-shaped token whose aud names a DIFFERENT Firebase project than the
// (fake) service account below — rejected by the mock verifier, then caught
// by the function's own cross-project diagnostic.
const b64url = (obj) => Buffer.from(JSON.stringify(obj)).toString("base64url");
const crossProjectToken = [
  b64url({ alg: "RS256", typ: "JWT" }),
  b64url({ aud: "some-other-project", sub: "someone-else" }),
  "forged-signature",
].join(".");

const VALID_SA_KEY = JSON.stringify({
  project_id: "tourly-test",
  client_email: "smoke@test.iam.gserviceaccount.com",
  private_key: "not-a-real-key",
});

function publishRequest(body, token) {
  return new Request(`${ORIGIN}/api/publish-tour`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      ...(token ? { authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify(body),
  });
}

const tourBody = (id) => ({
  tour: {
    id,
    name: "Auth flow test tour",
    stops: [{ id: "s1", title: "Living room", media: { kind: "panorama", dataUrl: "data:image/jpeg;base64,AAAA" } }],
  },
});

async function main() {
  const { default: publishTour } = await import(pathToFileURL(`${BASE}/publish-tour.mjs`).href);
  // Inspect the store through the INTERCEPTED specifier — importing the
  // mock file directly would create a second module instance (Node
  // canonicalizes loader-resolved vs directly-imported file URLs
  // differently), and its `backing` Map would be empty.
  const { backing } = await import("@netlify/blobs");

  console.log("[publish-tour — auth & ownership, mocked externals]");

  // 1. No service account key at all → honest 503 that names the variable.
  delete process.env.FIREBASE_SERVICE_ACCOUNT_KEY;
  const t1 = await publishTour(publishRequest(tourBody("auth-flow-1"), "test-id-token-alice"));
  const t1b = await jsonOf(t1);
  check(
    "missing FIREBASE_SERVICE_ACCOUNT_KEY → 503 naming the variable (no silent bypass)",
    t1.status === 503 && /FIREBASE_SERVICE_ACCOUNT_KEY/.test(String(t1b?.error)),
    `status=${t1.status} error=${t1b?.error}`
  );

  // 2. Malformed key JSON → 503 CONFIG error, not a misleading 401.
  process.env.FIREBASE_SERVICE_ACCOUNT_KEY = "{not-valid-json";
  const t2 = await publishTour(publishRequest(tourBody("auth-flow-2"), "test-id-token-alice"));
  const t2b = await jsonOf(t2);
  check(
    "malformed service-account key → 503 config error (never 'session expired')",
    t2.status === 503 && /not valid JSON/.test(String(t2b?.error)),
    `status=${t2.status} error=${t2b?.error}`
  );

  // 3. Valid-shaped key; NO Authorization header → 401 and nothing stored.
  process.env.FIREBASE_SERVICE_ACCOUNT_KEY = VALID_SA_KEY;
  const t3 = await publishTour(publishRequest(tourBody("auth-flow-3")));
  check("no token → 401 unauthenticated", t3.status === 401, `status=${t3.status}`);

  // 4. Garbage token → 401 (verifyIdToken throws), still nothing stored.
  const t4 = await publishTour(publishRequest(tourBody("auth-flow-4"), "garbage-not-a-jwt"));
  check("garbage token → 401 (token present but unverifiable)", t4.status === 401, `status=${t4.status}`);

  // 5. Cross-project token → the specific mismatch 401 naming both projects.
  const t5 = await publishTour(publishRequest(tourBody("auth-flow-5"), crossProjectToken));
  const t5b = await jsonOf(t5);
  check(
    "token from a different Firebase project → 401 naming both projects",
    t5.status === 401 &&
      /some-other-project/.test(String(t5b?.error)) &&
      /tourly-test/.test(String(t5b?.error)),
    `status=${t5.status} error=${t5b?.error}`
  );

  const toursNow = () => backing.get("waypoint-tours") ?? new Map();

  const storedIds = [...toursNow().keys()].filter((k) => !k.includes(":"));
  check(
    "no tour was stored by any rejected request above",
    storedIds.length === 0,
    `stored=${JSON.stringify(storedIds)}`
  );

  // 6. Alice publishes → 200, ownership recorded under HER verified uid.
  const t6 = await publishTour(publishRequest(tourBody("auth-flow-tour"), "test-id-token-alice"));
  const t6b = await jsonOf(t6);
  check("authenticated publish succeeds (200)", t6.status === 200 && t6b?.ok === true, `status=${t6.status}`);
  check(
    "ownership recorded server-side from the VERIFIED uid",
    toursNow().get("owner:auth-flow-tour")?.json?.uid === "uid-alice",
    `owner=${JSON.stringify(toursNow().get("owner:auth-flow-tour")?.json)}`
  );

  // 7. Bob (different verified user) CANNOT publish over Alice's tour id.
  const t7 = await publishTour(publishRequest(tourBody("auth-flow-tour"), "test-id-token-bob"));
  const t7b = await jsonOf(t7);
  check(
    "a different user's publish over the same id is rejected (403)",
    t7.status === 403 && /different account/.test(String(t7b?.error)),
    `status=${t7.status} error=${t7b?.error}`
  );
  check(
    "rejection left the original owner record intact",
    toursNow().get("owner:auth-flow-tour")?.json?.uid === "uid-alice",
    `owner=${JSON.stringify(toursNow().get("owner:auth-flow-tour")?.json)}`
  );
  check(
    "rejected publish did not overwrite the stored tour",
    toursNow().get("auth-flow-tour")?.json?.name === "Auth flow test tour",
    `name=${toursNow().get("auth-flow-tour")?.json?.name}`
  );

  // 8. Alice re-publishes her own tour → 200.
  const t8 = await publishTour(publishRequest(tourBody("auth-flow-tour"), "test-id-token-alice"));
  check("the owner re-publishing their own tour succeeds (200)", t8.status === 200, `status=${t8.status}`);

  // 9. A client-supplied uid field in the tour body proves nothing — the
  //    server must use the VERIFIED uid, not tour.ownerUid.
  const forged = tourBody("auth-flow-tour");
  forged.tour.ownerUid = "uid-bob"; // pretend to be bob inside the payload
  const t9 = await publishTour(publishRequest(forged, "test-id-token-alice"));
  check(
    "client-supplied uid inside the tour JSON is ignored (verified uid wins)",
    t9.status === 200 && toursNow().get("owner:auth-flow-tour")?.json?.uid === "uid-alice",
    `status=${t9.status}`
  );

  // 10. Password protection: the plaintext never lands in the public tour.
  const withPw = tourBody("auth-flow-pw");
  withPw.password = "hunter2-secret";
  const t10 = await publishTour(publishRequest(withPw, "test-id-token-alice"));
  const storedPublicTour = JSON.stringify(toursNow().get("auth-flow-pw")?.json ?? {});
  const storedMeta = toursNow().get("meta:auth-flow-pw")?.json;
  check(
    "publish with password → 200, plaintext password absent from the stored tour",
    t10.status === 200 && !storedPublicTour.includes("hunter2-secret"),
    `status=${t10.status}`
  );
  check(
    "password is stored server-side as a salted PBKDF2 hash instead",
    Boolean(storedMeta?.salt) && /^[0-9a-f]{64}$/.test(String(storedMeta?.hash)),
    `meta=${JSON.stringify(storedMeta)?.slice(0, 80)}`
  );

  console.log(`\nAUTHFLOW_SUMMARY: ${passed} ${failed}`);
  process.exit(failed === 0 ? 0 : 1);
}

main().catch((err) => {
  console.error("AUTH-FLOW HARNESS ERROR:", err);
  process.exit(1);
});
