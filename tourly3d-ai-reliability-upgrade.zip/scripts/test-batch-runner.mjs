/**
 * Resumable batch-runner tests (Phase 6) — pure state machine, no DOM, no
 * fetch. Exercises the exact resume semantics the Editor's auto-detect and
 * any future per-scene pass rely on:
 *
 *   - item failure recorded, batch CONTINUES
 *   - completed items are NEVER reprocessed (no duplicate billing)
 *   - retry pass re-runs ONLY failed items
 *   - systemic errors (auth/quota/not-configured) ABORT, never misreported
 *     as per-item failures
 *   - consecutive-failure wall stops a doomed run
 *   - shouldSkip marks items skipped with a reason
 *   - interrupted "processing" states normalize back to pending on resume
 *   - summaries count every state honestly
 *   - forceIds explicitly reprocess completed items when the user asks
 *
 * Run: node scripts/test-batch-runner.mjs   (chained into npm run test:units)
 */
import { spawnSync } from "node:child_process";
import { pathToFileURL, fileURLToPath } from "node:url";

const OUT = fileURLToPath(new URL("../node_modules/batchtest", import.meta.url));
const bundle = spawnSync(
  process.platform === "win32" ? "npx.cmd" : "npx",
  [
    "esbuild", "src/lib/batchRunner.ts", "src/lib/aiErrors.ts",
    "--bundle", "--platform=node", "--format=esm",
    `--outdir=${OUT}`, "--out-extension:.js=.mjs",
  ],
  { stdio: "pipe", cwd: fileURLToPath(new URL("..", import.meta.url)) }
);
if (bundle.status !== 0) {
  console.error("esbuild bundling failed:\n" + bundle.stdout + bundle.stderr);
  process.exit(1);
}
process.exitCode = 0;

const { runBatch, summarize, normalizeForResume } = await import(
  pathToFileURL(`${OUT}/batchRunner.mjs`).href
);
const { friendlyAiError, partialBatchMessage } = await import(
  pathToFileURL(`${OUT}/aiErrors.mjs`).href
);

let passed = 0;
let failed = 0;
const failures = [];
function check(name, condition, detail = "") {
  if (condition) {
    passed++;
    console.log(`  PASS  ${name}`);
  } else {
    failed++;
    failures.push(name);
    console.log(`  FAIL  ${name} — ${detail}`);
  }
}

const item = (id) => ({ id, state: "pending" });
const itemify = (n) => Array.from({ length: n }, (_, i) => item(`s${i + 1}`));

// --- Group 1: happy path -------------------------------------------------------

console.log("Group 1 — happy path\n");
{
  const items = itemify(3);
  const settled = [];
  const r = await runBatch({
    items,
    processItem: async (i) => `t-${i.id}`,
    classifyError: () => "item",
    onItemSettled: (its, s) => settled.push({ ...s }),
  });
  check("all completed", r.summary.completed === 3 && r.summary.failed === 0, JSON.stringify(r.summary));
  check("results attached", items.every((i) => i.result === `t-${i.id}`), JSON.stringify(items.map((i) => i.result)));
  check("no abort", !r.aborted, String(r.aborted));
  check("onItemSettled fired per item", settled.length === 3, `fires=${settled.length}`);
  check("summary counts every state", summarize([...items, { id: "x", state: "skipped" }]).skipped === 1, "skipped miscounted");
}

// --- Group 2: item failure continues the batch ----------------------------------

console.log("\nGroup 2 — item failure continues the batch\n");
{
  const items = itemify(4);
  const r = await runBatch({
    items,
    processItem: async (i) => {
      if (i.id === "s2") throw Object.assign(new Error("bad photo"), { friendlyMessage: "bad photo" });
      return "ok";
    },
    classifyError: () => "item",
  });
  check("3 completed, 1 failed, none pending", r.summary.completed === 3 && r.summary.failed === 1 && r.summary.pending === 0, JSON.stringify(r.summary));
  check("failure reason recorded", items.find((i) => i.id === "s2")?.reason === "bad photo", items.find((i) => i.id === "s2")?.reason);
  check("no abort on item failures", !r.aborted, String(r.aborted));
}

// --- Group 3: completed never reprocessed; retry-failed only ---------------------

console.log("\nGroup 3 — resume semantics (no re-billing, retry failed only)\n");
{
  // Simulate a previous run: s1 completed, s2 failed, s3 pending.
  const items = [
    { id: "s1", state: "completed", result: "done-1" },
    { id: "s2", state: "failed", reason: "boom" },
    { id: "s3", state: "pending" },
  ];
  const ran = [];
  const r = await runBatch({
    items,
    processItem: async (i) => {
      ran.push(i.id);
      return `done-${i.id}`;
    },
    classifyError: () => "item",
  });
  check("completed s1 NOT reprocessed", !ran.includes("s1"), ran.join(","));
  check("failed s2 and pending s3 ran", ran.includes("s2") && ran.includes("s3"), ran.join(","));
  check("all completed after retry pass", r.summary.completed === 3, JSON.stringify(r.summary));
  check("s1's original result preserved", items[0].result === "done-1", items[0].result);

  // A retry-failed-only pass (onlyIds) touches nothing else.
  const items2 = [
    { id: "a", state: "completed", result: "A" },
    { id: "b", state: "failed" },
    { id: "c", state: "failed" },
  ];
  const ran2 = [];
  const r2 = await runBatch({
    items: items2,
    onlyIds: ["c"],
    processItem: async (i) => {
      ran2.push(i.id);
      return "C";
    },
    classifyError: () => "item",
  });
  check("onlyIds runs ONLY the selected failed item", ran2.join(",") === "c", ran2.join(","));
  check("non-selected failures stay failed (untouched)", r2.summary.failed === 1 && r2.summary.completed === 2, JSON.stringify(r2.summary));
}

// --- Group 4: systemic errors abort honestly --------------------------------------

console.log("\nGroup 4 — systemic errors abort the batch\n");
{
  for (const kind of ["auth", "quota", "not-configured"]) {
    const items = itemify(5);
    const ran = [];
    const r = await runBatch({
      items,
      processItem: async (i) => {
        ran.push(i.id);
        throw Object.assign(new Error(kind), { friendlyMessage: kind });
      },
      classifyError: () => kind,
    });
    check(`${kind} aborts on the FIRST item (nothing else billed)`, ran.length === 1, `ran=${ran.length}`);
    check(`${kind} reports aborted with a message`, Boolean(r.aborted) && r.aborted.kind === kind, JSON.stringify(r.aborted));
    check(`${kind} leaves the rest pending (resumable)`, r.summary.pending === 4, JSON.stringify(r.summary));
    check(`${kind} message never blames the scene`, !/this scene|scene failed|bad scene|photo/i.test(r.aborted.message), r.aborted.message);
  }
}

// --- Group 5: consecutive-failure wall ---------------------------------------------

console.log("\nGroup 5 — consecutive-failure wall\n");
{
  const items = itemify(10);
  const r = await runBatch({
    items,
    processItem: async () => {
      throw new Error("flake");
    },
    classifyError: () => "item",
    maxConsecutiveFailures: 3,
  });
  check("stops after the configured consecutive failures", r.summary.failed === 3 && r.summary.pending === 7, JSON.stringify(r.summary));
  check("honest abort message about service health", /stopped|unhealthy/i.test(r.aborted?.message ?? ""), r.aborted?.message);
}
{
  // A success in the middle resets the streak.
  const items = itemify(6);
  const r = await runBatch({
    items,
    processItem: async (i) => {
      if (i.id === "s2") return "ok";
      throw new Error("flake");
    },
    classifyError: () => "item",
    maxConsecutiveFailures: 3,
  });
  check("interleaved success resets the streak (run continues past 3)", r.summary.failed === 4 && r.summary.pending === 1, JSON.stringify(r.summary));
}

// --- Group 6: skips + interrupted-run normalization ---------------------------------

console.log("\nGroup 6 — skips and interrupted-run normalization\n");
{
  const items = itemify(3);
  const r = await runBatch({
    items,
    shouldSkip: (i) => (i.id === "s2" ? { skip: true, reason: "no photo" } : null),
    processItem: async () => "ok",
    classifyError: () => "item",
  });
  check("skipped item has a reason", items.find((i) => i.id === "s2")?.state === "skipped" && items.find((i) => i.id === "s2")?.reason === "no photo", JSON.stringify(items.find((i) => i.id === "s2")));
  check("summary reports the skip", r.summary.skipped === 1 && r.summary.completed === 2, JSON.stringify(r.summary));

  const interrupted = [
    { id: "a", state: "processing" },
    { id: "b", state: "completed", result: "B" },
  ];
  const normalized = normalizeForResume(interrupted);
  check("interrupted processing → pending on resume", normalized[0].state === "pending", normalized[0].state);
  check("completed survives normalization", normalized[1].state === "completed", normalized[1].state);
}

// --- Group 7: forceIds (explicit re-run of completed) --------------------------------

console.log("\nGroup 7 — explicit force re-processing\n");
{
  const items = [
    { id: "a", state: "completed", result: "old" },
    { id: "b", state: "completed", result: "old" },
  ];
  const ran = [];
  await runBatch({
    items,
    forceIds: ["a"],
    processItem: async (i) => {
      ran.push(i.id);
      return "new";
    },
    classifyError: () => "item",
  });
  check("only the forced completed item re-ran", ran.join(",") === "a", ran.join(","));
  check("forced item got the new result", items[0].result === "new" && items[1].result === "old", `${items[0].result}/${items[1].result}`);
}

// --- Group 8: friendly error mapping (Phase 7) ----------------------------------------

console.log("\nGroup 8 — friendly frontend error mapping\n");
{
  const quotaBody = new Response(JSON.stringify({ error: "Daily AI limit reached (40 per day).", quota: { limit: 40, used: 40 } }), { status: 429 });
  const quota = await friendlyAiError(quotaBody);
  check("per-user quota 429 → friendly, non-retryable, mentions saved work", quota.kind === "quota" && quota.canRetry === false && /saved|safe/i.test(quota.message), JSON.stringify(quota));

  const rateBody = new Response(JSON.stringify({ error: "rate-limiting requests right now" }), { status: 429 });
  const rate = await friendlyAiError(rateBody);
  check("transient 429 → retryable busy message", rate.kind === "rate-limit" && rate.canRetry === true, JSON.stringify(rate));

  const providerQuota = new Response(JSON.stringify({ error: "The AI provider's daily limit is used up — please try again tomorrow" }), { status: 429 });
  const pq = await friendlyAiError(providerQuota);
  check("provider daily-quota 429 → provider-quota kind", pq.kind === "provider-quota" && pq.canRetry === false, JSON.stringify(pq));

  const notConfigured = new Response(JSON.stringify({ error: "AI features aren't configured on this server (GEMINI_API_KEY missing)." }), { status: 503 });
  const nc = await friendlyAiError(notConfigured);
  check("503 configured-message → not-configured, manual workflow hint", nc.kind === "not-configured" && /manual/i.test(nc.message), JSON.stringify(nc));

  const serverErr = new Response(JSON.stringify({ error: "temporarily unavailable" }), { status: 503 });
  const sv = await friendlyAiError(serverErr);
  check("503 transient → server, retryable", sv.kind === "server" && sv.canRetry === true, JSON.stringify(sv));

  const timeout = await friendlyAiError(null, Object.assign(new Error("x"), { name: "AbortError" }));
  check("client abort → timeout with saved-work note", timeout.kind === "timeout" && /safe/i.test(timeout.message), JSON.stringify(timeout));

  const network = await friendlyAiError(null, new Error("fetch failed"));
  check("network throw → connection message", network.kind === "network", JSON.stringify(network));

  const auth = new Response(JSON.stringify({ error: "session has expired" }), { status: 401 });
  const au = await friendlyAiError(auth);
  check("401 → auth, sign-in again", au.kind === "auth" && /sign in/i.test(au.message), JSON.stringify(au));

  const bad = new Response(JSON.stringify({ error: "Image payload too large for analysis" }), { status: 413 });
  const bd = await friendlyAiError(bad);
  check("413 → invalid with the server's message", bd.kind === "invalid" && /too large/i.test(bd.message), JSON.stringify(bd));

  const partial = partialBatchMessage(4, 2, 1);
  check("partial summary mentions counts + retry hint", /4 scenes processed/.test(partial) && /1 skipped/.test(partial) && /2 failed/.test(partial) && /retry/i.test(partial), partial);
}

console.log("\n============================================================");
console.log(`Batch runner + friendly errors: ${passed} passed, ${failed} failed`);
if (failures.length) {
  console.log("Failed checks:\n  - " + failures.join("\n  - "));
  process.exitCode = 1;
}
