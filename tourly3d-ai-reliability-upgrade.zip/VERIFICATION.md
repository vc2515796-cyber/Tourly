# Tourly3D — verification record

## ROUND 6 — Production-safe AI reliability upgrade (2026-10-18)

Base: `tourly3d-netlify-deployment-candidate-fixed.zip` (sha256
`5b529b6164ce2832b114b89081d132e0eeafca833d144d9b9a522146259c49af`,
166 files, testzip PASS) — the Stage D tree plus user-side fixes: text
fallback model default gemini-3.7-flash → gemini-3.1-flash-lite, the
analyze-floorplan cache key now includes perspective crops (correctness
fix), and Editor mobile-UI polish.

### Baseline honesty note

The uploaded baseline had ONE stale test: "same panorama → cached:true"
sent its replay WITHOUT crops, so the (correct) crop-aware cache key
rightly missed. The CODE fix was correct; the TEST was stale. Fixed the
test (identical inputs incl. crops → hit) and ADDED the regression check
the fix deserves (same panorama + different crops → miss, fresh AI call).

### What this round changed

| Area | Files |
|---|---|
| Provider adapter layer (Phase 2) | NEW `netlify/functions/_providers.mts` — Groq/Mistral resolution (env-driven, one active, Groq precedence), Gemini⇄OpenAI payload/response conversion, vision detection, per-provider circuit breaker + concurrency semaphore, test-reset hook |
| Fallback coordinator (Phase 3) | `_gemini.mts` rewritten as coordinator — same public API (callGemini signature/return + `provider` field added); secondary-provider leg with own bounded retries inside the SAME wall-clock budget; NEW kinds `quota-exhausted` (PerDay 429 bodies) and `malformed` (2xx unusable body); `breaker-open` when every viable provider is cooling down |
| Quotas + cache everywhere (Phases 4–5) | `_aiusage.mts`: fail-closed mode for expensive ops, metrics doc, cache hit/miss counters, request coalescing, `cachedAiCall` wrapper. Wired into analyze-scene, classify-scenes, suggest-hotspots, suggest-sequence, lead-draft, tour-assistant (per-IP), generate-marketing (cache), enhance-panorama / generate-3d-render / generate-panorama (quota, fail-closed) |
| Resumable batches (Phase 6) | NEW `src/lib/batchRunner.ts` (pure per-scene state machine: pending/processing/completed/skipped/failed, continue-on-item-failure, systemic-error abort, retry-failed-only, forceIds); Editor "Auto-detect all" rewired (per-scene states, incremental persist, honest summary bar, Retry-failed buttons); `classifyScenes.ts` batch continue-on-failure + per-image skip + partial results; SmartUploadPanel partial summary UI |
| Friendly errors (Phase 7) | NEW `src/lib/aiErrors.ts` shared normalizer; analyzeScene returns kind+canRetry; wired into batch classifier |
| Admin diagnostics (Phase 8) | NEW `netlify/functions/ai-diagnostics.mts` (ADMIN_EMAILS + verified token, safe snapshot, rate-limited live test), `src/lib/aiDiagnostics.ts`, `src/pages/AiDiagnostics.tsx`, route `/admin/ai` |
| Privacy (Phase 9) | `Privacy.tsx` — secondary-provider disclosure + provider privacy-terms links; buyer contact details already excluded from prompts (re-asserted) |
| Env config (Phase 10) | `.env.example` +9 quota vars, secondary-provider vars, reliability knobs, ADMIN_EMAILS; NETLIFY-SETUP §2 expanded (config/rotate/disable secondary, diagnostics); README reliability section; SCHEMA.md §5 metrics doc + cache expansion |
| Tests | NEW `scripts/test-ai-providers.mjs` (61), `scripts/test-batch-runner.mjs` (45), `scripts/test-ai-diagnostics.mjs` (24, smoke Group 7); test-gemini-fallback.mjs scenario-isolation resets (52); test-concept-flow.mjs cache-contract update (38) |

### Commands actually run (pristine + cleanroom13, Node v24.21.0 / npm 11.19.0)

| Command | Exit | Result |
|---|---|---|
| `npm ci` | 0 | clean install |
| `npm run typecheck` | 0 | tsc -b + functions tsc clean |
| `npm run build` | 0 | 5.3s; secret scanner CLEAN (caught and fixed one frontend regex referencing the key NAME — lesson retained) |
| `npm run test:units` | 0 | 270/270 (19 phash + 64 plan-geom + 52 gemini + 29 concept + 61 providers + 45 batch/errors) |
| `npm run test:smoke` | 0 | 180/180 (incl. NEW Group 7 diagnostics 24/24) |
| `npm run check:secrets` | 0 | no frontend secrets |
| `node --check` on all touched scripts | 0 | syntax clean |
| Browser (vite preview + agent-browser) | — | `/admin/ai` renders + fails gracefully unconfigured; `/privacy` shows Groq/Mistral disclosures; `/` and `/dashboard` no console errors |

### What the new tests prove (hermetic; mocked fetch/Blobs/admin)

- Secondary fallback normalizes Groq/Mistral responses into the Gemini
  shape end-to-end; adapter converts systemInstruction/roles/inline_data/
  response_format/temperature correctly (Group N assertions).
- 429 with PerDay body → `quota-exhausted` (no same-model retry burn) AND
  the secondary is still attempted; transient 429 keeps Retry-After path.
- Vision never silently goes to the text-only secondary (opt-in flag
  works); image generation never falls back; malformed 2xx → honest
  `malformed` failure, never a fake success.
- Breaker trips at threshold, skips the provider (zero fetches), auto-
  recovers after cooldown, success resets the streak; concurrency cap
  never exceeds max-in-flight; budget guard refuses hopeless secondary
  attempts; kill switch + Mistral precedence; no key material in ANY
  error detail (Gemini and secondary keys both asserted).
- Coalescing: 3 concurrent identical requests → 1 execution, same result
  for all sharers; failures reject every sharer.
- Batch runner: item failures continue; completed never reprocessed;
  retry-failed-only; systemic aborts (auth/quota/not-configured) never
  blamed on scenes; consecutive-failure wall; skips with reasons;
  interrupted processing → pending on resume.
- Diagnostics: anonymous/invalid/non-admin get 401/403 with NO
  operational detail; admin snapshot has only known-safe top-level keys
  and NEVER contains either provider key; GET makes zero provider
  requests; live test = exactly one ping per configured provider,
  sanitized, rate-limited 1/30s; ADMIN_EMAILS unset → fail closed.

### Explicitly NOT verified / not claimed

- NO real Groq/Mistral/Gemini request was made — every provider test is
  hermetic with mocked fetch. The adapters were written against the
  providers' official docs (console.groq.com/docs, docs.mistral.ai,
  verified 2026-10-18) but a live "Test connection" from /admin/ai on a
  real deployment is the honest way to confirm credentials.
- Free-tier numbers are NOT hardcoded as facts anywhere; docs point at
  the providers' own rate-limit pages (they change).
- The circuit breaker and concurrency cap are per function INSTANCE
  (Netlify may run several); metrics are best-effort counters. Both
  limitations are disclosed in the diagnostics UI itself.
- Browser pass covered routing/rendering/error states, not signed-in AI
  flows (no Firebase project locally).
- Nothing deployed to production.

---

# Tourly3D — verification record, Stage D: AI upgrade & Concept Floor Plan (2026-10-16)

Base: `tourly3d-stage-c-production (1).zip` (sha256
`2a0e1dd07c96ffce2c424913c1af2bfbd932566b676b8f1563590fb2ead289b6`) — the
Stage C round-2 deliverable, uploaded back byte-identical (re-verified).
This round adds the AI feature upgrade: the central usage-control layer,
the mandatory end-to-end AI Concept Floor Plan workflow, copywriter
additions, lead insights, optional interior concepts, and the Phase-8
scoping audit.

## 1. What this round changed

| Area | Files |
|---|---|
| Usage & cost layer (Phase 9) | NEW `netlify/functions/_aiusage.mts` (quotas, usage tracking, content-hash cache); `_gemini.mts` records usage centrally |
| Concept floor plan server (Phase 5A–C) | NEW `netlify/functions/analyze-floorplan.mts` (auth + quota + cache + strict schema validation; honest 502s) |
| Concept floor plan client (5A/B/D/E/F) | NEW `src/lib/conceptPlan.ts` (geometry engine), `src/lib/analyzeFloorPlan.ts` (validation + 4 perspective crops via canvas), `src/components/plan/ConceptGenerator.tsx`; MOD `plan/model.ts` (furniture + concept + uncertain, schemaVersion stays 1), `plan/ops.ts` (furniture ops), `PlanStudio.tsx` (entry, apply, reset, PNG/JSON export, "Use in tour"), `PlanCanvas2D.tsx` (furniture drag/render, dashed uncertainty, watermark, stage export ref), `PlanInspector.tsx` (furniture panel, add-object, AI provenance + reset) |
| Copywriter (Phase 4) | `generate-marketing.mts` (+highlights, +buyerSummary, quota, optional auth), `generateMarketing.ts` (token), `MarketingModal.tsx` (new editable fields) |
| Lead insights (Phase 7) | NEW `netlify/functions/lead-insights.mts`, `src/lib/leadInsights.ts`, `Leads.tsx` AI-insights section |
| Interior concepts (Phase 6) | NEW `netlify/functions/interior-concept.mts`, `src/lib/interiorConcept.ts`, `Editor.tsx` section |
| Tests | NEW `scripts/test-concept-plan.mjs` (29), `scripts/test-concept-flow.mjs` (36, child w/ mocked Blobs/admin/Gemini); chained into `test:units` / smoke Group 6 |
| Docs | `.env.example` (+6 quota/cache vars), `NETLIFY-SETUP.md` (§2 quota table, §4b cost model), `README.md`, `SCHEMA.md` §5, `FEATURE-CHECKLIST.md` Stage D, this file, PRODUCTION-READINESS round 4 |

Model IDs unchanged from round 2 (verified against Google's catalogue,
2026-10-06 page date). Pricing checked 2026-10-16 (ai.google.dev pricing
page) and documented in NETLIFY-SETUP §4b.

## 2. Commands actually run (pristine tree, Node v24.21.0 / npm 11.x)

| Command | Exit | Detail |
|---|---|---|
| `sha256sum` + `zipfile.testzip` on the upload | 0 | byte-identical to the round-2 deliverable; 142 entries, integrity OK |
| `npm ci` | 0 | lockfile install, no modifications |
| `npx tsc --noEmit -p tsconfig.functions.json` | 0 | functions incl. all new modules |
| `npx tsc -b` (app) | 0 | after each UI integration step |
| `node scripts/test-concept-plan.mjs` | 0 | **29 passed, 0 failed** |
| `node scripts/test-gemini-fallback.mjs` | 0 | 52 passed, 0 failed (unchanged from round 2, still green) |
| `npm run test:units` | 0 | 19 + 64 + 52 + 29 = **164 passed, 0 failed** |
| `npm run test:smoke` | 0 | **154 passed, 0 failed** — incl. new Group 6 concept-flow suite: 36/36 (auth 401/503 paths, 415/413/400 validation, malformed-JSON 502, invalid-geometry 502, clamping + kind coercion, cache hit skips AI AND quota, per-user quota 429 with numbers, usage doc contents, lead 404 isolation + phone-not-in-prompt, tour-assistant per-call scoping, copywriter anonymous quota + new fields) |
| `npm run build` | 0 | 5.21 s — preflight, secret scan, `tsc -b`, functions typecheck, vite build |
| `node --check scripts/*.mjs` | 0 | all script syntax |
| `npm ci --omit=dev && npm run build` | 0 | production-style install still builds |

Clean-room re-run from the SHIPPED ZIP: identical matrix, all exit 0
(recorded in the packaging log of this session).

## 3. What the new tests prove (hermetic; mocked Blobs/admin/Gemini)

- **No fabrication**: malformed model JSON and unusable geometry (outline
  < 3 points) both answer honest 502s — a room is never invented.
- **Validation**: MIME 415 / size 413 / missing-field 400; out-of-range
  coordinates and confidence CLAMPED; unknown furniture kinds coerced to
  `other`; uncertainty flags preserved end-to-end.
- **Access control**: analyze-floorplan and interior-concept require a
  server-verified account (401 otherwise; 503 when the deployment isn't
  configured); lead-insights is owner-scoped (bob probing alice's lead gets
  404 — no existence oracle) and the buyer's phone/email never reach the
  model prompt (asserted on the captured prompt).
- **Quotas & cache**: per-user daily quota returns a 429 carrying the
  limit/used numbers; the SAME panorama returns `cached:true` with ZERO new
  AI calls and no quota consumption — even after the quota is exhausted.
- **Usage privacy**: the usage doc contains aggregate counters only — the
  test asserts the input image data and prompt text are NOT in it.
- **Tour Q&A scoping (Phase 8)**: tour-assistant is stateless by design —
  it answers only from the caller-supplied tour content and never reads the
  tours store; per-call isolation asserted (Alpha's call never contains
  Beta's data and vice versa).
- **Geometry engine**: outline→vertex-ring→walls with dedupe; openings
  projected onto the nearest wall; furniture sizes/rotation/uncertainty
  preserved; uncalibrated by construction; degenerate outlines refused;
  concept snapshot has no unbounded nesting; save→load round trip keeps
  furniture + flags; pre-Stage-D plans still load untouched.
- **Watermark contract**: the exact string
  "CONCEPTUAL FLOOR PLAN — NOT TO SCALE" and the needs-watermark rule.

## 4. Explicitly NOT verified / not claimed

- **Real Gemini API behaviour** — every AI check runs against a mocked
  `fetch`. Live model output quality, latency and quotas need a preview
  deploy with a real `GEMINI_API_KEY` (unchanged manual step, flagged
  since round 1).
- **Real-browser interactions** — furniture drag (Konva), PNG
  rasterisation via `stage.toDataURL`, and the perspective-crop canvas
  projection are verified by type checks + pure-logic tests + the engine
  suite, but were NOT exercised in a real browser this round (previous
  rounds' browser harness targeted the public viewer, not Plan Studio).
- **Image-model pricing** — documented as "check the pricing page" rather
  than quoting numbers the docs page didn't itemise.
- **Live Netlify sync-timeout cutoff** — not measured (budget remains
  env-tunable; default 24 s).
- Nothing was deployed to production; no existing data was touched.

## 5. Prior rounds (regression-covered by the same matrix)

Round 2: Gemini fallback engine (52 engine checks + 2 wiring checks — all
still green). Round 1: analytics (36 checks), QR/embed/site-visit/CSV +
hotspot fix. Stage A/B security guarantees verified by the standing audit
probes in the packaging gate.

## 6. Packaging

Deliverable: `download/tourly3d-stage-c-production.zip` (rebuilt) — 149
files (142 + `_aiusage.mts`, `analyze-floorplan.mts`,
`interior-concept.mts`, `lead-insights.mts`, `test-concept-plan.mjs`,
`test-concept-flow.mjs`, minus none). Excludes `node_modules/`, `dist/`,
`.env*`, `.git`, generated SEO files, verification tooling. Integrity +
content audit + clean-room results in the packaging log.
