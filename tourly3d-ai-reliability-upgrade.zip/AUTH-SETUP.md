# Tourly3D — Firebase Authentication & Publishing Setup

This is the concise, complete guide for the two things that must be
configured OUTSIDE the codebase before sign-in and publishing work on a
deployment. Nothing here can be automated from the repo — the app will keep
answering with honest, specific errors (naming the missing variable) until
each step is done.

Total time: ~10 minutes. You need: a Firebase project (free Spark tier is
fine) and access to your Netlify site.

---

## §1 — Client config: the 6 `VITE_FIREBASE_*` variables (browser, public)

**Where:** Netlify UI → Site configuration → Environment variables. Create
these six with values from Firebase Console → Project settings → General →
"Your apps" → Web app → SDK setup and configuration:

| Netlify variable | Firebase Console value |
|---|---|
| `VITE_FIREBASE_API_KEY` | `apiKey` — must match the Firebase Console project exactly, or sign-in fails with "Firebase rejected the configured API key" |
| `VITE_FIREBASE_AUTH_DOMAIN` | `authDomain` (optional — auto-derived as `<projectId>.firebaseapp.com` if omitted) |
| `VITE_FIREBASE_PROJECT_ID` | `projectId` |
| `VITE_FIREBASE_STORAGE_BUCKET` | `storageBucket` |
| `VITE_FIREBASE_MESSAGING_SENDER_ID` | `messagingSenderId` |
| `VITE_FIREBASE_APP_ID` | `appId` |

These are **public by design** (they identify the project, they are not
secrets — Firebase security comes from server-side rules and verified
tokens, not from hiding these). They are **build-time**: after setting or
changing them you MUST trigger a new deploy ("Clear cache and deploy site")
because Vite inlines them into the bundle at build time.

**Availability scopes:** leave "Available to" as *Builds* + *Functions* +
*Deploy previews* — if you scope them to main-only, deploy previews will
build without Firebase and the app will run in local-mode (the yellow
banner says so).

## §2 — Enable the sign-in methods

Firebase Console → **Authentication → Sign-in method**:

- **Email/Password** — enable (this is what the sign-in form uses).
- **Google** — enable if you want the "Continue with Google" button to work.

If a method is disabled, sign-in fails with `auth/configuration-not-found`
and the app now says exactly that (older builds hid it behind a generic
"Something went wrong").

## §3 — Authorized domains (the Netlify preview-subdomain gotcha)

Firebase Console → **Authentication → Settings → Authorized domains**.
Sign-in ONLY works on domains in this list. Firebase does **not** support
wildcards, so `*.netlify.app` is NOT a valid entry — each host needs its
own explicit entry:

| Domain | Add it? |
|---|---|
| `<your-site>.netlify.app` | **Yes** — your production URL |
| `main--<your-site>.netlify.app` | **Yes if you use branch subdomains** — stable, add once |
| `deploy-preview-<N>--<your-site>.netlify.app` | Each preview subdomain you actually need to sign in from — add individually |
| `tourly.yourdomain.com` (custom domain) | **Yes** — after adding the domain in Netlify → Domain management |

Practical guidance: signing in from **deploy previews** is usually not worth
it (every PR gets a new subdomain). Either test auth on the production URL,
or pin a shared branch subdomain (Netlify UI → Domain management → Branch
subdomains → add `main`) and authorize that once. Attempts from an
unauthorized domain fail with `auth/unauthorized-domain`; the app now shows
the hostname and this fix instead of a generic error.

## §4 — Server config: `FIREBASE_SERVICE_ACCOUNT_KEY` (server-only, secret)

Publishing, cloud uploads and messaging codes verify the caller's Firebase
ID token server-side (see `netlify/functions/_shared.mts → verifyAuthToken`).
That requires a service-account key from the **SAME Firebase project** as §1.

**Create a fresh credential** (Firebase Console → Project settings →
**Service accounts** → **Generate new private key** → confirm; you get a
JSON file). If an older private key was ever shared or exposed, revoke or
delete that key first and use a newly generated one. Never commit the key
to Git, place it in `public/`, prefix it with `VITE_`, or share it in
screenshots or chat.

**Add it to Netlify** (Netlify UI → Site configuration → Environment
variables → **Add a variable**):

1. Name: exactly `FIREBASE_SERVICE_ACCOUNT_KEY` (case-sensitive).
2. Value: the **entire JSON object** from the downloaded service-account
   file, minified to ONE line — not just the `private_key`, and not a file
   path. One-liners from a shell:
   `tr -d '\n' < your-key.json > key-one-line.json` (or `jq -c . service-account.json`
   if you have `jq`). Keep the JSON's escaped `\n` sequences inside
   `private_key` intact — `JSON.parse` turns them into newline characters —
   and do not add extra quotes around the whole JSON string.
3. Available to: **Functions** (and **Builds** if you run `netlify dev`
   locally; add **Deploy previews** only if you actually test previews).
4. Save, then trigger a **new deploy**. Changing environment variables does
   NOT retrofit an already-built Functions bundle — Netlify must create a
   fresh deploy for the new value to reach the functions.

If the variable is missing, the API answers 503 with a message naming it;
if the key is malformed JSON or missing required fields
(`project_id` / `client_email` / `private_key`), it answers 503 saying
exactly what is wrong — neither ever silently disables verification. Check
**Netlify → Functions → Logs** for the parsing/credential error, and never
share those logs if they contain secrets.

**Note:** a successful sign-in by itself does **not** prove server-side
verification is configured — publishing a tour and creating a messaging
connect code are the actual tests (§6).

## §5 — One project, both sides

The browser build (§1) and the server key (§4) must belong to the **same
Firebase project**. If they don't, sign-in may look fine but every publish
fails 401 with a message naming the two mismatched project ids — fix it by
regenerating §1 or §4 from one project.

## §6 — Test safely, and keep other secrets out

1. Sign in to Tourly3D.
2. Open a draft walkthrough and try publishing.
3. Open the messaging panel and request a connect code.
4. If either fails, inspect **Netlify → Functions → Logs** for the
   corresponding function (`publish-tour` or `messaging-link`).

Other integrations are **optional** and separate from Firebase server
authentication: WhatsApp and Telegram need their own provider variables,
AI features need `GEMINI_API_KEY`, cloud storage needs the `S3_*`
variables (full walkthroughs in DEPLOY.md and `.env.example`). Do not add
unrelated secrets unless you are configuring those features.

## Troubleshooting — message → cause → fix

| What you see | Cause | Fix |
|---|---|---|
| "Sign-in isn't configured on this deployment…" | `VITE_FIREBASE_*` missing at build time | §1 + redeploy |
| "This sign-in method isn't enabled for the Firebase project" | Provider disabled | §2 |
| "This domain (…) isn't authorized for Firebase sign-in" | Host not in authorized domains (no wildcards — each host needs its own entry) | §3 |
| "Firebase rejected the configured API key" | Wrong `VITE_FIREBASE_API_KEY` value | §1 |
| "Local mode — Firebase auth isn't configured…" banner on dashboard/editor | Same as row 1; drafts are local, publishing disabled | §1 |
| "Publishing isn't available on this deployment yet — the FIREBASE_SERVICE_ACCOUNT_KEY environment variable isn't set" | Server verification unconfigured | §4 |
| "FIREBASE_SERVICE_ACCOUNT_KEY is not valid JSON" | Key pasted with line breaks / truncated | §4 step 2 |
| "Sign-in is split across two Firebase projects" | Client vars and server key from different projects | §5 |
| "Your session has expired — sign in again and retry" | Real invalid/expired token (also check Functions logs — failures log the auth error code there) | Sign in again; if persistent, check server clock/token minting |
| "This walkthrough was published by a different account" | A different verified user owns that tour id — by design | Publish under a new id, or from the owning account |

## What is enforced in code (no setup needed)

- Protected APIs (`publish-tour`, `media-upload`, `messaging-link`) require
  a Google-signed Firebase ID token, verified server-side with
  firebase-admin; a client-supplied uid/email field is never trusted.
- Tour ownership is recorded server-side on first publish (`owner:<id>` in
  Netlify Blobs) and every later publish of that id requires the same
  verified uid — cross-user publishes are rejected 403 (test-verified).
- Password-protected tours keep only a salted PBKDF2 hash server-side; the
  public tour JSON never contains the password.
- No secret ever reaches the browser bundle; the build's secret scanner
  (`npm run check:secrets`) fails the deploy if one appears.
