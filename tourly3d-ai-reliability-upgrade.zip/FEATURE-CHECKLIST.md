# Feature implementation checklist — honest status

Last verified build: see "Verification" at the bottom. Everything listed as
**Implemented** exists in the shipped source code; everything else says
exactly what is and isn't there. No aspirational entries.

---

## A — 360° virtual tour editor — ✅ Implemented

- Upload equirectangular panoramas, flat photos, and video (MP4/WebM/MOV);
  type/size validation with specific error messages **before** any read.
- Equirectangular aspect-ratio check — a flat photo uploaded as a "360°"
  stop raises a warning modal offering: keep as normal photo (default),
  AI-generate a true panorama, or override. A flat photo is never silently
  displayed as a panorama.
- Multiple scenes per tour; reorder, rename, describe, delete, bulk-select
  delete; empty states everywhere.
- Interactive hotspots: click-to-place on the panorama, drag-to-reposition,
  target picker, three icon styles, plus AI connection suggestions.
- Transitions between scenes; persistent tour configuration (localStorage
  drafts → published copy in Netlify Blobs); tour IDs/URLs stable across
  edits.
- Upload progress (real %, cloud XHR progress), blur-quality warning,
  storage-full errors, panorama warning modals.

## B — Gemini multimodal AI — ✅ Implemented (server-side only)

- `/api/analyze-scene`: room classification, evidence-grounded description,
  self-reported **confidence** (clamped 0–1), construction-stage label
  only when the photo visibly shows active construction. Response is
  validated + length-capped server-side; shown in the editor as an
  editable suggestion with a review hint — never auto-applied as fact.
- `/api/suggest-sequence`: proposes a logical scene order; applied only via
  an explicit "Apply order" action.
- Batch "Auto-detect all" with per-scene progress and honest stop-on-error.
- `GEMINI_API_KEY` lives only in server env; all calls go through Netlify
  Functions with per-IP rate limits, 30 s timeouts, 503/429 retry, block
  reasons surfaced, and JSON extracted defensively.
- Missing key → clear "not configured" responses (verified by test), never
  fake results. AI-generated panoramas/renders are always marked
  `synthetic` and labelled in the UI.

## C — Floor-plan HUD & room navigation — ✅ Implemented (manual calibration, documented)

- Blueprint upload (image ≤ 6 MB, compressed, decoded dimensions captured).
- Marker placement per scene: click to place, drag to fine-tune, one
  marker per scene, remove/replace plan keeps existing markers.
- Coordinates stored **normalized (0–1)** against the blueprint box, so
  markers stay aligned at any overlay size/aspect (CSS aspect-ratio box).
- Public viewer HUD: collapsible overlay, tap marker → jump to scene,
  active scene highlighted, responsive on mobile.
- **Radar/FOV cone** tracks the live camera yaw, rotated by a per-marker
  manual north calibration. Uncalibrated markers hide the cone rather than
  showing a misleading direction.
- **Honest limitation**: there is NO automatic geometric mapping between
  panorama pixels and blueprint coordinates — placement and north
  calibration are manual by design, and the UI says so. This is the
  documented MVP per the spec.

## D — Construction progress tracking — ✅ Implemented

- Append-only, versioned snapshots per scene: stage label, capture date
  (user-backdatable), optional note, scene title, media reference, stable
  snapshot id.
- Timeline browse per scene; select any snapshot; **side-by-side compare**
  against the scene's current media; delete repoints dedup references so
  history stays intact.
- Media deduplication: identical media references the earlier snapshot by
  id instead of copying multi-MB data.
- Persistence inside the tour document (draft + published copy) — never
  React state or temp memory. AI-suggested stage label prefills the field
  but is never auto-saved.

## E — White-label branding — ✅ Implemented

- Agency name, logo (validated upload ≤ 300 KB after compression, or an
  https URL — `javascript:`/`http:` rejected), primary + accent hex colors
  (validated), optional branded splash while the first panorama loads.
- Public viewer renders branding: header logo/name, theme colors, splash,
  and a best-effort runtime favicon swap.
- Password protection (pre-existing, kept): salted **PBKDF2-SHA256
  (100k iterations)** hash stored server-side in Netlify Blobs metadata —
  never plaintext, never inside the public tour JSON; verification is
  server-side in `/api/get-tour`. Link previews are suppressed for
  protected tours so a locked tour's photo is never leaked via OG tags.

## F — High-performance panorama viewer — ✅ Implemented (no tile pipeline — honest)

- Equirect sphere via three.js; drag pan, wheel/pinch zoom (FOV clamp),
  inertia, device-orientation gyro mode (opt-in, iOS permission handled).
- Panoramas downscaled to ≤ 4096 px on a canvas before GPU upload — 8K/12K
  sources load without blowing mobile texture limits.
- Visible loading and error states with retry; neighbouring scenes lazily
  preloaded after the active one settles.
- Fullscreen (with fallback messaging), scene transitions, responsive
  layout, hotspot projection from 3D to screen space.
- **WebXR is optional and capability-detected** — the VR button only
  renders when `navigator.xr` reports immersive-vr support; failure hides
  it again. Non-supporting browsers are unaffected.
- **NOT implemented: a multi-resolution tile pipeline.** No tile
  generation and no tile-requesting viewer path exist, so none is claimed.
  Large panoramas are handled by the 4096-px texture cap instead. **No
  load-time figures are claimed** — none were measured on representative
  mobile devices/networks.

## G — Cloud media storage — ✅ Implemented

- S3-compatible object storage (AWS S3, Cloudflare R2, MinIO, Wasabi) via
  server-side **SigV4 presigned PUT URLs** (15-min expiry, one object
  each). No storage credentials ever reach the browser.
- Unique object keys `tours/<uid>/<yyyy-mm>/<uuid>.<ext>`; per-user prefix
  = delete boundary; per-user rate limit (60/h).
- Type allowlist (JPEG/PNG/WebP; MP4/WebM/MOV) and size caps (60 MB
  images / 300 MB videos) enforced server-side; real upload progress;
  public/CDN URL returned; delete + replace flows.
- **No silent fallback**: without `S3_*` env vars the editor shows a
  visible notice and uses the legacy embedded-media flow with its smaller
  limits; the status endpoint reports `{configured: false}`. Missing
  credentials produce explicit errors, never fake success (test-verified).

## H — WhatsApp & Telegram automation — ✅ Implemented (needs external accounts)

- Both webhooks: provider-authenticated (WhatsApp `X-Hub-Signature-256`
  HMAC **and** Telegram secret-token header — both test-verified),
  idempotent via message-id dedup, per-IP burst limits, per-message
  processing status records, truthful error replies, no fake success.
- Account linking via single-use 24 h connect codes generated in the
  dashboard (`/api/messaging-link`, server-verified identity).
- Pipeline: fetch provider media → validate type/size (≤ 15 MB) → append
  scene to the linked sender's tour (created on first media, ownership
  recorded like a normal publish) → optional Gemini room-labelling →
  reply with the public tour URL. Tour JSON size guarded before write.
- Bot commands: `start CODE` (link), `new`, `link`, `help`; unsupported
  media types get an honest "can't process that" reply.
- **Not possible from code** (documented in DEPLOY.md §6–7): Meta app/WABA
  approval, permanent tokens, webhook subscription, Telegram setWebhook.
  Until those exist the endpoints answer honest 503s (test-verified).
- Known limitation: chat-created tours aren't pushed back into your
  browser's localStorage dashboard (the app has no per-user server-side
  tour DB); they're managed via the chat + public URL, and ownership is
  recorded server-side.

## I — Publishing & custom domains — ✅ Implemented (domains = documented boundary)

- Stable public URLs `/tour/<id>` that survive refresh and work on any
  device (Netlify Blobs + SPA redirect — redirect/API split in
  `netlify.toml`).
- Publish-time validation **on the server** (API is validated directly,
  not just the UI): ≥ 1 scene with media, hotspot targets must exist,
  name length, size limits, reserved-id guard. Useful JSON errors.
- Password protection on published links (server-side PBKDF2, above).
- Iframe embed snippet with responsive sizing copied from the editor.
- SEO/link previews: edge function rewrites OG/Twitter tags per tour
  before the SPA boots; protected tours expose no preview media.
- **Custom domains are NOT automated** — DNS/domain registration is an
  explicit manual boundary with exact steps in DEPLOY.md §8. No claim is
  made that code can configure DNS.

---

## Stage B1 — AI Smart Upload — ✅ Implemented
- Multi-select + drag-drop, type/size validation, previews, removal before processing — ✅
- Perceptual-hash duplicate detection (in-batch + against existing scenes) — ✅ local, reviewable badges, never auto-deletes
- Quality warnings: blurry / very dark / low resolution — ✅ local canvas heuristics, warnings only
- AI batch classification: category + title + description + order, editable before apply — ✅ server-side Gemini, pHash-cached, per-image retry, honest fallback when unavailable
- 360° treatment only after equirect dimension check + user confirmation — ✅
- Original files preserved; AI failure never destroys staged photos — ✅ (tested)
- NOT built: dimension estimation from photos, auto-panorama claims — by design

## Stage B2 — Plan Studio 2D editor — ✅ Implemented
- Konva vector editor: rooms/walls/doors/windows, select/move/delete/edit, labels — ✅
- Blueprint underlay on its own layer (opacity + drag) — ✅
- Zoom/pan/fit, grid + vertex snapping, undo/redo (capped 60) — ✅ (undo/redo persistence browser-tested)
- Scale calibration via known reference length (proportional rescale) — ✅ measured vs manual vs hidden-when-uncalibrated, honestly labelled
- Multi-floor with elevation; autosave saved/saving/error states; unsaved-changes guards — ✅
- Validation: self-intersection/collinear/duplicate corners with actionable errors; invalid rooms excluded from 3D — ✅
- Versioned document, safe loader (newer schema rejected + preserved, dangling refs dropped w/ warnings) — ✅ (unit-tested)

## Stage B3 — 3D dollhouse viewer — ✅ Implemented
- Generated ONLY from saved 2D geometry (shared wallPieces core) — ✅ 2D/3D cannot disagree
- Wall height/thickness configurable; door/window openings are real geometry gaps — ✅
- Orbit/pan/zoom/reset; room highlight + info; floor switching; scene linking (double-click) — ✅ (browser-tested)
- Loading state, render-error fallback, excluded-rooms report, GPU disposal — ✅
- Honest labels: assumed wall height, calibration state — ✅
- NOT claimed: structural/architectural accuracy, mobile GPU testing beyond build-level checks

## Stage B4 — AI listing copywriter — ✅ Implemented (evolves the original generator)
- Fact inputs incl. language EN/हिंदी/Hinglish + channel + audience/tone — ✅
- Never-invent rules; missingFields reported, not fabricated — ✅ (tested with mocked Gemini)
- Calibrated-plan area offered as a verified fact — ✅
- 9 output types incl. headline + tour intro; editable/copy/save-draft/regenerate — ✅ nothing auto-publishes
- API failures/quota handled with honest fallback — ✅

## Stage B5 — Lead assistant — ✅ Implemented
- Public consent-first enquiry capture (validation, honeypot, 5/min/IP, dedupe window) — ✅ (tested)
- Owner derived server-side from publish ownership record; client can't choose the recipient — ✅ (tested)
- CRM scoped by verified uid (prefix addressing + explicit owner check); cross-agent access impossible — ✅ (tested: bob sees zero)
- Stages, notes, contact history, next-action dates, search/filter — ✅ optimistic-concurrency 409 (tested)
- AI follow-up drafts grounded in the real enquiry; edit-before-use; "not sent" labelling; wa.me prefill only — ✅ (tested)
- Optional site-visit request checkbox → stored on the lead + counted in analytics (server-side) — ✅ (tested + browser-verified)
- CSV export of the agent's OWN leads (search/filter applied, Excel-safe escaping) — ✅ (browser-verified button + escaping reviewed)
- NOT claimed: WhatsApp/email delivery confirmation (no provider send integration) — by design

## Stage C — Buyer engagement analytics, QR, embed, hotspot fix — ✅ Implemented

- **Engagement analytics (server-side, privacy-conscious)** — ✅ (36 hermetic checks + browser-verified event firing)
  - Metrics: tour views (once per visitor session — refresh-safe), scene views,
    hotspot clicks, enquiries, site-visit requests, source attribution
    (QR / WhatsApp / link / embed / direct), conversion rate (enquiries ÷
    views, null — never 0% — when there are no views), week-over-week delta
    on the 7-day view.
  - Enquiry/visit-request counters written ONLY by capture-lead server-side;
    the public track-event endpoint refuses those kinds (tested) — a
    browser cannot inflate conversion.
  - Ownership: analytics-summary checks every requested tour id against the
    server-side owner record; non-owned ids silently excluded (tested:
    bob sees zero of alice's tours).
  - Privacy: aggregate day-documents only; unique visitors = hashed random
    browser tokens, capped at 5000/day ("5000+" shown beyond the cap, never
    an invented number); no IP/UA/referrer stored; privacy page updated.
  - Zero is shown as genuinely zero; empty states explain how to start
    collecting data; metric definitions printed on the page.
- **QR code share panel** — ✅ (browser-verified: the shipped chunk's QR was
  decoded by an independent decoder to the exact `?src=qr` URL)
  - Published banner now offers: tagged public link + copy, open-and-test,
  QR render + PNG download, WhatsApp share (message pre-filled, agent sends
  it themselves), embed snippet — all with source tags so analytics can
  attribute opens.
- **Embed support** — ✅ (browser-verified: `?embed=1&src=embed` renders
  "Open the full tour" escape hatch + events tagged `embed`; framing was
  already allowed by headers)
- **WhatsApp enquiry links now carry the `?src=wa` tour URL** — ✅
  (browser-verified href)
- **Hotspot pin rendering bug — FIXED** — ✅ (browser-verified before AND
  after): the visibility test demanded a hotspot be simultaneously behind
  the camera (dot < −0.15) and in front of it (projected.z < 1) —
  mathematically impossible, so pins never rendered at ANY orientation.
  Sign corrected; pins now appear in front of the camera and clicks
  navigate + track.
- **Indian formatting helpers** (en-IN currency/date) — ✅ (used by CSV
  export; marketing copy keeps free-text prices untouched)
- NOT built (and not claimed): historical activity backfill (tracking
  starts when this version deploys), cross-tour visitor dedupe (uniques are
  per-tour per-day by design), per-visitor session replay, GA4 auto-setup
  (GA stays optional + consent-gated, unchanged), printed-brochure PDF
  generation (QR PNG + embed + share links cover the "where supported"
  card/brochure scope)

## Stage C round 2 — Gemini reliability & fallback engine — ✅ Implemented

- **Server-side fallback engine** (`netlify/functions/_gemini.mts`) — ✅
  (52 hermetic engine checks + 2 function-level wiring checks)
  - Primary + fallback model per kind, env-configurable
    (`GEMINI_TEXT_MODEL[_FALLBACK]`, `GEMINI_IMAGE_MODEL[_FALLBACK]`);
    defaults verified against Google's official model catalogue (2026-10):
    `gemini-3.8-flash` → `gemini-3.1-flash-lite` (text),
    `gemini-3.1-flash-image` → `gemini-nano-banana-2.1` (image). No
    invented model IDs.
  - Bounded retries for transient failures only (429/500/503/504,
    timeouts, network errors) with exponential backoff + jitter and
    `Retry-After` awareness; 401/403 fail fast (no retry, no fallback —
    same key for every model); 404/400 fall back without same-model
    retries; wall-clock budget (default 24 s) bounds all attempts inside
    Netlify's sync execution limit.
  - All 11 AI endpoints rewired through it (payloads and multimodal
    inline images unchanged); classified errors with a `retryable` flag;
    API keys and internal details never reach the browser (sanitised,
    logged server-side only); no fabricated success ever.
  - NOT claimed: live-API behaviour of the default models (mocked-fetch
    tests only; needs a preview deploy with a real key).

## Security & data — ✅ Implemented

- Server-side Firebase ID-token verification for every authenticated API
  (publish, cloud upload sign/delete, messaging codes) — client flags
  prove nothing.
- API request-body validation, size caps, JSON-only responses (never the
  SPA's HTML — test-verified), reserved-key guards, constant-time
  compares, salted+iterated password hashing, per-IP/per-user rate limits
  (Blobs-backed, fail-open documented), secrets scanner wired into the
  build, `SECRETS_SCAN_OMIT_KEYS` documented in `netlify.toml`.
- React's escaping + `safeLogoSrc()` (data/https only) + hex validation
  for user-controlled strings/colors. Logs never contain tokens or media
  contents (status codes + short fragments only).
- Backward compatible: all new tour fields (`floorPlan`, `snapshots`,
  `branding`) are optional — pre-existing tours and accounts keep working;
  no data deletion or reset.

---

## Verification (what actually ran, 2026-10-09)

| Check | Result |
|---|---|
| `npm install` (lockfile complete) | ✅ pass |
| `npm run build` = secrets scan + SEO gen + `tsc -b` (app) + `tsc --noEmit -p tsconfig.functions.json` (functions) + `vite build` | ✅ pass (3.7 s vite build) |
| Netlify Functions typecheck (17 files, strict TS) | ✅ pass |
| Netlify Functions esbuild bundle (deploy-parity, all 17) | ✅ pass |
| Runtime smoke tests of bundled functions (22 assertions: honest 503/501s, JSON-only errors, forged-signature 401, valid-signature 200, verify-token handshake, secret-token 401/200, input validation 400/413, reserved-id guard, empty-tour 400) | ✅ 22/22 pass |
| ZIP archive integrity (`unzip -t`) + required-files audit | ✅ pass (see final report) |

**Not run (cannot run here — no live credentials/accounts):** live
Firebase auth round-trip, live Gemini calls, real S3 upload, real
WhatsApp/Telegram message flow, a real Netlify deploy, on-device mobile
load-time measurements. Each of these paths fails honestly without
credentials (that behaviour IS test-verified above).

## Explicitly not built (and not claimed)

- Multi-resolution tile pipeline (8K/12K pyramid) — see F.
- Automatic panorama→blueprint geometric mapping — manual calibration
  only, see C.
- Real multi-photo panorama stitching / interactive 3D room modeling /
  AI virtual staging — see README "What's intentionally NOT built".
- Sub-1.5 s load-time guarantee — never measured, never claimed.
- Automated DNS/custom-domain configuration — manual steps in DEPLOY.md §8.

## Stage D — AI feature upgrade & Concept Floor Plan — ✅ Implemented

- **Shared AI foundation** — ✅ engine (`_gemini.mts`, round 2) extended with
  centralized usage recording; `NETLIFY-SETUP.md` §4b documents the cost
  model (checked 2026-10-16).
- **AI usage & cost controls (Phase 9)** — ✅ `_aiusage.mts`: per-user daily
  quotas (per-IP anonymous fallback, env-tunable `AI_DAILY_QUOTA_*`),
  aggregate usage tracking (count/outcome/model/latency; never prompts or
  personal data — test-asserted), content-hash result cache
  (`AI_CACHE_TTL_HOURS`), clear 429 with quota numbers, fail-open on store
  hiccups.
- **AI Concept Floor Plan (Phase 5, mandatory)** — ✅ end-to-end:
  - Upload (5A): panorama stop picker with preview + honesty note; real
    type/size/integrity validation client AND server (415/413).
  - Processing (5B): four straightened perspective crops rendered
    client-side (dependency-free canvas inverse mapping), labelled as views
    of the SAME panorama; no new deps, no paid backend.
  - Vision analysis (5C): `analyze-floorplan.mts` — server-verified sign-in,
    quota + cache, verified Gemini vision model, STRICT schema validation
    (clamp/reject; malformed or unusable → honest 502, never a fabricated
    plan).
  - Geometry engine (5D): `conceptPlan.ts` converts the validated analysis
    into the EXISTING plan model (additive `furniture` + `concept` +
    `uncertain` fields; schemaVersion stays 1 — pre-existing plans load
    unchanged, test-asserted).
  - Editor (5E): reuses Plan Studio (drag furniture, undo/redo, snap);
    ConceptGenerator modal (states, confirm-regenerate, preserve-on-failure,
    quota note); inspector panels for furniture editing/adding/removing and
    AI provenance with reset-to-generated; dashed rendering for uncertain
    items; watermark on canvas.
  - Export (5F): high-res PNG (watermarked), geometry JSON download,
    save/reload through the existing tour pipeline (round-trip tested),
    "Use in tour" attaches the watermarked image to the public viewer's
    floor-plan mini-map (explicit confirm; marker impact stated).
  - Every generated plan is marked "CONCEPTUAL FLOOR PLAN — NOT TO SCALE";
    uncalibrated until the owner calibrates with a real measurement.
- **Copywriter additions (Phase 4)** — ✅ `highlights` (validated, capped,
  facts-grounded) + `buyerSummary`; editable locally without new AI calls;
  per-user quota (token sent by the editor client).
- **Lead insights (Phase 7)** — ✅ `lead-insights.mts`: enquiry summary,
  STATED requirements only, stage-aware next actions, all marked
  AI-generated; owner-scoped (bob→404 on alice's lead, test-asserted);
  buyer phone/email never sent to the model (test-asserted). No auto-send.
- **Interior concepts (Phase 6, optional)** — ✅ `interior-concept.mts`:
  modern/minimal/contemporary whitelist, illustrative labelling, explicit
  apply/discard in the editor, honest 503 when unconfigured, quota'd.
- **Tour Q&A (Phase 8)** — ✅ verified stateless-by-design scoping (answers
  only from the caller's own tour content; never reads the tours store) —
  per-call isolation test-asserted.
- NOT claimed (honest limits): real Gemini API behaviour of the default
  models (mocked-fetch tests only — needs a preview deploy with a real
  key); browser canvas drag/PNG rasterisation verified by type + logic
  tests but not in a real browser this round; live Netlify sync-timeout
  cutoff not measured; image-model pricing not itemised (documented as
  "check the pricing page").


## Stage F — Production-safe AI reliability upgrade (2026-10-18)

- [x] Provider adapter layer (`_providers.mts`): optional Groq/Mistral secondary, env-driven, Gemini primary untouched
- [x] Fallback coordinator in `_gemini.mts`: same public API, secondary leg within the shared wall-clock budget
- [x] Error classification: rate-limit vs quota-exhausted (PerDay bodies) vs malformed vs breaker-open; no retry of permanent errors
- [x] Circuit breaker (per instance, threshold+cooldown, auto half-open) + per-provider concurrency cap
- [x] Per-user daily quotas on ALL 14 AI endpoints (per-IP for anonymous incl. public tour assistant); image generation fails CLOSED
- [x] Content-hash cache + request coalescing on all deterministic features; cache hits never consume quota; failures never cached
- [x] Resumable auto-detect: per-scene states, continue-on-failure, incremental persist, honest summary, Retry-failed-only; Smart Upload same
- [x] Shared friendly error normalization (`aiErrors.ts`) across AI clients
- [x] Admin-only diagnostics `/admin/ai` (ADMIN_EMAILS + server-verified token; safe snapshot; rate-limited live test; zero requests on load)
- [x] Privacy disclosure updated for secondary providers with links to provider privacy terms
- [x] Env config documented (.env.example, NETLIFY-SETUP §2 incl. rotate/disable secondary); no invented free-tier numbers
- [x] Tests: 270 unit + 180 smoke assertions, all hermetic; provider keys never printed
