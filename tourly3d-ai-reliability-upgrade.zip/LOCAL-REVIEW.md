# Tourly3D Stage D — independent local review

Review date: 2026-10-16

## Checks completed in this review

- ZIP archive integrity: passed (`ZipFile.testzip()` returned no errors).
- `node --check` for every `scripts/*.mjs`: passed.
- `node scripts/check-secrets.mjs`: passed; no frontend secrets found in `src/`, `public/`, or `index.html`.
- Package/lockfile identity: `tourly@0.1.0`, lockfile v3, names and versions match.
- Packaging scan: no `.env`, `.env.local`, or Firebase service-account JSON file is included in the source archive.
- Code correction: floor-plan analysis cache key now includes the MIME type and the actual accepted perspective crops (including labels), as well as the panorama. This prevents a result generated from one crop set from being reused for a different crop set of the same panorama.

## Checks not completed

A clean dependency install (`npm ci`) could not complete in this environment because requests to `registry.npmjs.org` failed with `EAI_AGAIN` (DNS/network resolution). The environment's `node_modules` therefore remained partial. Consequently, this review did **not** independently establish that TypeScript checks, the Vite production build, unit tests, or Netlify function smoke tests pass for this corrected archive.

The `VERIFICATION.md` file contains test results reported by the previous packaging run. Those results are retained as historical claims but are not represented here as independently rerun.

## Before deployment

1. Run `npm ci` in a network-enabled environment from the directory containing this `package.json`.
2. Run `npm run build`, `npm run test:units`, and `npm run test:smoke`; resolve any failures.
3. Test the resulting deploy as a Netlify Preview Deploy, not production. Verify sign-in, panorama analysis, plan editing, save/load, and PNG export in a real browser.
4. Configure `GEMINI_API_KEY` and `FIREBASE_SERVICE_ACCOUNT_KEY` only as server-side Netlify environment variables. Never put these in `VITE_*` variables or in the ZIP.

This review archive has **not** been deployed to any Netlify site.
