# Tourly

A walkthrough builder — build a route of stops, each with a regular photo,
video, or 360° panorama (drag to look around, tap hotspots to walk to the
next stop) — then share a link people click through like a guided tour.

## Stack
React + TypeScript + Vite + Tailwind + react-router-dom + lucide-react +
three.js (panorama viewer) + a Netlify Function calling Gemini for silent
photo enhancement.

## Routes
- `/` — marketing landing page
- `/dashboard` — create/list walkthroughs + chat-to-tour linking panel
- `/editor/:id` — build a tour: stops, media, hotspots, floor plan,
  construction snapshots, branding, publish
- `/tour/:id` — public cinematic viewer: keyboard + route-strip + floor-plan
  HUD navigation, branding, password gate, iframe-embeddable
- `/analytics` — real, local view-count dashboard
- `/founder` — about page

> Full deployment walkthrough (Firebase, Gemini, S3/R2 storage, WhatsApp &
> Telegram bots, custom domains): **[DEPLOY.md](DEPLOY.md)**.
> Feature-by-feature status with honest limitations:
> **[FEATURE-CHECKLIST.md](FEATURE-CHECKLIST.md)**.

## Sharing across devices (Publish)
`/tour/:id` links only worked in the browser that created them until now —
tours lived purely in `localStorage`. The editor's **"Get shareable link"**
button uploads the tour's current state to Netlify Blobs
(`netlify/functions/publish-tour.mts`); anyone opening the link on any
device fetches it via `netlify/functions/get-tour.mts` if it isn't already
in their own browser.

Important limits:
- **Not automatic** — editing a tour after publishing does NOT update the
  shared copy. Click "Get shareable link" again after changes.
- **Requires a real backend context** — plain `npm run dev` (Vite only)
  can't run Netlify Functions or Blobs. Use `netlify dev` locally, or a
  real deploy, or the button will show a clear error instead of failing
  silently.
- Viewing someone else's shared link does **not** add it to your own
  `/dashboard` list — it's fetched fresh each time, not claimed as yours.

## AI panorama generation (explicit, cost-guarded)
When a photo doesn't look like a real 2:1 panorama, the validation
warning offers **"Auto-generate a 360° from this photo (AI)"** —
`netlify/functions/generate-panorama.mts` asks Gemini to invent the rest
of the room around what's actually in the photo. This is fundamentally
different from the seam-fix/enhancement features above: most of the
resulting image is **not photographed**, it's generated.

Because of that, every synthetic panorama is marked — a short note on the
stop ("AI-generated panorama — not a real capture") that's visible in
both the editor and the public viewer, plus a distinct sparkle icon on
its route-strip thumbnail (vs. the loop icon for real captures). Keep
this marker if you touch this code; presenting invented room content as
a real scan is the one thing this app has deliberately avoided
everywhere else.

Cost controls (tune both for your actual Gemini pricing/budget — neither
reads your real billing, there's no API for that here):
- Input is downscaled to 768px before sending — this is just a seed
  reference for the model, not the output resolution.
- A hard cap (`MAX_GENERATIONS` in `src/lib/generatePanorama.ts`,
  currently 12) tracked in `localStorage`, so it can't run away
  unbounded. Once hit, the button disables until you raise the cap.

## AI reliability (server-side fallback engine)

Every AI call in the app goes through one server-side engine,
`netlify/functions/_gemini.mts`, which implements the full reliability
policy in one place:

- **Primary + fallback model, env-configurable.** Defaults
  `gemini-3.8-flash` → `gemini-3.1-flash-lite` (text) and
  `gemini-3.1-flash-image` → `gemini-nano-banana-2.1` (image), all
  verified against Google's official model catalogue (2026-10). Override
  with `GEMINI_TEXT_MODEL` / `GEMINI_TEXT_MODEL_FALLBACK` /
  `GEMINI_IMAGE_MODEL` / `GEMINI_IMAGE_MODEL_FALLBACK` (see
  `NETLIFY-SETUP.md` §2).
- **Transient failures only are retried** — HTTP 429/500/503/504,
  per-attempt timeouts, network errors — with bounded retries
  (default 2 per model, hard max 5), exponential backoff + jitter, and
  `Retry-After` awareness on 429s.
- **Never retried:** 401/403 (invalid key / permission — the same key is
  used for every model, so retrying or falling back cannot help), or any
  other non-transient 4xx. A 400 or 404 (bad params / retired model) is
  not retried on the same model but the fallback model gets one fresh
  attempt.
- **A wall-clock budget** (`GEMINI_TOTAL_BUDGET_MS`, default 24s) bounds
  ALL attempts across both models so the function always answers inside
  Netlify's synchronous execution limit instead of being killed
  mid-flight.
- **Honest errors, no fabrication.** If everything fails, the browser
  gets a safe, specific message (never the API key or internal details)
  plus a `retryable` flag; the AI buttons in the UI stay clickable as the
  retry option. The engine never fakes a successful response.
- **Multimodal preserved.** Payloads (including inline image data for
  vision/image endpoints) are passed through verbatim to both models.

Stage F (the reliability upgrade) extends the same engine with:

- **Optional secondary provider** (`_providers.mts`): set `GROQ_API_KEY`
  or `MISTRAL_API_KEY` and text requests fall back to that provider when
  Gemini fails a rate limit, daily quota, outage, timeout or network
  error — the response is normalized into Gemini's shape, so every
  feature and test parses it unchanged. Text-only by default
  (`AI_FALLBACK_ALLOW_VISION=true` to opt in with a vision model);
  image GENERATION never falls back; `AI_DISABLE_FALLBACK_PROVIDER` is
  the kill switch. One request never fans out to multiple providers, and
  keys are never rotated to dodge limits.
- **Daily-quota-aware 429s.** A 429 body that identifies a PerDay quota is
  classified `quota-exhausted`: no same-model retry burn, but the fallback
  model (own daily quota) and the secondary provider still get tried.
  A 2xx with an unusable body classifies as `malformed` — never a fake
  success.
- **Circuit breaker + concurrency cap.** After `AI_BREAKER_THRESHOLD`
  consecutive failures a provider is skipped for
  `AI_BREAKER_COOLDOWN_MS`, then retried (per function instance — visible
  in admin diagnostics). At most `AI_MAX_CONCURRENT_PER_PROVIDER`
  in-flight requests per provider per instance, FIFO within the budget.
- **Quotas + cache on every AI endpoint.** All 14 AI features enforce
  per-user daily quotas (per-IP for anonymous callers, including the
  public tour assistant); deterministic results are cached by full-input
  content hash with request coalescing, and image GENERATION fails CLOSED
  when the limiter is unreachable (see `## AI usage & cost controls`).
- **Resumable auto-detect.** "Auto-detect all" and Smart Upload track
  per-scene states (pending/processing/completed/skipped/failed), continue
  after recoverable per-scene failures, keep every completed scene, and
  offer "Retry failed" for exactly the failed ones. Systemic failures
  (expired session, quota gone, AI unconfigured) abort the run honestly
  (`src/lib/batchRunner.ts` + Editor wiring).
- **Admin diagnostics.** `/admin/ai` — server-authorized via
  `ADMIN_EMAILS` + a verified Firebase token — shows provider config,
  model ids, last success/error, error categories, rate-limit/quota
  events, breaker trips, cache hit ratio and quota settings. No keys, no
  customer data, no live requests on page load; "Test connection" is the
  only live check (one minimal ping per provider, rate-limited to 1/30s).
- **Friendly shared errors.** Every AI client normalizes failures through
  `src/lib/aiErrors.ts`: honest, actionable messages (no stack traces, no
  provider dumps), honest partial-batch summaries, retry hints that match
  what can actually succeed.

## AI Concept Floor Plan (from one 360° panorama)

The Plan Studio's **AI concept** button starts the workflow: pick a 360°
panorama scene → the browser renders four straightened perspective views
(dependency-free canvas projection) → the server's verified Gemini vision
model returns a STRUCTURED, schema-validated analysis (room type, outline
polygon, wall segments, door/window markers, furniture with uncertainty
flags) → the conceptual geometry engine (`src/lib/conceptPlan.ts`) converts
it into the SAME typed floor-plan document the editor already uses, so
drag, undo/redo, 3D preview, save and publish all work unchanged.

Honesty rules baked into the feature:
- The generated plan is **UNCALIBRATED** — computed measurements stay
  hidden until the owner calibrates against a real measurement.
- It is watermarked **"CONCEPTUAL FLOOR PLAN — NOT TO SCALE"** on the
  canvas, in the PNG export, and in the public-tour mini-map image, for as
  long as it has concept origin.
- Items the model couldn't actually see arrive flagged `uncertain` and are
  drawn **dashed** for review; the inspector shows the AI's own uncertainty
  notes.
- A failed regeneration never touches the current plan; "reset to
  generated layout" restores the pristine AI snapshot; regenerating an
  existing plan always asks first.
- Exports: high-res PNG (with watermark), editable geometry JSON, and
  "Use in tour" attaches the watermarked image as the public viewer's
  floor-plan mini-map blueprint.

Requires sign-in (server-verified), consumes the per-account daily quota
(`AI_DAILY_QUOTA_ANALYZE_FLOORPLAN`), and results are cached by
content-hash — re-analysing the same panorama is free.

## AI usage & cost controls

`netlify/functions/_aiusage.mts` is the central usage-control layer:
per-user daily quotas (per-IP for anonymous callers, env-tunable via
`AI_DAILY_QUOTA_*`), aggregate usage tracking per feature (count, outcome,
model, latency — never prompts or personal data), and a content-hash
result cache (`AI_CACHE_TTL_HOURS`). All AI features report a clear 429
with the quota numbers when the daily limit is reached. No feature
promises unlimited free usage; the cost model is documented in
`NETLIFY-SETUP.md` §4b.

## AI lead insights & interior concepts

- **Lead insights** (Leads page → "AI insights"): enquiry summary, the
  buyer's STATED requirements (never inferred), and 2-4 next actions for
  the lead's current stage — all marked AI-generated, grounded in the
  lead's own message + tour content. The buyer's phone/email are never
  sent to the model.
- **Interior concept** (Editor → scene settings): an OPTIONAL illustrative
  restyle of a room photo (modern / minimal / contemporary) using the
  configured image model. Always labelled "AI interior concept —
  illustrative only, not the actual property"; applying it to the scene is
  an explicit confirm action, and without a configured key the feature
  shows an honest "not configured" state.

## AI editing assistants (all suggest, never auto-apply)
Three Gemini-backed helpers, each shown to the creator as an editable/
approvable suggestion — none of them write anything without a person
clicking Add/Accept:
- **Room auto-detect** (`netlify/functions/analyze-scene.mts`, "Auto-detect"
  button in Scene Settings) — looks at the stop's photo and suggests a room
  label + one-line description. Fills the Name/Notes fields; you can edit
  or ignore it.
- **Hotspot suggestions** (`netlify/functions/suggest-hotspots.mts`,
  "Suggest" button in the Hotspots section) — given only the stop titles/
  notes (not the photos), proposes which rooms likely connect. Each
  suggestion is a pending chip you Add or dismiss individually. Accepted
  hotspots land at the panorama's center (yaw/pitch 0,0) since there's no
  real placement data behind a text-only suggestion — reposition with the
  Hotspot tool if needed.
- **Marketing copy** (`netlify/functions/generate-marketing.mts`,
  "Marketing" button in the editor header) — drafts a title, descriptions,
  an Instagram caption, a WhatsApp message, and SEO fields from the tour's
  own stop titles/notes. Never invents price, area, or amenities that
  weren't entered. Shown in a copy-to-clipboard modal, not auto-published.

## AI tour assistant + WhatsApp enquiry (public viewer)
- **WhatsApp button** — set a number in Scene Settings → "WhatsApp
  enquiry" and a floating **Enquire** button appears on the public tour
  linking to `wa.me` with a prefilled message. No AI involved; hidden if
  no number is set.
- **Ask-a-question chat** (`netlify/functions/tour-assistant.mts`, bottom-
  right of `/tour/:id`) — answers visitor questions using ONLY the tour
  name/subtitle and stop titles/notes the creator entered. Explicitly
  instructed to say "I don't have that information" rather than guess at
  price, exact area, or amenities that were never entered.

## Photo quality check (client-side, heuristic)
`src/lib/qualityCheck.ts` runs a rough blur estimate (Laplacian variance)
on every uploaded photo, entirely in the browser — no network call. If a
photo looks soft, a dismissible banner suggests retaking it; nothing is
blocked. This is a heuristic tuned by eye, not a calibrated CV model —
treat `BLUR_VARIANCE_THRESHOLD` as approximate.

## 3D render from floor plan (explicit, cost-guarded)
Scene Settings → "3D render from floor plan" lets you upload a 2D floor
plan photo/screenshot and get back a stylized isometric room render
(`netlify/functions/generate-3d-render.mts`, 4 style presets). This is
the same kind of AI image generation as `generate-panorama.mts` — **not**
real 3D reconstruction. There's no actual geometry, no accurate scale,
and the result is one static image, not an interactive/orbitable 3D
model. It's saved as a regular photo stop with `synthetic: true`, and
`buildSyntheticNote()` appends an honest marker to the stop's note (shown
in both the editor and the public viewer) so it's never mistaken for a
real photo of the property. Same cost controls as panorama generation:
input downscaled before sending, hard local usage cap
(`MAX_RENDERS` in `src/lib/generate3DRender.ts`, currently 8).

## Floor plan & room navigation (manual, honest)
Editor → **Tour tools → Floor plan & rooms**. Upload a blueprint photo,
place one draggable marker per scene (coordinates stored 0–100% so they
stay aligned at any size), and optionally calibrate each marker's compass
— the public viewer then shows a radar cone that tracks the camera's real
yaw. Markers are tappable on `/tour/:id` to jump between rooms. Placement
is **manual by design**: nothing auto-maps panorama pixels to blueprint
coordinates, and the UI says so.

## Stage B1 — AI Smart Upload (batch, honest, reviewable)

Pick or drag **many property photos at once** in the editor's "Smart" flow. Everything
heavy runs **locally**: duplicate detection via perceptual hashing (dHash — re-compressed
copies still match), and quality warnings (blurry / very dark / low resolution) via canvas
analysis. Optional AI pass (server-side Gemini, batch endpoint) suggests a **room category**
(living room / bedroom / kitchen / bathroom / balcony / exterior / … / unknown), a readable
**title**, a short description and a **tour order** — every suggestion is editable before
anything is applied, results are cached by photo hash (the same image is never re-sent), and
AI failure leaves the staged photos untouched (manual entry always works). A photo is only
treated as a 360° panorama when it passes the equirectangular dimension check AND you confirm
the toggle. The **original files** are what get attached to scenes.

## Stage B2 — Plan Studio: editable 2D floor plans (Konva)

A real vector editor, not a picture: draw **room polygons** (click corners, click the first
corner or double-click to close), **walls**, **doors and windows** (click a wall), on an
optional **blueprint underlay** (its own adjustable layer). Move corners or whole rooms,
rename rooms, link a room to a tour scene, add floors (multi-floor, per-floor elevation).
**Zoom / pan / fit / grid-snap / undo / redo** with a capped history. **Scale calibration**:
click two points with a known real length, enter it — the whole plan rescales proportionally
and computed measurements become real (until then they're hidden, not guessed; manual
dimensions are always labelled "manual"). Invalid geometry (self-crossing outlines,
collinear rooms) is flagged with actionable messages and excluded from 3D. The plan saves
into the tour itself — **autosave** with visible saved/saving/error states, an unsaved-changes
guard on close, and a safe loader (a newer-schema plan is never mangled; it offers a fresh
start while preserving the old data).

## Stage B3 — 3D dollhouse from the SAME geometry (three.js)

One click on the "3D" tab builds a navigable dollhouse **from the saved 2D geometry** —
floors are triangulated room rings, walls are the exact same wall segments (doors and
windows are real gaps, windows get panes), labels show room names + calibrated areas.
Orbit / zoom / reset camera, room selection on click, double-click a linked room to jump to
its tour scene, floor visibility toggles, invalid rooms excluded with an on-screen report.
The assumed wall height and calibration state are always labelled — this is a plan
visualisation, never claimed as measured architecture.

## Stage B4 — AI listing copywriter (fact-grounded, editable)

The Marketing tool now takes **facts first**: property type, location, price, size,
bedrooms, bathrooms, amenities, audience, tone, **language (English / हिंदी / Hinglish)**
and channel. The server-side prompt has hard never-invent rules — anything you didn't
supply is reported back as "not provided (and not invented)" instead of being fabricated.
When your Plan Studio plan is **calibrated**, its measured total area is offered as a
verified fact. Output covers a headline, listing title, short + long descriptions, WhatsApp
message, Instagram caption, SEO title/description and a tour introduction — **every field
editable**, with copy, save-draft (stored with the tour) and regenerate. Nothing
auto-publishes.

## Stage B5 — Leads: enquiry capture + agent CRM

Public tour pages have a consent-first enquiry form (name optional; phone **or** email
required; honeypot + server validation + 5/min/IP rate limit). Enquiries route to the
tour **publisher's** lead inbox — the owner is derived server-side from the publish-time
ownership record, never from the client. The **/leads** CRM (signed-in agents only,
scoped by the verified uid — one agent cannot even address another's leads) supports the
stages New → Contacted → Qualified → Visit requested → Visit scheduled → Closed / Not
interested, notes, manually-logged contact history, next-action dates, search and filters,
and **AI follow-up drafts** grounded in the actual enquiry + property content (EN/Hindi/
Hinglish; never invents prices or promises). Drafts are labelled "draft — not sent";
"Open in WhatsApp" merely pre-fills the message — **delivery is never claimed**, because
no provider integration confirms it. Updates use optimistic concurrency (409 on conflict).
Full data model: `SCHEMA.md`.

## Stage C — Engagement analytics, QR codes, embeds, site visits

**/analytics** now shows real cross-device engagement for your published tours:
tour views (counted once per visitor session — refreshes don't inflate), scene
views, hotspot clicks, enquiries, site-visit requests, conversion rate
(enquiries ÷ views), week-over-week change, and **where opens came from** —
QR scans, WhatsApp, copied links, embeds, or direct. Enquiry and
site-visit counters are written **only** by the enquiry endpoint
server-side, so no browser can inflate them. Every requested tour is
checked against the server-side ownership record, so only your own
numbers can ever appear. Privacy: aggregate day-counts only; "unique
visitors" are hashed random browser tokens (no IP, no device data, no
personal identifiers); the definitions are printed on the page, and a
view is never presented as a buyer. Zero activity shows as genuinely
zero. The old this-browser-only view log remains as a labelled fallback
section (and as the honest state before server setup).

After publishing, the share banner now offers the public link, **a QR code**
(downloadable PNG, tagged so QR scans show up in analytics), a WhatsApp
share with the tour link pre-filled, and an **embed snippet**
(`?embed=1`) for any website that accepts HTML. Embedded tours show an
"Open the full tour" escape hatch and are tracked as embeds.

The public enquiry form gained an optional **"I'd like to request a site
visit"** checkbox — stored on the lead (with a badge in the CRM) and
counted in analytics. The CRM can **export CSV** of your own leads
(search/filter respected, Excel-safe escaping). WhatsApp enquiry buttons
now include the tour URL with a source tag so those opens are attributed.

**Fixed a real bug found by browser testing**: panorama hotspot pins never
rendered at any camera orientation (the visibility test demanded a
hotspot be simultaneously behind and in front of the camera). Pins now
appear ahead of the camera; clicking walks to the linked scene and counts
the interaction.

## Construction progress snapshots (versioned, append-only)
Editor → **Tour tools → Construction progress**. Save a dated, labelled
snapshot of any scene's current media (backdatable, optional note), browse
the timeline, and compare any capture side-by-side with today's media.
History is never overwritten; identical media is referenced, not
duplicated. Snapshots persist with the tour (draft + published copy) and
survive reloads. AI scene analysis can prefill the stage label — as a
suggestion only.

## White-label branding
Editor → **Tour tools → Branding & white-label**. Agency name, validated
logo (compact upload or https URL), primary/accent hex colors, and an
optional branded splash all render on the public viewer, plus a runtime
favicon swap. Invalid values are dropped, never rendered. Password
protection (salted PBKDF2, server-side verification) predates this build
and keeps working.

## Cloud media storage (S3-compatible, presigned)
When `S3_*` env vars are set, uploads go to your bucket (AWS S3 / R2 /
MinIO / Wasabi) via server-signed 15-minute presigned PUT URLs — full
resolution, unique keys, real progress, per-user delete boundaries. The
browser never sees credentials. Without the env vars the editor shows a
**visible** notice and falls back to embedded media with its smaller
limits — it never pretends media is in the cloud. Setup (bucket policy,
CORS, IAM): **[DEPLOY.md §5](DEPLOY.md)**.

## Build tours over chat (WhatsApp + Telegram)
Dashboard → **Build tours over chat**. Generate a single-use connect code,
send `start CODE` (WhatsApp) or `/start CODE` (Telegram) to your bot, then
just send photos/videos — each becomes an AI-labelled scene and the bot
replies with the public tour URL. Both webhooks verify provider
signatures (HMAC / secret token) before processing, dedupe message ids,
track processing status, and report failures truthfully. Requires the
external provider accounts described in **[DEPLOY.md §6–7](DEPLOY.md)**;
without them the endpoints answer honest 503s.

## What's intentionally NOT built (and why)
- **Real multi-photo panorama stitching** (guided phone capture → stitch
  overlapping frames into one panorama) is a genuinely hard computer-vision
  problem — feature matching, homography estimation, exposure blending —
  and isn't something that can be faked with a single Gemini call. Right
  now the app expects one already-equirectangular photo per panorama stop
  (from a phone's built-in Panorama/Photo Sphere mode or a 360° camera).
  `generate-panorama.mts` covers the "I only have a flat photo" case by
  generating a plausible full panorama instead — clearly marked synthetic,
  never presented as a real scan.
- **Real, interactive 3D room design** (orbit/zoom a true 3D model, edit
  walls/materials/furniture live, export a CAD-accurate scene — the kind
  of thing dedicated floor-plan-to-3D tools do) is NOT built and isn't a
  small addition — it needs an actual 3D reconstruction pipeline and a
  three.js scene graph, not an image generation call. What exists instead
  (`generate-3d-render.mts`, above) is a single AI-rendered concept image
  from a floor plan — useful for a quick visual, not a substitute for real
  3D modeling software.
- **AI virtual staging on real listing photos** (furniture added into an
  existing photo of an empty room, kept as if it were that same photo)
  was left out — it would mean altering a real capture while still
  presenting it as that capture, which cuts against this app's one
  consistent rule (real captures stay real, anything generated is marked
  and treated as a new, separate image — see the floor-plan render above
  for the pattern this app uses instead).

## Seam fixing (silent, background)
`netlify/functions/fix-seam.mts` fixes the classic panorama "seam" — one
edge slightly brighter/warmer than the other where the image wraps around.
It's a deterministic photometric correction (color/brightness only, no
content blending or AI), so it never blurs or ghosts real objects near the
edge, and the correction fades to zero by the horizontal center so the
"front" view is untouched. JPEG only for now — see the function's comments
for why (pure-JS codec, no native deps, to survive an ARM64→x64 deploy).
Runs automatically before the AI lighting pass, same silent/fallback
pattern as panorama enhancement below.

## Panorama enhancement (silent, background)
When a 360° or wide panorama is uploaded, `netlify/functions/enhance-panorama.mts`
silently sends a downscaled copy to Gemini's image-editing model to improve
lighting/sharpness/color — no UI mentions this happening. If the result's
aspect ratio drifts from the original, or anything fails/times out, the
original upload is used with no visible change to the user.

Requires `GEMINI_API_KEY` set in Netlify (Site settings → Environment
variables — not `VITE_`-prefixed, server-side only).

**Local testing:** plain `npm run dev` does NOT run Netlify Functions — use
`netlify dev` instead so `/api/enhance-panorama` resolves.

## Server-side auth verification, rate limits, password rules
A security pass after a "login screen checklist" video — fixed what was
genuinely broken, added what was missing, and explained plainly what I
won't fake.

**The real bug: "admin check" was client-side only.** `ProtectedRoute`
only ever controlled which page *rendered* in the browser — it never
stopped a direct call to `/api/publish-tour`. Before this, that endpoint
had **no server-side auth check at all**: anyone who knew (or guessed) a
tour's id could overwrite it, signed in or not. Fixed in
`netlify/functions/_shared.mts` (`verifyAuthToken`) using the
**firebase-admin** SDK to verify a real, Google-signed ID token — not a
client-supplied uid/email field, which proves nothing since the caller can
put anything there. The browser now fetches its own token via
`auth.currentUser.getIdToken()` (`src/lib/publish.ts`) and sends it as
`Authorization: Bearer <token>`; the function rejects the request (401) if
it's missing or invalid.

Requires a new **server-only** env var:
- `FIREBASE_SERVICE_ACCOUNT_KEY` — Firebase Console → Project settings →
  Service accounts → **Generate new private key**. Downloads a JSON file;
  paste its *entire contents as one line* into this env var in Netlify. This
  is a real secret (full admin access to your Firebase project) — never
  prefix it `VITE_`, never commit the JSON file.

Until that's set, `/api/publish-tour` returns 503 and the editor shows
"Publishing isn't available yet" rather than silently staying open —
failing closed was the point of this fix, so it doesn't quietly remain
exploitable until someone gets around to configuring it.

**Ownership, lightly enforced.** The first account to publish a given tour
id "claims" it (`owner:<id>` in Blobs); a different account trying to
publish over that same id gets 403. This is id-level locking, not a real
per-user tour database — see "Authentication" below for why that's a
separate, bigger piece of work.

**Rate limiting extended to every AI endpoint.** All 7 Gemini-backed
functions had **zero** request cap before this — `enforceAiRateLimit` (one
line per function) now caps each by IP: 5-20/min depending on cost (image
generation is capped tightest). Same Blobs-backed, fail-open limiter
already used for publishing.

**Password rules.** Sign-up now requires 8+ characters and shows a live
strength meter (`passwordStrength()` in `Login.tsx`) with a plain checklist
— it's a transparent rule set, not an entropy score, and only blocks
*signup*; an existing weaker password can still sign in. A real password-
*policy enforced by Firebase itself* (Identity Platform → Password Policy)
is server-side extra credit on top of this if you want it — a console
setting, not something this code can turn on for you.

**Email verification is now wired up**, not just written and unused: signup
sends a verification email automatically, and `/dashboard` shows a
dismissible banner with a resend button while `user.emailVerified` is
false.

**Skipped, honestly:**
- **Two-factor authentication.** Firebase supports it, but only via
  **Identity Platform** (a paid upgrade from plain Firebase Auth) with SMS
  delivery configured in the console first. I won't write MFA enrollment/
  challenge code against a feature that isn't turned on in your project —
  it would be untestable from here and likely to ship broken. Enable
  Identity Platform + MFA in the Firebase Console, tell me it's on, and
  I'll wire up the enrollment and sign-in challenge flow properly.
- **"Session token in localStorage."** Firebase's default web persistence
  actually uses **IndexedDB**, not raw `localStorage`, and this app never
  adds its own copy on top (no custom caching of the ID token — it's
  fetched fresh per request via `getIdToken()`). That said, IndexedDB is
  still JS-readable, so it's still exposed to a successful XSS the same way
  any client-stored token is. The real mitigation is minimizing XSS surface,
  not moving the token — this app doesn't use `dangerouslySetInnerHTML` or
  raw `innerHTML` anywhere (checked), but a true httpOnly-cookie session
  would need a stateful backend issuing and validating its own session
  cookies, which doesn't fit a static-hosted SPA + serverless-functions
  architecture without a much bigger rebuild.

## Authentication (Firebase)
`/dashboard`, `/editor/:id`, and `/analytics` now require sign-in
(email/password or Google) via Firebase Authentication — see
`src/lib/auth.tsx` and `src/pages/Login.tsx`. `/tour/:id` (the public
shared viewer) and the landing page stay open to everyone, since
shared links are meant to work for anyone who receives them.

**Firebase setup** (full walkthrough incl. authorized domains for
Netlify preview subdomains: **AUTH-SETUP.md** in the project root):
1. Create a project at https://console.firebase.google.com.
2. In **Build → Authentication → Sign-in method**, enable **Email/Password**
   and **Google**.
3. In **Project settings → General → Your apps**, add a Web app and copy
   the config values.
4. Set these as environment variables — locally in a `.env` file (copy
   `.env.example`), and on Netlify under **Site settings → Environment
   variables** (all must be prefixed `VITE_` so Vite exposes them to the
   browser bundle — this is safe, Firebase web config is not a secret):
   - `VITE_FIREBASE_API_KEY`
   - `VITE_FIREBASE_AUTH_DOMAIN`
   - `VITE_FIREBASE_PROJECT_ID`
   - `VITE_FIREBASE_STORAGE_BUCKET`
   - `VITE_FIREBASE_MESSAGING_SENDER_ID`
   - `VITE_FIREBASE_APP_ID`
5. In Firebase Console → Authentication → Settings → **Authorized domains**,
   add your Netlify domain (e.g. `your-site.netlify.app`) once deployed —
   Google sign-in will fail on unauthorized domains.

If these env vars aren't set, the app falls back to no-auth behavior
(same as before) instead of locking you out, and the Login page shows a
notice that Firebase isn't configured yet.

**What's real here:** this is the actual Firebase Authentication SDK end to
end — not a mock. Email/password, Google sign-in, and now **"Forgot
password?"** (`resetPassword` in `src/lib/auth.tsx`, sends Firebase's own
reset email) are all real calls against your Firebase project. `signOut`,
session persistence, and the `/login` redirect guard are real too.

**What's NOT yet real — sign-in only gates pages, it doesn't scope data.**
Every walkthrough still lives in one shared browser `localStorage` bucket
(see `src/lib/storage.ts`), with no connection to `user.uid`. Concretely:
two different accounts signed in on the same browser see the *same* tours,
and the same account on two different browsers/devices sees *different*
tours. Login currently proves who someone is; it doesn't yet own their
data. Fixing that for real means migrating tour storage from `localStorage`
to a per-user backend store (Firestore, since Firebase is already here) —
that's a genuine architecture change touching every page that reads or
writes a tour, and I didn't want to make it blind in one pass with no way
to run it against a live Firebase project from here. Worth doing as its own
focused piece of work — say the word and I'll scope it properly rather than
bolt it on.

Note: tours themselves still live in `localStorage`/Netlify Blobs as
before — signing in gates *access to the editor/dashboard*, it doesn't
yet scope which tours belong to which account. Anyone signed in sees the
same tour list on that browser.

## Run locally (Termux)
```bash
cd tourly
npm install
npm run dev
```

## Deploy to Netlify
```bash
npm run build
netlify deploy --prod
```

## Analytics — what's real vs not
`/analytics` shows genuine engagement counted **server-side** for your
published tours (views, scene opens, hotspot clicks, enquiries, visit
requests, and source attribution — see the Stage C section). Before
server setup, the page says so honestly and still shows the local,
this-browser-only view log, which is real but never presented as
visitor-wide. No fabricated stats anywhere in this app, on purpose.

## Legal / compliance pages (starting point, not legal advice)
Added `/privacy`, `/terms`, and `/notices` (linked from the landing page
footer), plus a required Terms/Privacy checkbox on signup in
`Login.tsx`. These are accurate to how the app is actually built (see the
pages themselves for specifics: Firebase Auth for accounts, localStorage
for draft tours, Netlify Blobs for published tours, Gemini API for AI
features, no tracking cookies). They are **not** a substitute for a
lawyer, and several things still need real review before this app
handles real users or money:

- **Demo panorama images** (`public/demo-panorama*.jpg` or similar) —
  confirm you have the right to use them, or swap in your own captures.
  `/notices` flags this but can't verify it for you.
- **Open-source license list** — the table in `/notices` reflects each
  package's commonly known license; verify with an actual license-checker
  tool against `package-lock.json` before publishing it.
- **Jurisdiction-specific requirements** — GDPR/CCPA/DPDP applicability,
  whether a cookie-consent banner is legally required for you (this app
  doesn't currently set tracking cookies, so one wasn't added, but that
  can change), and the correct minimum age for your audience are all
  things a lawyer should confirm for where your users actually are.
- **Support email placeholders** — `/privacy` and `/terms` both have
  `[add your support email here]` — replace before going live.
- **Pricing/billing** — no payment processing exists yet; the pricing
  section says so explicitly. Once you wire up real billing, replace the
  placeholder refund/cancellation paragraph in `/terms` with your actual
  policy.
- **Third-party API terms** — using Gemini (Google), Firebase (Google),
  and Netlify means your usage is also bound by each of their terms of
  service; skim them for anything that affects your use case (rate
  limits, data residency, acceptable use).

## Advanced tools (editor, AI, publishing, dashboard)
**Editor**
- **Drag-to-reposition hotspots** — in the editor, existing pins can be dragged
  to a new spot on the panorama (drop position is raycast back onto the
  sphere, so yaw/pitch stay accurate). Placing new ones still uses the
  Hotspot tool.
- **Multi-select scenes** — checkboxes in the Scenes list; a bulk **Delete**
  appears once anything is selected.

**AI**
- **Auto-detect all** (header) — runs room-detect over every scene that has a
  photo, one at a time with a live `done/total` counter. Results are applied
  as they arrive and it stops with a visible error if Gemini fails.
- **Chat memory** — the tour assistant now receives the last few turns, so
  follow-ups ("and the second bedroom?") make sense. It's still grounded only
  in what the creator entered.

**Publishing**
- **Password-protected links** — set a *View password* in Scene Settings, then
  Publish. The password is sent separately from the tour, hashed server-side
  (salted PBKDF2-SHA256) and stored under a reserved `meta:` key; it is never
  part of the tour JSON viewers download, and `/api/tour` refuses to return
  the tour without a correct `x-tour-password` header. Clearing the password
  and republishing makes the link public again.
  *Honest limits:* this protects the shared link, not the creator's own browser
  copy; and `/api/publish-tour` is still unauthenticated, so anyone who knows a
  tour's (UUID) id could republish over it. Real per-user ownership needs the
  Firebase ID token verified in the functions — not done yet.
- **Embed code** — after Publish, a ready-to-paste `<iframe>` snippet appears
  (with `fullscreen; accelerometer; gyroscope` permissions so "Look with phone"
  works inside the embed).
- **Custom domains — intentionally NOT built.** Pointing a domain at a site is
  DNS + hosting-account configuration (Netlify → Domain management), not
  something app code can do per tour. Add your domain in Netlify and every
  `/tour/:id` link automatically uses it.

**Dashboard / analytics**
- **Search** (name, description, folder) and **folders** (set per tour in
  Scene Settings; dashboard groups by folder with filter chips). Deleting a
  walkthrough now asks for confirmation.
- **Analytics** — 7/30/90-day range, per-walkthrough filter, comparison with
  the previous equal period, busiest day, last-viewed date. Still real data
  only, and still per-browser (see "Analytics — what's real vs not").

## Rebrand: Waypoint → Tourly, and the SEO domain-drift fix
The product was renamed from Waypoint to Tourly everywhere user-facing — UI
text, page titles/metadata, legal pages, OG image, manifest, `package.json`
name, even the project folder. **Not** renamed: internal `localStorage` key
prefixes (`waypoint:tours`, `waypoint:views`, etc.) and the Netlify Blobs
store name (`waypoint-tours`) — changing those would orphan every tour
and published link that already exists for real users. If you want those
renamed too, it's a deliberate data-migration task (read under the old key,
write under the new one, for everyone's existing local data) — say so and
I'll scope it properly rather than silently break existing saves.

**The SEO audit's domain-mismatch finding** (canonical/OG/sitemap pointing
at the wrong Netlify subdomain) isn't a code bug — `scripts/generate-seo.mjs`
and `vite.config.ts` already build every URL from Netlify's own `URL` env
var at build time, every single build. The mismatch happens when that
auto-detected value drifts from the domain people actually land on — e.g.
the site was renamed in Netlify after an earlier deploy, or there's more
than one domain alias pointing at it. **Fix: set `VITE_SITE_URL` explicitly**
in Netlify's environment variables to the one domain you want everywhere
(e.g. `https://tourly-3d.netlify.app`, or your eventual custom domain) —
see `.env.example`. That removes the auto-detection guesswork entirely, and
every rebuild after that will have canonical, OG, sitemap, and robots.txt
agreeing with each other automatically.

## Production hardening (SEO, security, performance)
Added in response to a generic "pre-launch checklist" — implemented where it
was genuinely doable from this codebase, skipped (with a note) where it
wasn't.

**SEO**
- Per-route `<title>`/description via `src/lib/usePageMeta.ts` (app pages are
  `noindex` — dashboard, editor, analytics, login, and shared `/tour/:id`
  links are unlisted, not meant for search).
- **Real per-tour link previews**: `netlify/edge-functions/tour-meta.ts`
  rewrites the OG/Twitter tags for `/tour/:id` at the edge, before any JS
  runs — this is what makes WhatsApp/iMessage/Slack previews show the actual
  tour name and a cover photo instead of the generic Tourly card. Skipped
  entirely for password-protected tours (no name/photo leak through a
  preview).
- `robots.txt` and `sitemap.xml` are generated at build time
  (`scripts/generate-seo.mjs`) from Netlify's own `URL` env var, so they're
  never stale or pointed at the wrong domain. Sitemap only lists public pages
  — published tours are unlisted by design, not crawled.
- Real favicon set, `apple-touch-icon.png`, `site.webmanifest`, and a
  generated `og-default.png` (`public/`) — previously missing entirely.
- **Real content in the raw HTML, not just after React mounts.** An SEO
  audit correctly flagged that the initial server response was an empty
  `<div id="root">` with all real copy arriving after JavaScript runs — fine
  for Google (which executes JS) but a real problem for crawlers that don't,
  including some AI-search bots. `index.html` now has a `#seo-fallback` block
  with genuine H1/description/benefits/FAQ content; `src/main.tsx` hides it
  the instant the script runs, so a real browser never sees it — only a
  plain HTTP fetch does. Keep it in sync with `Landing.tsx` by hand; it's not
  generated.
- **Structured data** (`Organization`, `WebSite`, `SoftwareApplication`
  JSON-LD in `index.html`) — only facts that are true right now. No fake
  reviews/ratings, and the only `Offer` listed is the Free tier (genuinely
  free and live today) — paid tiers aren't billed yet, so they're not in the
  schema either.
- `robots.txt` explicitly allows `OAI-SearchBot` (OpenAI's crawler) as its
  own named rule — sites that block it are excluded from ChatGPT Search
  answers entirely, not just downranked.

**Security**
- HTTPS is enforced by Netlify; `netlify.toml` adds HSTS plus
  `X-Content-Type-Options`, `Referrer-Policy`, and a locked-down
  `Permissions-Policy`. No CSP or COOP header — a strict CSP needs a careful
  Firebase/Fonts/blob-image allow-list and COOP breaks the Google sign-in
  popup; framing isn't blocked because embedding a published tour is a real
  feature (see below).
- `scripts/check-secrets.mjs` runs before every build and fails it if
  anything secret-shaped (API key literal, private key block, a reference to
  `GEMINI_API_KEY`, a `VITE_*_SECRET`-looking name) is found in `src/`,
  `public/`, or `index.html`. Firebase's web config is public by design and
  is explicitly exempted from Netlify's own secret scanner via
  `SECRETS_SCAN_OMIT_KEYS` in `netlify.toml`.
- Publish requests are capped in size (413 over ~6.5 MB) and rate-limited
  (429 over 20/min/IP, via a Netlify Blobs counter — best-effort, fails open
  on a Blobs error rather than blocking real users).

**Performance**
- Every upload is compressed client-side before it touches state or
  localStorage (`src/lib/imageCompress.ts`) — longest side capped per media
  kind, quality 0.85, skips images that are already small.
- `publishTour()` re-compresses a copy further if the tour is still over the
  ~5.5 MB function body limit, trying progressively smaller sizes before
  giving up with a specific error naming the actual size.
- Routes are code-split (`React.lazy` in `App.tsx`) — the landing page no
  longer downloads the editor's three.js viewer or Firebase Auth UI.
- Build assets are cached for a year (`Cache-Control: immutable`) since
  Vite hashes filenames on every change.

**Reliability**
- `StorageFullError` (`src/lib/storage.ts`) is thrown when the ~5 MB
  localStorage quota is hit, and the editor shows a specific "storage is
  full" message instead of silently losing the upload.
- A real 404 page (`src/pages/NotFound.tsx`) for unmatched routes.
- Cookie-consent banner (`src/components/CookieConsent.tsx`) — analytics is
  entirely OFF (no script tag, no cookies) unless `VITE_GA_MEASUREMENT_ID`
  is set AND the visitor clicks Accept; embedded tours never show it or load
  it, and viewed tour ids are masked before any path is sent to Google.

**Skipped, with reasons**
- **Custom domain / DNS** — infra config in Netlify's dashboard, not
  something app code can do (same reasoning as in "Advanced tools" above).
- **Content-Security-Policy** — would need real testing against Firebase,
  Google Fonts, and Gemini responses to avoid breaking the app; adding one
  blind is worse than not having one.
- **Automated broken-link checker** — I checked internal `<Link>`/`navigate()`
  targets by hand against the actual route list (see git history for the
  script used); there's no ongoing crawler wired into CI. Re-run that check
  after adding new routes.
- **WCAG contrast audit** — I computed real contrast ratios for the design
  tokens against the surfaces they're used on (bone/white/ink) rather than
  eyeballing them; every text/background combination in use passes WCAG AA
  (≥4.5:1 for normal text). I did not re-check colors introduced by hover/
  focus states or third-party UI (Firebase's own popup).

## Known limits (prototype stage)
- **Local drafts**: `localStorage` caps around 5–10 MB per origin — publish
  to Netlify Blobs (or configure cloud storage) for real capacity.
- **Publishing is explicit**: editing after publishing does not update the
  shared copy until you publish again.
- **Auth gates access, not data**: Firebase auth protects the
  dashboard/editor/analytics routes and verifies identity server-side for
  every authenticated API, but local tour drafts aren't partitioned
  per-user — published tours are ownership-checked server-side.
- **Webhook-created tours** aren't pushed back into your browser's
  dashboard (no per-user server-side tour DB yet); they're managed via the
  chat + public URL, with ownership recorded server-side.
- **No tile pipeline, no auto floor-plan mapping, no load-time claims** —
  see FEATURE-CHECKLIST.md for the full honest list.

## Design tokens
- Ink `#14181C` / Bone `#F6F3EC` / Brass `#C98A3E` / Sage `#4B6358`
- Display: Space Grotesk · Body: Inter · Mono: JetBrains Mono
- Landing page uses a separate white + emerald glassmorphism palette
  (Tailwind default `emerald-*`/`neutral-*`) — intentionally distinct from
  the app's cinematic dark theme for now.
