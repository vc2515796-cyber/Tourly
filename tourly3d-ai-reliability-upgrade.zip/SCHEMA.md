# Tourly3D — Data Model & Schema Documentation

This document describes every persistent data structure in Tourly3D after
**Stage B**, where each one lives, who can read/write it, and how migrations
are handled. There are exactly two persistence layers, both unchanged since
Stage A — Stage B added **no second database**:

| Layer | Technology | Written by | Scope |
|---|---|---|---|
| Creator drafts | Browser `localStorage` (`waypoint:tours`) | Client only | Per-browser |
| Published data | Netlify Blobs stores | Netlify Functions (server only) | Global, key-scoped |

---

## 1. Tour (draft) — `localStorage["waypoint:tours"]`

A JSON array of `Tour` objects (see `src/types.ts`). Everything the creator
edits lives here until they publish. Stage B added two **optional** fields —
older tours without them are untouched and fully functional:

```ts
type Tour = {
  id: string;                    // crypto.randomUUID
  name: string;
  subtitle: string;
  createdAt: number; updatedAt: number;
  stops: Stop[];                 // scenes: media + hotspots
  whatsappNumber?: string;
  viewPassword?: string;         // never published inside the tour JSON
  folder?: string;
  floorPlan?: FloorPlan;         // Stage A "Feature C": blueprint + markers
  snapshots?: ConstructionSnapshot[];
  branding?: Branding;
  plan?: FloorPlanDocument;      // ★ Stage B2/B3: Plan Studio document
  marketingDrafts?: SavedMarketingDraft[]; // ★ Stage B4
};
```

### 1.1 `FloorPlanDocument` (Stage B2/B3) — `src/lib/plan/model.ts`

The typed, **versioned** document edited in the Plan Studio and consumed by
BOTH the 2D editor and the 3D dollhouse (one geometry source of truth).

```ts
{
  schemaVersion: 1,              // gates migrations (see §Migrations)
  id: string,                    // plan id (stable)
  tourId: string,                // the tour (property record) it belongs to
  scale: {
    units: "m" | "ft",
    calibrated: boolean,         // false until the user completes calibration
    referenceLength?: number,    // the known real length they entered
    drawnLength?: number,        // the drawn length it corresponded to
    calibratedAt?: number
  },
  defaultWallHeight: number,     // metres — an ASSUMPTION, labelled in 3D
  defaultWallThickness: number,  // plan units
  activeFloorId: string,
  floors: Floor[],
  createdAt: number; updatedAt: number
}

Floor = {
  id: string; name: string;
  elevation: number;             // metres above ground (ground = 0)
  vertices: { id: string; x: number; y: number }[];   // world units
  walls:    { id: string; a: string; b: string; thickness: number }[]; // vertex ids
  openings: { id: string; wallId: string; kind: "door" | "window";
              t: number /*0..1 along the wall*/; width: number;
              height: number /*m*/; sillHeight: number /*m*/ }[];
  rooms:    { id: string; name: string; polygon: string[] /* vertex ids, closed ring */;
              sceneStopId?: string /* link to a tour scene */;
              manualArea?: number; manualDimensions?: string;
              createdAt: number; updatedAt: number }[];
  background?: { dataUrl: string; width: number; height: number;
                 opacity: number; x: number; y: number; w: number; h: number };
}
```

Design rules:

- **Stable ids for every object** (vertices, walls, openings, rooms, floors),
  so edits, undo/redo and scene links survive reordering.
- **Ownership travels with the tour** (`tourId`). There is no separate
  Property entity in Tourly3D — the tour IS the property record; the plan is
  a part of it and publishes with it.
- **Measurements honesty**: computed lengths/areas are only shown when
  `scale.calibrated === true`. User-entered values are always labelled
  "manual". The 3D wall height is always labelled an assumption.
- **2D/3D consistency**: the 3D viewer is built exclusively from
  `wallPieces()` in `src/lib/plan/geometry.ts` — the same function the 2D
  canvas renders — so the two views cannot disagree.

### 1.2 `SavedMarketingDraft` (Stage B4)

```ts
{ id: string; createdAt: number; language: string; channel: string;
  fields: Record<string, string> }   // headline/title/descriptions/seo/…
```

Drafts are private to the tour; nothing is published anywhere without the
creator explicitly copying it out.

---

## 2. Server-side stores (Netlify Blobs)

All keys live in Netlify Blobs. Function code is the ONLY writer; the client
never addresses Blobs directly.

### 2.1 Store `waypoint-tours` (unchanged since Stage A)

| Key | Value | Notes |
|---|---|---|
| `{tourId}` | public Tour JSON | written by publish-tour (verified owner only) |
| `owner:{tourId}` | `{ uid }` | the publisher's VERIFIED Firebase uid — the ownership record |
| `meta:{tourId}` | `{ salt, hash }` | PBKDF2 tour password (never inside the tour JSON) |
| `preview:{tourId}` | JPEG data URL | link-preview cover |
| `ratelimit:{…}` | counters | per-IP publish rate limit |

### 2.2 Store `waypoint-ai-ratelimit` (unchanged)

Per-IP counters for the Gemini-backed functions. Stage B adds the endpoints
`classify-scenes` (6/min/IP) and `lead-draft` (10/min/IP) to the same
mechanism. Fails open on infra errors, like every rate limit in the app.

### 2.3 Store `waypoint-leads` (★ Stage B5 — new)

| Key | Value | Notes |
|---|---|---|
| `lead:{ownerUid}:{leadId}` | full `Lead` JSON | **The owner uid in the key is derived server-side from the tour's `owner:{tourId}` record at capture time — a client can never choose whose CRM a lead lands in.** |
| `leadcontact:{ownerUid}:{contactKey}:{tourId}` | `{ leadId, at }` | dedupe marker; `contactKey` = normalised phone digits or lowercased email; 10-minute window |
| `ratelimit:…` | counters | capture rate limit (5/min/IP) |

```ts
Lead = {
  id: string; tourId: string;
  tourName: string;             // snapshot for CRM display
  stopId?: string; stopTitle?: string;   // scene context at enquiry time
  name?: string; phone?: string; email?: string;  // only what the visitor supplied
  message: string;
  consent: boolean;             // must be true at capture
  visitRequested?: boolean;     // ★ Stage C — visitor ticked "request a site visit"
  stage: "new" | "contacted" | "qualified" | "visit-requested"
       | "visit-scheduled" | "closed" | "not-interested";
  ownerUid: string;             // set by the server, never the client
  createdAt: number; updatedAt: number;
  nextActionAt?: number;        // agent's own follow-up date
  activities: LeadActivity[];   // capped at 200 entries
}

LeadActivity =
  | { id; kind: "stage-change"; at; fromStage?; toStage }
  | { id; kind: "note" | "contact-logged"; at; text }
  | { id; kind: "draft"; at; text; channel; language }   // AI draft trail
```

**Access model (enforced in code, proven by tests):**

- `capture-lead` (public): validation + honeypot + rate limit; routes to the
  tour owner's prefix; returns nothing about the owner.
- `leads-list` (agent): requires a verified Firebase ID token; lists ONLY
  `lead:{callerUid}:*` — another agent's leads are not addressable, so the
  list for anyone else is simply empty.
- `lead-update` / `lead-draft` (agent): verified token + the lead is loaded
  under the caller's own prefix + an explicit `ownerUid === caller.uid`
  check (defense in depth). Updates use optimistic concurrency
  (`expectedUpdatedAt` mismatch → 409).

### 2.4 Lead privacy

- Only the fields the visitor explicitly submitted are stored.
- Consent is required at capture and recorded on the lead.
- Agent notes stay in the same owner-scoped store; there is no cross-agent
  read path.
- **No message is ever claimed as sent**: AI drafts are drafts; the "Open in
  WhatsApp" action just pre-fills a message the agent must send themselves.

### 2.5 Store `waypoint-analytics` (★ Stage C — new)

| Key | Value | Notes |
|---|---|---|
| `stats:{tourId}:{YYYY-MM-DD}` | `TourDayStats` aggregate | one document per published tour per **UTC** day |
| `ratelimit:track:…` | counters | track-event rate limit (60/min/IP, fails open) |

```ts
TourDayStats = {
  date: string;                        // YYYY-MM-DD (UTC)
  events: { "tour-view" | "scene-view" | "hotspot"
          | "enquiry" | "visit-request": number };
  sources: { "direct" | "link" | "qr" | "wa" | "embed": number };
  scenes: Record<sceneId, number>;     // scene-VIEW opens only (hotspots excluded)
  uniques: string[];                   // truncated SHA-256 hashes of random visitor tokens
  uniquesCapped: boolean;              // true once uniques hits 5000 for the day
  updatedAt: number;
}
```

**Event writers:**

- `track-event` (public): accepts ONLY `tour-view`, `scene-view`,
  `hotspot`. The `enquiry` / `visit-request` kinds are refused — those are
  written by `capture-lead` server-side at the moment a real enquiry is
  stored, so a browser can never inflate conversion numbers.

**Access model:**

- `analytics-summary` (agent): verified ID token; each requested tour id is
  checked against its `owner:{tourId}` record — non-owned ids are silently
  excluded, so one agent's request can never read another's numbers.
- Reads are bounded: ≤ 15 tour ids, ≤ 90 day documents per tour (plus the
  previous window for the 7-day view), fetched in parallel chunks.

**Privacy model (documented on the Privacy page):**

- Aggregates only — no IPs, no user agents, no referrers, no event-level
  timestamps are stored.
- "Unique visitors" derive from a random, PII-free browser token; only a
  truncated one-way hash rests in storage, capped at 5000/day (beyond the
  cap the UI shows "5000+", never an invented number).
- Summed across days, uniques count visitor-days — labelled as an
  estimate in the dashboard, not a headcount.

**Consistency model:** each event is a read-modify-write of the day
 document; two simultaneous writes can lose one increment
 (last-write-wins). These are best-effort engagement counts, not billing
 records — the small undercount under extreme concurrency is the accepted
 trade-off for keeping one small document per day.

---

## 3. Migrations & safety

- **No destructive migration exists.** All Stage B fields are optional
  additions.
- `loadPlan()` (B2) validates any persisted plan before the editor touches
  it: an unknown NEWER `schemaVersion` is **rejected** (the editor offers a
  fresh start while KEEPING the old blob in the tour record); dangling wall/
  opening/room references are dropped **with warnings**; a `tourId` mismatch
  warns. Nothing is silently overwritten.
- Room geometry validity (≥3 corners, non-self-intersecting, non-collinear)
  is validated live in the editor and by `validateRoomRing`; invalid rooms
  are drawn red and **excluded from the 3D build** with an on-screen report.
- Lead updates are atomic (single JSON blob per lead) and
  conflict-detected.

---

## 4. Environment variables

No NEW environment variables were introduced by Stage B. Everything reuses
the Stage A set — see `.env.example` and `DEPLOY.md`. Summary of what each
new feature needs:

| Feature | Requires |
|---|---|
| Smart upload (local checks) | nothing |
| Smart upload (AI suggestions) | `GEMINI_API_KEY` (server) |
| Plan Studio (2D/3D) | nothing — fully local |
| Copywriter AI | `GEMINI_API_KEY` (server) |
| Lead capture + CRM | `FIREBASE_SERVICE_ACCOUNT_KEY` (server) — same as publishing |
| Lead AI follow-up drafts | `GEMINI_API_KEY` + the above |

---

## 5. Stage D (AI upgrade) — new stores & plan extensions

### 5.1 `waypoint-ai-usage` (Netlify Blobs) — aggregate usage tracking

Key: `usage:{scope}:{YYYY-MM-DD}` where scope is `uid:<verified-uid>` or
`ip:<client-ip>`. Value (one JSON doc per scope per UTC day):

```json
{ "features": { "analyze-floorplan": {
    "count": 3, "ok": 3, "failed": 0,
    "totalLatencyMs": 8450,
    "models": { "gemini-3.8-flash": 3 },
    "providers": { "gemini": 3 } } } }
```

`providers` (additive, Stage F) counts which provider answered — aggregate
counters only. Privacy: aggregate counters ONLY — no prompts, no image
data, no buyer details, no API keys are ever written here (test-asserted).
Docs expire after ~2 days. Quota enforcement (`AI_DAILY_QUOTA_*`) reads/
writes the same docs; cache hits skip quota entirely.

**Stage F — metrics doc** (same store, key `metrics:global`, ~30-day
expiry): `{ providers: { gemini|groq|mistral: { okCount, errCount,
lastOkAt, lastErrAt, lastErrKind, rateLimitEvents, quotaEvents,
breakerTrips } }, cache: { hits, misses }, updatedAt }` — best-effort
counters for the admin diagnostics page (`/admin/ai`); never contains
prompts, user ids, or error messages, only sanitized failure KINDS.

### 5.2 `waypoint-ai-cache` (Netlify Blobs) — safe AI result cache

Key: `{feature}:{sha256(feature|schemaVersion|model|canonicalInput)}` →
`{ savedAt, value }`. Stage F extended the cache beyond floor plans to
analyze-scene, classify-scenes, suggest-hotspots, suggest-sequence,
lead-draft, generate-marketing, and tour-assistant — each endpoint hashes
its FULL canonical input (every field that can change the result, e.g.
analyze-floorplan includes the panorama AND all perspective crops).
`value` is always the VALIDATED, sanitized server output. TTL via
`AI_CACHE_TTL_HOURS` (default 24h). No personal data is cached — the key
is a content hash, and identical inputs would have produced identical
outputs anyway. Concurrent identical requests are coalesced server-side
into ONE provider call (`withCoalescing`), and failures are never cached
as successes.

### 5.3 Floor-plan document extensions (schemaVersion stays 1)

Additive, optional fields — every pre-existing plan loads unchanged
(loader-tested):

- `FloorPlanDocument.concept?: PlanConceptMeta` — AI provenance:
  `generatedBy: "ai-concept-v1"`, `sourceStopId`, `generatedAt`, `model`,
  `uncertaintyNotes[]`, and `generatedSnapshot` (the pristine converted
  document enabling "reset to generated layout"; the snapshot's own
  `concept.generatedSnapshot` is stripped to prevent nesting).
- `PlanFloor.furniture?: PlanFurniture[]` — `{ id, kind (16-item
  whitelist), label?, x, y (center, plan units), w, h (nominal sizes),
  rotation°, uncertain? }`. AI-placed items carry `uncertain: true` until
  the agent edits them; user-placed items never do.
- `PlanOpening.uncertain?: boolean` — same rule for AI-placed doors/windows.

### 5.4 Concept analysis wire format (`/api/analyze-floorplan`)

Server-validated before anything renders: `schemaVersion: 1`, `roomType`,
`confidence` (0..1 clamped), `roomOutline` (3..24 normalized points,
0..1 clamped), `walls` (≤40 segments, `certain` flags), `openings`
(≤24, kind door|window, nearest-wall projection client-side),
`furniture` (≤40, kind whitelist with `other` fallback, clamped),
`uncertaintyNotes` (≤6). Malformed/insufficient responses are rejected
with an honest 502 — never repaired into a fake plan.

### 5.5 Stage D environment variables (all OPTIONAL)

`AI_DAILY_QUOTA_DEFAULT` (40), `AI_DAILY_QUOTA_ANALYZE_FLOORPLAN` (10),
`AI_DAILY_QUOTA_INTERIOR_CONCEPT` (10), `AI_DAILY_QUOTA_LEAD_INSIGHTS`
(30), `AI_DAILY_QUOTA_GENERATE_MARKETING` (30), `AI_CACHE_TTL_HOURS` (24).
Feature requirements: Concept Floor Plan analysis and lead insights need
sign-in + `FIREBASE_SERVICE_ACCOUNT_KEY` + `GEMINI_API_KEY`; interior
concepts need the same plus the (paid-tier) image model; all AI quotas and
fallback knobs are documented in `.env.example` / `NETLIFY-SETUP.md`.
